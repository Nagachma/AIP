PRE-REQUISITES:

1.Kubernetes Cluster

2.Namespace

3.Custom values.yaml(xops-ci-values.yaml)

The Airflow has been deployed through Bitnami helm chart

default values.yaml = https://github.com/bitnami/charts/blob/main/bitnami/airflow/values.yaml

custom values.yaml = https://dev.azure.com/aipplus/xOps/_git/xops?path=/charts/ci/xops-ci-values.yaml

azure-pipeline.yaml = https://dev.azure.com/aipplus/xOps/_git/xops?path=/azure-pipelines.yml

Azure pipeline = https://dev.azure.com/aipplus/xOps/_build?definitionId=113

If you want to make any changes in azure-pipelines.yaml related to airflow deployment, please update HelmDeploy@0 task on line no. 106

*Dev Environment details:*

Airflow URL : http://airflow-xops-dev.rapiddev.accentureanalytics.com/home

Username: xops 

Kubernetes namespace : xops-dev 

Variables group: xops-dev

Dags repo : https://dev.azure.com/aipplus/xOps/_git/airflow?path=%2F&version=GBAirflow&_a=contents

*QA Environment details:*

Airflow URL: http://airflow.xops-qa.accentureanalytics.com/home

Username: xops

Kubernetes namespace : xops-backend

Dags repo : https://dev.azure.com/aipplus/xOps/_git/airflow?path=%2F&version=GBqa&_a=contents

*References:*

https://artifacthub.io/packages/helm/bitnami/airflow



