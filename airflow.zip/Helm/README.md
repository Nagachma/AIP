#PRE-REQUISITES:
1. Kubernetes Cluster
2. Namespace  
3. Custom values.yaml(airflow-values.yaml)
4. EFS - File Store 

#EFS CREATION:
Steps to create Amazon EFS file system:
1. Open the Amazon EFS Management Console 
2. Choose Create file system to open the Create file system dialog box.
3. Enter a Name for your file system. [**xops-airflow-logs**]
4. For Virtual Private Cloud (VPC), choose your VPC, or keep it set to your default VPC.
5. For Availability and Durability, choose one of the following:
- Regional to create a file system that uses Standard storage classes. Standard storage classes store file system data and metadata redundantly across all Availability Zones within an AWS Region. Regional offers the highest levels of availability and durability.
- One Zone to create a file system that uses One Zone storage classes. One Zone storage classes store file sytem data and metadata redundantly within a single Availability Zone which makes it less expensive than Standard storage classes.  
In this case, we chose **One Zone** - **"us-east-1a"**
6. Choose Create to create a file system
7. The File systems page appears with a banner across the top showing the status of the file system you created. A link to access the file system details page appears in the banner when the file system becomes available.
![image](C:\Users\arbadit.chowdhury\Downloads\airflow1.png)
#EFS PROVISIONER
To attach the efs, a provisioner pod has to be created in default namespace
```
-helm repo add isotoma https://isotoma.github.io/charts/  
-helm install efs-provisioner isotoma/efs-provisioner --version 0.14.0  --set efsProvisioner.efsFileSystemId=fs-0970c2caf0e9ab69f --set efsProvisioner.awsRegion=us-east-1
```

#PVC CREATION to claim storage:
Steps to create a PVC, kubectl apply -f airflow-pvc.yaml -n aiops

airflow-pvc.yaml:
```
kind: PersistentVolumeClaim
apiVersion: v1
metadata:
  name: airflow-pvc
spec:
  storageClassName: aws-efs
  accessModes:
    - ReadWriteMany
  resources:
    requests:
      storage: 1Gi
```

#STEPS TO INSTALL AIRFLOW HELM CHART:

```
- helm repo add apache-airflow https://airflow.apache.org
- helm repo update
- helm upgrade --install airflow apache-airflow/airflow -f airflow-values.yaml -n aiops --version 1.6.0
```

#TROUBLESHOOTING
 *DNS issue* 
TRY 
`nslookup fs-0970c2caf0e9ab69f.efs.us-east-1.amazonaws.com`
Deploy dnsutil pod in default namespace,
perform kubectl exec for dnsutil pod and try 
```
nslookup fs-0970c2caf0e9ab69f.efs.us-east-1.amazonaws.com
nslookup efs.us-east-1.amazonaws.com
telnet efs.us-east-1.amazonaws.com 2049
```
`kubectl get configmap -n kube-system`
`kubectl get configmap core-dns -n kube-system -o yaml`
Add this in configmap for core-dns
```
    efs.us-east-1.amazonaws.com:53 {
        forward . 10.253.160.2
        cache 30
    }
```
 
#REFERENCE:
1. https://airflow.apache.org/docs/helm-chart/stable/index.html
2. https://github.com/airflow-helm/charts/tree/main/charts/airflow
3. https://docs.aws.amazon.com/efs/latest/ug/gs-step-two-create-efs-resources.html