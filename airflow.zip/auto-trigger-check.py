from datetime import datetime
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator

def print_hello():
    return 'Hello world from first Airflow DAG!'

def print_hello_a():
    return 'Task B Triggered!'

def print_hello_b():
    return 'Task C Triggered!'

def print_hello_c():
    return 'Task D Triggered!'

dag = DAG('auto-trigger-check', description='Hello World DAG',
          schedule_interval='0 12 * * *',
          start_date=datetime(2017, 3, 20), catchup=False)

hello_operator_1 = PythonOperator(task_id='hello_task_1', python_callable=print_hello, dag=dag)

hello_operator_2 = PythonOperator(task_id='hello_task_2', python_callable=print_hello_a, dag=dag)

hello_operator_3 = PythonOperator(task_id='hello_task_3', python_callable=print_hello_b, dag=dag)

hello_operator_4 = PythonOperator(task_id='hello_task_4', python_callable=print_hello_c, dag=dag)

hello_operator_1 >> [hello_operator_2,hello_operator_3] >> hello_operator_4