from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.models import DagModel, DagRun
from datetime import datetime, timedelta
from smtplib import SMTP
import pytz

__author__ = 'prudhvi'
__version__ = '0.1.1'   # 2023-06-15

def send_mail(subject, message, time_range, **kwargs):
    """Send an email with DAG information

    Args:
        subject: subject of the email
        message: message content to send
    """
    host = kwargs.get('host')
    port = kwargs.get('port')
    from_address = kwargs.get('from_address')
    to_addresses = kwargs.get('to_addresses')
    body = ''

    body = f'\nNo successful runs found for below DAGs in last {time_range} minutes:\n' + '\n'.join(str(line) for line in message)
    print(body)

    with SMTP(host, port) as server:
        response = server.sendmail(from_addr=from_address, to_addrs=to_addresses, msg=f'Subject: {subject}\n' + body)

    if response:
        print(f"Failed to send mail to below addresses: {list(response.keys())}")


def get_last_dag_run_status(dag_id):
    """ Returns the status of the last dag run for the given dag_id 
    
    Args:
        dag_id (str): The dag_id to check
    Returns:
        List - The status of the last dag run for the given dag_id
        List - The last execution date of the dag run for the given dag_id
    """
    dag = DagModel.get_dagmodel(dag_id)

    if dag is None:
        return ['DAG does not exist', None]

    last_dag_run = dag.get_last_dagrun(include_externally_triggered=True)

    if last_dag_run is None:
        return ['No previous runs found', None]

    return [last_dag_run.state, last_dag_run.execution_date]


def get_task_status(dag_id, task_id):
    """ Returns the status of the last dag run for the given dag_id

    Args:
        dag_id (str): The dag_id to check
        task_id (str): The task_id to check
    Returns:
        List - The status of the last dag run for the given dag_id
    """
    last_dag_run = DagRun.find(dag_id=dag_id)
    last_dag_run.sort(key=lambda x: x.execution_date, reverse=True)

    if last_dag_run:
        return last_dag_run[0].get_task_instance(task_id).state
    else:
        return


def get_dags_status(**kwargs):
    # load configuration
    utc=pytz.UTC
    env = kwargs.get('environment')
    dags_to_monitor = kwargs.get('dags_to_monitor')
    dags_monitoring_time_range_in_minutes = float(kwargs.get('dags_monitoring_time_range_in_minutes'))
    smtp_configuration = kwargs.get('smtp_configuration')

    current_time = datetime.now().replace(tzinfo=utc)
    # take twice of defined time range due to airflow scheduling naming issues. Refer: https://github.com/puckel/docker-airflow/issues/281
    last_run_time_range = current_time - timedelta(minutes=2*dags_monitoring_time_range_in_minutes)
    mail_subject = f"{env} | DAG status | {current_time.strftime('%Y-%m-%d %H:%M:%S')}"
    mail_body = []

    for dag_id in dags_to_monitor:
        status, last_exec_date = get_last_dag_run_status(dag_id)
        if status.lower() in ['success'] and last_exec_date is not None and last_run_time_range <= last_exec_date.replace(tzinfo=utc):
            pass        # positive case: if last run is successful and is within expected time range
        else:           # negative cases
            mail_body.append(f"DAG: {dag_id} | Last Execution Date: {last_exec_date.strftime('%Y-%m-%d %H:%M:%S.%f') if last_exec_date is not None else 'None'} | Status: {status}")

    if mail_body:
        send_mail(mail_subject, mail_body, dags_monitoring_time_range_in_minutes, **smtp_configuration)


with DAG(
  'dag-monitor',
  catchup = False,
  is_paused_upon_creation = False,
  start_date = datetime(2023, 6, 5),
  schedule_interval= '10,40 * * * *'
) as dag:

    t3 = PythonOperator(
        task_id = 'get_dags_status',
        python_callable = get_dags_status,
        op_kwargs = {
            'environment': 'SGWS Prod',
            'dags_to_monitor': ['metric_processor','correlation_engine'],
            'dags_monitoring_time_range_in_minutes': 30,
            'smtp_configuration': {
                'host': '10.254.251.153',
                'port': 465,
                'from_address': 'no-reply@accentureanalytics.com',
                'to_addresses': ['prudhvi.l.chelluri@accenture.com', 'santhosh.prabakaran@accenture.com', 'sriram.thayumanasamy@accenture.com']
            }
        }
    )
