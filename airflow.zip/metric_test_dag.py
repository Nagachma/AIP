
from airflow import DAG
from datetime import datetime, timedelta
from airflow.contrib.operators.kubernetes_pod_operator import KubernetesPodOperator
from airflow.operators.dummy_operator import DummyOperator


with DAG(
    start_date=datetime(2022,9,14),
    catchup=False,
    schedule_interval='*/5 * * * *',
    dag_id='metric_test_dag_1'
) as dag:

    metric_task_test = KubernetesPodOperator(
        namespace='airflow',
        image="registry.dev.accentureanalytics.com/xops/dmregistry/template-testing:typer_changes-metric",
        arguments=["--airflow"],
        labels={"env": "dev"},
        name="metric_demo",
        task_id="metric_run_demo",
        image_pull_policy="Always",
        get_logs=True,
        do_xcom_push=True,
        is_delete_operator_pod=True,
        dag=dag
        )
    

