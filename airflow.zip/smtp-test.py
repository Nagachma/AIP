from datetime import datetime
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
# import os
import smtplib


def print_hello():
    # return 'Hello world from first Airflow DAG!'
    print("hello")
    # print(os.environ['AIRFLOW__API__AUTH_BACKEND'])
    # print(os.environ['AIRFLOW__SMTP__SMTP_HOST'])
    host = '10.254.251.153'
    port = 465  #25
    with smtplib.SMTP(host, port) as server:
        resp = server.sendmail('no-reply@accentureanalytics.com', 'prudhvi.l.chelluri@accenture.com', 'Hello from DAG')
    print(resp)

    raise ValueError("This task is Failed")

default_args = {
    'owner': 'airflow',
    'start_date': datetime(2023, 3, 5),
    # 'retries': 1,
    'email': ['prudhvi.l.chelluri@accenture.com'],
    'email_on_failure': True,
    'email_on_retry': True
}

# def print_hello():
#     # return 'Hello world from first Airflow DAG!'
#     return False

# dag = DAG(
#     'example_dag',
#     default_args=default_args,
#     catchup=False
# )

with DAG('fail_email_test', default_args=default_args,schedule_interval=None) as dag:
    smtp_operator = PythonOperator(task_id='smtp_test', python_callable=print_hello)

smtp_operator