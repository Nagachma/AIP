from airflow import DAG
from datetime import datetime, timedelta
from airflow.contrib.operators.kubernetes_pod_operator import KubernetesPodOperator
from airflow.operators.dummy_operator import DummyOperator


default_args = {
    'owner': 'airflow-test',
    'depends_on_past': False,
    'start_date': datetime.utcnow(),
    'email': ['airflow@example.com'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5)
}

dag = DAG(
    'kubernetes_operator_test', default_args=default_args, schedule_interval=timedelta(minutes=10))


start = DummyOperator(task_id='run_this_first', dag=dag)

task_test = KubernetesPodOperator(namespace='xops-dev',
                          image="registry.dev.accentureanalytics.com/xops/dmregistry/template-testing:testing",
                          image_pull_secrets="gitlabregsecret",
                          cmds=["python3","-c"],
                          arguments=["print('hello world')"],
                          labels={"foo": "bar"},
                          name="demo",
                          task_id="run_demo",
                          get_logs=True,
                          dag=dag
                          )

task_test.set_upstream(start)
