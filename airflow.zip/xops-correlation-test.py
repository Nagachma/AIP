from airflow import DAG
from datetime import datetime, timedelta
from airflow.contrib.operators.kubernetes_pod_operator import KubernetesPodOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.decorators import task


default_args = {
    'owner': 'airflow',
    'retries': 5,
    'retry_delay': timedelta(minutes=3)
}

with DAG(
    start_date=datetime(2022,9,14),
    catchup=False,
    schedule_interval='@daily',
    default_args=default_args,
    dag_id='xops_correlation_test'
) as dag:

    aiops_task_test = KubernetesPodOperator(
        namespace='xops-dev',
        image="registry.dev.accentureanalytics.com/xops/dmregistry/correlation_test:correlation_test",
        image_pull_secrets="gitlabregsecret",
        labels={"env": "dev"},
        name="xops_correlation",
        task_id="xops_correlation",
        image_pull_policy="Always",
        get_logs=True,
        do_xcom_push=False,
        is_delete_operator_pod=True,
        dag=dag
        )
