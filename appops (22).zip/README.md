
#Introduction 

AppOps - this repository houses all the required utilities and configuration files per tool along-with how to enable each tool for metric collection and ingestion.

# Developers Checklist 
https://dev.azure.com/aipplus/Performance%20Engineering/_wiki/wikis/Performance-Engineering.wiki/5427/Developer's-Checklist-for-DM-Tool-Metrics

# Tools Developed:
1. AWS:
    * S3
    * Glue
    * Redshift
    * RDS
    * Lambda
    * Sagemaker
2. Azure:
    * Azure SQL
    * Azure Datafactory
    * Azure Databricks
    * AKS clusters
    * Azure ML
    * Synapse Analytics
    * Azure Blob Storage / ADLS Gen1 / ADLS Gen2
    
**[More tools to be added]

Service	| Priority
--- | ---
--- AWS | ---
AWS Glue |	1
Lambda |	1
Sagemaker |	1
S3 |	1
EC2 |	1
--- Azure | ---
Data Factory |	2
AKS |	2
Storage Account |	2
Synapse |	2
Azure ML |	2
--- GCP | ---
PubSub |	3
Cloud Storage |	3
Cloud SQL |	3
Cloud BigTable |	3
BigQuery |	3
DataFlow |	3
DataProc |	3
GKE |	3


# Tools Config:

Link: https://ts.accenture.com/sites/AIPPETeam/Shared%20Documents/Deep%20Monitoring/deep%20monitoring/DM_Tool_Config.xlsx?web=1  

Sample Example:
Tools|Metrics source|Access Requirements|Enablement Requirements|Performance Implication|Cost Implication|Steps to achieve the requirement
--- | --- | --- | --- |--- |--- |--- 
Lambda|1.CloudWatch 2. Lambda Insights 3. Custom|IAM service account user. AWS Access key & Secret key. 1. CloudWatchReadonlyAccess. 2. AWSLambdaBasicExecutionRole & Log groups name.|Enabling: Can be enabled in console, CLI, etc. by client without making changes in code. (Source: https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/Lambda-Insights-Getting-Started.html )|Performance impact: Extensions can impact the performance of your function because they share function resources such as CPU, memory, and storage. For example, if an extension performs compute-intensive operations, you may see your function's execution duration increase. Each extension must complete its initialization before Lambda invokes the function. (Source)| Cost impact: You are charged for the execution time consumed by the Lambda extension, in 1ms increments. (Source: https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/Lambda-Insights.html). When you enable Lambda Insights for your Lambda function, Lambda Insights reports 8 metrics per function and every function invocation sends about 1KB of log data to CloudWatch. You only pay for the metrics and logs reported for your function by Lambda Insights. There are no minimum fees or mandatory service usage polices. You do not pay for Lambda Insights if the function is not invoked (Source: https://docs.aws.amazon.com/lambda/latest/dg/monitoring-insights.html)
 

# Getting Started
TODO: Guide users through getting your code up and running on their own system. In this section you can talk about:
1.	Installation process
2.	Software dependencies
3.	Latest releases
4.	API references

# Build and Test
Refer to readmes under each tool on how to build your code and run the tests. 

