# Connector Monitor

Monitor the connectors status using heartbeats.

## Installation

1. Requires the following:

    ```
    python >= 3.9
    pip >= 20.0
    smtp connection
    ```

2. Install pip dependencies

    ```
    pip install -r requirements.txt
    ```

## Execution

1. Navigate to the project directory.
2. Configure `connector_monitor.yaml` as per requirements.
3. Execute the script:

    ```
    python connector_monitor.py
    ```

4. Custom configuration can be passed with `-c` flag. Check `python connector_monitor.py -h` for more details.
5. Set it up as a cronjob for continuous monitoring. Sample crontab to run every 5 minutes with 1 minute buffer before collecting heartbeats:
    ```
    */5 * * * * /bin/su -c "sleep 1m && cd /data01/appops/common-utility/appops-monitor && python3 connector_monitor.py" - dmuser
    ```

## Testing

1. Validate if smtp connection is working

    ```
    python tests/test_smtp.py
    ```

2. Sample heartbeat record:

    ```
    {
        "_id": {
            "$oid": "649ed125c03674a9262e9216"
        },
        "connectors": [
            {
                "connector": "sqlserver",
                "last_successful_ingestion_time": {
                    "$date": "2023-06-30T13:00:00.000Z"
                },
                "status_code": 1
            },
            {
                "connector": "powerbi",
                "last_successful_ingestion_time": {
                    "$date": "2023-06-30T11:00:00.000Z"
                },
                "status_code": 3
            }
        ]
    }
    ```

3. Sample monitoring output:

    ```
    0(dmuser@shiueccpaioai01 [~/AppOps-Monitor])$ python3.9 connector_monitor.py
    [2023-06-30 13:14:36] INFO: Checking heartbeat status for connector [sqlserver]...
    [2023-06-30 13:14:36] INFO: sqlserver: Last Successful Ingestion Time [2023-06-30 13:00:00+00:00] is within alert threshold [30 min]
    [2023-06-30 13:14:36] INFO: Checking heartbeat status for connector [powerbi]...
    [2023-06-30 13:14:36] INFO: powerbi: Last Successful Ingestion Time [2023-06-30 11:00:00+00:00] is not within alert threshold [30 min]
    [2023-06-30 13:14:36] WARNING: powerbi: Last Successful Ingestion Time [2023-06-30 11:00:00+00:00] is not within alert threshold [30 min]
    [2023-06-30 13:14:36] INFO: Sending alert...
    ```

## Next Steps / Future release
 - Add log rotation to avoid increasing log file size
