'''
This script periodically monitors the connectors status based on their heartbeat information
'''
__author__ = 'Prudhvi Chelluri'
__email__ = 'prudhvi.l.chelluri@accenture.com'
__version__ = '0.1.0'   # 2023-06-22


import argparse
import logging
import os
import pytz
import sys
import yaml
from datetime import datetime, timedelta
from pymongo import MongoClient, DESCENDING
from smtplib import SMTP
from vault_utility_v2 import vault_credentials

utc = pytz.UTC
# message to display as per status code
error_code_mapping = {
    1: 'Ingestion successful',
    2: 'No new metrics to ingest',
    3: 'Ingestion failed'
}

log_levels = {
    'DEBUG': logging.DEBUG,
    'INFO': logging.INFO,
    'WARNING': logging.WARNING,
    'ERROR': logging.ERROR
}

class SMTPUtil():
    '''SMTP implementation for alerts'''
    def __init__(self, **kwargs):
        self.host = kwargs.get('host')
        self.port = kwargs.get('port')
        self.from_address = kwargs.get('from_address')
        self.to_addresses = kwargs.get('to_addresses')

    def send_mail(self, subject: str, message: list):
        '''Send an email using smtp library

        Args:
            subject: subject of the email
            message: message content to send
        '''
        body = ''

        body = f'\nNo successful runs found for below connectors:\n' + '\n'.join(str(line) for line in message)
        logging.debug(body)

        with SMTP(self.host, self.port) as server:
            response = server.sendmail(from_addr=self.from_address, to_addrs=self.to_addresses, msg=f'Subject: {subject}\n' + body)

        if response:
            logging.error(f"Failed to send mail to below addresses: {list(response.keys())}")

class MongoUtil():
    '''Utility class for MongoDB transactions'''
    def __init__(self, **kwargs):
        self.connection_uri = kwargs.get('connection_uri')
        self.database = kwargs.get('database')
        self.collection = kwargs.get('collection')
        # create mongodb connection
        self.create_connection()

    def create_connection(self):
        '''create a new database connection'''
        logging.debug('MongoDB connection created')
        self.mongo_client = MongoClient(self.connection_uri, tz_aware=True)
        self.db = self.mongo_client.get_database(self.database)
        self.collection = self.db.get_collection(self.collection)

    def insert(self, records: list):
        '''insert list of records into database'''
        logging.debug(f'Inserting {len(records)} records into database')
        self.collection.insert_many(records)

    def read(self, query={}):
        '''return latest one record from database'''
        logging.debug('Fetching data from database')
        # docs = self.collection.find(query).sort('_id', DESCENDING).limit(1)
        # result = [ doc for doc in docs ]
        # since the heartbeat contains only one record, we can simply query the collection without any filters
        result = self.collection.find_one(query)

        return result

    def close_connection(self):
        '''close mongo connection'''
        if self.mongo_client:
            logging.debug('Closing mongo connection')
            self.mongo_client.close()

def load_yaml(config_file):
    '''Load yaml configuration

    Args: configuration file
    Returns: yaml file as dict
    '''
    # check if config file exists
    if not os.path.isfile(config_file):
        logging.info(f'Configuration file not found [{config_file}]')
        exit(1)

    config = {}
    with open(config_file, 'r') as conf:
        try:
            config = yaml.safe_load(conf)
        except yaml.YAMLError as ye:
            logging.info(f'Error loading config file: {ye}')
            exit(1)

    return config

def get_mongouri_from_vault(**config) -> dict:
    '''Retrieve the mongodb connection uri from the vault

    Args: config containing use_vault, vault_path, vault_keys
    Returns: dict of configuration
    '''
    vault_conf = {}
    if config['use_vault']:
        # import vault utilities
        # from vault_utility_v2 import vault_credentials
        vault_conf = vault_credentials.get_secret_from_vault(config['vault_path'], config['vault_keys'])

    return vault_conf.get('mongo_url')

def check_alert_threshold(timestamp, threshold) -> bool:
    '''Check if given time is within alert threshold

    Args:
        timestamp: timestamp to check against
        threshold: alert threshold time in minutes

    Returns:
        bool: True if time is within alert threshold
    '''
    if timestamp is None:
        return False
    timestamp = timestamp.astimezone(utc)
    threshold_timestamp = datetime.now().astimezone(utc) - timedelta(minutes=threshold)
    logging.debug(f'Calculated timestamp (in UTC): [{timestamp}], Error threshold timestamp (in UTC): {threshold_timestamp}')

    return threshold_timestamp < timestamp


if __name__ == '__main__':
    # get cli arguments
    parser = argparse.ArgumentParser(description='monitor the status of the connectors')
    parser.add_argument('-c', '--config', type=str, default='connector_monitor.yaml', help='configuration file')
    parser.add_argument('-v', '--version', action='version', version=f'{os.path.basename(__file__)} v{__version__}')

    args = parser.parse_args()
    config_file = args.config

    config = load_yaml(config_file)
    default_threshold = config.get('default_error_threshold_time_in_minutes')
    # create logging handler
    if config.get('LOGGING').get('log_to_file'):
        logging_config = {
            'filename': config.get('LOGGING').get('log_filename'),
            'filemode': config.get('LOGGING').get('log_filemode')
        }
    else:
        logging_config = {'stream': sys.stdout}
    logging_config['level'] = log_levels.get(config.get('LOGGING').get('log_level').upper())
    logging.basicConfig(format='[%(asctime)s] %(levelname)s: %(message)s', datefmt='%Y-%m-%d %H:%M:%S', **logging_config)

    ############################### MAIN ####################################
    try:
        alerts = []
        mongo_util = None
        # init mail utility
        mail_util = SMTPUtil(**config['SMTP_CONFIG'])
        mail_subject = f"{config['SMTP_CONFIG']['environment']} | AppOps-Monitor | {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        # get mongo uri from Vault
        # mongo_uri = get_mongouri_from_vault(**config['VAULT_CONFIG'])
        mongo_uri = None
        try:
            mongo_uri = get_mongouri_from_vault(**config['VAULT_CONFIG'])
        except Exception as e:
            logging.error(f'Error occured: {e}')
            vault_msg = f'Unable to fetch Mongo Uri from vault due to below error \n {e}'
            alerts.append(vault_msg)
            mail_util.send_mail(mail_subject, alerts)
            exit()
        if mongo_uri:
            config['MONGODB_CONFIG']['connection_uri'] = mongo_uri
        # init mongo utility
        mongo_util = MongoUtil(**config['MONGODB_CONFIG'])
        data = mongo_util.read()
        # logging.debug(f'Data retrieved: {data}')
        if data.get('connectors') is None:
            raise Exception('Connectors list not found in the collection')

        connector_col = config['MONGODB_CONFIG']['column_mapping']['connector_name']
        last_ingestion_time_col = config['MONGODB_CONFIG']['column_mapping']['last_ingestion_time']
        status_code_col = config['MONGODB_CONFIG']['column_mapping']['status_code']

        for item in data['connectors']:
            threshold = None
            connector = item.get(connector_col)
            if connector is None:
                continue    # skip
            logging.info(f'Checking heartbeat status for connector [{connector}]...')
            last_ingestion_time = item.get(last_ingestion_time_col)
            status_code = item.get(status_code_col)
            # set connector specific threshold else use default
            if config.get('connector_specific_thresholds'): threshold = config.get('connector_specific_thresholds').get(connector)
            if threshold is None: threshold = default_threshold

            is_within_alert_threshold = check_alert_threshold(last_ingestion_time, threshold)
            status = '' if is_within_alert_threshold else 'not '
            msg = f'{connector}: Last Successful Ingestion Time [{last_ingestion_time}] is {status}within alert threshold [{threshold} min]'
            if is_within_alert_threshold:
                logging.info(msg)
            else:
                logging.warning(msg)
                alerts.append(msg)

        if alerts:
            # send email alert
            logging.info('Sending alert...')
            mail_util.send_mail(mail_subject, alerts)

    except Exception as e:
        logging.error(f'Error occured: {e}')

    finally:
        if mongo_util: mongo_util.close_connection()
