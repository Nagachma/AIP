from smtplib import SMTP
import os
import yaml

class SMTPUtil():
    '''SMTP implementation for alerts'''
    def __init__(self, **kwargs):
        self.host = kwargs.get('host')
        self.port = kwargs.get('port')
        self.from_address = kwargs.get('from_address')
        self.to_addresses = kwargs.get('to_addresses')

    def send_mail(self, subject: str, message: list):
        '''Send an email using smtp library

        Args:
            subject: subject of the email
            message: message content to send
        '''
        body = f'\n' + '\n'.join(str(line) for line in message)

        with SMTP(self.host, self.port) as server:
            response = server.sendmail(from_addr=self.from_address, to_addrs=self.to_addresses, msg=f'Subject: {subject}\n' + body)

        if response:
            print(f"Failed to send mail to below addresses: {list(response.keys())}")

def load_yaml(config_file):
    '''Load yaml configuration

    Args: configuration file
    Returns: yaml file as dict
    '''
    # check if config file exists
    if not os.path.isfile(config_file):
        print(f'Configuration file not found [{config_file}]')
        exit(1)

    config = {}
    with open(config_file, 'r') as conf:
        try:
            config = yaml.safe_load(conf)
        except yaml.YAMLError as ye:
            print(f'Error loading config file: {ye}')
            exit(1)

    return config

# load configuration
config = load_yaml('connector_monitor.yaml')

# init mail utility
mail_util = SMTPUtil(**config['SMTP_CONFIG'])

# send test mail
print("Sending test mail. If you don't see any error after this, then we are good to go.")
mail_util.send_mail('Test mail', ['This is a test mail'])
