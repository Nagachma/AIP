#Description - Script to add job names from all the deployed connectors in client env to a single collection which will be used for inventory service.

steps to run:
- Deploy the scripts in the client env.
- change the services in config file to include connectors which are deployed in client.
- setup the cron.

``` 
## INVENTORY
*/10 * * * * /bin/su -c "/data01/appops/py39venv/bin/python /data01/inventory/standalone_inventory_collection.py > /data01/inventory/inventory.log 2>&1" - dmuser
```

frequency of cron is 10 minutes