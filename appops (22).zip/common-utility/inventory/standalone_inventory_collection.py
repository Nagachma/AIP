import boto3
import json
import pymongo
import datetime
import yaml
from vault_utility_v2 import vault_credentials

def read_yaml(filename):
    """ A function to read YAML file"""
    with open(filename) as f:
        config = yaml.safe_load(f)
    return config

def write_document(inventories):
    document = {}
    for i in inventories:
        Active = []
        Deleted = []
        for j in inventories[i]:
            new_doc = {
                "name": j,
                "LastModifiedOn": "",
                "user": '',
                "Created_On": ''
            }
            Active.append(new_doc)
        document[i] = {'Active': Active,'Deleted': Deleted}
        # document[i]['Active'] = Active
        # document[i]['Deleted'] = Deleted

    return (document)

if __name__ == "__main__":
    config = read_yaml('/home/dmuser/inventory/config.yaml')
    services = config['services']
    mongo_cred = vault_credentials.get_secret_from_vault(config['mongo_vault_path'], config['mongo_vault_keys'])
    mongourl = mongo_cred.get('mongo_url')


    myclient = pymongo.MongoClient(mongourl)
    mydb = myclient[mongo_cred.get('mongo_db')]
    inventories = {}
    for i in services:
        job_name = []
        collection = mydb[i]
        dict = collection.find().sort("_id", -1).limit(10)
        for doc in dict:
            for name in (doc[config[i]['dimension']]):
                job_name.append(name[config[i]['jobname']])

        res = [*set(job_name)]
        inventories[i] = res


    documents = write_document(inventories)

    write_collection = mydb['standalone_inventory']

    write_collection.delete_many({})

    insert_result = write_collection.insert_one(documents)
