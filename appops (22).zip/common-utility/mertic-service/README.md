# metrics service 

## Dev setup (mac)
1. Install Python 3.10
2. Install MongoDB 6, create DB timeseries  
3. Install poetry package manager https://python-poetry.org/docs/ 
4. clone repo 
5. run ```poetry shell```
6. run ```poetry install```
7. run ```python3 --version``` to confirm version 
8. run ```python3.10 -m metricservice.main``` to run service
9. run ```poetry build``` to share wheel file
10. run ```poetry shell``` use next time onwards to start working

## How to add new resources
1. add model 
2. add router 
3. add router app.py
4. add model name in database.py list 
5. Test 
6. Update document 

## Testing (Glue)
1. Test Data can be inserted using tests folder glue-http.http requests file 
``` 
POST http://0.0.0.0:8000/gluemetrics/
accept: application/json
Content-Type: application/json

{
  "source": {
    "region": "us-east",
    "env": "dev",
    "service_provider": "AWS"
  },
  "ts": "2022-10-02T10:24:54.303Z",
  "jobs": [
    {
      "jobname": "cwtest-dev",
      "runs": [
        {
          "job_run_id": "jr_b6bd37db87d3ff3a9eb46b6d4536755f74c0e694ac7b982ddd5e5a89b7b3a7e4",
          "glue.driver.jvm.heap.usage": "0.027944192",
          "glue.driver.aggregate.bytesRead": "6604776",
          "glue.driver.aggregate.elapsedTime": "33332",
          "glue.driver.aggregate.numCompletedStages": "6",
          "glue.driver.aggregate.numCompletedTasks": "6",
          "glue.driver.aggregate.numFailedTasks": "0",
          "glue.driver.aggregate.numKilledTasks": "0",
          "glue.driver.aggregate.recordsRead": "110034",
          "glue.driver.aggregate.shuffleBytesWritten": "0",
          "glue.driver.aggregate.shuffleLocalBytesRead": "0",
          "glue.driver.BlockManager.disk.diskSpaceUsed_MB": "0",
          "glue.ALL.jvm.heap.usage": "0.038659182",
          "glue.driver.jvm.heap.used": "299076952",
          "glue.ALL.jvm.heap.used": "413754704",
          "glue.driver.s3.filesystem.read_bytes": "0",
          "glue.ALL.s3.filesystem.read_bytes": "2201592",
          "glue.driver.s3.filesystem.write_bytes": "0",
          "glue.ALL.s3.filesystem.write_bytes": "2274336",
          "glue.driver.system.cpuSystemLoad": "0.004172926",
          "glue.ALL.system.cpuSystemLoad": "0.004089126",
          "ExecutionTime": "65606",
          "JobRunState": "STOPPED",
          "StartedOn": "2022-08-10 10:31:37",
          "LastModifiedOn": "2022-08-11 04:45:17",
          "CompletedOn": "2022-08-11 04:45:17",
          "AllocatedCapacity": "10",
          "WorkerType": "G.1X",
          "NumberOfWorkers": "10",
          "GlueVersion": "2.0",
          "ErrorMessage": ""
        }
      ]
    }
  ]
} 
```
2. Example query curl to this URL with params
```
   GET http://127.0.0.1:8000/gluemetrics/?start_date=2022-10-01 10:20:51&end_date=2022-10-05 10:21:51&env=prod
   Accept: application/json

```
Response 
```
{
  "service_provider": "",
  "env_name": "prod",
  "account_id": "",
  "start_time": "2022-10-01 10:20:51",
  "end_time": "2022-10-05 10:21:51",
  "metrics": {
    "dimension": [
      "jobname"
    ],
    "metric_name": [
      "jobname",
      "run_id",
      "glue.driver.jvm.heap.usage",
      "glue.driver.aggregate.bytesRead",
      "glue.driver.aggregate.elapsedTime",
      "glue.driver.aggregate.numCompletedStages",
      "glue.driver.aggregate.numCompletedTasks",
      "glue.driver.aggregate.numFailedTasks",
      "glue.driver.aggregate.numKilledTasks",
      "glue.driver.aggregate.recordsRead",
      "glue.driver.aggregate.shuffleBytesWritten",
      "glue.driver.aggregate.shuffleLocalBytesRead",
      "glue.driver.BlockManager.disk.diskSpaceUsed_MB",
      "glue.ALL.jvm.heap.usage",
      "glue.driver.jvm.heap.used",
      "glue.ALL.jvm.heap.used",
      "glue.driver.s3.filesystem.read_bytes",
      "glue.ALL.s3.filesystem.read_bytes",
      "glue.driver.s3.filesystem.write_bytes",
      "glue.ALL.s3.filesystem.write_bytes",
      "glue.driver.system.cpuSystemLoad",
      "glue.ALL.system.cpuSystemLoad",
      "ExecutionTime",
      "JobRunState",
      "StartedOn",
      "LastModifiedOn",
      "CompletedOn",
      "AllocatedCapacity",
      "WorkerType",
      "NumberOfWorkers",
      "GlueVersion",
      "ErrorMessage"
    ]
  },
  "metric_records": [
    {
      "timestamp": "2022-10-02 10:24:54.303000",
      "metric_value": [
        "cwtest",
        "jr_b6bd37db87d3ff3a9eb46b6d4536755f74c0e694ac7b982ddd5e5a89b7b3a7e4",
        "0.027944192",
        "6604776.0",
        "33332",
        "6",
        "6",
        "0",
        "0",
        "110034",
        "0",
        "0",
        "0",
        "0.038659182",
        "299076952",
        "413754704",
        "0",
        "2201592",
        "0",
        "2274336",
        "0.004172926",
        "0.004089126",
        "65606",
        "STOPPED",
        "2022-08-10 10:31:37",
        "2022-08-11 04:45:17",
        "2022-08-11 04:45:17",
        "10.0",
        "G.1X",
        "10",
        "2.0",
        ""
      ]
    },
    {
      "timestamp": "2022-10-02 10:24:54.303000",
      "metric_value": [
        "cwtest",
        "jr_b6bd37db87d3ff3a9eb46b6d4536755f74c0e694ac7b982ddd5e5a89b7b3a7e4",
        "0.027944192",
        "6604776.0",
        "33332",
        "6",
        "6",
        "0",
        "0",
        "110034",
        "0",
        "0",
        "0",
        "0.038659182",
        "299076952",
        "413754704",
        "0",
        "2201592",
        "0",
        "2274336",
        "0.004172926",
        "0.004089126",
        "65606",
        "STOPPED",
        "2022-08-10 10:31:37",
        "2022-08-11 04:45:17",
        "2022-08-11 04:45:17",
        "10.0",
        "G.1X",
        "10",
        "2.0",
        ""
      ]
    },
    {
      "timestamp": "2022-10-02 10:24:54.303000",
      "metric_value": [
        "cwtest",
        "jr_b6bd37db87d3ff3a9eb46b6d4536755f74c0e694ac7b982ddd5e5a89b7b3a7e4",
        "0.027944192",
        "6604776.0",
        "33332",
        "6",
        "6",
        "0",
        "0",
        "110034",
        "0",
        "0",
        "0",
        "0.038659182",
        "299076952",
        "413754704",
        "0",
        "2201592",
        "0",
        "2274336",
        "0.004172926",
        "0.004089126",
        "65606",
        "STOPPED",
        "2022-08-10 10:31:37",
        "2022-08-11 04:45:17",
        "2022-08-11 04:45:17",
        "10.0",
        "G.1X",
        "10",
        ""
      ]
    }
  ]
}

```
## Known issues 
1. Glue 
      * Remove POST end point
      * Remove optional params in get and test with paging
      * Expose Open API spec
      * Add Prod main in docker file  
      * Add Docker and Kubernetes deploy files 
      * Add pipeline to build and deploy 
