import os

from pydantic import BaseSettings, Field
from vault_utility_v2 import vault_credentials

creds = vault_credentials.get_secret_from_vault("environment/1/metric_api", ["connection_string"])


class Settings(BaseSettings):
    db_url: str = Field(creds["connection_string"], env='DATABASE_URL')


settings = Settings()
