from fastapi import FastAPI

from metricservice.server.database import init_db
from metricservice.server.routes.glue import grouter
from metricservice.server.routes.s3 import s3router
from metricservice.server.routes.Lambda import lambda_grouter
from metricservice.server.routes.sagemaker import sagemakerrouter
from metricservice.server.routes.s3_invent import s3_invent_router
from metricservice.server.routes.lambda_invent import lambda_invent_router
from metricservice.server.routes.glue_invent import glue_invent_router
from metricservice.server.routes.sagemaker_endpoints import sagemakerendpointrouter
from metricservice.server.routes.sagemaker_pipeline import sagemakerpipelinerouter
from metricservice.server.routes.aurora_postgres import aurorapostgresrouter
from metricservice.server.routes.synapse import synapserouter
from metricservice.server.routes.synapse_big_data_pool import synapsebigdatapoolrouter
from metricservice.server.routes.synapse_sql_pool import synapsesqlpoolrouter
from metricservice.server.routes.adls import adlspipelinerouter
from metricservice.server.routes.datafactory import datafactoryrouter
from metricservice.server.routes.datafactory_activity_runs import datafactorysqlpoolrouter
from metricservice.server.routes.datafactory_pipeline_runs import datafactorybigdatapoolrouter
from metricservice.server.routes.aks import aksrouter
from metricservice.server.routes.aks_computer import akscomputerrouter
from metricservice.server.routes.aks_container import akscontainerrouter
from metricservice.server.routes.aks_node import aksnoderouter
from metricservice.server.routes.sagemaker_processing import sagemakerprocessingjobrouter
from metricservice.server.routes.aurora_pg_stat_database import aurorapostgres_pg_stat_database_router
from metricservice.server.routes.aurora_conn_count import aurorapostgres_conn_count_router
from metricservice.server.routes.aurora_pg_stat_user_database import aurorapostgres_pg_state_user_tables_router
from metricservice.server.routes.aurora_query import aurorapostgres_query_router
from metricservice.server.routes.tableau_porcessing_job import tableau_processing_router
from metricservice.server.routes.databricks_route_executors import databricksexecutorrouter
from metricservice.server.routes.databricks_route_tasks import databrickstasksrouter
from metricservice.server.routes.databricks_route_jobruns import databricksrunsrouter
from metricservice.server.routes.azure_ml_route import azuremlrouter
from metricservice.server.routes.aws_invent import aws_invent_router
from metricservice.server.routes.cloudstorage_route import cloudstorage_pipeliine_router
from metricservice.server.routes.azure_inventory import azure_invent_router
from metricservice.server.routes.dataflow_job_worker import dataflow_job_worker_router
from metricservice.server.routes.dataflow_job_pubsub import dataflow_job_pubsub_router
from metricservice.server.routes.dataflow_endpoints import dataflow_endpoints_router
from metricservice.server.routes.dataflow_jobs import dataflow_job_router
from metricservice.server.routes.bigquery import prjctsrouter
from metricservice.server.routes.bigquery_datasets import datasetsrouter
from metricservice.server.routes.bigquery_jobs import jobsrouter
from metricservice.server.routes.cloudscheduler import cloud_scheduler_router
from metricservice.server.routes.azure_sqlserver_route import azuresqlserverrouter
from metricservice.server.routes.composer_environments import environmentsrouter
from metricservice.server.routes.composer_pools import poolsrouter
from metricservice.server.routes.composer_queues import queuesrouter
from metricservice.server.routes.composer_webservers import webserversrouter
from metricservice.server.routes.composer_workflows import workflowsrouter
from metricservice.server.routes.gcp_inventory import gcp_inventory_router
from metricservice.server.routes.vertexai_training import vertexai_training_router
from metricservice.server.routes.vertexai_endpoint import vertexai_endpoint_router
from metricservice.server.routes.vertexai_featurestore import vertexai_featuresotre_router
from metricservice.server.routes.redshift_route import redshiftrouter
from metricservice.server.routes.rdsoracle_queries import rdsoraclerouter
from metricservice.server.routes.rdsoracle_schemas import rdsoracleschemasrouter
from metricservice.server.routes.postgres_route_queries import postgres_queries_router
from metricservice.server.routes.postgres_route_tables import postgres_tables_router
from metricservice.server.routes.ropen_infra import ropen_infra_router
from metricservice.server.routes.linux_infra import linux_infra_router
from metricservice.server.routes.ropen_process import ropen_process_router
from metricservice.server.routes.linux_process import linux_process_router
from metricservice.server.routes.rapidv12 import rapidv12router
from metricservice.server.routes.rapidv13 import rapidv13router
from metricservice.server.routes.mongo import mongo_monitoring_router
from metricservice.server.routes.informatica import informatica_router
from metricservice.server.routes.informaticapowerexchange import powerexchange_router
from metricservice.server.routes.informaticajvm import informatica_jvmtest_router
from metricservice.server.routes.sqlserver import sqlserverrouterqueries
from metricservice.server.routes.powerbi_router import powerbirouter
from metricservice.server.routes.azurerediscache import azurerediscacherouter
from metricservice.server.routes.informatica_status_checker import informatica_status_checker_router
from metricservice.server.routes.redis_instances import redis_instances_router
from metricservice.server.routes.disk import diskrouter
from metricservice.server.routes.hyperscale_sql import hyperscale_sql_router
from metricservice.server.routes.sftp import sftp_router
from metricservice.server.routes.azure_blobfuse_route import azureblobfuserouter
from metricservice.server.routes.azure_blobfuse_filecache_route import blobfusefilecacherouter
from metricservice.server.routes.azure_blobfuse_blobfusestats_route import blobfusestatsrouter






app = FastAPI()
app.include_router(grouter, tags=["glue"], prefix="/gluemetrics")
app.include_router(s3router, tags=["s3"], prefix="/s3metrics")
app.include_router(lambda_grouter, tags=["lambda"], prefix="/lambdametrics")
app.include_router(sagemakerrouter, tags=["sagemaker"], prefix="/sagemaker")
app.include_router(s3_invent_router, tags=["inventory_s3"], prefix="/s3inventory")
app.include_router(lambda_invent_router, tags=["inventory_lambda"], prefix="/lambdainventory")
app.include_router(glue_invent_router, tags=["inventory_glue"], prefix="/glueinventory")
app.include_router(sagemakerendpointrouter, tags=["sagemaker_endpoint"], prefix="/sagemakerendpoint")
app.include_router(sagemakerpipelinerouter, tags=["sagemaker_pipeline"], prefix="/sagemakerpipeline")
app.include_router(aurorapostgresrouter, tags=["aurorapostgres"], prefix="/aurorapostgres")
app.include_router(synapserouter, tags=["synapse"], prefix="/synapse")
app.include_router(synapsebigdatapoolrouter, tags=["synapse_bigdatapool"], prefix="/synapsebigdatapool")
app.include_router(synapsesqlpoolrouter, tags=["synapse_sqlpool"], prefix="/synapsesqlpool")
app.include_router(adlspipelinerouter, tags=["adls"], prefix="/adls")
app.include_router(datafactoryrouter, tags=["datafactory"],prefix="/datafactory")
app.include_router(datafactorysqlpoolrouter, tags=["datafactory_activity_runs"],prefix="/datafactoryactivityruns")
app.include_router(datafactorybigdatapoolrouter, tags=["datafactory_pipeline_runs"],prefix="/datafactorypipelineruns")
app.include_router(aksrouter, tags=["aks"], prefix="/aks")
app.include_router(akscomputerrouter, tags=["aks_computer"], prefix="/akscomputer")
app.include_router(akscontainerrouter, tags=["aks_container"], prefix="/akscontainer")
app.include_router(aksnoderouter, tags=["aks_node"], prefix="/aksnode")
app.include_router(sagemakerprocessingjobrouter, tags=["sagemaker_processing_job"], prefix="/sagemakerprocessingjob")
app.include_router(aurorapostgres_pg_stat_database_router, tags=["aurorapostgres_pgstat_database"], prefix="/aurorapostgrespgstatdatabase")
app.include_router(aurorapostgres_conn_count_router, tags=["aurorapostgres_conn_count"], prefix="/aurorapostgresconncount")
app.include_router(aurorapostgres_pg_state_user_tables_router, tags=["aurorapostgres_pg_stat_user_tables"], prefix="/aurorapostgresusertables")
app.include_router(aurorapostgres_query_router, tags=["aurora_query"], prefix="/auroraquery")
app.include_router(tableau_processing_router, tags=["tableau processing router"], prefix="/tableauProcessing")
app.include_router(databricksexecutorrouter, tags=['databricks_executors'], prefix='/databricks/executors')
app.include_router(databrickstasksrouter, tags=['databricks_tasks'], prefix='/databricks/jobs/runs/tasks')
app.include_router(databricksrunsrouter, tags=['databricks_runs'], prefix='/databricks/jobs/runs')
app.include_router(azuremlrouter, tags=['azure_ml'], prefix='/azureml')
app.include_router(aws_invent_router, tags=["aws_inventory"], prefix="/awsinventory")
app.include_router(cloudstorage_pipeliine_router, tags=['cloudstorage'], prefix='/cloudstorage')
app.include_router(azure_invent_router, tags=["azure_inventory"], prefix="/azure/inventory")
app.include_router(dataflow_job_worker_router, tags=['dataflow_job_worker'], prefix='/dataflow/job/worker')
app.include_router(dataflow_job_pubsub_router, tags=['dataflow_job_pubsub'], prefix='/dataflow/job/pubsub')
app.include_router(dataflow_endpoints_router, tags=['dataflow_endpoints'], prefix='/dataflow/endpoints')
app.include_router(dataflow_job_router, tags=['dataflow_jobs'], prefix='/dataflow/jobs')
app.include_router(prjctsrouter, tags=['bigquery'], prefix='/bigquery')
app.include_router(datasetsrouter, tags=['bigquery_datasets'], prefix='/bigquery_datasets')
app.include_router(jobsrouter, tags=['bigquery_jobs'], prefix='/bigquery_jobs')
app.include_router(cloud_scheduler_router, tags=['cloud_scheduler'], prefix='/cloudscheduler')
app.include_router(azuresqlserverrouter, tags=['azure_sqlserver'], prefix='/azuresqlserver')
app.include_router(environmentsrouter, tags=['composer_environments'], prefix='/cloudcomposer/environments')
app.include_router(poolsrouter, tags=['composer_pools'], prefix='/cloudcomposer/pools')
app.include_router(queuesrouter, tags=['composer_queues'], prefix='/cloudcomposer/queues')
app.include_router(webserversrouter, tags=['composer_webservers'], prefix='/cloudcomposer/webservers')
app.include_router(workflowsrouter, tags=['composer_workflows'], prefix='/cloudcomposer/workflows')
app.include_router(gcp_inventory_router, tags=['gcp_inventory'], prefix='/gcp/inventory')
app.include_router(vertexai_endpoint_router, tags=['vertexai_endpoint'], prefix='/gcp/vertexai/endpoint')
app.include_router(vertexai_training_router, tags=['vertexai_training'], prefix='/gcp/vertexai/training')
app.include_router(vertexai_featuresotre_router, tags=['vertexai_featurestore'], prefix='/gcp/vertexai/featurestore')
app.include_router(redshiftrouter, tags=['redshift'], prefix='/redshift')
app.include_router(rdsoraclerouter, tags=['rdsoracle_queries'], prefix='/rdsoracle/queries')
app.include_router(rdsoracleschemasrouter, tags=['rdsoracle_schemas'], prefix='/rdsoracle/schemas')
app.include_router(postgres_queries_router, tags=['postgres_queries'], prefix='/postgres/queries')
app.include_router(postgres_tables_router, tags=['postgres_tables'], prefix='/postgres/tables')
app.include_router(ropen_infra_router, tags=['ropen_instance'], prefix='/ropen/instance')
app.include_router(ropen_process_router, tags=['ropen_process'], prefix='/ropen/process')
app.include_router(linux_infra_router, tags=['linux_instance'], prefix='/linux/instance')
app.include_router(linux_process_router, tags=['linux_process'], prefix='/linux/process')
app.include_router(rapidv12router, tags=["rapidv12"], prefix="/rapidv12")
app.include_router(rapidv13router, tags=["rapidv13"], prefix="/rapidv13")
app.include_router(mongo_monitoring_router, tags=['mongo_monitoring'], prefix='/mongodb')
app.include_router(sqlserverrouterqueries, tags=['sqlserver'], prefix='/sqlserver')
app.include_router(redis_instances_router, tags=['redis_instances'], prefix='/redis/instances')
app.include_router(powerbirouter, tags=['powerbi'], prefix='/powerbi')
app.include_router(azurerediscacherouter, tags=['azurerediscache'], prefix='/azurerediscache')
app.include_router(diskrouter, tags=['disk'], prefix='/disk')
app.include_router(sftp_router, tags=['sftp'], prefix='/sftp')
app.include_router(informatica_router, tags=['informatica'], prefix='/informatica')
app.include_router(powerexchange_router, tags=['informaticapowerexchange'], prefix='/informaticapowerexchange')
app.include_router(informatica_jvmtest_router, tags=['informaticajvm'], prefix='/informaticajvm')
app.include_router(informatica_status_checker_router, tags=['informatica_status_checker'], prefix='/informatica_status_checker')
app.include_router(azureblobfuserouter, tags=['azure_blobfuse'], prefix='/azureblobfuse')
app.include_router(blobfusefilecacherouter, tags=['azure_blobfuse_filecache'], prefix='/azureblobfusefilecache')
app.include_router(blobfusestatsrouter, tags=['azure_blobfuse_blobfusestats'], prefix='/azureblobfusestats')
app.include_router(hyperscale_sql_router, tags=['hyperscale_sql'], prefix='/hyperscalesql')

@app.on_event("startup")
async def start_db():
    await init_db()


@app.get("/", tags=["Root"])
async def read_root() -> dict:
    return {"message": "Welcome to your beanie powered metric-service!"}
