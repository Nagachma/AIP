from beanie import init_beanie
import motor.motor_asyncio

from metricservice.server.models.sqlserver import sqlserver
from metricservice.config import settings
from metricservice.server.models.adls import adls
from metricservice.server.models.glue import glue
from metricservice.server.models.s3 import s3
from metricservice.server.models.Lambda import Lambda
from metricservice.server.models.sagemaker import sagemaker
from metricservice.server.models.aurora_postgres import aurorapostgres
from metricservice.server.models.glueInvent import glue_custom
from metricservice.server.models.synapse import synapse
from metricservice.server.models.datafactory import datafactory
from metricservice.server.models.aks import aks
from metricservice.server.models.tableau import tableau
from metricservice.server.models.databricks import databricks
from metricservice.server.models.azure_ml import azure_ml
from metricservice.server.models.azure_sqlserver import azure_sqlserver
from metricservice.server.models.aws import aws_inventory
from metricservice.server.models.cloudstorage import cloudstorage
from metricservice.server.models.azure_inventory import azure_inventory
from metricservice.server.models.dataflow import dataflow
from metricservice.server.models.bigquery import bigquery
from metricservice.server.models.cloud_scheduler import cloud_scheduler
from metricservice.server.models.cloud_composer import cloud_composer
from metricservice.server.models.gcp_inventory import gcp_inventory
from metricservice.server.models.vertexai import vertexai
from metricservice.server.models.redshift import redshift
from metricservice.server.models.rdsoracle import rdsoracle
from metricservice.server.models.postgres import postgres
from metricservice.server.models.ropen import ropen
from metricservice.server.models.linux import linux
from metricservice.server.models.rapidv12 import rapidv12
from metricservice.server.models.rapidv13 import rapidv13
from metricservice.server.models.informatica import informatica
from metricservice.server.models.informaticapowerexchange import informaticapowerexchange
from metricservice.server.models.sftp import sftp
from metricservice.server.models.disk import disk
from metricservice.server.models.mongo import mongo_monitoring
from metricservice.server.models.powerbi import powerbi
from metricservice.server.models.azurerediscache import azurerediscache
from metricservice.server.models.redis import redis
from metricservice.server.models.azure_blobfuse import azure_blobfuse

from metricservice.server.models.informaticajvm import informaticajvm
from metricservice.server.models.informatica_status_checker import informatica_service_status
from metricservice.server.models.hyperscale_sql import hyperscale_sql

async def init_db():
    client = motor.motor_asyncio.AsyncIOMotorClient(
        settings.db_url
    )
    await init_beanie(database=client.get_default_database(), document_models=[glue, s3, Lambda, sagemaker, aurorapostgres, glue_custom, synapse, adls, aks, tableau, databricks, datafactory, azure_ml, aws_inventory, cloudstorage, azure_inventory, dataflow, bigquery, cloud_scheduler, azure_sqlserver, cloud_composer, gcp_inventory, vertexai,redshift,rdsoracle,postgres,ropen,mongo_monitoring, sqlserver, redis, linux,informatica,informaticapowerexchange,informaticajvm,informatica_service_status,powerbi,disk,hyperscale_sql, rapidv12, rapidv13, sftp, azurerediscache,azure_blobfuse])
