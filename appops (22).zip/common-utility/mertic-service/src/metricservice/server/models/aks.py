from datetime import datetime
from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel , Field
from typing import Optional,Dict,List

class Computer(BaseModel):
    Computer: Optional[str]
    Avgdiskioreads: Optional[float] = Field(None, alias='Avgdiskioreads')
    Avgdiskioread_bytes: Optional[float] = Field(None, alias='Avgdiskioread_bytes')
    Avgdiskioread_time: Optional[float] = Field(None, alias='Avgdiskioread_time')
    Avgdiskiowrites: Optional[float] = Field(None, alias='Avgdiskiowrites')
    Avgdiskiowrite_bytes: Optional[float] = Field(None, alias='Avgdiskiowrite_bytes')
    Avgdiskiowrite_time: Optional[float] = Field(None, alias='Avgdiskiowrite_time')
    Avgdiskio_time: Optional[float] = Field(None, alias='Avgdiskio_time')
    Avgdiskiops_in_progress: Optional[float] = Field(None, alias='Avgdiskiops_in_progress')
    computer_id: Optional[str] = Field(None, alias='computer_id')
    Avgdiskfree: Optional[float] = Field(None, alias='Avgdiskfree')
    Avgdiskused: Optional[float] = Field(None, alias='Avgdiskused')
    Avgdiskusedpercent: Optional[float] = Field(None, alias='Avgdiskusedpercent')
    Avgbytes_recv: Optional[float] = Field(None, alias='Avgbytes_recv')
    Avgbytes_sent: Optional[float] = Field(None, alias='Avgbytes_sent')
    Avgerr_in: Optional[float] = Field(None, alias='Avgerr_in')
    Avgerr_out: Optional[float] = Field(None, alias='Avgerr_out')
    AvgpvUsedBytes: Optional[float] = Field(None, alias='AvgpvUsedBytes')
    ReadyCount: Optional[float] = Field(None, alias='ReadyCount')
    NotReadyCount: Optional[float] = Field(None, alias='NotReadyCount')

class Container(BaseModel):
    ShortInstanceName: Optional[str]
    AvgcpuRequestNanoCores: Optional[float] = Field(None, alias='AvgcpuRequestNanoCores')
    AvgcpuLimitNanoCores: Optional[float] = Field(None, alias='AvgcpuLimitNanoCores')
    AvgcpuUsageNanoCores: Optional[float] = Field(None, alias='AvgcpuUsageNanoCores')
    AvgmemoryRequestBytes: Optional[float] = Field(None, alias='AvgmemoryRequestBytes')
    AvgmemoryLimitBytes: Optional[float] = Field(None, alias='AvgmemoryLimitBytes')
    AvgmemoryRssBytes: Optional[float] = Field(None, alias='AvgmemoryRssBytes')
    AvgmemoryWorkingSetBytes: Optional[float] = Field(None, alias='AvgmemoryWorkingSetBytes')
    AvgrestartTimeEpoch: Optional[float] = Field(None, alias='AvgrestartTimeEpoch')
    container_id: Optional[str] = Field(None, alias='container_id')

class Node(BaseModel):
    ShortInstanceName: Optional[str]
    AvgcpuAllocatableNanoCores: Optional[float] = Field(None, alias='AvgcpuAllocatableNanoCores')
    AvgcpuUsageNanoCores: Optional[float] = Field(None, alias='AvgcpuUsageNanoCores')
    AvgcpuCapacityNanoCores: Optional[float] = Field(None, alias='AvgcpuCapacityNanoCores')
    AvgmemoryAllocatableBytes: Optional[float] = Field(None, alias='AvgmemoryAllocatableBytes')
    AvgmemoryCapacityBytes: Optional[float] = Field(None, alias='AvgmemoryCapacityBytes')
    AvgmemoryRssBytes: Optional[float] = Field(None, alias='AvgmemoryRssBytes')
    AvgmemoryWorkingSetBytes: Optional[float] = Field(None, alias='AvgmemoryWorkingSetBytes')
    AvgrestartTimeEpoch: Optional[float] = Field(None, alias='AvgrestartTimeEpoch')
    node_id: Optional[str] = Field(None, alias='node_id')

class ManagedClusters(BaseModel):
    aks_name: Optional[str]
    apiserver_current_inflight_requests: Optional[float] = Field(None,alias='apiserver_current_inflight_requests')
    cluster_autoscaler_cluster_safe_to_autoscale: Optional[float] = Field(None, alias='cluster_autoscaler_cluster_safe_to_autoscale')
    cluster_autoscaler_scale_down_in_cooldown: Optional[float] = Field(None, alias='cluster_autoscaler_scale_down_in_cooldown')
    cluster_autoscaler_unneeded_nodes_count: Optional[float] = Field(None, alias='cluster_autoscaler_unneeded_nodes_count')
    cluster_autoscaler_unschedulable_pods_count: Optional[float] = Field(None, alias='cluster_autoscaler_unschedulable_pods_count')
    kube_node_status_allocatable_cpu_cores: Optional[float] = Field(None, alias='kube_node_status_allocatable_cpu_cores')
    kube_node_status_allocatable_memory_bytes: Optional[float] = Field(None, alias='kube_node_status_allocatable_memory_bytes')
    kube_pod_status_ready: Optional[float] = Field(None, alias='kube_pod_status_ready')
    kube_node_status_condition: Optional[float] = Field(None, alias='kube_node_status_condition')
    kube_pod_status_phase: Optional[float] = Field(None, alias='kube_pod_status_phase')
    node_cpu_usage_millicores: Optional[float] = Field(None, alias='node_cpu_usage_millicores')
    node_cpu_usage_percentage: Optional[float] = Field(None, alias='node_cpu_usage_percentage')
    node_memory_rss_bytes: Optional[float] = Field(None, alias='node_memory_rss_bytes')
    node_memory_rss_percentage: Optional[float] = Field(None, alias='node_memory_rss_percentage')
    node_memory_working_set_bytes: Optional[float] = Field(None, alias='node_memory_working_set_bytes')
    node_memory_working_set_percentage: Optional[float] = Field(None, alias='node_memory_working_set_percentage')
    node_disk_usage_bytes: Optional[float] = Field(None, alias='node_disk_usage_bytes')
    node_disk_usage_percentage: Optional[float] = Field(None, alias='node_disk_usage_percentage')
    node_network_in_bytes: Optional[float] = Field(None, alias='node_network_in_bytes')
    node_network_out_bytes: Optional[float] = Field(None, alias='node_network_out_bytes')
    cpuExceededPercentage: Optional[float] = Field(None, alias='cpuExceededPercentage')
    cpuThresholdViolated: Optional[float] = Field(None, alias='cpuThresholdViolated')
    memoryRssExceededPercentage: Optional[float] = Field(None, alias='memoryRssExceededPercentage')
    memoryRssThresholdViolated: Optional[float] = Field(None, alias='memoryRssThresholdViolated')
    memoryWorkingSetExceededPercentage: Optional[float] = Field(None, alias='memoryWorkingSetExceededPercentage')
    memoryWorkingSetThresholdViolated: Optional[float] = Field(None, alias='memoryWorkingSetThresholdViolated')
    podCount: Optional[float] = Field(None, alias='podCount')
    completedJobsCount: Optional[float] = Field(None, alias='completedJobsCount')
    restartingContainerCount: Optional[float] = Field(None, alias='restartingContainerCount')
    oomKilledContainerCount: Optional[float] = Field(None, alias='oomKilledContainerCount')
    podReadyPercentage: Optional[float] = Field(None, alias='podReadyPercentage')
    cpuUsageMillicores: Optional[float] = Field(None, alias='cpuUsageMillicores')
    cpuUsagePercentage: Optional[float] = Field(None, alias='cpuUsagePercentage')
    cpuUsageAllocatablePercentage: Optional[float] = Field(None, alias='cpuUsageAllocatablePercentage')
    memoryRssBytes: Optional[float] = Field(None, alias='memoryRssBytes')
    memoryRssPercentage: Optional[float] = Field(None, alias='memoryRssPercentage')
    memoryRssAllocatablePercentage: Optional[float] = Field(None, alias='memoryRssAllocatablePercentage')
    memoryWorkingSetBytes: Optional[float] = Field(None, alias='memoryWorkingSetBytes')
    memoryWorkingSetPercentage: Optional[float] = Field(None, alias='memoryWorkingSetPercentage')
    nodesCount: Optional[float] = Field(None, alias='nodesCount')
    diskUsedPercentage: Optional[float] = Field(None, alias='diskUsedPercentage')
    pvUsageExceededPercentage: Optional[float] = Field(None, alias='pvUsageExceededPercentage')
    pvUsageThresholdViolated: Optional[float] = Field(None, alias='pvUsageThresholdViolated')
    Avgnodecpuusage: Optional[float] = Field(None, alias='Avgnodecpuusage')
    Avgnodememoryusage: Optional[float] = Field(None, alias='Avgnodememoryusage')
    TotalCount: Optional[float] = Field(None, alias='TotalCount')
    PendingCount: Optional[float] = Field(None, alias='PendingCount')
    RunningCount: Optional[float] = Field(None, alias='RunningCount')
    SucceededCount: Optional[float] = Field(None, alias='SucceededCount')
    FailedCount: Optional[float] = Field(None, alias='FailedCount')
    UnknownCount: Optional[float] = Field(None, alias='UnknownCount')
    MaxNodeDiskUsage: Optional[float] = Field(None, alias='MaxNodeDiskUsage')
    Computer: Optional[List[Computer]]
    Container: Optional[List[Container]]
    Node: Optional[List[Node]]


class Source(BaseModel):
    region: str
    env: str
    service_provider: str

class aks(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    managed_clusters: List[ManagedClusters] = []

    class Settings:
        name: "aks"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field = "source",
            granularity=Granularity.minutes  # Optional
            #expire_after_seconds=2  # Optional
        )
