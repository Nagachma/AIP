from datetime import datetime
from typing import Optional, List

from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel, Field


class Source(BaseModel):
    region: str = Field(None, alias='region')
    env: str = Field(None, alias='prod')
    service_provider: str = Field(None, alias='Azure')


class file_cache(BaseModel):
    FileCache_cacheEvent: Optional[str] = Field(None,alias='FileCache.cacheEvent')
    FileCache_path: Optional[str] = Field(None, alias='FileCache.path')
    FileCache_isDir: Optional[str] = Field(None, alias='FileCache.isDir')
    FileCache_cacheSize: Optional[float] = Field(None, alias='FileCache.cacheSize')
    FileCache_cacheConsumed: Optional[str] = Field(None, alias='FileCache.cacheConsumed')
    FileCache_cacheFilesCount: Optional[float] = Field(None, alias='FileCache.cacheFilesCount')
    FileCache_evictedFilesCount: Optional[float] = Field(None, alias='FileCache.evictedFilesCount')
    FileCache_value_FileSize: Optional[float] = Field(None, alias='FileCache.value.FileSize')
    

class blobfusestats(BaseModel):
    BlobfuseStats_timestamp: Optional[str] = Field(None,alias='BlobfuseStats.timestamp')
    BlobfuseStats_componentName: Optional[str] = Field(None,alias='BlobfuseStats.componentName')
    BlobfuseStats_operation: Optional[str] = Field(None,alias='BlobfuseStats.operation')
    BlobfuseStats_path: Optional[str] = Field(None,alias='BlobfuseStats.path')
    BlobfuseStats_value_Mode: Optional[str] = Field(None,alias='BlobfuseStats.value.Mode')
    BlobfuseStats_value_BytesTransferred: Optional[str] = Field(None,alias='BlobfuseStats.value.Bytes Transferred')
    BlobfuseStats_value_Size: Optional[str] = Field(None,alias='BlobfuseStats.value.Size')
    BlobfuseStats_value_BytesUploaded: Optional[str] = Field(None,alias='BlobfuseStats.value.Bytes Uploaded')
    BlobfuseStats_value_Chmod: Optional[str] = Field(None,alias='BlobfuseStats.value.Chmod')
    BlobfuseStats_value_DeleteFile: Optional[str] = Field(None,alias='BlobfuseStats.value.DeleteFile')
    BlobfuseStats_value_OpenFileHandles: Optional[str] = Field(None,alias='BlobfuseStats.value.OpenFileHandles')
    BlobfuseStats_value_SyncFile: Optional[str] = Field(None,alias='BlobfuseStats.value.SyncFile')
    BlobfuseStats_value_CacheUsage: Optional[str] = Field(None, alias='BlobfuseStats.value.Cache Usage')
    BlobfuseStats_value_UsagePercent: Optional[str] = Field(None, alias='BlobfuseStats.value.Usage Percent')

class blobfuses(BaseModel):
    Timestamp: Optional[str]
    CPUUsage: Optional[str]
    MemoryUsage: Optional[str]
    file_cache: Optional[List[file_cache]]
    blobfusestats: Optional[List[blobfusestats]]



class azure_blobfuse(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    blobfuse: List[blobfuses] = []

    class Settings:
        name: "azure_blobfuse"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field="source",
            granularity=Granularity.minutes  # Optional
            # expire_after_seconds=2  # Optional
        )
