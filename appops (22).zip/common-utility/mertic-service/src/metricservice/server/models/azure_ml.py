from datetime import datetime
from typing import Optional, List

from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel, Field


class Source(BaseModel):
    region: str = Field(None, alias='region')
    env: str = Field(None, alias='prod')
    service_provider: str = Field(None, alias='Azure')


class Jobs(BaseModel):
    JobName: Optional[str]
    JobId: Optional[str]
    JobDuration: Optional[str]
    JobStatus: Optional[str]
    ExecutionState: Optional[str]
    JobNodeId: Optional[str]
    DeviceType: Optional[str]
    avg_Utilization: Optional[float]
    DeviceId: Optional[str]
    DurationMs: Optional[str]
    NodeId: Optional[str]
    

class Cluster(BaseModel):
    ClusterName: Optional[str]
    Time: Optional[str]
    ClusterType: Optional[str]
    VmSize: Optional[str]
    VmPriority: Optional[str]
    ScalingType: Optional[str]
    InitialNodeCount: Optional[float]
    MinimumNodeCount: Optional[float]
    MaximumNodeCount: Optional[float]
    Sku: Optional[str]
    Version: Optional[str]
    CurrentNodeCount: Optional[float]
    TargetNodeCount: Optional[float]
    NodeIdleTimeSecondsBeforeScaleDown: Optional[float]
    PreemptedNodeCount: Optional[float]
    PreparingNodeCount: Optional[float]
    UnusableNodeCount: Optional[float]
    LeavingNodeCount: Optional[float]
    IdleNodeCount: Optional[float]
    RunningNodeCount: Optional[float]
    QuotaAllocated: Optional[float]
    QuotaUtilized: Optional[float]
    Jobs: Optional[List[Jobs]]


class Workspace(BaseModel):
    workspace_name: str
    workspace_ActiveCores: Optional[float] = Field(None,alias='Workspace.Active Cores')
    workspace_ActiveNodes: Optional[float] = Field(None, alias='Workspace.Active Nodes')
    workspace_CancelRequestedRuns: Optional[float] = Field(None, alias='Workspace.Cancel Requested Runs')
    workspace_CancelledRuns: Optional[float] = Field(None, alias='Workspace.Cancelled Runs')
    workspace_CompletedRuns: Optional[float] = Field(None, alias='Workspace.Completed Runs')
    workspace_CpuCapacityMillicores: Optional[float] = Field(None, alias='Workspace.CpuCapacityMillicores')
    workspace_CpuMemoryCapacityMegabytes: Optional[float] = Field(None, alias='Workspace.CpuMemoryCapacityMegabytes')
    workspace_CpuMemoryUtilizationMegabytes: Optional[float] = Field(None, alias='Workspace.CpuMemoryUtilizationMegabytes')
    workspace_CpuMemoryUtilizationPercentage: Optional[float] = Field(None, alias='Workspace.CpuMemoryUtilizationPercentage')
    workspace_CpuUtilization: Optional[float] = Field(None, alias='Workspace.CpuUtilization')
    workspace_CpuUtilizationMillicores: Optional[float] = Field(None, alias='Workspace.CpuUtilizationMillicores')
    workspace_CpuUtilizationPercentage: Optional[float] = Field(None, alias='Workspace.CpuUtilizationPercentage')
    workspace_DiskAvailMegabytes: Optional[float] = Field(None, alias='Workspace.DiskAvailMegabytes')
    workspace_DiskReadMegabytes: Optional[float] = Field(None, alias='Workspace.DiskReadMegabytes')
    workspace_DiskUsedMegabytes: Optional[float] = Field(None, alias='Workspace.DiskUsedMegabytes')
    workspace_DiskWriteMegabytes: Optional[float] = Field(None, alias='Workspace.DiskWriteMegabytes')
    workspace_Errors: Optional[float] = Field(None, alias='Workspace.Errors')
    workspace_FailedRuns: Optional[float] = Field(None, alias='Workspace.Failed Runs')
    workspace_FinalizingRuns: Optional[float] = Field(None, alias='Workspace.Finalizing Runs')
    workspace_GpuCapacityMilliGPUs: Optional[float] = Field(None, alias='Workspace.GpuCapacityMilliGPUs')
    workspace_GpuEnergyJoules: Optional[float] = Field(None, alias='Workspace.GpuEnergyJoules')
    workspace_GpuMemoryCapacityMegabytes: Optional[float] = Field(None, alias='Workspace.GpuMemoryCapacityMegabytes')
    workspace_GpuMemoryUtilization: Optional[float] = Field(None, alias='Workspace.GpuMemoryUtilization')
    workspace_GpuMemoryUtilizationMegabytes: Optional[float] = Field(None, alias='Workspace.GpuMemoryUtilizationMegabytes')
    workspace_GpuMemoryUtilizationPercentage: Optional[float] = Field(None, alias='Workspace.GpuMemoryUtilizationPercentage')
    workspace_GpuUtilization: Optional[float] = Field(None, alias='Workspace.GpuUtilization')
    workspace_GpuUtilizationMilliGPUs: Optional[float] = Field(None, alias='Workspace.GpuUtilizationMilliGPUs')
    workspace_GpuUtilizationPercentage: Optional[float] = Field(None, alias='Workspace.GpuUtilizationPercentage')
    workspace_IBReceiveMegabytes: Optional[float] = Field(None, alias='Workspace.IBReceiveMegabytes')
    workspace_IBTransmitMegabytes: Optional[float] = Field(None, alias='Workspace.IBTransmitMegabytes')
    workspace_IdleCores: Optional[float] = Field(None, alias='Workspace.Idle Cores')
    workspace_IdleNodes: Optional[float] = Field(None, alias='Workspace.Idle Nodes')
    workspace_LeavingCores: Optional[float] = Field(None, alias='Workspace.Leaving Cores')
    workspace_LeavingNodes: Optional[float] = Field(None, alias='Workspace.Leaving Nodes')
    workspace_ModelDeployFailed: Optional[float] = Field(None, alias='Workspace.Model Deploy Failed')
    workspace_ModelDeployStarted: Optional[float] = Field(None, alias='Workspace.Model Deploy Started')
    workspace_ModelDeploySucceeded: Optional[float] = Field(None, alias='Workspace.Model Deploy Succeeded')
    workspace_ModelRegisterFailed: Optional[float] = Field(None, alias='Workspace.Model Register Failed')
    workspace_ModelRegisterSucceeded: Optional[float] = Field(None, alias='Workspace.Model Register Succeeded')
    workspace_NetworkInputMegabytes: Optional[float] = Field(None, alias='Workspace.NetworkInputMegabytes')
    workspace_NetworkOutputMegabytes: Optional[float] = Field(None, alias='Workspace.NetworkOutputMegabytes')
    workspace_NotRespondingRuns: Optional[float] = Field(None, alias='Workspace.Not Responding Runs')
    workspace_NotStartedRuns: Optional[float] = Field(None, alias='Workspace.Not Started Runs')
    workspace_PreemptedCores: Optional[float] = Field(None, alias='Workspace.Preempted Cores')
    workspace_PreemptedNodes: Optional[float] = Field(None, alias='Workspace.Preempted Nodes')
    workspace_PreparingRuns: Optional[float] = Field(None, alias='Workspace.Preparing Runs')
    workspace_ProvisioningRuns: Optional[float] = Field(None, alias='Workspace.Provisioning Runs')
    workspace_QueuedRuns: Optional[float] = Field(None, alias='Workspace.Queued Runs')
    workspace_QuotaUtilizationPercentage: Optional[float] = Field(None, alias='Workspace.Quota Utilization Percentage')
    workspace_StartedRuns: Optional[float] = Field(None, alias='Workspace.Started Runs')
    workspace_StartingRuns: Optional[float] = Field(None, alias='Workspace.Starting Runs')
    workspace_StorageAPIFailureCount: Optional[float] = Field(None, alias='Workspace.StorageAPIFailureCount')
    workspace_StorageAPISuccessCount: Optional[float] = Field(None, alias='Workspace.StorageAPISuccessCount')
    workspace_TotalCores: Optional[float] = Field(None, alias='Workspace.Total Cores')
    workspace_TotalNodes: Optional[float] = Field(None, alias='Workspace.Total Nodes')
    workspace_UnusableCores: Optional[float] = Field(None, alias='Workspace.Unusable Cores')
    workspace_UnusableNodes: Optional[float] = Field(None, alias='Workspace.Unusable Nodes')
    workspace_Warnings: Optional[float] = Field(None, alias='Workspace.Warnings')
    Cluster: Optional[List[Cluster]]


class azure_ml(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    workspaces: List[Workspace] = []

    class Settings:
        name: "azure_ml"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field="source",
            granularity=Granularity.minutes  # Optional
            # expire_after_seconds=2  # Optional
        )
