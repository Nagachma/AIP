from datetime import datetime
from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel , Field
from typing import Optional,Dict,List

class jobs(BaseModel):
    project_number: Optional[str]
    user_email: Optional[str] = Field(None, alias='user_email')
    job_id: Optional[str] = Field(None, alias='job_id')
    job_type: Optional[str] = Field(None, alias='job_type')
    statement_type: Optional[str] = Field(None, alias='statement_type')
    priority: Optional[str] = Field(None, alias='priority')
    query: Optional[str] = Field(None, alias='query')
    state: Optional[str] = Field(None, alias='state')
    total_bytes_processed: Optional[str] = Field(None, alias='total_bytes_processed')
    total_slot_ms: Optional[str] = Field(None, alias='total_slot_ms')
    cache_hit: Optional[str] = Field(None, alias='cache_hit')
    referenced_tables: Optional[str] = Field(None, alias='referenced_tables')
    labels: Optional[str] = Field(None, alias='labels')
    timeline: Optional[str] = Field(None, alias='timeline')
    job_total_elapsed_time: Optional[str] = Field(None, alias='job_total_elapsed_time')
    job_stages: Optional[str] = Field(None, alias='job_stages')
    total_bytes_billed: Optional[str] = Field(None, alias='total_bytes_billed')

class table(BaseModel):
    table_name: Optional[str]
    stored_bytes: Optional[float] = Field(None, alias='stored_bytes')
    uploaded_row_count: Optional[float] = Field(None, alias='uploaded_row_count')
    uploaded_bytes: Optional[float] = Field(None, alias='uploaded_bytes')
    uploaded_bytes_billed: Optional[float] = Field(None, alias='uploaded_bytes_billed')

class datasets(BaseModel):
    dataset_id: Optional[str]
    table_count: Optional[float] = Field(None, alias='table_count')
    table: Optional[List[table]]

class prjcts(BaseModel):
    project_id: Optional[str]
    num_in_flight: Optional[float] = Field(None,alias='num_in_flight')
    scanned_bytes_billed: Optional[float] = Field(None, alias='scanned_bytes_billed')
    count: Optional[float] = Field(None, alias='count')
    execution_times: Optional[float] = Field(None, alias='execution_times')
    statement_scanned_bytes: Optional[float] = Field(None, alias='statement_scanned_bytes')
    scanned_scanned_bytes_billed: Optional[float] = Field(None, alias='scanned_scanned_bytes_billed')
    allocated: Optional[float] = Field(None, alias='allocated')
    allocated_for_project_and_job_type: Optional[float] = Field(None, alias='allocated_for_project_and_job_type')
    allocated_for_reservation: Optional[float] = Field(None, alias='allocated_for_reservation')
    allocated_for_project: Optional[float] = Field(None, alias='allocated_for_project')
    assigned: Optional[float] = Field(None, alias='assigned')
    capacity_committed: Optional[float] = Field(None, alias='capacity_committed')
    max_assigned: Optional[float] = Field(None, alias='max_assigned')
    total_allocated_for_reservation: Optional[float] = Field(None, alias='total_allocated_for_reservation')
    scanned_bytes: Optional[float] = Field(None, alias='scanned_bytes')
    biengine_fallback_count: Optional[float] = Field(None, alias='biengine_fallback_count')
    execution_count: Optional[float] = Field(None, alias='execution_count')
    total_available: Optional[float] = Field(None, alias='total_available')
    insertall_inserted_bytes: Optional[float] = Field(None, alias='insertall_inserted_bytes')
    insertall_inserted_rows: Optional[float] = Field(None, alias='insertall_inserted_rows')
    datasets: Optional[List[datasets]]
    jobs: Optional[List[jobs]]


class Source(BaseModel):
    region: str
    env: str
    service_provider: str

class bigquery(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    projects: List[prjcts] = []

    class Settings:
        name: "bigquery"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field = "source",
            granularity=Granularity.minutes  # Optional
            #expire_after_seconds=2  # Optional
        )
