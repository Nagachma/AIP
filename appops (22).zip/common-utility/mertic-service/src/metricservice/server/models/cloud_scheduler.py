from datetime import datetime
from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel, Field
from typing import Optional, List


class Job(BaseModel):
    job_id: str
    log_bytes: Optional[float] = Field(None, alias='log_bytes')
    log_entries: Optional[float] = Field(None, alias='log_entries')
    logs_based_metric_errors: Optional[float] = Field(None, alias='logs_based_metric_errors')
    istio_request_duration_in_milliseconds: Optional[float] = Field(None, alias='istio_request_duration_in_milliseconds')
    istio_requests_number: Optional[float] = Field(None, alias='istio_requests_number')
    job_start_count: Optional[float] = Field(None, alias='job_start_count')
    job_failure_count: Optional[float] = Field(None, alias='job_failure_count')
    job_failure_rate: Optional[float] = Field(None, alias='job_failure_rate')


class Source(BaseModel):
    region: str
    env: str
    service_provider: str


class cloud_scheduler(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    jobs: List[Job] = []

    class Settings:
        name: "cloud_scheduler"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field="source",
            granularity=Granularity.minutes  # Optional
            # expire_after_seconds=2  # Optional
        )
