from datetime import datetime
from typing import Optional, List

from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel, Field


class Source(BaseModel):
    region: str = Field(None, alias='region')
    env: str = Field(None, alias='prod')
    service_provider: str = Field(None, alias='Azure')


class Executor(BaseModel):
    executor: Optional[str]
    ActiveTasksPerExecutor: Optional[float]
    CPUTimeAndRuntimeRatio: Optional[float]
    Deserializetime: Optional[float]
    DiskBytesSpilledInShuffling: Optional[float]
    FileSystemBytesRead: Optional[float]
    FileSystemBytesWritten: Optional[float]
    percentageOfJvmGCTime: Optional[float]
    MemoryBytesSpilledInShuffling: Optional[float]
    Resultserializationtime: Optional[float]
    BytesWrittenInShuffling: Optional[float]
    usedHeapMemory: Optional[float] = Field(None, alias="usedHeapMemory")
    BytesReadToDiskInShuffling: Optional[float]
    BytesReadInShuffling: Optional[float]
    driver_BlockManager_memory_diskSpaceUsed_MB: Optional[float] = Field(None, alias="BlockManager.memory.diskSpaceUsed_MB")
    driver_BlockManager_memory_offHeapMemUsed_MB: Optional[float] = Field(None, alias="BlockManager.memory.offHeapMemUsed_MB")
    driver_BlockManager_memory_maxMem_MB: Optional[float] = Field(None, alias="BlockManager.memory.maxMem_MB")
    driver_BlockManager_memory_onHeapMemUsed_MB: Optional[float] = Field(None, alias="BlockManager.memory.onHeapMemUsed_MB")
    driver_BlockManager_memory_remainingOnHeapMem_MB: Optional[float] = Field(None, alias="BlockManager.memory.remainingOnHeapMem_MB")
    driver_BlockManager_memory_maxOffHeapMem_MB: Optional[float] = Field(None, alias="BlockManager.memory.maxOffHeapMem_MB")
    driver_BlockManager_memory_maxOnHeapMem_MB: Optional[float] = Field(None, alias="BlockManager.memory.maxOnHeapMem_MB")
    driver_BlockManager_memory_remainingMem_MB: Optional[float] = Field(None, alias="BlockManager.memory.remainingMem_MB")
    driver_BlockManager_memory_memUsed_MB: Optional[float] = Field(None, alias="BlockManager.memory.memUsed_MB")
    driver_BlockManager_memory_remainingOffHeapMem_MB: Optional[float] = Field(None, alias="BlockManager.memory.remainingOffHeapMem_MB")
    driver_CodeGenerator_compilationTime: Optional[float] = Field(None, alias="CodeGenerator.compilationTime")
    driver_CodeGenerator_sourceCodeSize: Optional[float] = Field(None, alias="CodeGenerator.sourceCodeSize")
    driver_CodeGenerator_generatedClassSize: Optional[float] = Field(None, alias="CodeGenerator.generatedClassSize")
    driver_CodeGenerator_generatedMethodSize: Optional[float] = Field(None, alias="CodeGenerator.generatedMethodSize")
    driver_DAGScheduler_job_activeJobs: Optional[float] = Field(None, alias="DAGScheduler.job.activeJobs")
    driver_DAGScheduler_job_allJobs: Optional[float] = Field(None, alias="DAGScheduler.job.allJobs")
    driver_DAGScheduler_messageProcessingTime: Optional[float] = Field(None, alias="DAGScheduler.messageProcessingTime")
    driver_DAGScheduler_stage_failedStages: Optional[float] = Field(None, alias="DAGScheduler.stage.failedStages")
    driver_DAGScheduler_stage_runningStages: Optional[float] = Field(None, alias="DAGScheduler.stage.runningStages")
    driver_DAGScheduler_stage_waitingStages: Optional[float] = Field(None, alias="DAGScheduler.stage.waitingStages")
    driver_executor_jvmGCTime: Optional[float] = Field(None, alias="executor.jvmGCTime")
    driver_executor_threadpool_activeTasks: Optional[float] = Field(None, alias="executor.threadpool.activeTasks")
    driver_executor_filesystem_hdfs_read_ops: Optional[float] = Field(None, alias="executor.filesystem.hdfs.read_ops")
    driver_executor_shuffleRemoteBytesReadToDisk: Optional[float] = Field(None, alias="executor.shuffleRemoteBytesReadToDisk")
    driver_executor_filesystem_hdfs_write_bytes: Optional[float] = Field(None, alias="executor.filesystem.hdfs.write_bytes")
    driver_executor_shuffleRecordsRead: Optional[float] = Field(None, alias="executor.shuffleRecordsRead")
    driver_executor_resultSize: Optional[float] = Field(None, alias="executor.resultSize")
    driver_executor_deserializeCpuTime: Optional[float] = Field(None, alias="executor.deserializeCpuTime")
    driver_executor_bytesWritten: Optional[float] = Field(None, alias="executor.bytesWritten")
    driver_executor_filesystem_hdfs_write_ops: Optional[float] = Field(None, alias="executor.filesystem.hdfs.write_ops")
    driver_executor_filesystem_hdfs_read_bytes: Optional[float] = Field(None, alias="executor.filesystem.hdfs.read_bytes")
    driver_executor_filesystem_file_write_bytes: Optional[float] = Field(None, alias="executor.filesystem.file.write_bytes")
    driver_executor_shuffleWriteTime: Optional[float] = Field(None, alias="executor.shuffleWriteTime")
    driver_executor_shuffleLocalBytesRead: Optional[float] = Field(None, alias="executor.shuffleLocalBytesRead")
    driver_executor_shuffleTotalBytesRead: Optional[float] = Field(None, alias="executor.shuffleTotalBytesRead")
    driver_executor_resultSerializationTime: Optional[float] = Field(None, alias="executor.resultSerializationTime")
    driver_executor_shuffleRecordsWritten: Optional[float] = Field(None, alias="executor.shuffleRecordsWritten")
    driver_executor_memoryBytesSpilled: Optional[float] = Field(None, alias="executor.memoryBytesSpilled")
    driver_executor_shuffleBytesWritten: Optional[float] = Field(None, alias="executor.shuffleBytesWritten")
    driver_executor_bytesRead: Optional[float] = Field(None, alias="executor.bytesRead")
    driver_executor_runTime: Optional[float] = Field(None, alias="executor.runTime")
    driver_executor_recordsRead: Optional[float] = Field(None, alias="executor.recordsRead")
    driver_executor_shuffleFetchWaitTime: Optional[float] = Field(None, alias="executor.shuffleFetchWaitTime")
    driver_executor_recordsWritten: Optional[float] = Field(None, alias="executor.recordsWritten")
    driver_executor_diskBytesSpilled: Optional[float] = Field(None, alias="executor.diskBytesSpilled")
    driver_executor_filesystem_hdfs_largeRead_ops: Optional[float] = Field(None, alias="executor.filesystem.hdfs.largeRead_ops")
    driver_executor_filesystem_file_read_ops: Optional[float] = Field(None, alias="executor.filesystem.file.read_ops")
    driver_executor_threadpool_maxPool_size: Optional[float] = Field(None, alias="executor.threadpool.maxPool_size")
    driver_executor_threadpool_currentPool_size: Optional[float] = Field(None, alias="executor.threadpool.currentPool_size")
    driver_executor_filesystem_file_read_bytes: Optional[float] = Field(None, alias="executor.filesystem.file.read_bytes")
    driver_executor_shuffleRemoteBytesRead: Optional[float] = Field(None, alias="executor.shuffleRemoteBytesRead")
    driver_executor_filesystem_file_largeRead_ops: Optional[float] = Field(None, alias="executor.filesystem.file.largeRead_ops")
    driver_executor_deserializeTime: Optional[float] = Field(None, alias="executor.deserializeTime")
    driver_executor_cpuTime: Optional[float] = Field(None, alias="executor.cpuTime")
    driver_executor_threadpool_completeTasks: Optional[float] = Field(None, alias="executor.threadpool.completeTasks")
    driver_HiveExternal_CatalogfileCacheHits: Optional[float] = Field(None, alias="HiveExternalCatalog.fileCacheHits")
    driver_HiveExternal_CataloghiveClientCalls: Optional[float] = Field(None, alias="HiveExternalCatalog.hiveClientCalls")
    driver_HiveExternal_CatalogfilesDiscovered: Optional[float] = Field(None, alias="HiveExternalCatalog.filesDiscovered")
    driver_HiveExternal_CatalogparallelListingJobCount: Optional[float] = Field(None, alias="HiveExternalCatalog.parallelListingJobCount")
    driver_HiveExternal_CatalogpartitionsFetched: Optional[float] = Field(None, alias="HiveExternalCatalog.partitionsFetched")
    driver_jvm_pools_CompressedClassSpaceused: Optional[float] = Field(None, alias="jvm.pools.Compressed-Class-Space.used")
    driver_jvm_directcapacity: Optional[float] = Field(None, alias="jvm.direct.capacity")
    driver_jvm_totalmax: Optional[float] = Field(None, alias="jvm.total.max")
    driver_jvm_pools_PSSurvivorSpaceusage: Optional[float] = Field(None, alias="jvm.pools.PS-Survivor-Space.usage")
    driver_jvm_pools_CodeCacheinit: Optional[float] = Field(None, alias="jvm.pools.Code-Cache.init")
    driver_jvm_pools_PSSurvivorSpacecommitted: Optional[float] = Field(None, alias="jvm.pools.PS-Survivor-Space.committed")
    driver_jvm_pools_PSOldGeninit: Optional[float] = Field(None, alias="jvm.pools.PS-Old-Gen.init")
    driver_jvm_pools_PSEdenSpaceusedaftergc: Optional[float] = Field(None, alias="jvm.pools.PS-Eden-Space.used-after-gc")
    driver_jvm_nonheapmax: Optional[float] = Field(None, alias="jvm.non-heap.max")
    driver_jvm_pools_Metaspaceused: Optional[float] = Field(None, alias="jvm.pools.Metaspace.used")
    driver_jvm_mappedcount: Optional[float] = Field(None, alias="jvm.mapped.count")
    driver_jvm_pools_Metaspaceusage: Optional[float] = Field(None, alias="jvm.pools.Metaspace.usage")
    driver_jvm_directcount: Optional[float] = Field(None, alias="jvm.direct.count")
    driver_jvm_pools_CompressedClassSpaceinit: Optional[float] = Field(None, alias="jvm.pools.Compressed-Class-Space.init")
    driver_jvm_pools_CodeCacheused: Optional[float] = Field(None, alias="jvm.pools.Code-Cache.used")
    driver_jvm_nonheapusage: Optional[float] = Field(None, alias="jvm.non-heap.usage")
    driver_jvm_totalused: Optional[float] = Field(None, alias="jvm.total.used")
    driver_jvm_nonheapcommitted: Optional[float] = Field(None, alias="jvm.non-heap.committed")
    driver_jvm_heapusage: Optional[float] = Field(None, alias="jvm.heap.usage")
    driver_jvm_heapmax: Optional[float] = Field(None, alias="jvm.heap.max")
    driver_jvm_pools_PSSurvivorSpaceusedaftergc: Optional[float] = Field(None, alias="jvm.pools.PS-Survivor-Space.used-after-gc")
    driver_jvm_PSScavengetime: Optional[float] = Field(None, alias="jvm.PS-Scavenge.time")
    driver_jvm_pools_PSEdenSpacemax: Optional[float] = Field(None, alias="jvm.pools.PS-Eden-Space.max")
    driver_jvm_totalinit: Optional[float] = Field(None, alias="jvm.total.init")
    driver_jvm_pools_PSSurvivorSpaceused: Optional[float] = Field(None, alias="jvm.pools.PS-Survivor-Space.used")
    driver_jvm_pools_PSOldGenusedaftergc: Optional[float] = Field(None, alias="jvm.pools.PS-Old-Gen.used-after-gc")
    driver_jvm_pools_PSSurvivorSpaceinit: Optional[float] = Field(None, alias="jvm.pools.PS-Survivor-Space.init")
    driver_jvm_pools_PSOldGenusage: Optional[float] = Field(None, alias="jvm.pools.PS-Old-Gen.usage")
    driver_jvm_pools_PSOldGenmax: Optional[float] = Field(None, alias="jvm.pools.PS-Old-Gen.max")
    driver_jvm_pools_PSEdenSpaceused: Optional[float] = Field(None, alias="jvm.pools.PS-Eden-Space.used")
    driver_jvm_pools_Metaspacecommitted: Optional[float] = Field(None, alias="jvm.pools.Metaspace.committed")
    driver_jvm_pools_CodeCacheusage: Optional[float] = Field(None, alias="jvm.pools.Code-Cache.usage")
    driver_jvm_pools_PSOldGencommitted: Optional[float] = Field(None, alias="jvm.pools.PS-Old-Gen.committed")
    driver_jvm_mappedused: Optional[float] = Field(None, alias="jvm.mapped.used")
    driver_jvm_pools_PSEdenSpaceinit: Optional[float] = Field(None, alias="jvm.pools.PS-Eden-Space.init")
    driver_jvm_pools_Metaspaceinit: Optional[float] = Field(None, alias="jvm.pools.Metaspace.init")
    driver_jvm_pools_PSEdenSpacecommitted: Optional[float] = Field(None, alias="jvm.pools.PS-Eden-Space.committed")
    driver_jvm_heapinit: Optional[float] = Field(None, alias="jvm.heap.init")
    driver_jvm_pools_PSOldGenused: Optional[float] = Field(None, alias="jvm.pools.PS-Old-Gen.used")
    driver_jvm_PSScavengecount: Optional[float] = Field(None, alias="jvm.PS-Scavenge.count")
    driver_jvm_pools_Metaspacemax: Optional[float] = Field(None, alias="jvm.pools.Metaspace.max")
    driver_jvm_pools_PSEdenSpaceusage: Optional[float] = Field(None, alias="jvm.pools.PS-Eden-Space.usage")
    driver_jvm_pools_CompressedClassSpaceusage: Optional[float] = Field(None, alias="jvm.pools.Compressed-Class-Space.usage")
    driver_jvm_pools_CompressedClassSpacemax: Optional[float] = Field(None, alias="jvm.pools.Compressed-Class-Space.max")
    driver_jvm_pools_PSSurvivorSpacemax: Optional[float] = Field(None, alias="jvm.pools.PS-Survivor-Space.max")
    driver_jvm_pools_CodeCachemax: Optional[float] = Field(None, alias="jvm.pools.Code-Cache.max")
    driver_jvm_heapcommitted: Optional[float] = Field(None, alias="jvm.heap.committed")
    driver_jvm_PSMarkSweeptime: Optional[float] = Field(None, alias="jvm.PS-MarkSweep.time")
    driver_jvm_pools_CompressedClassSpacecommitted: Optional[float] = Field(None, alias="jvm.pools.Compressed-Class-Space.committed")
    driver_jvm_direct_used: Optional[float] = Field(None, alias="jvm.direct.used")
    driver_jvm_pools_CodeCachecommitted: Optional[float]= Field(None, alias="jvm.pools.Code-Cache.committed")
    driver_jvm_PSMarkSweep_count: Optional[float]= Field(None, alias="jvm.PS-MarkSweep.count")
    driver_jvm_nonheap_used: Optional[float]= Field(None, alias="jvm.non-heap.used")
    driver_jvm_total_committed: Optional[float] =Field(None, alias="jvm.total.committed")
    driver_jvm_nonheap_init: Optional[float] = Field(None, alias="jvm.non-heap.init")
    driver_jvm_mapped_capacity: Optional[float] = Field(None, alias="jvm.mapped.capacity")
    driver_jvm_heap_used: Optional[float] = Field(None, alias="jvm.heap.used")
    driver_LiveListenerBus_listenerProcessingTime_org_apache_spark_status_AppStatusListener: Optional[float] = Field(None, alias="LiveListenerBus.listenerProcessingTime.org.apache.spark.status.AppStatusListener")
    driver_LiveListenerBus_queue_appStatus_numDroppedEvents: Optional[float] = Field(None, alias="LiveListenerBus.queue.appStatus.numDroppedEvents")
    driver_LiveListenerBus_queue_appStatus_listenerProcessingTime: Optional[float] = Field(None, alias="LiveListenerBus.queue.appStatus.listenerProcessingTime")
    driver_LiveListenerBus_queue_executorManagement_numDroppedEvents: Optional[float] = Field(None, alias="LiveListenerBus.queue.executorManagement.numDroppedEvents")
    driver_LiveListenerBus_listenerProcessingTime_org_apache_spark_listeners_UnifiedSparkListener: Optional[float] = Field(None, alias="LiveListenerBus.listenerProcessingTime.org.apache.spark.listeners.UnifiedSparkListener")
    driver_LiveListenerBus_queue_executorManagement_listenerProcessingTime: Optional[float] = Field(None, alias="LiveListenerBus.queue.executorManagement.listenerProcessingTime")
    driver_LiveListenerBus_queue_shared_listenerProcessingTime: Optional[float] = Field(None, alias="LiveListenerBus.queue.shared.listenerProcessingTime")
    driver_LiveListenerBus_queue_shared_numDroppedEvents: Optional[float] = Field(None, alias="LiveListenerBus.queue.shared.numDroppedEvents")
    driver_LiveListenerBus_numEventsPosted: Optional[float] = Field(None, alias="LiveListenerBus.numEventsPosted")
    driver_LiveListenerBus_listenerProcessingTime_com_databricks_backend_daemon_driver_DBCEventLoggingListener: Optional[float] = Field(None, alias="LiveListenerBus.listenerProcessingTime.com.databricks.backend.daemon.DBCEventLoggingListener")
    RunningExecutorsInApplication: Optional[float] = Field(None, alias="RunningExecutorsInApplication")


class Task(BaseModel):
    task_run_id: Optional[int]
    task_key: Optional[str]
    task_start_time: Optional[str]
    task_execution_duration: Optional[float]
    task_end_time: Optional[str]
    task_life_cycle_state: Optional[str]
    task_result_state: Optional[str]
    task_state_message: Optional[str]
    task_user_cancelled_or_timedout: Optional[str]


class Run(BaseModel):
    run_id: Optional[int]
    creator_user_name: Optional[str]
    number_in_job: Optional[int]
    original_attempt_run_id: Optional[int]
    life_cycle_state: Optional[str]
    result_state: Optional[str]
    state_message: Optional[str]
    user_cancelled_or_timedout: Optional[str]
    start_time: Optional[str]
    setup_duration: Optional[float]
    execution_duration: Optional[float]
    cleanup_duration: Optional[float]
    end_time: Optional[str]
    run_duration: Optional[str]
    trigger: Optional[str]
    run_name: Optional[str]
    run_page_url: Optional[str]
    run_type: Optional[str]
    format: Optional[str]
    tasks: Optional[List[Task]]


class Job(BaseModel):
    job_id: Optional[int]
    job_name: Optional[str]
    runs: Optional[List[Run]]


class Cluster(BaseModel):
    ClusterName: Optional[str]
    ClusterId: Optional[str]
    MemoryUsedForShuffling: Optional[float]
    RuntimeRatioForCluster: Optional[float]
    NumberOfNodes: Optional[float]
    UsedHeapMemoryForCluster: Optional[float]
    jobs: Optional[List[Job]]
    executor: Optional[List[Executor]]


class Workspace(BaseModel):
    workspaceName: str
    timeGenerated: str
    cluster: Optional[List[Cluster]]


class databricks(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    workspaces: List[Workspace] = []

    class Settings:
        name: "databricks"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field="source",
            granularity=Granularity.minutes  # Optional
            # expire_after_seconds=2  # Optional
        )
