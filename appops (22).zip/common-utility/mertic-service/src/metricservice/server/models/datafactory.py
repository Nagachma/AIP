from datetime import datetime
from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel, Field
from typing import Optional, Dict, List


class pipeline_runs(BaseModel):
    TimeStamp: Optional[str]
    id: Optional[str]
    factoryName: Optional[str]
    # pipeline_runs_id: Optional[float] = Field(None, alias='PipelineRuns.id')
    runId: Optional[str]
    debugRunId: Optional[str]
    runGroupId: Optional[str]
    pipelineName: Optional[str]
    parameters: Optional[str]
    invokedBy_id: Optional[str]
    invokedBy_name: Optional[str]
    invokedBy_invokedByType: Optional[str]
    runStart: Optional[datetime]
    runEnd: Optional[datetime]
    durationInMs: Optional[float]
    status: Optional[str]
    message: Optional[str]
    lastUpdated: Optional[datetime]
    annotations: Optional[str]
    runDimension: Optional[str]
    isLatest: Optional[str]


class activity_runs(BaseModel):
    TimeStamp: Optional[str]
    activityName: Optional[str]
    factoryName: Optional[str]
    activityRunEnd: Optional[datetime]
    # activityName: Optional[float] = Field(None, alias='ActivityRuns.activityName')
    activityRunStart: Optional[datetime]
    activityType: Optional[str]
    durationInMs: Optional[float]
    retryAttempt: Optional[float]
    error_errorCode: Optional[str]
    error_message: Optional[str]
    error_failureType: Optional[float]
    error_target: Optional[str]
    error_details: Optional[str]
    activityRunId: Optional[str]
    iterationHash: Optional[str]
    input_source_type: Optional[str]
    input_sink_type: Optional[str]
    linkedServiceName: Optional[float]
    output_dataRead: Optional[float]
    output_dataWrittent: Optional[float]
    output_filesRead: Optional[float]
    output_sourcePeakConnections: Optional[float]
    output_sinkPeakConnections: Optional[float]
    output_rowsRead: Optional[float]
    output_rowsCopied: Optional[float]
    output_copyDuration: Optional[float]
    output_throughput: Optional[float]
    output_errors: Optional[str]
    output_effectiveIntegrationRuntime: Optional[str]
    output_usedDataIntegrationUnits: Optional[float]
    output_usedParallelCopies: Optional[float]
    pipelineName: Optional[str]
    pipelineRunId: Optional[str]
    status: Optional[str]


class factories(BaseModel):
    factoryName: Optional[str]
    TimeStamp: Optional[str]
    # factoryName: Optional[float] = Field(None,alias='Factories.factoryName')
    PipelineFailedRuns: Optional[float]
    PipelineSucceededRuns: Optional[float]
    PipelineCancelledRuns: Optional[float]
    ActivityFailedRuns: Optional[float]
    ActivitySucceededRuns: Optional[float]
    ActivityCancelledRuns: Optional[float]
    TriggerFailedRuns: Optional[float]
    TriggerSucceededRuns: Optional[float]
    TriggerCancelledRuns: Optional[float]
    IntegrationRuntimeCpuPercentage: Optional[float]
    IntegrationRuntimeAvailableMemory: Optional[float]
    IntegrationRuntimeAverageTaskPickupDelay: Optional[float]
    IntegrationRuntimeQueueLength: Optional[float]
    IntegrationRuntimeAvailableNodeNumber: Optional[float]
    MaxAllowedResourceCount: Optional[float]
    MaxAllowedFactorySizeInGbUnits: Optional[float]
    ResourceCount: Optional[float]
    FactorySizeInGbUnits: Optional[float]
    PipelineElapsedTimeRuns: Optional[float]
    SSISIntegrationRuntimeStartFailed: Optional[float]
    SSISIntegrationRuntimeStartSucceeded: Optional[float]
    SSISIntegrationRuntimeStartCancel: Optional[float]
    SSISIntegrationRuntimeStopStuck: Optional[float]
    SSISIntegrationRuntimeStopSucceeded: Optional[float]
    SSISPackageExecutionSucceeded: Optional[float]
    SSISPackageExecutionFailed: Optional[float]
    SSISPackageExecutionCancel: Optional[float]
    pipeline_runs: Optional[List[pipeline_runs]]
    activity_runs: Optional[List[activity_runs]]


# class Job(BaseModel):
#     jobname: str
#     runs: List[factories]

class Source(BaseModel):
    region: str
    env: str
    service_provider: str


class datafactory(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    factory: List[factories] = []

    class Settings:
        name: "datafactory"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field="source",
            granularity=Granularity.minutes  # Optional
            # expire_after_seconds=2  # Optional
        )
