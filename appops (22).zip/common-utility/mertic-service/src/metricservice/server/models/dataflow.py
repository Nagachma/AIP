from datetime import datetime
from typing import Optional, List

from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel, Field


class Source(BaseModel):
    region: str = Field(None, alias='region')
    env: str = Field(None, alias='prod')
    service_provider: str = Field(None, alias='GCP')


class Workers(BaseModel):
    WorkerId: Optional[str]
    worker_memory_bytes_used: Optional[float]
    worker_memory_container_limit: Optional[float]
    worker_memory_total_limit: Optional[float]

class Pubsub(BaseModel):
    TopicId: Optional[str]
    job_pubsub_write_latencies: Optional[str]
    job_pubsub_write_count: Optional[float]
    job_pubsub_streaming_pull_connection_status: Optional[float]
    job_pubsub_read_latencies: Optional[float]
    job_pubsub_read_count: Optional[float]


class Jobs(BaseModel):
    JobId: Optional[str]
    JobName: Optional[str]
    job_backlog_bytes: Optional[float]
    job_backlog_elements: Optional[float]
    job_bigquery_write_count: Optional[float]
    job_billable_shuffle_data_processed: Optional[float]
    job_bundle_user_processing_latencies: Optional[float]
    job_current_num_vcpus: Optional[float]
    job_current_shuffle_slots: Optional[float]
    job_data_watermark_age: Optional[float]
    job_disk_space_capacity: Optional[float]
    job_duplicates_filtered_out_count: Optional[float]
    job_elapsed_time: Optional[float]
    job_element_count: Optional[float]
    job_elements_produced_count: Optional[float]
    job_estimated_backlog_processing_time: Optional[float]
    job_estimated_byte_count: Optional[float]
    job_estimated_bytes_produced_count: Optional[float]
    job_gpu_memory_utilization: Optional[float]
    job_gpu_utilization: Optional[float]
    job_is_failed: Optional[float]
    job_memory_capacity: Optional[float]
    job_per_stage_data_watermark_age: Optional[float]
    job_per_stage_system_lag: Optional[float]
    job_processing_parallelism_keys: Optional[float]
    job_status: Optional[str]
    job_streaming_engine_key_processing_availability: Optional[float]
    job_streaming_engine_persistent_state_read_bytes_count: Optional[float]
    job_streaming_engine_persistent_state_write_bytes_count: Optional[float]
    job_streaming_engine_persistent_state_write_latencies: Optional[str]
    job_system_lag: Optional[float]
    job_thread_time: Optional[float]
    job_timers_pending_count: Optional[float]
    job_timers_processed_count: Optional[float]
    job_total_memory_usage_time: Optional[float]
    job_total_pd_usage_time: Optional[float]
    job_total_shuffle_data_processed: Optional[float]
    job_total_streaming_data_processed: Optional[float]
    job_total_memory_usjob_total_vcpu_timeage_time: Optional[float]
    job_user_counter: Optional[float]
    workers: Optional[List[Workers]]
    pubsubs: Optional[List[Pubsub]]
    
class Endpoints(BaseModel):
    EndpointName: Optional[str]
    quota_region_endpoint_shuffle_slot_exceeded: Optional[float]
    quota_region_endpoint_shuffle_slot_limit: Optional[float]
    quota_region_endpoint_shuffle_slot_usage: Optional[float]


class dataflow(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    jobs: List[Jobs] = []
    endpoints: List[Endpoints] = []

    class Settings:
        name: "dataflow"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field="source",
            granularity=Granularity.minutes  # Optional
            # expire_after_seconds=2  # Optional
        )
