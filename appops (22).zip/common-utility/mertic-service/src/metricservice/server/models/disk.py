from datetime import datetime
from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel, Field
from typing import Optional, List

class disks(BaseModel):
    server_instance_name: Optional[str]
    server_ip: Optional[str]
    disk_name: Optional[str]
    disk_mount_path: Optional[str]
    disk_status: Optional[str]

class disk_connectivity(BaseModel):
    disks: Optional[List[disks]]


class Source(BaseModel):
    region: str
    env: str
    service_provider: str


class disk(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    disk_connectivity: List[disk_connectivity]

    class Settings:
        name: "disk"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field="source",
            granularity=Granularity.minutes  # Optional
            # expire_after_seconds=2  # Optional
        )
