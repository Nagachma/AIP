from datetime import datetime
from typing import Optional, List, Dict, Any

from beanie import Document
from pydantic import BaseModel, Field, root_validator, Extra


class gcp_inventory(Document):
    id: Any = Field(..., alias='_id')
    projectId: str
    insertedTime: datetime
    assets: List[Dict[str, Any]]

    class Settings:
        name: "gcp_inventory"

