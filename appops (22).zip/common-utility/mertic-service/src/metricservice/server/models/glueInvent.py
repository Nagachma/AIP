from datetime import datetime
from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel , Field
from typing import Optional,Dict,List

class Run(BaseModel):
    job_run_id: str
    ExecutionTime: Optional[int]
    JobRunState: Optional[str]
    StartedOn: Optional[datetime]
    LastModifiedOn: Optional[datetime]
    CompletedOn: Optional[datetime]
    AllocatedCapacity: Optional[float]
    WorkerType: Optional[str]
    NumberOfWorkers: Optional[int]
    GlueVersion: Optional[float]
    ErrorMessage: Optional[str]

class Job(BaseModel):
    jobname: str
    runs: List[Run]

class Source(BaseModel):
    region: str
    env: str
    service_provider: str

class glue_custom(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    jobs: List[Job] = []

    class Settings:
        name: "glue_custom"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field = "source",
            granularity=Granularity.minutes  # Optional
            #expire_after_seconds=2  # Optional
        )
