from datetime import datetime
from typing import Optional, List

from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel, Field


class Source(BaseModel):
    region: Optional[str] = Field(None, alias='region')
    env: Optional[str] = Field(None, alias='prod')
    service_provider: Optional[str] = Field(None, alias='Azure')

class Object(BaseModel):
    index_name: Optional[str]
    object_id: Optional[str]
    object_name: Optional[str]
    schema_name: Optional[str]
    latch_wait_duration_ms: Optional[int] = Field(None, alias='latch_wait_duration_ms')
    latch_session_id: Optional[str] = Field(None, alias='latch_session_id')


class Lock(BaseModel):
    resource_type: Optional[str]
    resource_subtype: Optional[str]
    resource_database_id: Optional[str]
    resource_description: Optional[str]
    resource_associated_entity_id: Optional[str]
    resource_lock_partition: Optional[str]
    request_mode: Optional[str]
    request_type: Optional[str]
    request_status: Optional[str]
    request_reference_count: Optional[str]
    request_lifetime: Optional[str]
    request_session_id: Optional[str]
    request_exec_context_id: Optional[str]
    request_request_id: Optional[str]
    request_owner_type: Optional[str]
    request_owner_id: Optional[str]
    request_owner_guid: Optional[str]
    request_owner_lockspace_id: Optional[str]
    lock_owner_address: Optional[str]


class Query(BaseModel):
    query_text: Optional[str]
    session_id: Optional[int]
    request_id: Optional[str]
    request_start_time: Optional[str]
    status: Optional[int] = Field(None, alias='STATUS')
    user_id: Optional[str]
    user_name: Optional[str]
    login_name: Optional[str]
    connection_id: Optional[str]
    blocking_session_id: Optional[str]
    wait_type: Optional[str]
    wait_time: Optional[int]
    last_wait_type: Optional[str]
    wait_resource: Optional[str]
    open_transaction_count: Optional[int]
    open_resultset_count: Optional[int]
    transaction_id: Optional[str]
    estimated_completion_time: Optional[int]
    total_elapsed_time: Optional[int]
    cpu_time: Optional[int]
    lock_timeout: Optional[str] = Field(None, alias='LOCK_TIMEOUT')
    row_count: Optional[int]
    is_resumable: Optional[str]
    is_query_blocked: Optional[bool]
    query_unresponsive_status: Optional[bool]
    latch_contention_objects: Optional[List[Object]]
    active_locks: Optional[List[Lock]]


class Lock_latch_waits(BaseModel):
    table_id: Optional[str]
    table_name: Optional[str]
    partition_number: Optional[int]
    total_row_lock_waits: Optional[int]
    total_row_lock_wait_in_ms: Optional[int]
    total_page_lock_waits: Optional[int]
    total_page_lock_wait_in_ms: Optional[int]
    total_lock_wait_in_ms: Optional[int]
    total_page_latch_wait_in_ms: Optional[int]
    total_page_io_latch_wait_in_ms: Optional[int]
    total_latch_wait_in_ms: Optional[int]


class Database(BaseModel):
    database_id: Optional[str]
    database_name: Optional[str]
    # database_slowness_status: Optional[bool]
    allocated_data_storage: Optional[float]
    app_cpu_billed: Optional[float]
    app_cpu_percent: Optional[float]
    app_memory_percent: Optional[float]
    blocked_by_firewall: Optional[float]
    connection_failed: Optional[float]
    connection_successful: Optional[float]
    cpu_limit: Optional[float]
    cpu_percent: Optional[float]
    cpu_used: Optional[float]
    deadlock: Optional[float]
    log_write_percent: Optional[float]
    sessions_percent: Optional[float]
    sqlserver_process_core_percent: Optional[float]
    sqlserver_process_memory_percent: Optional[float]
    tempdb_data_size: Optional[float]
    tempdb_log_used_percent: Optional[float]
    workers_percent: Optional[float]
    xtp_storage_percent: Optional[float]
    physical_data_read_percent: Optional[float]
    tempdb_log_size: Optional[float]

    cpu_utilization_time: Optional[int]
    cpu_utilization_percentage: Optional[float]
    db_buffer_memory_utilization_MB: Optional[int]
    db_buffer_memory_utilization_percent: Optional[float]
    queries: Optional[List[Query]]
    waits: Optional[List[Lock_latch_waits]]


class Server(BaseModel):
    server_name: Optional[str]
    sqlserver_start_time: Optional[str]
    committed_memory_to_memory_manager: Optional[int]
    total_physical_memory_mb: Optional[int]
    available_physical_memory_mb: Optional[int]
    system_high_memory_signal_state: Optional[bool]
    system_low_memory_signal_state: Optional[bool]
    system_memory_state_desc: Optional[str]
    physical_memory_in_use_mb: Optional[int]
    committed_memory_utilization_percentage: Optional[float]
    total_active_connections: Optional[int]
    client_machines: Optional[int]
    maximum_connections: Optional[int]
    login_attempts: Optional[int]
    databases: Optional[List[Database]]


class hyperscale_sql(Document):
    source: Optional[Source]
    ts: datetime = Field(default_factory=datetime.now())
    servers: List[Server] = []

    class Settings:
        name: "hyperscale_sql"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field="source",
            granularity=Granularity.minutes  # Optional
            # expire_after_seconds=2  # Optional
        )
