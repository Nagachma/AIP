from datetime import datetime
from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel, Field
from typing import Optional, List


class Nodes(BaseModel):
    node_name: Optional[str] = Field(None, alias='node_name')

class Services(BaseModel):
    service_name: Optional[str] = Field(None, alias='service_name')
    service_status: Optional[str] = Field(None, alias='service_status')
    message: Optional[str] = Field(None, alias='message')
    nodes: Optional[List[Nodes]] = Field(None, alias='nodes')

class Domain(BaseModel):
    domain_name: Optional[str] = Field(None, alias='domain_name')
    services: Optional[List[Services]] = Field(None, alias='services')

class Source(BaseModel):
    region: str
    env: str
    service_provider: str


class informatica_service_status(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    domains: List[Domain]

    class Settings:
        name: "informatica_service_status"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field="source",
            granularity=Granularity.minutes  # Optional
            # expire_after_seconds=2  # Optional
        )
