from datetime import datetime
from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel, Field
from typing import Optional, List

"""
__author__ = "Sachin Maurya"
__copyright__ = "Copyright 2023, The OrchastrAI Project"
__license__ = "GPL"
__version__ = "1.0.0"
__email__ = "sachin.maurya@accenture.com"
"""

class Task(BaseModel):
    run_id: Optional[str] = Field(None, alias='run_id')
    Start_Time: Optional[datetime] = Field(None, alias='Start_Time')
    End_Time: Optional[datetime] = Field(None, alias='End_Time')
    WORKFLOW_EXECUTION_ID: Optional[str] = Field(None, alias='WORKFLOW_EXECUTION_ID')
    SUCCESSFUL_SOURCE_ROWS: Optional[int] = Field(None, alias='SUCCESSFUL_SOURCE_ROWS')
    FAILED_SOURCE_ROWS: Optional[int] = Field(None, alias='FAILED_SOURCE_ROWS')
    SUCCESSFUL_TARGET_ROWS: Optional[int] = Field(None, alias='SUCCESSFUL_TARGET_ROWS')
    FAILED_TARGET_ROWS: Optional[int] = Field(None, alias='FAILED_TARGET_ROWS')
    STATUS: Optional[str] = Field(None, alias='STATUS')
    TASK_NAME: Optional[str] = Field(None, alias='TASK_NAME')
    INTEGRATION_SERVICE: Optional[str] = Field(None, alias='INTEGRATION_SERVICE')
    Folder_Name: Optional[str] = Field(None, alias='Folder_Name')

class WorkFlow(BaseModel):
    Workflow_Name: Optional[str] = Field(None, alias='Workflow_Name')
    Workflow_Status: Optional[str] = Field(None, alias='Workflow_Status')
    DURATION_IN_SECONDS: Optional[str] = Field(None, alias='DURATION_IN_SECONDS')
    run_id: Optional[str] = Field(None, alias='run_id')
    Tasks: Optional[List[Task]] = []


class Source(BaseModel):
    region: str
    env: str
    service_provider: str


class informaticapowerexchange(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    workflows: List[WorkFlow] = []

    class Settings:
        name: "informaticapowerexchange"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field="source",
            granularity=Granularity.minutes  # Optional
            # expire_after_seconds=2  # Optional
        )
