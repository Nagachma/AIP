from datetime import datetime
from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel, Field
from typing import Optional, List


class AvgCPU(BaseModel):
    user: Optional[float]
    nice: Optional[float]
    system: Optional[float]
    iowait: Optional[float]
    steal: Optional[float]
    idle: Optional[float]


class SadfMetrics(BaseModel):
    CPU: Optional[float]
    user: Optional[float] = Field(None, alias='%user')
    nice: Optional[float] = Field(None, alias='%nice')
    system: Optional[float] = Field(None, alias='%system')
    iowait: Optional[float] = Field(None, alias='%iowait')
    steal: Optional[float] = Field(None, alias='%steal')
    idle: Optional[float] = Field(None, alias='%idle')
    proc_s: Optional[float] = Field(None, alias='proc/s')
    cswch_s: Optional[float] = Field(None, alias='cswch/s')
    pswpin_s: Optional[float] = Field(None, alias='pswpin/s')
    pswpout_s: Optional[float] = Field(None, alias='pswpout/s')
    pgpgin_s: Optional[float] = Field(None, alias='pgpgin/s')
    pgpgout_s: Optional[float] = Field(None, alias='pgpgout/s')
    fault_s: Optional[float] = Field(None, alias='fault/s')
    majflt_s: Optional[float] = Field(None, alias='majflt/s')
    pgfree_s: Optional[float] = Field(None, alias='pgfree/s')
    pgscank_s: Optional[float] = Field(None, alias='pgscank/s')
    pgscand_s: Optional[float] = Field(None, alias='pgscand/s')
    pgsteal_s: Optional[float] = Field(None, alias='pgsteal/s')
    vmeff: Optional[float] = Field(None, alias='%vmeff')
    tps: Optional[float] = Field(None, alias='tps')
    rtps: Optional[float] = Field(None, alias='rtps')
    wtps: Optional[float] = Field(None, alias='wtps')
    dtps: Optional[float] = Field(None, alias='dtps')
    bread_s: Optional[float] = Field(None, alias='bread/s')
    bwrtn_s: Optional[float] = Field(None, alias='bwrtn/s')
    bdscd_s: Optional[float] = Field(None, alias='bdscd/s')
    kbmemfree: Optional[float] = Field(None, alias='kbmemfree')
    kbavail: Optional[float] = Field(None, alias='kbavail')
    kbmemused: Optional[float] = Field(None, alias='kbmemused')
    memused: Optional[float] = Field(None, alias='%memused')
    kbbuffers: Optional[float] = Field(None, alias='kbbuffers')
    kbcached: Optional[float] = Field(None, alias='kbcached')
    kbcommit: Optional[float] = Field(None, alias='kbcommit')
    commit: Optional[float] = Field(None, alias='%commit')
    kbactive: Optional[float] = Field(None, alias='kbactive')
    kbinact: Optional[float] = Field(None, alias='kbinact')
    kbdirty: Optional[float] = Field(None, alias='kbdirty')
    kbswpfree: Optional[float] = Field(None, alias='kbswpfree')
    kbswpused: Optional[float] = Field(None, alias='kbswpused')
    swpused: Optional[float] = Field(None, alias='%swpused')
    kbswpcad: Optional[float] = Field(None, alias='kbswpcad')
    swpcad: Optional[float] = Field(None, alias='%swpcad')
    dentunusd: Optional[float] = Field(None, alias='dentunusd')
    file_nr: Optional[float] = Field(None, alias='file-nr')
    inode_nr: Optional[float] = Field(None, alias='inode-nr')
    pty_nr: Optional[float] = Field(None, alias='pty-nr')
    runq_sz: Optional[float] = Field(None, alias='runq-sz')
    plist_sz: Optional[float] = Field(None, alias='plist-sz')
    ldavg_1: Optional[float] = Field(None, alias='ldavg-1')
    ldavg_5: Optional[float] = Field(None, alias='ldavg-5')
    ldavg_15: Optional[float] = Field(None, alias='ldavg-15')
    blocked: Optional[float] = Field(None, alias='blocked')


class Disk(BaseModel):
    disk_device: str
    tps: Optional[float]
    kB_read_s: Optional[float] = Field(None, alias='kB_read/s')
    kB_wrtn_s: Optional[float] = Field(None, alias='kB_wrtn/s')
    kB_dscd_s: Optional[float] = Field(None, alias='kB_dscd/s')
    kB_read: Optional[float]
    kB_wrtn: Optional[float]
    kB_dscd: Optional[float]


class Statistics(BaseModel):
    avg_cpu: AvgCPU = Field(None, alias='avg-cpu')
    sadf_metrics: SadfMetrics
    disk: List[Disk]


class Process(BaseModel):
    pid: int
    elapsed: str
    uid: Optional[float] = Field(None, alias='UID')
    user: str
    per_usr: Optional[float]
    per_system: Optional[float]
    per_guest: Optional[float]
    per_cpu: Optional[float]
    cpu: Optional[float]
    minflt_s: Optional[float]
    majflt_s: Optional[float]
    vsz: Optional[float]
    rss: Optional[float]
    per_mem: Optional[float]
    kB_rd_s: Optional[float]
    kB_wr_s: Optional[float]
    kB_ccwr_s: Optional[float]
    iodelay: Optional[float]
    threads: Optional[str]


class Instance(BaseModel):
    nodename: str
    sysname: Optional[str]
    release: Optional[str]
    machine: Optional[str]
    number_of_cpus: int = Field(None, alias='number-of-cpus')
    statistics: Optional[List[Statistics]]
    processes: Optional[List[Process]]


class Source(BaseModel):
    region: str
    env: str
    service_provider: str


class linux(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    instances: List[Instance]

    class Settings:
        name: "linux"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field="source",
            granularity=Granularity.minutes  # Optional
            # expire_after_seconds=2  # Optional
        )
