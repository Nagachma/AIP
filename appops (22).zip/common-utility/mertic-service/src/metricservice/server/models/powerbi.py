from datetime import datetime
from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel, Field
from typing import Optional, Dict, List





class Dax_query(BaseModel):
    dataset_mode: Optional[str]
    eventText: Optional[str]
    status: Optional[str]
    max_cpu_time: Optional[str]
    max_duration: Optional[str]
    avg_cpu_time: Optional[str]
    avg_duration: Optional[str]


class Executing_user(BaseModel):
    executing_user: Optional[str]
    succceeded_queries: Optional[str]
    failed_queries: Optional[str]
    dax_queries: Optional[List[Dax_query]]


class Artifact(BaseModel):
    artifact_id: Optional[str]
    artifact_name: Optional[str]
    artifact_kind: Optional[str]
    last_accessed: Optional[str]
    subscription_id: Optional[str]
    tenant_id: Optional[str]
    log_count: Optional[str]
    succeeded_refresh: Optional[str]
    failed_refresh: Optional[str]
    unique_user: Optional[str]
    executing_users: Optional[List[Executing_user]]


class Workspace(BaseModel):
    powerbi_workspace_name: Optional[str]
    artifacts: Optional[List[Artifact]]


class Capacity(BaseModel):
    premium_capacity_id: Optional[str] = Field(None, alias='premium_capacity_id')
    workspaces: Optional[List[Workspace]]

class Source(BaseModel):
    region: Optional[str]
    env: Optional[str]
    service_provider: Optional[str]

class powerbi(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    capacities: List[Capacity] = []

    class Settings:
        name: "powerbi"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field="source",
            granularity=Granularity.minutes  # Optional
            # expire_after_seconds=2  # Optional
        )
