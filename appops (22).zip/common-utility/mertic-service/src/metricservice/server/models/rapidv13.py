from datetime import datetime
from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel, Field
from typing import Optional, List


class Page(BaseModel):
    page_id: str
    page_id_ascii: Optional[str]
    app_id: Optional[str]
    application_page_action_time_rate_per_second: Optional[float]
    application_page_action_time_one_min_rate_per_second: Optional[float]
    application_page_action_time_five_min_rate_per_second: Optional[float]
    application_page_action_time_fifteen_min_rate_per_second: Optional[float]
    application_page_action_time_min_seconds: Optional[float]
    application_page_action_time_max_seconds: Optional[float]
    application_page_action_time_mean_seconds: Optional[float]
    application_page_action_time_stddev_seconds: Optional[float]
    application_page_action_time_seconds_count: Optional[float]
    application_page_action_time_seconds_sum: Optional[float]
    application_page_action_time_seconds_quantile_500: Optional[float]
    application_page_action_time_seconds_quantile_750: Optional[float]
    application_page_action_time_seconds_quantile_950: Optional[float]
    application_page_action_time_seconds_quantile_980: Optional[float]
    application_page_action_time_seconds_quantile_990: Optional[float]
    application_page_action_time_seconds_quantile_999: Optional[float]
    application_page_load_time_rate_per_second: Optional[float]
    application_page_load_time_one_min_rate_per_second: Optional[float]
    application_page_load_time_five_min_rate_per_second: Optional[float]
    application_page_load_time_fifteen_min_rate_per_second: Optional[float]
    application_page_load_time_min_seconds: Optional[float]
    application_page_load_time_max_seconds: Optional[float]
    application_page_load_time_mean_seconds: Optional[float]
    application_page_load_time_stddev_seconds: Optional[float]
    application_page_load_time_seconds_count: Optional[float]
    application_page_load_time_seconds_sum: Optional[float]
    application_page_load_time_seconds_quantile_500: Optional[float]
    application_page_load_time_seconds_quantile_750: Optional[float]
    application_page_load_time_seconds_quantile_950: Optional[float]
    application_page_load_time_seconds_quantile_980: Optional[float]
    application_page_load_time_seconds_quantile_990: Optional[float]
    application_page_load_time_seconds_quantile_999: Optional[float]


class Instance(BaseModel):
    instance_name: str
    URL: str
    unique_run_id: Optional[int]
    application_number_of_user_sessions_current: Optional[float]
    application_number_of_user_sessions_max: Optional[float]
    application_number_of_user_sessions_min: Optional[float]
    base_classloader_loadedClasses_count: Optional[float]
    base_classloader_loadedClasses_total: Optional[float]
    base_classloader_unloadedClasses_total: Optional[float]
    base_cpu_availableProcessors: Optional[float]
    base_cpu_processCpuLoad: Optional[float]
    base_cpu_processCpuTime_seconds: Optional[float]
    base_cpu_systemLoadAverage: Optional[float]
    base_gc_time_total_seconds_name_g1_old_generation1: Optional[float]
    base_gc_time_total_seconds_name_g1_young_generation1: Optional[float]
    base_gc_total_name_g1_old_generation1: Optional[float]
    base_gc_total_name_g1_young_generation1: Optional[float]
    base_jvm_uptime_seconds: Optional[float]
    base_memory_committedHeap_bytes: Optional[float]
    base_memory_committedNonHeap_bytes: Optional[float]
    base_memory_maxHeap_bytes: Optional[float]
    base_memory_maxNonHeap_bytes: Optional[float]
    base_memory_usedHeap_bytes: Optional[float]
    base_memory_usedNonHeap_bytes: Optional[float]
    base_thread_count: Optional[float]
    base_thread_daemon_count: Optional[float]
    base_thread_max_count: Optional[float]
    vendor_BufferPool_used_memory_direct_bytes: Optional[float]
    vendor_BufferPool_used_memory_mapped_bytes: Optional[float]
    vendor_BufferPool_used_memory_mapped____non_volatile_memory__bytes: Optional[float]
    vendor_memoryPool_CodeHeap__non_nmethods__usage_bytes: Optional[float]
    vendor_memoryPool_CodeHeap__non_nmethods__usage_max_bytes: Optional[float]
    vendor_memoryPool_CodeHeap__non_profiled_nmethods__usage_bytes: Optional[float]
    vendor_memoryPool_CodeHeap__non_profiled_nmethods__usage_max_bytes: Optional[float]
    vendor_memoryPool_CodeHeap__profiled_nmethods__usage_bytes: Optional[float]
    vendor_memoryPool_CodeHeap__profiled_nmethods__usage_max_bytes: Optional[float]
    vendor_memoryPool_Compressed_Class_Space_usage_bytes: Optional[float]
    vendor_memoryPool_Compressed_Class_Space_usage_max_bytes: Optional[float]
    vendor_memoryPool_G1_Eden_Space_usage_bytes: Optional[float]
    vendor_memoryPool_G1_Eden_Space_usage_max_bytes: Optional[float]
    vendor_memoryPool_G1_Old_Gen_usage_bytes: Optional[float]
    vendor_memoryPool_G1_Old_Gen_usage_max_bytes: Optional[float]
    vendor_memoryPool_G1_Survivor_Space_usage_bytes: Optional[float]
    vendor_memoryPool_G1_Survivor_Space_usage_max_bytes: Optional[float]
    vendor_memoryPool_Metaspace_usage_bytes: Optional[float]
    vendor_memoryPool_Metaspace_usage_max_bytes: Optional[float]
    pages: Optional[List[Page]]


class Source(BaseModel):
    region: str
    env: str
    service_provider: str


class rapidv13(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    instances: List[Instance] = []

    class Settings:
        name: "rapid"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field="source",
            granularity=Granularity.minutes  # Optional
            # expire_after_seconds=2  # Optional
        )
