from datetime import datetime
from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel, Field
from typing import Optional, Dict, List

class queries(BaseModel):
    sql_id: Optional[str]
    username: Optional[str]
    sid: Optional[str]
    SERIAL: Optional[str]
    conn_status: Optional[str]
    schemaname: Optional[str]
    logon_time: Optional[str]
    first_load_time: Optional[str]
    last_load_time: Optional[str]
    sql_fulltext: Optional[str]
    parsing_schema: Optional[str]
    cpu_time: Optional[str]
    elapsed_time: Optional[str]
    module: Optional[str]
    sql_text: Optional[str]
    physical_read_bytes: Optional[str]
    physical_read_requests: Optional[str]
    physical_write_requests: Optional[str]
    physical_write_bytes: Optional[str]
    opname: Optional[str]
    start_time: Optional[str]
    target: Optional[str]
    sofar: Optional[str]
    totalwork: Optional[str]
    units: Optional[str]
    elapsed_seconds: Optional[str]
    message: Optional[str]
    service_name: Optional[str]
    sql_exec_start: Optional[str]
    sql_exec_id: Optional[str]
    query_status: Optional[str]
    error_number: Optional[str]
    error_message: Optional[str]



class totalthreadcount(BaseModel):
    thread_count: Optional[str]
    schemaname: Optional[str]
    osuser: Optional[str]

class querycount(BaseModel):
    query_count: Optional[str]
    inst_id: Optional[str]
    schemaname: Optional[str]
    osuser: Optional[str]

class table_size(BaseModel):
    owner: Optional[str]
    table_name: Optional[str]
    bytes: Optional[str]


class schemas(BaseModel):
    queries: Optional[List[queries]]
    table_size: Optional[List[table_size]]
    querycount: Optional[List[querycount]]
    totalthreadcount: Optional[List[totalthreadcount]]


class Instance(BaseModel):
    instance_name: str
    instance_created_unique_id: Optional[str]
    start_time: Optional[str]
    end_time: Optional[str]
    BinLogDiskUsage: Optional[str]
    BurstBalance: Optional[str]
    ConnectionAttempts: Optional[str]
    CPUCreditUsage: Optional[str]
    CPUCreditBalance: Optional[str]
    EBSByteBalance: Optional[str]
    EBSIOBalance: Optional[str]
    FailedSQLServerAgentJobsCount: Optional[str]
    ReplicaLag: Optional[str]
    ReadLatency: Optional[str]
    CPUUtilization: Optional[str]
    DatabaseConnections: Optional[str]
    DiskQueueDepth: Optional[str]
    FreeableMemory: Optional[str]
    FreeStorageSpace: Optional[str]
    NetworkReceiveThroughput: Optional[str]
    NetworkTransmitThroughput: Optional[str]
    ReadIOPS: Optional[str]
    ReadThroughput: Optional[str]
    SwapUsage: Optional[str]
    WriteIOPS: Optional[str]
    WriteLatency: Optional[str]
    WriteThroughput: Optional[str]
    db_Cache_blks_hit_avg: Optional[str] = Field(None, alias='db.Cache.blks_hit.avg')
    db_Cache_buffers_alloc_avg: Optional[str] = Field(None, alias='db.Cache.buffers_alloc.avg')
    db_Checkpoint_buffers_checkpoint_avg: Optional[str] = Field(None, alias='db.Checkpoint.buffers_checkpoint.avg')
    db_Checkpoint_checkpoint_sync_time_avg: Optional[str] = Field(None, alias='db.Checkpoint.checkpoint_sync_time.avg')
    db_Checkpoint_checkpoint_write_time_avg: Optional[str] = Field(None, alias='db.Checkpoint.checkpoint_write_time.avg')
    db_Checkpoint_checkpoints_req_avg: Optional[str] = Field(None, alias='db.Checkpoint.checkpoints_req.avg')
    db_Checkpoint_checkpoints_timed_avg: Optional[str] = Field(None, alias='db.Checkpoint.checkpoints_timed.avg')
    db_Checkpoint_maxwritten_clean_avg: Optional[str] = Field(None, alias='db.Checkpoint.maxwritten_clean.avg')
    db_Checkpoint_checkpoint_sync_latency_avg: Optional[str] = Field(None, alias='db.Checkpoint.checkpoint_sync_latency.avg')
    db_Checkpoint_checkpoint_write_latency_avg: Optional[str] = Field(None, alias='db.Checkpoint.checkpoint_write_latency.avg')
    db_Concurrency_deadlocks_avg: Optional[str] = Field(None, alias='db.Concurrency.deadlocks.avg')
    db_IO_blk_read_time_avg: Optional[str] = Field(None, alias='db.IO.blk_read_time.avg')
    db_IO_blks_read_avg: Optional[str] = Field(None, alias='db.IO.blks_read.avg')
    db_IO_buffers_backend_avg: Optional[str] = Field(None, alias='db.IO.buffers_backend.avg')
    db_IO_buffers_backend_fsync_avg: Optional[str] = Field(None, alias='db.IO.buffers_backend_fsync.avg')
    db_IO_buffers_clean_avg: Optional[str] = Field(None, alias='db.IO.buffers_clean.avg')
    db_IO_read_latency_avg: Optional[str] = Field(None, alias='db.IO.read_latency.avg')
    db_SQL_tup_deleted_avg: Optional[str] = Field(None, alias='db.SQL.tup_deleted.avg')
    db_SQL_tup_fetched_avg: Optional[str] = Field(None, alias='db.SQL.tup_fetched.avg')
    db_SQL_tup_inserted_avg: Optional[str] = Field(None, alias='db.SQL.tup_inserted.avg')
    db_SQL_tup_returned_avg: Optional[str] = Field(None, alias='db.SQL.tup_returned.avg')
    db_SQL_tup_updated_avg: Optional[str] = Field(None, alias='db.SQL.tup_updated.avg')
    db_state_active_count_avg: Optional[str] = Field(None, alias='db.state.active_count.avg')
    db_state_idle_count_avg: Optional[str] = Field(None, alias='db.state.idle_count.avg')
    db_state_idle_in_transaction_count_avg: Optional[str] = Field(None, alias='db.state.idle_in_transaction_count.avg')
    db_state_idle_in_transaction_aborted_count_avg: Optional[str] = Field(None, alias='db.state.idle_in_transaction_aborted_count.avg')
    db_state_idle_in_transaction_max_time_avg: Optional[str] = Field(None, alias='db.state.idle_in_transaction_max_time.avg')
    db_Temp_temp_bytes_avg: Optional[str] = Field(None, alias='db.Temp.temp_bytes.avg')
    db_Temp_temp_files_avg: Optional[str] = Field(None, alias='db.Temp.temp_files.avg')
    db_Transactions_active_transactions_avg: Optional[str] = Field(None, alias='db.Transactions.active_transactions.avg')
    db_Transactions_blocked_transactions_avg: Optional[str] = Field(None, alias='db.Transactions.blocked_transactions.avg')
    db_Transactions_max_used_xact_ids_avg: Optional[str] = Field(None, alias='db.Transactions.max_used_xact_ids.avg')
    db_Transactions_xact_commit_avg: Optional[str] = Field(None, alias='db.Transactions.xact_commit.avg')
    db_Transactions_xact_rollback_avg: Optional[str] = Field(None, alias='db.Transactions.xact_rollback.avg')
    db_User_numbackends_avg: Optional[str] = Field(None, alias='db.User.numbackends.avg')
    db_WAL_archived_count_avg: Optional[str] = Field(None, alias='db.WAL.archived_count.avg')
    db_WAL_archived_failed_count_avg: Optional[str] = Field(None, alias='db.WAL.archived_failed_count.avg')
    os_cpuUtilization_guest_avg: Optional[str] = Field(None, alias='os.cpuUtilization.guest.avg')
    os_cpuUtilization_idle_avg: Optional[str] = Field(None, alias='os.cpuUtilization.idle.avg')
    os_cpuUtilization_irq_avg: Optional[str] = Field(None, alias='os.cpuUtilization.irq.avg')
    os_cpuUtilization_nice_avg: Optional[str] = Field(None, alias='os.cpuUtilization.nice.avg')
    os_cpuUtilization_steal_avg: Optional[str] = Field(None, alias='os.cpuUtilization.steal.avg')
    os_cpuUtilization_system_avg: Optional[str] = Field(None, alias='os.cpuUtilization.system.avg')
    os_cpuUtilization_total_avg: Optional[str] = Field(None, alias='os.cpuUtilization.total.avg')
    os_cpuUtilization_user_avg: Optional[str] = Field(None, alias='os.cpuUtilization.user.avg')
    os_cpuUtilization_wait_avg: Optional[str] = Field(None, alias='os.cpuUtilization.wait.avg')
    os_diskIO_avgQueueLen_avg: Optional[str] = Field(None, alias='os.diskIO.avgQueueLen.avg')
    os_diskIO_avgReqSz_avg: Optional[str] = Field(None, alias='os.diskIO.avgReqSz.avg')
    os_diskIO_await_avg: Optional[str] = Field(None, alias='os.diskIO.await.avg')
    os_diskIO_readIOsPS_avg: Optional[str] = Field(None, alias='os.diskIO.readIOsPS.avg')
    os_diskIO_readKb_avg: Optional[str] = Field(None, alias='os.diskIO.readKb.avg')
    os_diskIO_readKbPS_avg: Optional[str] = Field(None, alias='os.diskIO.readKbPS.avg')
    os_diskIO_rrqmPS_avg: Optional[str] = Field(None, alias='os.diskIO.rrqmPS.avg')
    os_diskIO_tps_avg: Optional[str] = Field(None, alias='os.diskIO.tps.avg')
    os_diskIO_util_avg: Optional[str] = Field(None, alias='os.diskIO.util.avg')
    os_diskIO_writeIOsPS_avg: Optional[str] = Field(None, alias='os.diskIO.writeIOsPS.avg')
    os_diskIO_writeKb_avg: Optional[str] = Field(None, alias='os.diskIO.writeKb.avg')
    os_diskIO_writeKbPS_avg: Optional[str] = Field(None, alias='os.diskIO.writeKbPS.avg')
    os_diskIO_wrqmPS_avg: Optional[str] = Field(None, alias='os.diskIO.wrqmPS.avg')
    os_fileSys_maxFiles_avg: Optional[str] = Field(None, alias='os.fileSys.maxFiles.avg')
    os_fileSys_total_avg: Optional[str] = Field(None, alias='os.fileSys.total.avg')
    os_fileSys_used_avg: Optional[str] = Field(None, alias='os.fileSys.used.avg')
    os_fileSys_usedFilePercent_avg: Optional[str] = Field(None, alias='os.fileSys.usedFilePercent.avg')
    os_fileSys_usedFiles_avg: Optional[str] = Field(None, alias='os.fileSys.usedFiles.avg')
    os_fileSys_usedPercent_avg: Optional[str] = Field(None, alias='os.fileSys.usedPercent.avg')
    os_general_numVCPUs_avg: Optional[str] = Field(None, alias='os.general.numVCPUs.avg')
    os_loadAverageMinute_fifteen_avg: Optional[str] = Field(None, alias='os.loadAverageMinute.fifteen.avg')
    os_loadAverageMinute_five_avg: Optional[str] = Field(None, alias='os.loadAverageMinute.five.avg')
    os_loadAverageMinute_one_avg: Optional[str] = Field(None, alias='os.loadAverageMinute.one.avg')
    os_memory_active_avg: Optional[str] = Field(None, alias='os.memory.active.avg')
    os_memory_buffers_avg: Optional[str] = Field(None, alias='os.memory.buffers.avg')
    os_memory_cached_avg: Optional[str] = Field(None, alias='os.memory.cached.avg')
    os_memory_dirty_avg: Optional[str] = Field(None, alias='os.memory.dirty.avg')
    os_memory_free_avg: Optional[str] = Field(None, alias='os.memory.free.avg')
    os_memory_hugePagesFree_avg: Optional[str] = Field(None, alias='os.memory.hugePagesFree.avg')
    os_memory_hugePagesRsvd_avg: Optional[str] = Field(None, alias='os.memory.hugePagesRsvd.avg')
    os_memory_hugePagesSize_avg: Optional[str] = Field(None, alias='os.memory.hugePagesSize.avg')
    os_memory_hugePagesSurp_avg: Optional[str] = Field(None, alias='os.memory.hugePagesSurp.avg')
    os_memory_hugePagesTotal_avg: Optional[str] = Field(None, alias='os.memory.hugePagesTotal.avg')
    os_memory_inactive_avg: Optional[str] = Field(None, alias='os.memory.inactive.avg')
    os_memory_mapped_avg: Optional[str] = Field(None, alias='os.memory.mapped.avg')
    os_memory_pageTables_avg: Optional[str] = Field(None, alias='os.memory.pageTables.avg')
    os_memory_slab_avg: Optional[str] = Field(None, alias='os.memory.slab.avg')
    os_memory_total_avg: Optional[str] = Field(None, alias='os.memory.total.avg')
    os_memory_writeback_avg: Optional[str] = Field(None, alias='os.memory.writeback.avg')
    os_network_rx_avg: Optional[str] = Field(None, alias='os.network.rx.avg')
    os_network_tx_avg: Optional[str] = Field(None, alias='os.network.tx.avg')
    os_swap_cached_avg: Optional[str] = Field(None, alias='os.swap.cached.avg')
    os_swap_free_avg: Optional[str] = Field(None, alias='os.swap.free.avg')
    os_swap_total_avg: Optional[str] = Field(None, alias='os.swap.total.avg')
    os_swap_in_avg: Optional[str] = Field(None, alias='os.swap.in.avg')
    os_swap_out_avg: Optional[str] = Field(None, alias='os.swap.out.avg')
    os_tasks_blocked_avg: Optional[str] = Field(None, alias='os.tasks.blocked.avg')
    os_tasks_running_avg: Optional[str] = Field(None, alias='os.tasks.running.avg')
    os_tasks_sleeping_avg: Optional[str] = Field(None, alias='os.tasks.sleeping.avg')
    os_tasks_stopped_avg: Optional[str] = Field(None, alias='os.tasks.stopped.avg')
    os_tasks_total_avg: Optional[str] = Field(None, alias='os.tasks.total.avg')
    os_tasks_zombie_avg: Optional[str] = Field(None, alias='os.tasks.zombie.avg')
    schemas: Optional[List[schemas]]


class Source(BaseModel):
    region: str
    env: str
    service_provider: str


class rdsoracle(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    instances: List[Instance] = []

    class Settings:
        name: "rdsoracle"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field="source",
            granularity=Granularity.minutes  # Optional
            # expire_after_seconds=2  # Optional
        )
