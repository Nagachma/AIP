from datetime import datetime
from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel, Field
from typing import Optional, List


class Instances(BaseModel):
    ip: Optional[str]
    redis_version: Optional[str]
    redis_build_id: Optional[str]
    redis_mode: Optional[str]
    process_id: Optional[float]
    process_supervised: Optional[str]
    run_id: Optional[str]
    io_threads_active: Optional[float]
    connected_clients: Optional[float]
    cluster_connections: Optional[float]
    maxclients: Optional[float]
    client_recent_max_input_buffer: Optional[float]
    client_recent_max_output_buffer: Optional[float]
    blocked_clients: Optional[float]
    tracking_clients: Optional[float]
    clients_in_timeout_table: Optional[float]
    used_memory: Optional[float]
    used_memory_human: Optional[str]
    used_memory_rss: Optional[float]
    used_memory_rss_human: Optional[str]
    used_memory_peak: Optional[float]
    used_memory_peak_human: Optional[str]
    used_memory_peak_perc: Optional[str]
    used_memory_overhead: Optional[float]
    used_memory_startup: Optional[float]
    used_memory_dataset: Optional[float]
    used_memory_dataset_perc: Optional[str]
    total_system_memory: Optional[float]
    total_system_memory_human: Optional[str]
    used_memory_lua: Optional[float]
    used_memory_lua_human: Optional[str]
    used_memory_scripts: Optional[float]
    used_memory_scripts_human: Optional[str]
    maxmemory: Optional[float]
    mem_clients_slaves: Optional[float]
    mem_clients_normal: Optional[float]
    mem_cluster_links: Optional[float]
    mem_aof_buffer: Optional[float]
    mem_replication_backlog: Optional[float]
    mem_total_replication_buffers: Optional[float]
    mem_allocator: Optional[str]
    total_connections_received: Optional[float]
    total_commands_processed: Optional[float]
    rejected_connections: Optional[float]
    used_cpu_sys: Optional[float]
    used_cpu_user: Optional[float]
    used_cpu_sys_children: Optional[float]
    used_cpu_user_children: Optional[float]
    used_cpu_sys_main_thread: Optional[float]
    used_cpu_user_main_thread: Optional[float]
    errorstat_ERR: Optional[str]
    cluster_enabled: Optional[float]
    latency_percentiles_usec_hello_p50: Optional[float]
    latency_percentiles_usec_hello_p99: Optional[float]
    latency_percentiles_usec_hello_p999: Optional[float]
    latency_percentiles_usec_ping_p50: Optional[float]
    latency_percentiles_usec_ping_p99: Optional[float]
    latency_percentiles_usec_ping_p999: Optional[float]
    latency_percentiles_usec_command_docs_p50: Optional[float]
    latency_percentiles_usec_command_docs_p99: Optional[float]
    latency_percentiles_usec_command_docs_p999: Optional[float]
    latency_percentiles_usec_memory_stats_p50: Optional[float]
    latency_percentiles_usec_memory_stats_p99: Optional[float]
    latency_percentiles_usec_memory_stats_p999: Optional[float]
    latency_percentiles_usec_memory_doctor_p50: Optional[float]
    latency_percentiles_usec_memory_doctor_p99: Optional[float]
    latency_percentiles_usec_memory_doctor_p999: Optional[float]
    latency_percentiles_usec_info_p50: Optional[float]
    latency_percentiles_usec_info_p99: Optional[float]
    latency_percentiles_usec_info_p999: Optional[float]
    latency_percentiles_usec_latency_graph_p50: Optional[float]
    latency_percentiles_usec_latency_graph_p99: Optional[float]
    latency_percentiles_usec_latency_graph_p999: Optional[float]
    latency_percentiles_usec_latency_latest_p50: Optional[float]
    latency_percentiles_usec_latency_latest_p99: Optional[float]
    latency_percentiles_usec_latency_latest_p999: Optional[float]
    latency_percentiles_usec_latency_history_p50: Optional[float]
    latency_percentiles_usec_latency_history_p99: Optional[float]
    latency_percentiles_usec_latency_history_p999: Optional[float]
    latency_percentiles_usec_slowlog_get_p50: Optional[float]
    latency_percentiles_usec_slowlog_get_p99: Optional[float]
    latency_percentiles_usec_slowlog_get_p999: Optional[float]
    latency_percentiles_usec_slowlog_help_p50: Optional[float]
    latency_percentiles_usec_slowlog_help_p99: Optional[float]
    latency_percentiles_usec_slowlog_help_p999: Optional[float]


class Source(BaseModel):
    region: str
    env: str
    service_provider: str


class redis(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    instances: List[Instances]

    class Settings:
        name: "redis"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field="source",
            granularity=Granularity.minutes  # Optional
            # expire_after_seconds=2  # Optional
        )
