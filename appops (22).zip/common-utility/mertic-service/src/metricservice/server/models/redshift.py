from datetime import datetime
from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel , Field
from typing import Optional,Dict,List

class Queries(BaseModel):
    query_id: Optional[str]
    querytext: Optional[str]
    # min_run_in_ms: Optional[float]
    # max_run_in_ms: Optional[float]
    # avg_run_in_ms: Optional[float]
    total_run_in_ms: Optional[float]
    user_name: Optional[str]
    last_run: Optional[datetime]
    aborted: Optional[float]
    userid: Optional[float]
    total_wlm_queue_time_ms: Optional[float]
    error_record_time: Optional[datetime]
    error_code: Optional[int]
    error_context: Optional[str]
    error: Optional[str]
    


class Database(BaseModel):
    database_name: Optional[str]
    queries: Optional[List[Queries]]


class Clusters(BaseModel):
    cluster_name: str
    cluster_unique_id:Optional[str]
    start_time: Optional[datetime]
    CommitQueueLength: Optional[float]
    ConcurrencyScalingActiveClusters: Optional[float]
    ConcurrencyScalingSeconds: Optional[float]
    HealthStatus: Optional[float]
    MaintenanceMode: Optional[float]
    MaxConfiguredConcurrencyScalingClusters: Optional[float]
    DatabaseConnections: Optional[float]
    ReadIOPS: Optional[float]
    ReadLatency: Optional[float]
    WriteLatency: Optional[float]
    ReadThroughput: Optional[float]
    WriteThroughput: Optional[float]
    CPUUtilization: Optional[float]
    PercentageDiskSpaceUsed: Optional[float]
    StorageUsed: Optional[float]
    WLMQueueLength: Optional[float]
    WriteIOPS: Optional[float]
    WLMQueueWaitTime: Optional[float]
    WLMQueriesCompletedPerSecond: Optional[float]
    WLMQueryDuration: Optional[float]
    WLMRunningQueries: Optional[float]
    SchemaQuota: Optional[float]
    NetworkReceiveThroughput: Optional[float]
    NetworkTransmitThroughput: Optional[float]
    QueriesCompletedPerSecond: Optional[float]
    QueryDuration: Optional[float]
    QueryRuntimeBreakdown: Optional[float]
    RedshiftManagedStorageTotalCapacity: Optional[float]
    TotalTableCount: Optional[float]
    NumExceededSchemaQuotas: Optional[float]
    PercentageQuotaUsed: Optional[float]
    databases: Optional[List[Database]]


class Source(BaseModel):
    region: str
    env: str
    service_provider: str

class redshift(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    clusters: List[Clusters] = []

    class Settings:
        name: "redshift"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field = "source",
            granularity=Granularity.minutes  # Optional
            #expire_after_seconds=2  # Optional
        )
