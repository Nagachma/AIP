from datetime import datetime
from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel, Field
from typing import Optional, List


class ConnectionStatus(BaseModel):
    host: Optional[str]
    username_ascii: Optional[str]
    username: Optional[str]
    server_reachability: Optional[str]
    server_connectivity: Optional[str]
    conn_directory: Optional[str]
    list_of_files: Optional[str]


class Source(BaseModel):
    region: str
    env: str
    service_provider: str


class sftp(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    connection_status: List[ConnectionStatus]

    class Settings:
        name: "sftp"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field="source",
            granularity=Granularity.minutes  # Optional
            # expire_after_seconds=2  # Optional
        )
