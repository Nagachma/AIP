from datetime import datetime
from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel , Field
from typing import Optional,Dict,List

class queries(BaseModel):
    request_id: Optional[str]
    session_id: Optional[str] = Field(None, alias='session_id')
    status: Optional[str] = Field(None, alias='status')
    submit_time: Optional[str] = Field(None, alias='submit_time')
    start_time: Optional[str] = Field(None, alias='start_time')
    end_compile_time: Optional[str] = Field(None, alias='end_compile_time')
    end_time: Optional[str] = Field(None, alias='end_time')
    total_elapsed_time: Optional[str] = Field(None, alias='total_elapsed_time')
    error_id: Optional[str] = Field(None, alias='error_id')
    database_id: Optional[str] = Field(None, alias='database_id')
    command: Optional[str] = Field(None, alias='command')
    resource_class: Optional[str] = Field(None, alias='resource_class')
    importance: Optional[str] = Field(None, alias='importance')
    group_name: Optional[str] = Field(None, alias='group_name')
    classifier_name: Optional[str] = Field(None, alias='classifier_name')
    resource_allocation_percentage: Optional[str] = Field(None, alias='resource_allocation_percentage')
    result_cache_hit: Optional[str] = Field(None, alias='result_cache_hit')
    client_correlation_id: Optional[str] = Field(None, alias='client_correlation_id')
    command2: Optional[str] = Field(None, alias='command2')
    error_details: Optional[str] = Field(None, alias='error_details')
    metric_datetime: Optional[str] = Field(None, alias='metric_datetime')

class bigdatapool(BaseModel):
    big_data_pool_name : Optional[str]
    bigdatapool_BigDataPoolAllocatedCores: Optional[float] = Field(None, alias='BigDataPool.BigDataPoolAllocatedCores')
    bigdatapool_BigDataPoolAllocatedMemory: Optional[float] = Field(None, alias='BigDataPool.BigDataPoolAllocatedMemory')
    bigdatapool_BigDataPoolApplicationsActive: Optional[float] = Field(None, alias='BigDataPool.BigDataPoolApplicationsActive')
    bigdatapool_BigDataPoolApplicationsEnded: Optional[float] = Field(None, alias='BigDataPool.BigDataPoolApplicationsEnded')
class sqlpool(BaseModel):
    sql_pool_name : Optional[str]
    sqlPool_DWULimit: Optional[float] = Field(None, alias='SQLPool.DWULimit')
    sqlPool_DWUUsed: Optional[float] = Field(None, alias='SQLPool.DWUUsed')
    sqlPool_DWUUsedPercent: Optional[float] = Field(None, alias='SQLPool.DWUUsedPercent')
    sqlPool_ConnectionsBlockedByFirewall: Optional[float] = Field(None, alias='SQLPool.ConnectionsBlockedByFirewall')
    sqlPool_AdaptiveCacheHitPercent: Optional[float] = Field(None, alias='SQLPool.AdaptiveCacheHitPercent')
    sqlPool_AdaptiveCacheUsedPercent: Optional[float] = Field(None, alias='SQLPool.AdaptiveCacheUsedPercent')
    sqlPool_LocalTempDBUsedPercent: Optional[float] = Field(None, alias='SQLPool.LocalTempDBUsedPercent')
    sqlPool_MemoryUsedPercent: Optional[float] = Field(None, alias='SQLPool.MemoryUsedPercent')
    sqlPool_CPUPercent: Optional[float] = Field(None, alias='SQLPool.CPUPercent')
    sqlPool_Connections: Optional[float] = Field(None, alias='SQLPool.Connections')
    sqlPool_ActiveQueries: Optional[float] = Field(None, alias='SQLPool.ActiveQueries')
    sqlPool_QueuedQueries: Optional[float] = Field(None, alias='SQLPool.QueuedQueries')
    sqlPool_WLGActiveQueries: Optional[float] = Field(None, alias='SQLPool.WLGActiveQueries')
    sqlPool_WLGActiveQueriesTimeouts: Optional[float] = Field(None, alias='SQLPool.WLGActiveQueriesTimeouts')
    sqlPool_WLGQueuedQueries: Optional[float] = Field(None, alias='SQLPool.WLGQueuedQueries')
    sqlPool_WLGAllocationBySystemPercent: Optional[float] = Field(None, alias='SQLPool.WLGAllocationBySystemPercent')
    sqlPool_WLGAllocationByEffectiveCapResourcePercent: Optional[float] = Field(None, alias='SQLPool.WLGAllocationByEffectiveCapResourcePercent')
    sqlPool_WLGEffectiveCapResourcePercent: Optional[float] = Field(None, alias='SQLPool.WLGEffectiveCapResourcePercent')
    sqlPool_WLGEffectiveMinResourcePercent: Optional[float] = Field(None, alias='SQLPool.WLGEffectiveMinResourcePercent')
    queries: Optional[List[queries]]
class workspace(BaseModel):
    workspace_name : Optional[str]
    workspace_BuiltinSqlPoolDataProcessedBytes: Optional[float] = Field(None,alias='Workspace.BuiltinSqlPoolDataProcessedBytes')
    workspace_IntegrationActivityRunsEnded: Optional[float] = Field(None, alias='Workspace.IntegrationActivityRunsEnded')
    workspace_IntegrationPipelineRunsEnded: Optional[float] = Field(None, alias='Workspace.IntegrationPipelineRunsEnded')
    workspace_IntegrationTriggerRunsEnded: Optional[float] = Field(None, alias='Workspace.IntegrationTriggerRunsEnded')
    workspace_SQLStreamingBackloggedInputEventSources: Optional[float] = Field(None, alias='Workspace.SQLStreamingBackloggedInputEventSources')
    workspace_SQLStreamingConversionErrors: Optional[float] = Field(None, alias='Workspace.SQLStreamingConversionErrors')
    workspace_SQLStreamingDeserializationError: Optional[float] = Field(None, alias='Workspace.SQLStreamingDeserializationError')
    workspace_SQLStreamingEarlyInputEvents: Optional[float] = Field(None, alias='Workspace.SQLStreamingEarlyInputEvents')
    workspace_SQLStreamingInputEventBytes: Optional[float] = Field(None, alias='Workspace.SQLStreamingInputEventBytes')
    workspace_SQLStreamingInputEvents: Optional[float] = Field(None, alias='Workspace.SQLStreamingInputEvents')
    workspace_SQLStreamingInputEventsSourcesPerSecond: Optional[float] = Field(None, alias='Workspace.SQLStreamingInputEventsSourcesPerSecond')
    workspace_SQLStreamingLateInputEvents: Optional[float] = Field(None, alias='Workspace.SQLStreamingLateInputEvents')
    workspace_SQLStreamingOutOfOrderEvents: Optional[float] = Field(None, alias='Workspace.SQLStreamingOutOfOrderEvents')
    workspace_SQLStreamingOutputEvents: Optional[float] = Field(None, alias='Workspace.SQLStreamingOutputEvents')
    workspace_SQLStreamingOutputWatermarkDelaySeconds: Optional[float] = Field(None, alias='Workspace.SQLStreamingOutputWatermarkDelaySeconds')
    workspace_SQLStreamingResourceUtilization: Optional[float] = Field(None, alias='Workspace.SQLStreamingResourceUtilization')
    workspace_SQLStreamingRuntimeErrors: Optional[float] = Field(None, alias='Workspace.SQLStreamingRuntimeErrors')
    bigDataPools : Optional[List[bigdatapool]]
    sqlPools: Optional[List[sqlpool]]


class Source(BaseModel):
    region: str
    env: str
    service_provider: str

class synapse(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    workspaces: List[workspace] = []

    class Settings:
        name: "synapse"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field = "source",
            granularity=Granularity.minutes  # Optional
            #expire_after_seconds=2  # Optional
        )
