from datetime import datetime
from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel , Field
from typing import Optional,Dict,List

class Processwise(BaseModel):
    process_id : Optional[str]
    unique_id : Optional[str]
    # process_name : Optional[str]
    # priority_class : Optional[str]
    handle_count : Optional[str]
    working_set : Optional[str]
    paged_memory_size : Optional[str]
    private_memory_size : Optional[str]
    virtual_memory_size : Optional[str]
    # total_processor_time : Optional[str]
    # session_identifier : Optional[float]
    VM : Optional[str]
    PM : Optional[str]
    NPM : Optional[str]
    cpu : Optional[str]
    exit_code : Optional[str]
    has_exited : Optional[str]
    exit_time : Optional[str]
    # max_working_set : Optional[float]
    # min_working_set : Optional[float]
    # non_paged_system_memory_size : Optional[float]
    paged_system_memory_size : Optional[str]
    # priority_bost_enabled : Optional[str]
    # privileged_processor_time : Optional[str]
    # processor_afinity : Optional[float]
    # responding : Optional[str]
    user_processor_time : Optional[str]



class Workbook(BaseModel):
    workbook_name: Optional[str]
    workbook_id: Optional[int]
    workbook_size_bytes: Optional[int]
    start_time: Optional[datetime]
    end_time: Optional[datetime]
    load_time: Optional[str]
    sites_name: Optional[str]
    sites_id: Optional[int]
    project_name:Optional[str]
    project_id: Optional[str]
    active_users: Optional[int]
    background_job_failure: Optional[int]
    extract_refresh_fails: Optional[int]
    view_accessed: Optional[int]
    processwise: Optional[List[Processwise]]


class Source(BaseModel):
    region: Optional[str]
    env: Optional[str]
    service_provider: Optional[str]

class tableau(Document):
    source: Optional[Source]
    ts: datetime = Field(default_factory=datetime.now())
    workbooks: List[Workbook] = []


    class Settings:
        name: "tableau"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field = "source",
            granularity=Granularity.minutes  # Optional
            #expire_after_seconds=2  # Optional
        )
