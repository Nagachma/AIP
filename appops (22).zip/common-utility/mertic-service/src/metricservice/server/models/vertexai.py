from datetime import datetime
from typing import Optional, List

from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel, Field

class Endpoints(BaseModel):
    start_time: Optional[datetime] = Field(None, alias='start_time')
    end_time: Optional[datetime] = Field(None, alias='end_time')
    project_id: Optional[str]
    deployed_model_id: Optional[str]
    replica_id: Optional[str]
    endpoint_id: Optional[str]
    duty_cycle: Optional[float]
    bytes_used_accelerator_memory: Optional[float]
    endpoint_utilization: Optional[float]
    bytes_used_online_memory: Optional[float]
    received_bytes_count: Optional[float]
    sent_bytes_count: Optional[float]
    prediction_latencies: Optional[float]
    response_count: Optional[float]
    replicas: Optional[float]
    target_replicas: Optional[float]

class Training(BaseModel):
    start_time: Optional[datetime] = Field(None, alias='start_time')
    end_time: Optional[datetime] = Field(None, alias='end_time')
    project_id: Optional[str]
    job_id: Optional[str]
    utilization_accelerator_memory: Optional[float]
    utilization_accelerator: Optional[float]
    utilization_cpu: Optional[float]
    utilization_memory: Optional[float]
    received_bytes_count_training: Optional[float]
    sent_bytes_count_training: Optional[float]
    request_latencies: Optional[float]
    job_status: Optional[str]
    job_duration: Optional[str]

class Featurestore(BaseModel):
    start_time: Optional[datetime] = Field(None, alias='start_time')
    end_time: Optional[datetime] = Field(None, alias='end_time')
    project_id: Optional[str]
    featurestore_id: Optional[str]
    cpu_load: Optional[float]
    authentication_count: Optional[float]
    cpu_load_hottest_node: Optional[float]
    node_count: Optional[float]
    stored_bytes: Optional[float]

class Source(BaseModel):
    region: str = Field(None, alias='region')
    env: str = Field(None, alias='prod')
    service_provider: str = Field(None, alias='GCP')

class vertexai(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    endpoints: List[Endpoints] = []
    training: List[Training] = []
    featurestore: List[Featurestore] = []

    class Settings:
        name: "vertexai"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field="source",
            granularity=Granularity.minutes  # Optional
            # expire_after_seconds=2  # Optional
        )