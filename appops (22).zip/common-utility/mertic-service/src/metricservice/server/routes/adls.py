import datetime

from fastapi import APIRouter

from metricservice.server.models.adls import Metrics, Event
from metricservice.server.models.adls import adls

adlspipelinerouter = APIRouter()


def prepare_adls_response(start_date: datetime.datetime,
                          end_date: datetime.datetime,
                          env: str,
                          results: adls) -> dict:
    flat_list = []
    for doc in results:

        adls1_metric_value = []
        adls2_metric_value = []
        if len(doc.adls1) > 0:

            for metrics in doc.adls1:
                is_event=None
                for key in metrics.dict().keys():
                    value1 = metrics.dict()[key]
                    if value1 is not None and type(value1) != list:
                        adls1_metric_value.append(value1)
                    elif value1 is not None and type(value1) == list:
                        if key=='error_events' and len(value1)>0:
                            is_event=True
                    else:
                        adls1_metric_value.append('')
                if is_event:
                    for event1 in metrics.dict()['error_events']:
                        adls1_metric_value_temp=[]
                        adls1_metric_value_temp.extend(adls1_metric_value)
                        for key3 in event1.keys():
                            if event1[key3] is None:
                                value3=''
                            else:
                                value3 = event1[key3]
                            adls1_metric_value_temp.append(value3)
                        metric_record1 = {"timestamp": str(doc.ts), "metric_value": adls1_metric_value_temp}
                        flat_list.append(metric_record1)
                else:
                    e1 = Event()
                    l1 = len(e1.dict().keys())
                    event_metric_value_temp1 =['']*l1
                    adls1_metric_value.extend(event_metric_value_temp1)
                    metric_record = {"timestamp": str(doc.ts), "metric_value": adls1_metric_value}
                    flat_list.append(metric_record)
                # metric_record = {"timestamp": str(doc.ts), "metric_value": adls1_metric_value}
                # flat_list.append(metric_record)
                adls1_metric_value = list()
        if len(doc.adls2) > 0:

            for metrics in doc.adls2:
                is_event = None
                for key in metrics.dict().keys():
                    value2 = metrics.dict()[key]
                    if value2 is not None and type(value2) != list:
                        adls2_metric_value.append(value2)
                    elif value2 is not None and type(value2) == list:
                        if key=='error_events' and len(value2)>0:
                            is_event=True
                    else:
                        adls2_metric_value.append('')
                if is_event:
                    for event2 in metrics.dict()['error_events']:
                        adls2_metric_value_temp=[]
                        adls2_metric_value_temp.extend(adls2_metric_value)
                        for key4 in event2.keys():
                            if event2[key4] is None:
                                value4=''
                            else:
                                value4 = event2[key4]
                            adls2_metric_value_temp.append(value4)
                        metric_record2 = {"timestamp": str(doc.ts), "metric_value": adls2_metric_value_temp}
                        flat_list.append(metric_record2)
                else:
                    e2 = Event()
                    l2 = len(e2.dict().keys())
                    event_metric_value_temp2 =['']*l2
                    adls2_metric_value.extend(event_metric_value_temp2)
                    metric_record = {"timestamp": str(doc.ts), "metric_value": adls2_metric_value}
                    flat_list.append(metric_record)
                # metric_record = {"timestamp": str(doc.ts), "metric_value": adls2_metric_value}
                # flat_list.append(metric_record)
                adls2_metric_value = list()
    # get all the metric key names by creating test object
    a1 = Metrics(account_name="example1")
    a2 = Event()
    metric_names = list(a1.dict(by_alias=True, exclude={"error_events"}))+list(a2.dict(exclude={"Event"}))

    # create final response
    response_metrics_record = {
        "service_provider": "",
        "env_name": env,
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["account_name"], "metric_name": metric_names},
        "metric_records": flat_list
    }
    return response_metrics_record


# TODO: removed optional params and test with paging before production
@adlspipelinerouter.get("/", response_description="Metric records retrieved")
async def get_adls_record(start_date: datetime.datetime | None = None,
                          end_date: datetime.datetime | None = None,
                          env: str | None = None) -> adls:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await adls.find_all().to_list();
    else:
        criteria = {"$and": [{"ts": {"$gte": start_date, "$lte": end_date}},
                             {"source.env": {"$eq": env}}
                             ]}
        results = await adls.find_many(criteria).to_list();
    return prepare_adls_response(start_date, end_date, env, results)


# TODO: remove this end point before production
@adlspipelinerouter.post("/", response_description=" Metrics added to the database")
async def add_adls_record(review: adls) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}
