from fastapi import APIRouter
import datetime
from metricservice.server.models.aurora_postgres import aurorapostgres
from metricservice.server.models.aurora_postgres import Instance

aurorapostgresrouter = APIRouter()

def prepare_aurora_postgres_response(start_date: datetime.datetime,
                     end_date: datetime.datetime,
                     env: str,
                     results: aurorapostgres) -> dict:
    # flatten the JSON object
    flat_list = [] 
    for record in results:
        for instance in record.instances:
            instance_metric_value = []
            for key in instance.dict().keys():
                value = instance.dict()[key]
                if value is not None:
                    instance_metric_value.append(str(value))
                else:
                    instance_metric_value.append('')
            metric_record = {"timestamp": str(record.ts), "metric_value": instance_metric_value}
            flat_list.append(metric_record)
    # get all the metric key names by creating test object
    i = Instance(instance_name = "example2")
    metric_names =  list(i.dict(by_alias=True)) 


    # create final response
    response_metrics_record = {
        "service_provider": "",
        "env_name": env,
        "account_id": "",
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["instance_name"], "metric_name": list(metric_names)},    #, "PipelineName", "LabelingJobName", "LabelingJob"
        "metric_records": flat_list
    }
    return response_metrics_record   

# TODO: removed optional params and test with paging before production
@aurorapostgresrouter.get("/", response_description="Metric records retrieved")
async def get_aurora_postgres_record(start_date: datetime.datetime | None = None,
                        end_date: datetime.datetime | None = None,
                        env: str | None = None) -> aurorapostgres:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await aurorapostgres.find_all().to_list();
    else:
        criteria = {"$and": [ {"ts": {"$gte": start_date, "$lte": end_date}},
                              {"source.env": {"$eq": env}}
                              ]}
        results = await aurorapostgres.find_many(criteria).to_list();
    return prepare_aurora_postgres_response(start_date, end_date, env, results)

# TODO: remove this end point before production
@aurorapostgresrouter.post("/", response_description=" Metrics added to the database")
async def add_aurora_postgres_record(review: aurorapostgres) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}