from fastapi import APIRouter
import datetime
from beanie import Document
from metricservice.server.models.aws import aws_inventory

aws_invent_router = APIRouter()


def prepare_response(ser,
                     results: aws_inventory) -> dict:
    # flatten the JSON object
    flat_list = []
    # print (results.keys())
    # print (ser)
    for res in results:
        # print (res[0])
        # print (res[1])
        if (res[0].lower()) in ser:
            dict = {}
            dict[res[0]] = res[1]
            flat_list.append(dict)

    # create final response
    response_metrics_record = flat_list
    return response_metrics_record

# TODO: removed optional params and test with paging before production
@aws_invent_router.get("/", response_description="Metric records retrieved")
async def get_review_record(Service: str | None = None, Environment: str | None = None) -> aws_inventory:
    results = []
    ser = []
    if Service is None:
        #ser = ["glue","lambda","s3","sagemaker","aurora","redshift"]
        ser = ["glue","lambda","s3"]
    else:
        if Service == "lambda":
            Service = "Lambda"
        ser = [Service.lower()]
    results = await aws_inventory.find_one();
    return prepare_response(ser, results)


# TODO: remove this end point before production
@aws_invent_router.post("/", response_description=" Metrics added to the database")
async def add_glue_record(review: aws_inventory) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}