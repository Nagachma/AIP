from __future__ import annotations
from metricservice.server.models.azure_blobfuse import azure_blobfuse
from metricservice.server.models.azure_blobfuse import blobfuses, file_cache, blobfusestats

from fastapi import APIRouter
import datetime

blobfusestatsrouter = APIRouter()


def prepare_blobfuse_bfusestats_response(start_date: datetime.datetime,
                         end_date: datetime.datetime,
                         env: str,
                         results: azure_blobfuse) -> dict:
    # print("RESULTS: ", results)

    # get all the metric key names by creating test object
    a = blobfuses(timestamp="example", blobfusestats=[])
    b = blobfusestats()

    metric_names = list(a.dict(by_alias=True, exclude={'file_cache', 'blobfusestats'})) + list(b.dict(by_alias=True))

    # flatten the JSON object
    flat_list = []
    for record in results:
        blobfuses_metric_value = []
        for bfuse in record.blobfuse:
            for key in bfuse.dict().keys():
                if key != "file_cache" and key != "blobfusestats":
                    value = bfuse.dict()[key]
                    if value is not None:
                        blobfuses_metric_value.append(str(value))
                    else:
                        blobfuses_metric_value.append("")
            if bfuse.blobfusestats is not None:
                if len(bfuse.blobfusestats) > 0:
                    for bfuse2 in bfuse.blobfusestats:
                        metric_record = {"timestamp": str(record.ts), "metric_value": blobfuses_metric_value.copy()}
                        metric_value = []
                        for key in bfuse2.dict().keys():
                            value = bfuse2.dict()[key]
                            if value is not None:
                                metric_value.append(str(value))
                            else:
                                metric_value.append("")
                        metric_record["metric_value"] += metric_value;
                        flat_list.append(metric_record)
                else:
                    metric_record = {"timestamp": str(record.ts), "metric_value": blobfuses_metric_value.copy()}
                    c1 = blobfusestats()
                    l = len(c1.dict().keys())
                    metric_value = [''] * l
                    metric_record["metric_value"] += metric_value;
                    flat_list.append(metric_record)

    # create final response
    response_metrics_record = {
        "service_provider": "AZURE",
        "env_name": env,
        "account_id": "",
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["blobfuses", "blobfusestats"], "metric_name": list(metric_names)},
        "metric_records": flat_list
    }
    return response_metrics_record


# TODO: removed optional params and test with paging before production
@blobfusestatsrouter.get("/", response_description="Metric records retrieved")
async def get_blobfuse_bfusestats_record(start_date: datetime.datetime | None = None,
                             end_date: datetime.datetime | None = None,
                             env: str | None = None) -> azure_blobfuse:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await azure_blobfuse.find_all().to_list();
    else:
        criteria = {"$and": [{"ts": {"$gte": start_date, "$lte": end_date}},
                             {"source.env": {"$eq": env}}
                             ]}
        results = await azure_blobfuse.find_many(criteria).to_list();
    return prepare_blobfuse_bfusestats_response(start_date, end_date, env, results)


# TODO: remove this end point before production
@blobfusestatsrouter.post("/", response_description=" Metrics added to the database")
async def add_blobfuse_bfusestats_record(review: azure_blobfuse) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}
