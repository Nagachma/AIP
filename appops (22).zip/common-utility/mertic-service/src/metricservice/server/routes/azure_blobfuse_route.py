from __future__ import annotations
from metricservice.server.models.azure_blobfuse import azure_blobfuse
from metricservice.server.models.azure_blobfuse import blobfuses, file_cache, blobfusestats


from fastapi import APIRouter
import datetime

azureblobfuserouter = APIRouter()


def prepare_azure_blobfuse_response(start_date: datetime.datetime,
                         end_date: datetime.datetime,
                         env: str,
                         results: azure_blobfuse) -> dict:
    # flatten the JSON object
    flat_list = []
    for doc in results:
        blobfuse_metric_value = []
        for blobfuse in doc.blobfuse:
            for key in blobfuse.dict().keys():
                value = blobfuse.dict()[key]
                if value is not None and type(value) != list:
                    blobfuse_metric_value.append(str(value))
                elif value is not None and type(value) == list:
                    i = 0
                    metric_values = []
                    while i < len(value):
                        for keys, val in value[i].items():
                            if val is not None:
                                metric_values.append(str(val))
                            else:
                                metric_values.append('')
                        i = i + 1
                        blobfuse_metric_value.append(metric_values)
                        metric_values = []
                else:
                    blobfuse_metric_value.append('')

        metric_record = {"timestamp": str(doc.ts), "metric_value": blobfuse_metric_value}
        flat_list.append(metric_record)
    # get all the metric key names by creating test object
    a1 = blobfuses(blobfuse="example1")
    a2 = file_cache(file_cache="example1")
    a3 = blobfusestats(blobfuse_stats="example1")

    metric_names = list(a1.dict(by_alias=True, exclude={'file_cache', 'blobfuse_stats'})) + list(a2.dict(by_alias=True, exclude={'file_cache'})) + list(a3.dict(by_alias=True, exclude={'blobfuse_stats'}))

    # create final response
    response_metrics_record = {
        "service_provider": "",
        "env_name": env,
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["blobfuses", "file_cache", "blobfuse_stats"],
                    "metric_name": metric_names},
        "metric_records": flat_list
    }
    return response_metrics_record


# TODO: removed optional params and test with paging before production
@azureblobfuserouter.get("/", response_description="Metric records retrieved")
async def get_azure_blobfuse_record(start_date: datetime.datetime | None = None,
                             end_date: datetime.datetime | None = None,
                             env: str | None = None) -> azure_blobfuse:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await azure_blobfuse.find_all().to_list();
    else:
        criteria = {"$and": [{"ts": {"$gte": start_date, "$lte": end_date}},
                             {"source.env": {"$eq": env}}
                             ]}
        results = await azure_blobfuse.find_many(criteria).to_list();
    return prepare_azure_blobfuse_response(start_date, end_date, env, results)


# TODO: remove this end point before production
@azureblobfuserouter.post("/", response_description=" Metrics added to the database")
async def add_azure_blobfuse_record(review: azure_blobfuse) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}
