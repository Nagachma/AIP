import datetime

from fastapi import APIRouter
from metricservice.server.models.azure_sqlserver import azure_sqlserver
from metricservice.server.models.azure_sqlserver import Server, Queries, Databases

azuresqlserverrouter = APIRouter()


def prepare_azure_sqlserver_response(start_date: datetime.datetime,
                                     end_date: datetime.datetime,
                                     env: str,
                                     results: azure_sqlserver) -> dict:
    stime=datetime.datetime.now(datetime.timezone.utc)
    flat_list = []
    for doc in results:
        # print("second 1234")
        if len(doc.servers) > 0:
            # print("first if working")
            for server in doc.servers:
                # print(server.queries)
                # print(workspace.dict().keys())
                server_metric_value = []
                for key in server.dict().keys():
                    if key not in ["databases"]:
                        value1 = server.dict()[key]
                        if value1 is not None:
                            server_metric_value.append(str(value1))
                        else:
                            server_metric_value.append("")

                if server.databases is not None and len(server.databases) > 0:
                    for db in server.databases:
                        server_db_metric_value = []
                        for key in db.dict().keys():
                            if key not in ["queries"]:
                                value1 = db.dict()[key]
                                if value1 is not None:
                                    server_db_metric_value.append(str(value1))
                                else:
                                    server_db_metric_value.append("")

                        if db.queries is not None and len(db.queries) > 0:
                            # print("if for q is working")
                            for query in db.queries:  # iterating quesries
                                query_metric_value = []
                                query_metric_value.extend(server_metric_value)
                                query_metric_value.extend(server_db_metric_value)
                                for key in query.dict().keys():
                                    if key in ['server_name', 'sqldatabasesname']:
                                        continue

                                    value1 = query.dict()[key]
                                    if value1 is not None:
                                        query_metric_value.append(str(value1))
                                    else:
                                        query_metric_value.append("")
                                # print(query_metric_value)
                                # print(query_metric_value)
                                metric_record = {"timestamp": str(doc.ts), "metric_value": query_metric_value.copy()}
                                # b1 = Jobs()
                                # l = len(b1.dict().keys())
                                # metric_value = [''] * l
                                # metric_record["metric_value"]
                                flat_list.append(metric_record)
                        else:
                            # print("else for q is working")
                            metric_record = {"timestamp": str(doc.ts), "metric_value": server_metric_value.copy()
                                                                                       + server_db_metric_value.copy()}
                            b1 = Queries()
                            l0 = len(b1.dict().keys())
                            metric_value = [''] * (l0 - 2)
                            metric_record["metric_value"] += metric_value
                            flat_list.append(metric_record)
                else:
                    metric_record = {"timestamp": str(doc.ts), "metric_value": server_metric_value.copy()}
                    db1 = Databases()
                    l1 = len(db1.dict().keys())
                    l1 = l1 - 1
                    b1 = Queries()
                    l0 = len(b1.dict().keys())
                    l0 = l0 - 2
                    l2 = l0 + l1
                    metric_value = [''] * l2
                    metric_record["metric_value"] += metric_value
                    flat_list.append(metric_record)

    # get all the metric key names by creating test object
    a2 = Queries(session_id=0)
    a3 = Server(server_name="example1")
    a4 = Databases(database_name="db1")

    metric_names = list(a3.dict(by_alias=True, exclude={"databases"})) + list(
        a4.dict(by_alias=True, exclude={"queries"})) \
                   + list(a2.dict(by_alias=True, exclude={'server_name', 'sqldatabasesname'}))
    response_metrics_record = {
        "service_provider": "",
        "env_name": env,
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["server_name", "database_name", "session_id"],
                    "metric_name": metric_names},
        "metric_records": flat_list
    }
    # print(response_metrics_record)
    return response_metrics_record


# prepare_azure_sqlserver_response(start_date='2022-12-15 12:00:00', end_date='2022-12-15 12:00:00', env='', results='')
# TODO: removed optional params and test with paging before production
@azuresqlserverrouter.get("/", response_description="Metric records retrieved")
async def get_azure_sqlserver_record(start_date: datetime.datetime | None = None,
                                     end_date: datetime.datetime | None = None,
                                     env: str | None = None) -> azure_sqlserver:
    sttime = datetime.datetime.now(datetime.timezone.utc)
    if start_date is None or end_date is None or env is None:
        results = await azure_sqlserver.find_all().to_list()
    else:
        criteria = {"$and": [{"ts": {"$gte": start_date, "$lte": end_date}},
                             {"source.env": {"$eq": env}}
                             ]}
        results = await azure_sqlserver.find_many(criteria).to_list()
    return prepare_azure_sqlserver_response(start_date, end_date, env, results)


# TODO: remove this end point before production
@azuresqlserverrouter.post("/", response_description=" Metrics added to the database")
async def add_azure_sqlserver_record(review: azure_sqlserver) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}
