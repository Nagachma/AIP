import datetime

from fastapi import APIRouter

from metricservice.server.models.azurerediscache import azurerediscache
from metricservice.server.models.azurerediscache import AzureRedisCache


azurerediscacherouter = APIRouter()


def prepare_azurerediscache_response(start_date: datetime.datetime,
                                end_date: datetime.datetime,
                                env: str,
                                results: azurerediscache) -> dict:

    flat_list = []
    # print(results)

    for doc in results:
        if len(doc.azure_redis_cache) > 0:
            for function in doc.azure_redis_cache:

                function_metric_value = []
                for key, value in function.dict().items():
                    if value is not None:
                        function_metric_value.append(str(value))
                    if value is None:
                        function_metric_value.append('')

                # function_metric_value_temp = function_metric_value
            metric_record = {"timestamp": str(doc.ts),
                                "metric_value": function_metric_value}
            flat_list.append(metric_record)



    # print(flat_list)
    # get all the metric key names by creating test object
    a1 = AzureRedisCache(name="example1")
    # a2 = Requestlevelmetrics(Requestname="example1")
    # a3 = Workspace(workspace_name="example1")

    metric_names = list(a1.dict(by_alias=True))
    response_metrics_record = {
        "service_provider": "",
        "env_name": str(env),
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["name"],
                    "metric_name": metric_names},
        "metric_records": flat_list
    }
    return response_metrics_record


# TODO: removed optional params and test with paging before production
@azurerediscacherouter.get("/", response_description="Metric records retrieved")
async def get_azurerediscache_record(start_date: datetime.datetime | None = None,
                                end_date: datetime.datetime | None = None,
                                env: str | None = None) -> azurerediscache:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await azurerediscache.find_all().to_list();
    else:
        criteria = {"$and": [{"ts": {"$gte": start_date, "$lte": end_date}},
                             {"source.env": {"$eq": env}}
                             ]}
        results = await azurerediscache.find_many(criteria).to_list()
    return prepare_azurerediscache_response(start_date, end_date, env, results)


# TODO: remove this end point before production
@azurerediscacherouter.post("/", response_description=" Metrics added to the database")
async def add_azurerediscache_record(review: azurerediscache) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}
