from __future__ import annotations
from metricservice.server.models.bigquery import bigquery
from metricservice.server.models.bigquery import prjcts
from metricservice.server.models.bigquery import datasets
from metricservice.server.models.bigquery import table
from metricservice.server.models.bigquery import jobs
from fastapi import APIRouter
import datetime


datasetsrouter = APIRouter()

def prepare_datasets_response(start_date: datetime.datetime,
                     end_date: datetime.datetime,
                     env: str,
                     results: bigquery) -> dict:

    # print("RESULTS: ", results)

    # get all the metric key names by creating test object
    p = prjcts(project_id="example", datasets=[])
    d = datasets()
    t = table()

    metric_names = list(p.dict(by_alias=True, exclude={'datasets', 'jobs'})) + list(d.dict(by_alias=True, exclude={'table'})) + list(t.dict(by_alias=True))

    # flatten the JSON object
    flat_list = []
    for record in results:
        project_metric_value = []
        for job1 in record.projects:
            for key in job1.dict().keys():
                if key != "datasets" and key != "jobs":
                    value = job1.dict()[key]
                    if value is not None:
                        project_metric_value.append(str(value))
                    else:
                        project_metric_value.append("")
            dataset_metric_value = []
            if job1.datasets is not None:
                if len(job1.datasets) > 0:
                    for job2 in job1.datasets:
                        for key in job2.dict().keys():
                            if key != "table":
                                value = job2.dict()[key]
                                if value is not None:
                                    dataset_metric_value.append(str(value))
                                else:
                                    dataset_metric_value.append("")
                        if job2.table is not None:
                            if len(job2.table) > 0:
                                for job3 in job2.table:
                                    metric_record = {"timestamp": str(record.ts), "metric_value": project_metric_value.copy()+ dataset_metric_value.copy()}
                                    metric_value = []
                                    for key in job3.dict().keys():
                                        value = job3.dict()[key]
                                        if value is not None:
                                            metric_value.append(str(value))
                                        else:
                                            metric_value.append("")
                                    metric_record["metric_value"] += metric_value
                                    flat_list.append(metric_record)
                        else:
                            metric_record = {"timestamp": str(record.ts), "metric_value": project_metric_value.copy() + dataset_metric_value.copy()}
                            t1 = table()
                            l = len(t1.dict().keys())
                            metric_value = [''] * l
                            metric_record["metric_value"] += metric_value
                            flat_list.append(metric_record)
            else:
                metric_record = {"timestamp": str(record.ts), "metric_value": project_metric_value.copy()}
                d1 = datasets()
                t1 = table()
                l = len(d1.dict(by_alias=True, exclude={'table'}).keys()) + len(t1.dict().keys())
                metric_value = [''] * l
                metric_record["metric_value"] += metric_value
                flat_list.append(metric_record)

    # create final response
    response_metrics_record = {
        "service_provider": "",
        "env_name": env,
        "account_id": "",
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["project_id", "dataset_id", "table_name"], "metric_name": list(metric_names)},    #, "PipelineName", "LabelingJobName", "LabelingJob"
        "metric_records": flat_list
    }
    return response_metrics_record

# TODO: removed optional params and test with paging before production
@datasetsrouter.get("/", response_description="Metric records retrieved")
async def get_datasets_record(start_date: datetime.datetime | None = None,
                        end_date: datetime.datetime | None = None,
                        env: str | None = None) -> bigquery:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await bigquery.find_all().to_list();
    else:
        criteria = {"$and": [ {"ts": {"$gte": start_date, "$lte": end_date}},
                              {"source.env": {"$eq": env}}
                              ]}
        results = await bigquery.find_many(criteria).to_list();
    return prepare_datasets_response(start_date, end_date, env, results)

# TODO: remove this end point before production
@datasetsrouter.post("/", response_description=" Metrics added to the database")
async def add_datasets_record(review: bigquery) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}