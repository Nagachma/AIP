import datetime

from fastapi import APIRouter
from metricservice.server.models.cloudstorage import Metrics, Response
from metricservice.server.models.cloudstorage import cloudstorage

cloudstorage_pipeliine_router = APIRouter()


# TODO: removed optional params and test with paging before production
def prepare_cloudstorage_response(start_date: datetime.datetime,
                                  end_date: datetime.datetime,
                                  env: str,
                                  results: cloudstorage):
    flat_list = []
    for doc in results:

        if len(doc.buckets) > 0:
            for metrics in doc.buckets:
                bucket_metric_value = []
                has_error =None
                for key in metrics.dict().keys():
                    value = metrics.dict()[key]
                    if value is not None and type(value) != list:
                        bucket_metric_value.append(value)
                    elif value is not None and type(value) == list:
                        if key=='responses' and len(value)>0:
                            has_error = True
                    else:
                        bucket_metric_value.append('')
                if has_error:
                    for error in metrics.dict()['responses']:
                        bucket_metric_value_temp = []
                        bucket_metric_value_temp.extend(bucket_metric_value)
                        for key3 in error.keys():
                            if error[key3] is None:
                                value3 = ''
                            else:
                                value3 = error[key3]
                            bucket_metric_value_temp.append(value3)
                        metric_record1 = {"timestamp": str(doc.ts), "metric_value": bucket_metric_value_temp}
                        flat_list.append(metric_record1)
                else:
                    bucket_metric_value_temp = []
                    r = Response()
                    l = len(r.dict().keys())
                    response_metric_value = [''] * l
                    bucket_metric_value_temp = bucket_metric_value + response_metric_value
                    metric_record = {"timestamp": str(doc.ts), "metric_value": bucket_metric_value_temp}
                    flat_list.append(metric_record)

    # get all the metric key names by creating test object
    a1 = Metrics(bucket_name="example1")
    a2 = Response(uuid="example1")
    metric_names = list(a1.dict(by_alias=True, exclude={"responses"})) + list(a2.dict(by_alias=True))
    # create final response
    response_metrics_record = {
        "service_provider": "",
        "env_name": env,
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["bucket_name", "uuid"], "metric_name": metric_names},
        "metric_records": flat_list
    }
    return response_metrics_record


@cloudstorage_pipeliine_router.get("/", response_description="Metric records retrieved")
async def get_cloudstorage_record(start_date: datetime.datetime | None = None,
                                  end_date: datetime.datetime | None = None,
                                  env: str | None = None) -> cloudstorage:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await cloudstorage.find_all().to_list();
    else:
        criteria = {"$and": [{"ts": {"$gte": start_date, "$lte": end_date}},
                             {"source.env": {"$eq": env}}
                             ]}
        results = await cloudstorage.find_many(criteria).to_list();
    return prepare_cloudstorage_response(start_date, end_date, env, results)


# TODO: remove this end point before production
@cloudstorage_pipeliine_router.post("/", response_description=" Metrics added to the database")
async def add_cloudstorage_record(review: cloudstorage) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}
