from __future__ import annotations
from metricservice.server.models.cloud_composer import cloud_composer
from metricservice.server.models.cloud_composer import prjcts
from metricservice.server.models.cloud_composer import environments
from metricservice.server.models.cloud_composer import workflows
from metricservice.server.models.cloud_composer import tasks

from fastapi import APIRouter
import datetime


workflowsrouter = APIRouter()

def prepare_workflows_response(start_date: datetime.datetime,
                     end_date: datetime.datetime,
                     env: str,
                     results: cloud_composer) -> dict:

    # print("RESULTS: ", results)

    # get all the metric key names by creating test object
    pr = prjcts(project_id="example", environments=[])
    e = environments()
    w = workflows()
    t = tasks()

    metric_names = list(pr.dict(by_alias=True, exclude={'environments'})) + list(e.dict(by_alias=True, exclude={'pools','queues','webservers','workflows'})) + list(w.dict(by_alias=True, exclude={'tasks'})) + list(t.dict(by_alias=True))

    # flatten the JSON object
    flat_list = []
    for record in results:
        project_metric_value = []
        for job1 in record.projects:
            for key in job1.dict().keys():
                if key != "environments":
                    value = job1.dict()[key]
                    if value is not None:
                        project_metric_value.append(str(value))
                    else:
                        project_metric_value.append("")
            environment_metric_value = []
            if job1.environments is not None:
                if len(job1.environments) > 0:
                    for job2 in job1.environments:
                        for key in job2.dict().keys():
                            if key != "pools" and key != "queues" and key != "webservers" and key != "workflows":
                                value = job2.dict()[key]
                                if value is not None:
                                    environment_metric_value.append(str(value))
                                else:
                                    environment_metric_value.append("")
                        if job2.workflows is not None:
                            if len(job2.workflows) > 0:
                                for job3 in job2.workflows:
                                    metric_record = {"timestamp": str(record.ts), "metric_value": project_metric_value.copy()+ environment_metric_value.copy()}
                                    workflow_metric_value = []
                                    for key in job3.dict().keys():
                                        if key != "tasks":
                                            value = job3.dict()[key]
                                            if value is not None:
                                                workflow_metric_value.append(str(value))
                                            else:
                                                workflow_metric_value.append("")
                                    if job3.tasks is not None:
                                        if len(job3.tasks) > 0:
                                            for job4 in job3.tasks:
                                                metric_record = {"timestamp": str(record.ts),"metric_value": project_metric_value.copy() + environment_metric_value.copy() + workflow_metric_value.copy()}
                                                metric_value = []
                                                for key in job4.dict().keys():
                                                    value = job4.dict()[key]
                                                    if value is not None:
                                                        metric_value.append(str(value))
                                                    else:
                                                        metric_value.append("")
                                                metric_record["metric_value"] += metric_value
                                                flat_list.append(metric_record)
                                    else:
                                        metric_record = {"timestamp": str(record.ts),"metric_value": project_metric_value.copy() + environment_metric_value.copy() + workflow_metric_value.copy()}
                                        t1 = tasks()
                                        l = len(t1.dict().keys())
                                        metric_value = [''] * l
                                        metric_record["metric_value"] += metric_value
                                        flat_list.append(metric_record)
                        else:
                            metric_record = {"timestamp": str(record.ts), "metric_value": project_metric_value.copy() + environment_metric_value.copy()}
                            w1 = workflows()
                            t1 = tasks()
                            l = len(w1.dict(by_alias=True, exclude={'tasks'}).keys()) + len(t1.dict().keys())
                            metric_value = [''] * l
                            metric_record["metric_value"] += metric_value
                            flat_list.append(metric_record)
            else:
                metric_record = {"timestamp": str(record.ts), "metric_value": project_metric_value.copy()}
                e1 = environments()
                w1 = workflows()
                t1 = tasks()
                l = len(e1.dict(by_alias=True, exclude={'pools','queues','webservers','workflows'}).keys()) + len(w1.dict(by_alias=True, exclude={'tasks'}).keys()) + len(t1.dict().keys())
                metric_value = [''] * l
                metric_record["metric_value"] += metric_value
                flat_list.append(metric_record)

    # create final response
    response_metrics_record = {
        "service_provider": "",
        "env_name": env,
        "account_id": "",
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["project_id", "environment_name","workflow_name","task_name"], "metric_name": list(metric_names)},    #, "PipelineName", "LabelingJobName", "LabelingJob"
        "metric_records": flat_list
    }
    return response_metrics_record

# TODO: removed optional params and test with paging before production
@workflowsrouter.get("/", response_description="Metric records retrieved")
async def get_workflows_record(start_date: datetime.datetime | None = None,
                        end_date: datetime.datetime | None = None,
                        env: str | None = None) -> cloud_composer:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await cloud_composer.find_all().to_list();
    else:
        criteria = {"$and": [ {"ts": {"$gte": start_date, "$lte": end_date}},
                              {"source.env": {"$eq": env}}
                              ]}
        results = await cloud_composer.find_many(criteria).to_list();
    return prepare_workflows_response(start_date, end_date, env, results)

# TODO: remove this end point before production
@workflowsrouter.post("/", response_description=" Metrics added to the database")
async def add_workflows_record(review: cloud_composer) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}