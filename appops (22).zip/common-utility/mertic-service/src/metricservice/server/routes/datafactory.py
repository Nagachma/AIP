from __future__ import annotations

# import synapse
# import workspace as workspace
from metricservice.server.models.datafactory import datafactory
from metricservice.server.models.datafactory import pipeline_runs
from metricservice.server.models.datafactory import activity_runs
from metricservice.server.models.datafactory import factories
from fastapi import APIRouter
import datetime


datafactoryrouter = APIRouter()

def prepare_datafactory_response(start_date: datetime.datetime,
                     end_date: datetime.datetime,
                     env: str,
                     results: datafactory) -> dict:

    # print("RESULTS: ", results)
    # flatten the JSON object
    flat_list = []
    for record in results:
        datafactory_metric_value = []
        for factory1 in record.factory:
            for key in factory1.dict().keys():
                value = factory1.dict()[key]
                # print(type(value))
                if value is not None and type(value) != list:
                    datafactory_metric_value.append(str(value))
                elif value is not None and type(value) == list:
                    # print("VALUE: ", value[0].items())
                    i=0
                    metric_values = []
                    for keys,val in value[i].items():
                        if val is not None:
                            metric_values.append(str(val))
                        else:
                            metric_values.append('')
                    i = i+1
                    datafactory_metric_value.append(metric_values)
                else:
                    datafactory_metric_value.append('')

        # print("workspace_metric_value")
        # print(workspace_metric_value)
        metric_record = {"timestamp": str(record.ts), "metric_value": datafactory_metric_value}
        flat_list.append(metric_record)
    # get all the metric key names by creating test object
    w = factories(FactoryName="example")
    b = pipeline_runs(PipelineName="example1")
    s = activity_runs(ActivityName="example1")

    # print("w: ",w)

    metric_names = list(w.dict(by_alias=True,exclude={"pipelineRuns", "activityRuns"}))
    metric_names = metric_names + list(b.dict(by_alias=True)) + list(s.dict(by_alias=True))
    # print("METRIC NAMES: ", metric_names)


    # create final response
    response_metrics_record = {
        "service_provider": "",
        "env_name": env,
        "account_id": "",
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["factoryName", "id", "activityName"], "metric_name": list(metric_names)},    #, "PipelineName", "LabelingJobName", "LabelingJob"
        "metric_records": flat_list
    }
    return response_metrics_record

# TODO: removed optional params and test with paging before production
@datafactoryrouter.get("/", response_description="Metric records retrieved")
async def get_datafactory_record(start_date: datetime.datetime | None = None,
                        end_date: datetime.datetime | None = None,
                        env: str | None = None) -> datafactory:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await datafactory.find_all().to_list();
    else:
        criteria = {"$and": [ {"ts": {"$gte": start_date, "$lte": end_date}},
                              {"source.env": {"$eq": env}}
                              ]}
        results = await datafactory.find_many(criteria).to_list();
    return prepare_datafactory_response(start_date, end_date, env, results)

# TODO: remove this end point before production
@datafactoryrouter.post("/", response_description=" Metrics added to the database")
async def add_datafactory_record(review: datafactory) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}
