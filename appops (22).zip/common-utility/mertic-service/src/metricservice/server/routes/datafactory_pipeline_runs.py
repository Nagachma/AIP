from __future__ import annotations
from metricservice.server.models.datafactory import datafactory
from metricservice.server.models.datafactory import pipeline_runs
from metricservice.server.models.datafactory import activity_runs
from metricservice.server.models.datafactory import factories
from fastapi import APIRouter
import datetime


datafactorybigdatapoolrouter = APIRouter()

def prepare_datafactory_response(start_date: datetime.datetime,
                     end_date: datetime.datetime,
                     env: str,
                     results: datafactory) -> dict:

    # print("RESULTS: ", results)

    # get all the metric key names by creating test object
    w = factories(factoryName="example", pipeline_runs=[])
    b = pipeline_runs()

    metric_names = list(w.dict(by_alias=True, exclude={'pipeline_runs', 'activity_runs'})) + list(
        b.dict(by_alias=True, exclude={'factoryName', 'TimeStamp'}))

    # flatten the JSON object
    flat_list = []
    for record in results:
        for factory_obj in record.factory:
            datafactory_metric_value = []
            for key in factory_obj.dict().keys():
                if key != "pipeline_runs" and key != "activity_runs":
                    value = factory_obj.dict()[key]
                    if value is not None:
                        datafactory_metric_value.append(str(value))
                    else:
                        datafactory_metric_value.append("")
            if len(factory_obj.pipeline_runs) > 0:
                for pipe_run in factory_obj.pipeline_runs:
                    metric_record = {"timestamp": str(record.ts), "metric_value": datafactory_metric_value.copy()}
                    metric_value = []
                    for key in pipe_run.dict().keys():
                        if key in ['factoryName', 'TimeStamp']:
                            pass
                        else:
                            value = pipe_run.dict()[key]
                            if value is not None:
                                metric_value.append(str(value))
                            else:
                                metric_value.append("")
                    metric_record["metric_value"] += metric_value
                    flat_list.append(metric_record)
            else:
                metric_record = {"timestamp": str(record.ts), "metric_value": datafactory_metric_value.copy()}
                b1 = pipeline_runs()
                l = len(b1.dict().keys())
                metric_value = [''] * (l - 2)
                metric_record["metric_value"] += metric_value
                flat_list.append(metric_record)

    # create final response
    response_metrics_record = {
        "service_provider": "",
        "env_name": env,
        "account_id": "",
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["factoryName", "runId"], "metric_name": list(metric_names)},    #, "PipelineName", "LabelingJobName", "LabelingJob"
        "metric_records": flat_list
    }
    return response_metrics_record

# TODO: removed optional params and test with paging before production
@datafactorybigdatapoolrouter.get("/", response_description="Metric records retrieved")
async def get_datafactory_record(start_date: datetime.datetime | None = None,
                        end_date: datetime.datetime | None = None,
                        env: str | None = None) -> datafactory:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await datafactory.find_all().to_list();
    else:
        criteria = {"$and": [ {"ts": {"$gte": start_date, "$lte": end_date}},
                              {"source.env": {"$eq": env}}
                              ]}
        results = await datafactory.find_many(criteria).to_list();
    return prepare_datafactory_response(start_date, end_date, env, results)

# TODO: remove this end point before production
@datafactorybigdatapoolrouter.post("/", response_description=" Metrics added to the database")
async def add_datafactory_record(review: datafactory) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}





