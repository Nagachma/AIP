import datetime

from fastapi import APIRouter

from metricservice.server.models.dataflow import dataflow
from metricservice.server.models.dataflow import Jobs,Pubsub


dataflow_job_pubsub_router = APIRouter()


def prepare_dataflow_response(start_date: datetime.datetime,
                                end_date: datetime.datetime,
                                env: str,
                                results: dataflow) -> dict:
    flat_list = []
    for record in results:
        # if len(record.jobs) > 0:
        for job in record.jobs:
            job_metric_value=[]
            for key in job.dict().keys():
                if key != "workers" and key != "pubsubs":
                    value1 = job.dict()[key]
                    if value1 is not None:
                        job_metric_value.append(str(value1))
                    else:
                        job_metric_value.append("")
            
            if job.pubsubs is not None and len(job.pubsubs) > 0:
                for pub in job.pubsubs: # iterating clusters
                    metric_record = {"timestamp": str(record.ts), "metric_value": job_metric_value.copy()}
                    pubsub_metric_value = []
                    # job_metric_value.extend(clus_metric_value)
                    for key in pub.dict().keys():
                        value1 = pub.dict()[key]
                        if value1 is not None:
                            pubsub_metric_value.append(str(value1))
                        else:
                            pubsub_metric_value.append("")
                    metric_record["metric_value"] += pubsub_metric_value;
                    flat_list.append(metric_record)
            else:
                metric_record = {"timestamp": str(record.ts), "metric_value": job_metric_value.copy()}
                r1 = Pubsub()
                l = len(r1.dict().keys())
                metric_value = ['']*l
                metric_record["metric_value"] += metric_value;
                flat_list.append(metric_record)

    
    # get all the metric key names by creating test object
    a1 = Jobs(JobId="example1")
    a2 = Pubsub(TopicId="example1")

    metric_names = list(a1.dict(by_alias=True,exclude={'pubsubs', 'workers'})) + list(a2.dict(by_alias=True))
    response_metrics_record = {
        "service_provider": "",
        "env_name": env,
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["JobId", "JobName", "TopicId"],"metric_name": list(metric_names)},
        "metric_records": flat_list
    }
    return response_metrics_record


# TODO: removed optional params and test with paging before production
@dataflow_job_pubsub_router.get("/", response_description="Metric records retrieved")
async def get_dataflow_record(start_date: datetime.datetime | None = None,
                                end_date: datetime.datetime | None = None,
                                env: str | None = None) -> dataflow:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await dataflow.find_all().to_list();
    else:
        criteria = {"$and": [{"ts": {"$gte": start_date, "$lte": end_date}},
                             {"source.env": {"$eq": env}}
                             ]}
        results = await dataflow.find_many(criteria).to_list();
    return prepare_dataflow_response(start_date, end_date, env, results)


# TODO: remove this end point before production
@dataflow_job_pubsub_router.post("/", response_description=" Metrics added to the database")
async def add_dataflow_record(review: dataflow) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}
