import datetime

from fastapi import APIRouter
from metricservice.server.models.hyperscale_sql import hyperscale_sql, Server, Database, Query, Object, Lock

hyperscale_sql_router = APIRouter()


def prepare_sqlserver_response(start_date: datetime.datetime,
                               end_date: datetime.datetime,
                               env: str,
                               results: hyperscale_sql) -> dict:
    stime = datetime.datetime.now(datetime.timezone.utc)
    flat_list = []
    for doc in results:
        if len(doc.servers) > 0:
            for server in doc.servers:
                server_metric_value = []
                for key, value in server.dict().items():
                    if key not in ['databases'] and value is not None:
                        server_metric_value.append(str(value))
                    if key not in ['databases'] and value is None:
                        server_metric_value.append('')
                    if key == 'databases' and value is not None and type(value) == list:
                        i = 0

                        for i in range(len(value)):
                            database_metric_value = []
                            for keys1, val1 in value[i].items():
                                if val1 is None and keys1 not in ['queries', 'waits']:
                                    database_metric_value.append('')
                                elif val1 is not None and type(val1) != list:
                                    database_metric_value.append(str(val1))
                                elif keys1 == 'queries' and val1 is not None and type(val1) == list:
                                    if len(val1) > 0:
                                        j = 0
                                        for j in range(len(val1)):
                                            server_metric_value_temp = []
                                            query_metric_value = []
                                            object_metric_value=[]
                                            lock_metric_value =[]
                                            for keys2, val2 in val1[j].items():
                                                # print(keys2, val2)
                                                if val2 is not None and type(val2) != list and keys2 not in ['latch_contention_objects', 'active_locks']:
                                                    query_metric_value.append(str(val2))
                                                elif keys2 == 'latch_contention_objects' and val2 is not None and type(
                                                        val2) == list:
                                                    if len(val2) > 0:
                                                        k = 0
                                                        for k in range(len(val2)):
                                                            for keys3, val3 in val2[k].items():
                                                                if val3 is not None and type(val3) != list:
                                                                    object_metric_value.append(str(val3))
                                                                else:
                                                                    object_metric_value.append('')

                                                            query_metric_value = query_metric_value + object_metric_value
                                                            k = k + 1
                                                elif keys2 == 'active_locks' and val2 is not None and type(
                                                        val2) == list:
                                                    if len(val2) > 0:
                                                        l = 0
                                                        for l in range(len(val2)):
                                                            for keys3, val3 in val2[l].items():
                                                                if val3 is not None and type(val3) != list:
                                                                    lock_metric_value.append(str(val3))
                                                                else:
                                                                    lock_metric_value.append('')

                                                            query_metric_value = query_metric_value + lock_metric_value
                                                            l = l + 1
                                                elif val2 is None and keys2 == 'latch_contention_objects':
                                                    e = Object()
                                                    l = len(e.dict().keys())
                                                    object_metric_value = [''] * l
                                                    query_metric_value = query_metric_value + object_metric_value
                                                elif val2 is None and keys2 == 'active_locks':
                                                    e = Lock()
                                                    l = len(e.dict().keys())
                                                    lock_metric_value = [''] * l
                                                    query_metric_value = query_metric_value + lock_metric_value
                                                else:
                                                    query_metric_value.append('')

                                            server_metric_value_temp = server_metric_value + database_metric_value + query_metric_value
                                            metric_record = {"timestamp": str(doc.ts),
                                                             "metric_value": server_metric_value_temp}
                                            flat_list.append(metric_record)
                                            j = j + 1
                                    if len(val1) == 0:
                                        server_metric_value_temp = []
                                        e = Query()
                                        l1 = len(e.dict().keys())
                                        query_metric_value_temp = [''] * l1
                                        o= Object()
                                        l2 = len(o.dict().keys())
                                        object_metric_value_temp = [''] * l2
                                        lck = Lock()
                                        l3 = len(lck.dict().keys())
                                        lock_metric_value_temp = [''] * l3
                                        server_metric_value_temp = server_metric_value + database_metric_value + query_metric_value_temp + object_metric_value_temp + lock_metric_value_temp
                                        metric_record = {"timestamp": str(doc.ts),
                                                         "metric_value": server_metric_value_temp}
                                        flat_list.append(metric_record)
                                elif keys1 == 'queries' and val1 is None:
                                    server_metric_value_temp = []
                                    e = Query()
                                    l1 = len(e.dict().keys()) -2
                                    query_metric_value_temp = [''] * l1
                                    o = Object()
                                    l2 = len(o.dict().keys())
                                    object_metric_value_temp = [''] * l2
                                    lck = Lock()
                                    l3 = len(lck.dict().keys())
                                    lock_metric_value_temp = [''] * l3
                                    server_metric_value_temp = server_metric_value + database_metric_value + query_metric_value_temp + object_metric_value_temp + lock_metric_value_temp
                                    metric_record = {"timestamp": str(doc.ts),
                                                     "metric_value": server_metric_value_temp}
                                    flat_list.append(metric_record)
                                elif keys1 == 'waits':
                                    continue


                            i = i + 1

    # get all the metric key names by creating test object
    a1 = Server(server_name='example1')
    a3 = Database(database_name="example1")
    a4 = Query(request_id='example1')
    a5 = Object(object_id='example1')
    a6 = Lock(resource_associated_entity_id='1')

    metric_name = list(a1.dict(by_alias=True, exclude={"databases"})) + \
                  list(a3.dict(by_alias=True, exclude={"queries", "waits"})) + list(
        a4.dict(by_alias=True, exclude={"latch_contention_objects", "active_locks"})) + list(
        a5.dict(by_alias=True)) + list(a6.dict(by_alias=True))

    response_metrics_record = {
        "service_provider": "",
        "env_name": str(env),
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["server_name", "database_name", "request_id","object_id"],
                    "metric_name": metric_name},
        "metric_records": flat_list
    }
    return response_metrics_record


# prepare_azure_sqlserver_response(start_date='2022-12-15 12:00:00', end_date='2022-12-15 12:00:00', env='', results='')
# TODO: removed optional params and test with paging before production
@hyperscale_sql_router.get("/", response_description="Metric records retrieved")
async def get_sqlserver_record(start_date: datetime.datetime | None = None,
                               end_date: datetime.datetime | None = None,
                               env: str | None = None) -> hyperscale_sql:
    sttime = datetime.datetime.now(datetime.timezone.utc)
    if start_date is None or end_date is None or env is None:
        results = await hyperscale_sql.find_all().to_list()
    else:
        criteria = {"$and": [{"ts": {"$gte": start_date, "$lte": end_date}},
                             {"source.env": {"$eq": env}}
                             ]}
        results = await hyperscale_sql.find_many(criteria).to_list()
    return prepare_sqlserver_response(start_date, end_date, env, results)


# TODO: remove this end point before production
@hyperscale_sql_router.post("/", response_description=" Metrics added to the database")
async def add_azure_sqlserver_record(review: hyperscale_sql) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}
