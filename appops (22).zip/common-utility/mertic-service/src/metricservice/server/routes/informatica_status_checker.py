from __future__ import annotations

import uuid

from metricservice.server.models.informatica_status_checker import informatica_service_status, Domain, Nodes, Services

from fastapi import APIRouter
import datetime

informatica_status_checker_router = APIRouter()


def prepare_metrics_response(start_date: datetime.datetime.now(),
                             env: str,
                             results: informatica_service_status) -> dict:
    # get all the metric key names by creating test object
    a1 = Domain(host="example1")
    a2 = Nodes(db="example1")
    a3 = Services(db="example1")

    metric_names = list(a1.dict(by_alias=True, exclude={"services"})) + list(a3.dict(by_alias=True, exclude={"nodes"})) + list(a2.dict(by_alias=True))

    flat_list = []
    for record in results:
        # list_of_services = record.services;
        list_of_domains = record.domains
        for domain in list_of_domains:
            if dict(domain).get('services') is not None and len(dict(domain).get('services')) > 0:
                for service in dict(domain).get('services'):
                    metrics_value_list = []
                    metrics_value_list.append(dict(domain).get('domain_name'))
                    metrics_value_list.append(dict(service).get('service_name'))
                    metrics_value_list.append(dict(service).get('service_status'))
                    metrics_value_list.append(dict(service).get('message'))
                    if dict(service).get('nodes') is not None and len(dict(service).get('nodes')) > 0:
                        nodes = dict(service).get('nodes')
                        for node in nodes:
                            tmp_metrics_value_list = []
                            tmp_metrics_value_list.extend(metrics_value_list)
                            tmp_metrics_value_list.extend(['' if v is None else v for v in list(dict(node).values())])
                            metric_record = {"timestamp": str(record.ts), "metric_value": tmp_metrics_value_list}
                            flat_list.append(metric_record)
    # create final response
    response_metrics_record = {
        "service_provider": "INFORMATICA STATUS CHECKER",
        "env_name": env,
        "metrics": {"dimension": ["domain_name", "service_name", "service_status"],
                    "metric_name": list(metric_names)},
        "metric_records": flat_list
    }
    return response_metrics_record


# TODO: removed optional params and test with paging before production
@informatica_status_checker_router.get("/", response_description="Metric records retrieved")
async def get_informatica_powercenter_record(start_date: datetime.datetime | None = None,
                                             end_date: datetime.datetime | None = None,
                                             env: str | None = None) -> dict:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await informatica_service_status.find_all().to_list()
    else:
        criteria = {"$and": [{"ts": {"$gte": start_date, "$lte": end_date}},
                             {"source.env": {"$eq": env}}
                             ]}
        results = await informatica_service_status.find_many(criteria).to_list()
    return prepare_metrics_response(start_date, env, results)


# TODO: remove this end point before production
@informatica_status_checker_router.post("/", response_description=" Metrics added to the database")
async def add_informatica_powercenter_record(review: informatica_service_status) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}
