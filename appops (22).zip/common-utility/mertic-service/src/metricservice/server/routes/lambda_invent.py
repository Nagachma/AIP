from fastapi import APIRouter
import datetime
from metricservice.server.models.Lambda import Lambda
from metricservice.server.models.Lambda import Run
from metricservice.server.models.Lambda import Function


lambda_invent_router = APIRouter()


def prepare_lambda_invent_response(start_date: datetime.datetime,
                     end_date: datetime.datetime,
                     env: str,
                     results: Lambda) -> dict:
    # get all the metric key names by creating test object
    f = Function(functionName="example",runs=[])
    r = Run()
    metric_names = list(f.dict(by_alias=True,exclude={'runs','start_time','end_time','Duration','ConcurrentExecutions','Throttles','Invocations','Errors','ProvisionedConcurrencyUtilization','PostRuntimeExtensionsDuration','ProvisionedConcurrencyInvocations','ProvisionedConcurrencySpilloverInvocations','ProvisionedConcurrentExecutions'})) + list(r.dict(by_alias=True, exclude={'Interval','BilledDuration','MemorySize','MaxMemoryUsed'}))

    # flatten the JSON object
    flat_list = []
    for record in results:
        for function in record.functions:
            function_metric_value = []
            for key in function.dict().keys():
                if key == "functionName":
                    value = function.dict()[key]
                    if value is not None:
                        function_metric_value.append(str(value))
                    else:
                        function_metric_value.append("")
            if len(function.runs) > 0:
                for run in function.runs:
                    metric_record = {"timestamp": str(record.ts), "metric_value": function_metric_value.copy()}
                    metric_value = []
                    for key in run.dict().keys():
                        value = run.dict()[key]
                        if key == 'UniqueID' and value is not None:
                            metric_value.append(str(value))
                        elif key == 'UniqueID' and value is None:
                            metric_value.append("")
                    metric_record["metric_value"] += metric_value;
                    flat_list.append(metric_record)
            else:
                metric_record = {"timestamp": str(record.ts), "metric_value": function_metric_value.copy()}
                metric_value = []
                metric_value.append("")
                metric_record["metric_value"] += metric_value;
                flat_list.append(metric_record)

    # create final response
    response_metrics_record = {
        "service_provider": "",
        "env_name": env,
        "account_id": "",
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["functionname"], "metric_name": list(metric_names)},
        "metric_records": flat_list
    }
    return response_metrics_record

# TODO: removed optional params and test with paging before production
@lambda_invent_router.get("/", response_description="Metric records retrieved")
async def get_lambda_record(start_date: datetime.datetime | None = None,
                            end_date: datetime.datetime | None = None,
                            env: str | None = None) -> Lambda:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await Lambda.find_all().to_list();
    else:
        criteria = {"$and": [ {"ts": {"$gte": start_date, "$lte": end_date}},
                              {"source.env": {"$eq": env}}
                              ]}
        results = await Lambda.find_many(criteria).to_list();
    return prepare_lambda_invent_response(start_date, end_date, env, results)


# TODO: remove this end point before production
@lambda_invent_router.post("/", response_description=" Metrics added to the database")
async def add_lambda_record(review: Lambda) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}
