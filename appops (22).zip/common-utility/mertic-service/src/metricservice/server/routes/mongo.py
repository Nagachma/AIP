from __future__ import annotations
from metricservice.server.models.mongo import *
from fastapi import APIRouter
import datetime

"""
__author__ = "Sachin Maurya"
__copyright__ = "Copyright 2023, The OrchastrAI Project"
__license__ = "GPL"
__version__ = "1.0.0"
__email__ = "sachin.maurya@accenture.com"
"""


mongo_monitoring_router = APIRouter()


def prepare_metrics_response(start_date: datetime.datetime.now(),
                             end_date:datetime.datetime.now() ,
                             env: str, results: mongo_monitoring) -> dict:
    # get all the metric key names by creating test object
    a1 = Instance(host="example1")
    a2 = Database(db="example1")
    a3 = Collection(ns="example1")

    metric_names = list(a1.dict(by_alias=True, exclude={"databases"})) + list(
        a2.dict(by_alias=True, exclude={"collections"})) + list(a3.dict(by_alias=True))
    flat_list = []
    # for record in results:
    #     flat_list.append(record)

    for record in results:
        instances = dict(record.instance[0])
        host = instances['host']
        version = instances['version']
        metrics_value_list = []
        for dbs in instances['databases']:
            db_dict = dict(dbs)
            db_name = db_dict['db']
            datasize = db_dict['dataSize']
            storagesize = db_dict['storageSize']
            colls = db_dict['collections']
            metric_record = {}
            metric_value_core = [host,version,db_name,datasize,storagesize]
            if len(colls)==0:
                pass
                # a4 = Collection(ns="")
                # metric_value = metric_value_core+list((a4.dict(by_alias=True)).values())
                # metric_record = {"timestamp": str(record.ts), "metrics_value": metric_value}
                # flat_list.append(metric_record)
            else:
                for coll in colls:
                    metric_value = []
                    metric_value.extend(metric_value_core)
                    metric_value.extend(list(dict(coll).values()))
                    metric_record = {"timestamp": str(record.ts), "metric_value": metric_value}
                    flat_list.append(metric_record)

    # create final response
    response_metrics_record = {
        "service_provider": "MongoDB",
        "env_name": env,
        "start_date": start_date,
        "end_date": end_date,
        "account_id": "",
        "metrics": {"dimension": ["host","db","ns"], "metric_name": list(metric_names)},
        "metric_records": flat_list
    }
    return response_metrics_record


# TODO: removed optional params and test with paging before production
@mongo_monitoring_router.get("/", response_description="Metric records retrieved")
async def get_mongo_record(start_date: datetime.datetime | None = None,
                          end_date: datetime.datetime | None = None,
                          env: str | None = None) -> dict:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await mongo_monitoring.find_all().to_list()
    else:
        criteria = {"$and": [{"ts": {"$gte": start_date, "$lte": end_date}},
                             {"source.env": {"$eq": env}}
                             ]}
        results = await mongo_monitoring.find_many(criteria).to_list()
    return prepare_metrics_response(start_date,end_date, env, results)


# TODO: remove this end point before production
@mongo_monitoring_router.post("/", response_description=" Metrics added to the database")
async def add_mongo_record(review: mongo_monitoring) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}
