import datetime

from fastapi import APIRouter

from metricservice.server.models.postgres import postgres
from metricservice.server.models.postgres import Instances,Databases,Tables


postgres_tables_router = APIRouter()


def prepare_postgres_response(start_date: datetime.datetime,
                                end_date: datetime.datetime,
                                env: str,
                                results: postgres) -> dict:
    flat_list = []
    for doc in results:
        if len(doc.instances) > 0:
            for instance in doc.instances: # iterating instances
                instance_metric_value=[]
                for key in instance.dict().keys():
                    if key != "databases" :
                        value1 = instance.dict()[key]
                        if value1 is not None:
                            instance_metric_value.append(str(value1))
                        else:
                            instance_metric_value.append("")
                if instance.databases is not None and len(instance.databases) > 0:
                    for database in instance.databases: # iterating databases
                        database_metric_value = []
                        database_metric_value.extend(instance_metric_value)
                        for key in database.dict().keys():
                            if key != "query_duration" and key != "tables":
                                value1 = database.dict()[key]
                                if value1 is not None:
                                    database_metric_value.append(str(value1))
                                else:
                                    database_metric_value.append("")
                        if database.tables is not None and len(database.tables) > 0:
                            for table in database.tables: # iterating Tables
                                table_metric_value = []
                                table_metric_value.extend(database_metric_value)
                                for key in table.dict().keys():
                                    value1 = table.dict()[key]
                                    if value1 is not None:
                                        table_metric_value.append(str(value1))
                                    else:
                                        table_metric_value.append("")
                                metric_record_ = {"timestamp": str(doc.ts), "metric_value": table_metric_value}
                                flat_list.append(metric_record_)
                        else:
                            metric_record = {"timestamp": str(doc.ts), "metric_value": database_metric_value.copy()}
                            b1 = Tables()
                            l = len(b1.dict().keys())
                            metric_value = [''] * l
                            metric_record["metric_value"] += metric_value
                            flat_list.append(metric_record)
                else:
                    metric_record = {"timestamp": str(doc.ts), "metric_value": instance_metric_value.copy()}
                    b1 = Databases()
                    l0 = len(b1.dict().keys())
                    metric_value = [''] * (l0 - 1)
                    metric_record["metric_value"] += metric_value
                    b2 = Tables()
                    l1 = len(b2.dict().keys())
                    _metric_value = [''] * l1
                    metric_record["metric_value"] += _metric_value
                    flat_list.append(metric_record)

    # print(flat_list)
    # get all the metric key names by creating test object
    a1 = Tables(pid="example1")
    a2 = Databases(database_name="example1")
    a3 = Instances(instance_name="example1")

    metric_names = list(a3.dict(by_alias=True, exclude={"databases"})) + list(a2.dict(by_alias=True, exclude={"query_duration","tables"})) + list(a1.dict(by_alias=True))
    response_metrics_record = {
        "service_provider": "",
        "env_name": env,
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["instance_name", "database_name", "table_name"],
                    "metric_name": metric_names},
        "metric_records": flat_list
    }
    return response_metrics_record


# TODO: removed optional params and test with paging before production
@postgres_tables_router.get("/", response_description="Metric records retrieved")
async def get_postgres_record(start_date: datetime.datetime | None = None,
                                end_date: datetime.datetime | None = None,
                                env: str | None = None) -> postgres:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await postgres.find_all().to_list();
    else:
        criteria = {"$and": [{"ts": {"$gte": start_date, "$lte": end_date}},
                             {"source.env": {"$eq": env}}
                             ]}
        results = await postgres.find_many(criteria).to_list();
    return prepare_postgres_response(start_date, end_date, env, results)


# TODO: remove this end point before production
@postgres_tables_router.post("/", response_description=" Metrics added to the database")
async def add_postgres_record(review: postgres) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}
