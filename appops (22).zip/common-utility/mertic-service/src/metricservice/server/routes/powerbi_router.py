import datetime

from fastapi import APIRouter

from metricservice.server.models.powerbi import powerbi, Capacity, Workspace, Artifact, Executing_user, Dax_query

powerbirouter = APIRouter()


def prepare_powerbi_response(start_date: datetime.datetime,
                               end_date: datetime.datetime,
                               env: str,
                               results: powerbi) -> dict:
    stime = datetime.datetime.now(datetime.timezone.utc)
    flat_list = []
    for doc in results:
        if len(doc.capacities) > 0:
            for capacity in doc.capacities:
                capacity_metric_value = []
                for key, value in capacity.dict().items():
                    if key not in ['workspaces'] and value is not None:
                        capacity_metric_value.append(str(value))
                    if key not in ['workspaces'] and value is None:
                        capacity_metric_value.append('')
                    if key == 'workspaces' and value is not None and type(value) == list:
                        i = 0

                        for i in range(len(value)):
                            workspace_metric_value = []
                            for keys1, val1 in value[i].items():
                                if val1 is None and keys1 != 'artifacts':
                                    workspace_metric_value.append('')
                                elif val1 is not None and type(val1) != list:
                                    workspace_metric_value.append(str(val1))
                                elif keys1 == 'artifacts' and val1 is not None and type(val1) == list:
                                    if len(val1) > 0:
                                        j = 0
                                        for j in range(len(val1)):
                                            capacity_metric_value_temp = []
                                            artifacts_metric_value = []
                                            for keys2, val2 in val1[j].items():
                                                # print(keys2, val2)
                                                if val2 is not None and type(val2) != list and keys2 not in ['executing_users']:
                                                    artifacts_metric_value.append(str(val2))
                                                elif keys2 == 'executing_users' and val2 is not None and type(
                                                        val2) == list:
                                                    if len(val2) > 0:
                                                        k = 0
                                                        for k in range(len(val2)):
                                                            capacity_metric_value_temp = []
                                                            executing_users_metric_value = []
                                                            for keys3, val3 in val2[k].items():
                                                                if val3 is not None and type(val3) != list and keys3 not in ['dax_queries']:
                                                                    executing_users_metric_value.append(str(val3))
                                                                elif keys3 == 'dax_queries' and val3 is not None and type(val3) == list:
                                                                    if len(val3) >0:
                                                                        l=0
                                                                        for l in range(len(val3)):
                                                                            capacity_metric_value_temp = []
                                                                            dax_queries_metric_value = []
                                                                            for keys4, val4 in val3[l].items():
                                                                                if val4 is not None and type(val4)!= list:
                                                                                    dax_queries_metric_value.append(str(val4))
                                                                                else:
                                                                                    dax_queries_metric_value.append('')

                                                                            capacity_metric_value_temp = capacity_metric_value + workspace_metric_value + artifacts_metric_value + executing_users_metric_value+dax_queries_metric_value
                                                                            metric_record = {"timestamp": str(doc.ts),
                                                                                             "metric_value": capacity_metric_value_temp}
                                                                            flat_list.append(metric_record)
                                                                            l=l+1
                                                                    elif len(val3)==0:
                                                                        capacity_metric_value_temp = []
                                                                        e = Dax_query()
                                                                        l = len(e.dict().keys())
                                                                        dax_queries_metric_value_temp = [''] * l
                                                                        capacity_metric_value_temp = capacity_metric_value + workspace_metric_value + artifacts_metric_value + executing_users_metric_value+dax_queries_metric_value_temp
                                                                        metric_record = {"timestamp": str(doc.ts),
                                                                                         "metric_value": capacity_metric_value_temp}
                                                                        flat_list.append(metric_record)
                                                                else:
                                                                    executing_users_metric_value.append('')
                                                            k = k + 1
                                                    if len(val2) == 0:
                                                        capacity_metric_value_temp = []
                                                        dq = Dax_query()
                                                        dq_l = len(dq.dict().keys())
                                                        dax_queries_metric_value_temp = [''] * dq_l
                                                        eu = Executing_user()
                                                        eu_l = len(eu.dict().keys())
                                                        executing_users_metric_value_temp = [''] * eu_l -1
                                                        capacity_metric_value_temp = capacity_metric_value + workspace_metric_value + artifacts_metric_value + executing_users_metric_value_temp + dax_queries_metric_value_temp
                                                        metric_record = {"timestamp": str(doc.ts),
                                                                         "metric_value": capacity_metric_value_temp}
                                                        flat_list.append(metric_record)

                                                else:
                                                    artifacts_metric_value.append('')


                                            j = j + 1
                                    if len(val1) == 0:
                                        capacity_metric_value_temp = []
                                        dq = Dax_query()
                                        dq_l = len(dq.dict().keys())
                                        dax_queries_metric_value_temp = [''] * dq_l
                                        eu = Executing_user()
                                        eu_l = len(eu.dict().keys())
                                        executing_users_metric_value_temp = [''] * eu_l - 1
                                        ar = Artifact()
                                        ar_l= len(ar.dict().keys())
                                        artifacts_metric_value_temp=[''] * ar_l -1
                                        capacity_metric_value_temp = capacity_metric_value + workspace_metric_value + artifacts_metric_value_temp + executing_users_metric_value_temp + dax_queries_metric_value_temp
                                        metric_record = {"timestamp": str(doc.ts),
                                                         "metric_value": capacity_metric_value_temp}
                                        flat_list.append(metric_record)
                            i = i + 1

    # get all the metric key names by creating test object
    a1 = Capacity(premium_capacity_id='example1')
    a3 = Workspace(powerbi_workspace_name="example1")
    a4 = Artifact(artifact_id='example1')
    a5 = Executing_user(executing_user='example1')
    a6 = Dax_query(eventText='example1')

    metric_name = list(a1.dict(by_alias=True, exclude={"workspaces"})) + \
                  list(a3.dict(by_alias=True, exclude={"artifacts"})) + list(
        a4.dict(by_alias=True, exclude={"executing_users"})) + list(
        a5.dict(by_alias=True,exclude={"dax_queries"})) + list(a6.dict(by_alias=True))

    response_metrics_record = {
        "service_provider": "",
        "env_name": str(env),
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["premium_capacity_id", "powerbi_workspace_name", "artifact_id","executing_user","eventText"],
                    "metric_name": metric_name},
        "metric_records": flat_list
    }
    return response_metrics_record


# prepare_azure_sqlserver_response(start_date='2022-12-15 12:00:00', end_date='2022-12-15 12:00:00', env='', results='')
# TODO: removed optional params and test with paging before production
@powerbirouter.get("/", response_description="Metric records retrieved")
async def get_powerbi_record(start_date: datetime.datetime | None = None,
                               end_date: datetime.datetime | None = None,
                               env: str | None = None) -> powerbi:
    sttime = datetime.datetime.now(datetime.timezone.utc)
    if start_date is None or end_date is None or env is None:
        results = await powerbi.find_all().to_list()
    else:
        criteria = {"$and": [{"ts": {"$gte": start_date, "$lte": end_date}},
                             {"source.env": {"$eq": env}}
                             ]}
        results = await powerbi.find_many(criteria).to_list()
    return prepare_powerbi_response(start_date, end_date, env, results)


# TODO: remove this end point before production
@powerbirouter.post("/", response_description=" Metrics added to the database")
async def add_azure_powerbi_record(review: powerbi) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}
