from __future__ import annotations

import datetime

from fastapi import APIRouter

from metricservice.server.models.redis import redis, Instances

redis_instances_router = APIRouter()


def prepare_jobs_response(start_date: datetime.datetime,
                          end_date: datetime.datetime,
                          env: str,
                          results: redis) -> dict:
    # get all the metric key names by creating test object
    c = Instances(ip=1, Command="example", user="user")

    instances_names = list(c.dict(by_alias=False))
    metric_names = list(c.dict(by_alias=True))

    flat_list = []
    for record in results:
        for top in record.instances:
            temp1 = [dict(top).get(metric) if dict(top).get(metric) is not None else ''
                     for metric in instances_names]
            metric_record = {"timestamp": str(record.ts), "metric_value": temp1}
            flat_list.append(metric_record)

    # create final response
    response_metrics_record = {
        "service_provider": "",
        "env_name": env,
        "account_id": "",
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["ip"], "metric_name": list(metric_names)},
        "metric_records": flat_list
    }
    return response_metrics_record


# TODO: removed optional params and test with paging before production
@redis_instances_router.get("/", response_description="Metric records retrieved")
async def get_jobs_record(start_date: datetime.datetime | None = None,
                          end_date: datetime.datetime | None = None,
                          env: str | None = None) -> dict:

    if start_date is None or end_date is None or env is None:
        results = await redis.find_all().to_list()
    else:
        criteria = {"$and": [{"ts": {"$gte": start_date, "$lte": end_date}},
                             {"source.env": {"$eq": env}}
                             ]}
        results = await redis.find_many(criteria).to_list()
    return prepare_jobs_response(start_date, end_date, env, results)


# TODO: remove this end point before production
@redis_instances_router.post("/", response_description=" Metrics added to the database")
async def add_jobs_record(review: redis) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}
