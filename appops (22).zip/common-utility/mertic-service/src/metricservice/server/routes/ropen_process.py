from __future__ import annotations

from metricservice.server.models.ropen import ropen, Instance, Process
from fastapi import APIRouter
import datetime

ropen_process_router = APIRouter()


def prepare_jobs_response(start_date: datetime.datetime,
                          end_date: datetime.datetime,
                          env: str,
                          results: ropen) -> dict:
    # get all the metric key names by creating test object
    j = Instance(nodename="example1")
    c = Process(pid=1,Command="example",elapsed="1",user="user")

    instance_names = list(j.dict(by_alias=False))
    instance_names.remove('statistics')
    instance_names.remove('processes')

    process_names = list(c.dict(by_alias=False))

    metric_names = instance_names + list(c.dict(by_alias=True))

    flat_list = []
    for record in results:
        for instance in record.instances:
            metric_value = [dict(instance).get(metric) if dict(instance).get(metric) is not None else ''
                            for metric in instance_names]
            for process in instance.processes:
                temp1 = metric_value.copy()
                temp1 = temp1 + [dict(process).get(metric) if dict(process).get(metric) is not None else ''
                                        for metric in process_names]
                metric_record = {"timestamp": str(record.ts), "metric_value": temp1}
                flat_list.append(metric_record)

    # create final response
    response_metrics_record = {
        "service_provider": "",
        "env_name": env,
        "account_id": "",
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["nodename", "pid"], "metric_name": list(metric_names)},
        "metric_records": flat_list
    }
    return response_metrics_record


# TODO: removed optional params and test with paging before production
@ropen_process_router.get("/", response_description="Metric records retrieved")
async def get_jobs_record(start_date: datetime.datetime | None = None,
                          end_date: datetime.datetime | None = None,
                          env: str | None = None) -> dict:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await ropen.find_all().to_list()
    else:
        criteria = {"$and": [{"ts": {"$gte": start_date, "$lte": end_date}},
                             {"source.env": {"$eq": env}}
                             ]}
        results = await ropen.find_many(criteria).to_list()
    return prepare_jobs_response(start_date, end_date, env, results)


# TODO: remove this end point before production
@ropen_process_router.post("/", response_description=" Metrics added to the database")
async def add_jobs_record(review: ropen) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}
