from fastapi import APIRouter
import datetime
from metricservice.server.models.sagemaker import sagemaker
from metricservice.server.models.sagemaker import processingjob
from metricservice.server.models.sagemaker import endpoint
from metricservice.server.models.sagemaker import groundtruth
from metricservice.server.models.sagemaker import workteam
from metricservice.server.models.sagemaker import pipeline
from metricservice.server.models.sagemaker import feature

sagemakerrouter = APIRouter()

def prepare_sagemaker_response(start_date: datetime.datetime,
                     end_date: datetime.datetime,
                     env: str,
                     results: sagemaker) -> dict:
    # flatten the JSON object
    flat_list = [] 
    for record in results:
        job_metric_value = []
        # for job1 in record.processingjobs:
        #     for key in job1.dict().keys():
        #         value = job1.dict()[key]
        #         if value is not None:
        #             job_metric_value.append(str(value))
        #         else:
        #             job_metric_value.append('')
        endpoint_metric_value = [] 
        for endpoint1 in record.endpoints:
            for key in endpoint1.dict().keys():
                value = endpoint1.dict()[key]
                if value is not None:
                    endpoint_metric_value.append(str(value))
                else:
                    endpoint_metric_value.append('')
        groundtruth_metric_value = []
        for groundtruth1 in record.groundtruths:
            for key in groundtruth1.dict().keys():
                value = groundtruth1.dict()[key]
                if value is not None:
                    groundtruth_metric_value.append(str(value))
                else:
                    groundtruth_metric_value.append('')
        pipeline_metric_value = []
        for pipeline1 in record.pipelines:
            for key in pipeline1.dict().keys():
                value = pipeline1.dict()[key]
                if value is not None:
                    pipeline_metric_value.append(str(value))
                else:
                    pipeline_metric_value.append('')
        workteam_metric_value = [] 
        for workteam1 in record.workteams:
            for key in workteam1.dict().keys():
                value = workteam1.dict()[key]
                if value is not None:
                    workteam_metric_value.append(str(value))
                else:
                    workteam_metric_value.append('')
        feature_metric_value = [] 
        for feature1 in record.features:
            for key in feature1.dict().keys():
                value = feature1.dict()[key]
                if value is not None:
                    feature_metric_value.append(str(value))
                else:
                    feature_metric_value.append('')
        # print("job_metric_value")
        # print(job_metric_value)
        # print("endpoint_metric_value")
        # print(endpoint_metric_value)
        # print("groundtruth_metric_value")
        # print(groundtruth_metric_value)
        # print("pipeline_metric_value")
        # print(pipeline_metric_value)
        # print("workteam_metric_value")
        # print(workteam_metric_value)
        # print("feature_metric_value")
        # print(feature_metric_value)
        metric_record = {"timestamp": str(record.ts), "metric_value": job_metric_value + endpoint_metric_value +groundtruth_metric_value + pipeline_metric_value + workteam_metric_value + feature_metric_value}  
        flat_list.append(metric_record)
    # get all the metric key names by creating test object
    j = processingjob(Host="example")
    e = endpoint(EndpointName = "example2")
    p = pipeline(PipelineName = "example3")
    g = groundtruth(LabelingJobName = "example4")
    w = workteam(LabelingJob = "example5")
    f = feature(FeatureGroupName = "example6")

    metric_names = list(j.dict(by_alias=True)) + list(e.dict(by_alias=True)) + list(g.dict(by_alias=True)) + list(p.dict(by_alias=True))+ list(w.dict(by_alias=True)) + list(f.dict(by_alias=True))


    # create final response
    response_metrics_record = {
        "service_provider": "",
        "env_name": env,
        "account_id": "",
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["Host","EndpointName","LabelingJobName", "PipelineName", "LabelingJob", "FeatureGroupName"], "metric_name": list(metric_names)},    #, "PipelineName", "LabelingJobName", "LabelingJob"
        "metric_records": flat_list
    }
    return response_metrics_record   

# TODO: removed optional params and test with paging before production
@sagemakerrouter.get("/", response_description="Metric records retrieved")
async def get_sagemaker_record(start_date: datetime.datetime | None = None,
                        end_date: datetime.datetime | None = None,
                        env: str | None = None) -> sagemaker:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await sagemaker.find_all().to_list();
    else:
        criteria = {"$and": [ {"ts": {"$gte": start_date, "$lte": end_date}},
                              {"source.env": {"$eq": env}}
                              ]}
        results = await sagemaker.find_many(criteria).to_list();
    return prepare_sagemaker_response(start_date, end_date, env, results)

# TODO: remove this end point before production
@sagemakerrouter.post("/", response_description=" Metrics added to the database")
async def add_s3_record(review: sagemaker) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}