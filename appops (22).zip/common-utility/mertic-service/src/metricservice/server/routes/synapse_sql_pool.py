from __future__ import annotations
from metricservice.server.models.synapse import synapse
from metricservice.server.models.synapse import workspace
from metricservice.server.models.synapse import bigdatapool
from metricservice.server.models.synapse import sqlpool
from metricservice.server.models.synapse import queries
from fastapi import APIRouter
import datetime


synapsesqlpoolrouter = APIRouter()

def prepare_synapse_response(start_date: datetime.datetime,
                     end_date: datetime.datetime,
                     env: str,
                     results: synapse) -> dict:

    # print("RESULTS: ", results)

    # get all the metric key names by creating test object
    w = workspace(workspaceName="example", sqlPools=[])
    s = sqlpool()
    q = queries()

    metric_names = list(w.dict(by_alias=True, exclude={'bigDataPools', 'sqlPools'})) + list(s.dict(by_alias=True, exclude={'queries'})) + list(q.dict(by_alias=True))

    # flatten the JSON object
    flat_list = []
    for record in results:
        workspace_metric_value = []
        for job1 in record.workspaces:
            for key in job1.dict().keys():
                if key != "bigDataPools" and key != "sqlPools":
                    value = job1.dict()[key]
                    if value is not None:
                        workspace_metric_value.append(str(value))
                    else:
                        workspace_metric_value.append("")
            sqlpool_metric_value = []
            if job1.sqlPools is not None:
                if len(job1.sqlPools) > 0:
                    for job2 in job1.sqlPools:
                        for key in job2.dict().keys():
                            if key != "queries":
                                value = job2.dict()[key]
                                if value is not None:
                                    sqlpool_metric_value.append(str(value))
                                else:
                                    sqlpool_metric_value.append("")
                        if job2.queries is not None:
                            if len(job2.queries) > 0:
                                for job3 in job2.queries:
                                    metric_record = {"timestamp": str(record.ts), "metric_value": workspace_metric_value.copy() + sqlpool_metric_value.copy()}
                                    metric_value = []
                                    for key in job3.dict().keys():
                                        value = job3.dict()[key]
                                        if value is not None:
                                            metric_value.append(str(value))
                                        else:
                                            metric_value.append("")
                                    metric_record["metric_value"] += metric_value
                                    flat_list.append(metric_record)
                        else:
                            metric_record = {"timestamp": str(record.ts), "metric_value": workspace_metric_value.copy() + sqlpool_metric_value.copy()}
                            q1 = queries()
                            l = len(q1.dict().keys())
                            metric_value = [''] * l
                            metric_record["metric_value"] += metric_value
                            flat_list.append(metric_record)
            else:
                metric_record = {"timestamp": str(record.ts), "metric_value": workspace_metric_value.copy()}
                s1 = sqlpool()
                q1 = queries()
                l = len(s1.dict(by_alias=True, exclude={'queries'}).keys()) + len(q1.dict().keys())
                metric_value = [''] * l
                metric_record["metric_value"] += metric_value
                flat_list.append(metric_record)

    # create final response
    response_metrics_record = {
        "service_provider": "",
        "env_name": env,
        "account_id": "",
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["workspace_name", "sql_pool_name", "request_id"], "metric_name": list(metric_names)},    #, "PipelineName", "LabelingJobName", "LabelingJob"
        "metric_records": flat_list
    }
    return response_metrics_record

# TODO: removed optional params and test with paging before production
@synapsesqlpoolrouter.get("/", response_description="Metric records retrieved")
async def get_synapse_record(start_date: datetime.datetime | None = None,
                        end_date: datetime.datetime | None = None,
                        env: str | None = None) -> synapse:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await synapse.find_all().to_list();
    else:
        criteria = {"$and": [ {"ts": {"$gte": start_date, "$lte": end_date}},
                              {"source.env": {"$eq": env}}
                              ]}
        results = await synapse.find_many(criteria).to_list();
    return prepare_synapse_response(start_date, end_date, env, results)

# TODO: remove this end point before production
@synapsesqlpoolrouter.post("/", response_description=" Metrics added to the database")
async def add_synapse_record(review: synapse) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}