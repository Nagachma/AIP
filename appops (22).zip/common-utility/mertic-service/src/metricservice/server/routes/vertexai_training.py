import datetime

from fastapi import APIRouter
from metricservice.server.models.vertexai import Training
from metricservice.server.models.vertexai import vertexai

vertexai_training_router = APIRouter()

# TODO: removed optional params and test with paging before production
def prepare_vertexai_response(start_date: datetime.datetime,
                          end_date: datetime.datetime,
                          env: str,
                          results: vertexai):
    flat_list = []
    for doc in results:
        project_id_metric_value=[]
        if len(doc.training)>0:
            for metrics in doc.training:
                for key in metrics.dict().keys():

                    value = metrics.dict()[key]
                    if value is not None:
                        project_id_metric_value.append(value)
                    else:
                        project_id_metric_value.append('')
                metric_record = {"timestamp": str(doc.ts), "metric_value": project_id_metric_value}
                flat_list.append(metric_record)
                project_id_metric_value = list()
    # get all the metric key names by creating test object
    a1 = Training(job_id="example1")
    metric_names = list(a1.dict(by_alias=True))
    # create final response
    response_metrics_record = {
        "service_provider": "GCP",
        "env_name": env,
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["project_id","job_id"], "metric_name": metric_names},
        "metric_records": flat_list
    }
    return response_metrics_record

@vertexai_training_router.get("/", response_description="Metric records retrieved")
async def get_vertexai_record(start_date: datetime.datetime | None = None,
                          end_date: datetime.datetime | None = None,
                          env: str | None = None) -> vertexai:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await vertexai.find_all().to_list();
    else:
        criteria = {"$and": [{"ts": {"$gte": start_date, "$lte": end_date}},
                             {"source.env": {"$eq": env}}
                             ]}
        results = await vertexai.find_many(criteria).to_list();
    return prepare_vertexai_response(start_date, end_date, env, results)


# TODO: remove this end point before production
@vertexai_training_router.post("/", response_description=" Metrics added to the database")
async def add_vertexai_record(review: vertexai) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}