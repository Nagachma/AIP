'''
This script contains functions related to MongoDB
'''
__author__ = 'Prudhvi Chelluri'
__email__ = 'prudhvi.l.chelluri@accenture.com'
__version__ = '0.1.0'   # 2023-07-08

from pymongo import MongoClient

class MongoUtil():
    '''Utility class for MongoDB transactions'''
    def __init__(self, connection_uri, database, collection_name, logger):
        self.connection_uri = connection_uri
        self.database = database
        self.collection = collection_name
        # assgin logging client
        self.logger = logger
        # create mongodb connection
        self.create_connection()

    def create_connection(self):
        '''create a new database connection'''
        self.logger.debug(f'MongoDB connection created for collection [{self.database}.{self.collection}]')
        self.mongo_client = MongoClient(self.connection_uri, tz_aware=True)
        self.db = self.mongo_client.get_database(self.database)
        self.collection = self.db.get_collection(self.collection)

    def count(self, query={}) -> int:
        '''return count of documents based on the query'''
        self.logger.debug(f'Getting count of documents using query [{query}]')
        return self.collection.count_documents(query)

    def read(self, query={}):
        '''return latest one record from database'''
        self.logger.debug('Fetching data from database')
        # docs = self.collection.find(query).sort('_id', DESCENDING).limit(1)
        # result = [ doc for doc in docs ]
        # since the heartbeat contains only one record, we can simply query the collection without any filters
        result = self.collection.find_one(query)

        return result

    def insert(self, records):
        '''insert records into database'''
        self.logger.debug(f'Inserting {len(records)} records into database')
        if isinstance(records, list):
            self.collection.insert_many(records)
        else:
            self.collection.insert_one(records)

    def upsert(self, filter, update_expression):
        '''upsert a record into database (update the record if exists, else insert)'''
        self.logger.debug(f'Upserting record in database')
        self.collection.update_one(filter, update_expression, upsert=True)

    def close_connection(self):
        '''close mongo connection'''
        if self.mongo_client:
            self.logger.debug('Closing mongo connection')
            self.mongo_client.close()

# if __name__ == '__main__':
#     import logging
#     logging.basicConfig(format='[%(asctime)s] %(levelname)s: %(message)s', datefmt='%Y-%m-%d %H:%M:%S', level=logging.DEBUG)
#
#     mongo_uri =
#     mongo_util = MongoUtil(mongo_uri, 'appops_dev', 'health_check', logging)
#     print(mongo_util.read())
#
#     mongo_util.close_connection()
