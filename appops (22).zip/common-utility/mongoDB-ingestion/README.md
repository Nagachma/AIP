## MongoDB Ingestion

### Pre-requisite

- Install Python 3.9 or greater
- Install pip packages from requirements.txt:
  `pip install -r requirements.txt`

### Pre-setup

Following are all required changes to be done in config.yaml -

- Mongo DB url to be updated to correct URL for testing and during deployment in Production in Vault
```yaml
For each service , provide the alias, check from Xops DB from services table and provide the name 
alias: Glue      - Example
```
- Add the CSV paths of each Metric Source; the mongo collection name, ingestion location path, ingestion prefix-
```yaml
cloudscheduler_metrics_info:  # cloudscheduler -> the service name, should always be without spaces or underscores
  alias: Cloud Scheduler     # check from Xops services table and provide
  csv_ingestion_location: ../common-utility/mongoDB-ingestion/gcp/cloudscheduler/ingestion/csv/
  csv_ingestion_prefix: cloudscheduler_metrics  # prefix should always start with service name without spaces or underscores
  jobs_csv_metric_location: ../common-utility/mongoDB-ingestion/gcp/cloudscheduler/metrics/jobs/  # jobs_csv_metric_location --> `jobs` is the Metric source type
  jobsfailure_csv_metric_location: ../common-utility/mongoDB-ingestion/gcp/cloudscheduler/metrics/jobsfailure/
  jobs_csv: ../common-utility/mongoDB-ingestion/gcp/cloudscheduler/ingestion/csv/jobs_cloudscheduler_metrics_diff.csv
  jobsfailure_csv: ../common-utility/mongoDB-ingestion/gcp/cloudscheduler/ingestion/csv/jobsfailure_cloudscheduler_metrics_diff.csv
  json_ingestion_location: ../common-utility/mongoDB-ingestion/gcp/cloudscheduler/ingestion/json/
  json_ingestion_prefix: cloudscheduler_metrics
  mongo_collection: cloud_scheduler  # mongo collection name in which data will be ingested
```

### Ingestion JSON template
A template or structure of the data that will be ingested into MongoDB is kept for each service, under ingestion\json, e.g.:
`common-utility/mongoDB-ingestion/azure/datafactory/ingestion/json/datafactory_template.json`

### Execution
Run the main.py with passing the service name:
```shell
python main.py redshift
```