from json import dumps as convert_to_json
from os import makedirs
from os.path import exists
from os.path import isfile as is_file

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2

def find_index_of_list_of_dicts_by_value(lst, key, value):
    for i, dic in enumerate(lst):
        if dic[key] == value:
            return i
    return -1

def ingest_lambda_csvs(config,logger,exit_handler):
	#TO DO check if config values even exist. 
	# dymanmically get cloudwatch csv and custom csv

	source = config['source']

	cloud_watch_csv = config['lambda_metrics_info']['cloud_watch_csv']
	custom_csv = config['lambda_metrics_info']['custom_csv']
	
	json_ingestion_location = config['lambda_metrics_info']['json_ingestion_location']
	json_ingestion_prefix = config['lambda_metrics_info']['json_ingestion_prefix']

	# Make ingrestion directories if it doesn't exist
	# TO DO: Check write access to create this directory
	if not exists(json_ingestion_location):
		makedirs(json_ingestion_location)

	metric_dict = {}
	index = 0
	fp = open(cloud_watch_csv,"r")
	for line in fp.readlines():
		line = line.strip()
		if index == 0:
			headers = line.split(",")
			for header in headers:
				metric_dict[header] = []
			index += 1
		else:
			line = line.split(",")
			for i in range(len(line)):
				if "+" in line[i]:
					line[i] = ":".join(line[i].split("+")[0].split(":")[0:-1])
				metric_dict[headers[i]].append(line[i])
	fp.close()

	custom_dict = {}
	index = 0
	fp = open(custom_csv,"r")
	for line in fp.readlines():
		line = line.strip()
		if index == 0:
			headers = line.split(",")
			for header in headers:
				custom_dict[header] = []
			index += 1
		else:
			line = line.split(",")
			for i in range(len(line)):
				if "+" in line[i] and headers[i] != "Interval":
					line[i] = ":".join(line[i].split("+")[0].split(":")[0:-1])
				custom_dict[headers[i]].append(line[i])
	fp.close()

	for i in range(len(metric_dict["metric_value"])):
		value = metric_dict["metric_value"][i]
		try:
			value = float(value)
		except ValueError:
			pass
		else:
			metric_dict["metric_value"][i] = float(value)

	for key in custom_dict.keys():
		for i in range(len(custom_dict[key])):
			value =custom_dict[key][i]
			try:
				value = float(value)
			except ValueError:
				pass
			else:
				custom_dict[key][i] = float(value)
	
	for timestamp in sorted(set(metric_dict["start_time"]) | set(custom_dict["Start Time"])):
		json_dict = {"source":source,"ts":timestamp,"functions":[]}
		for i in range(len(metric_dict["FunctionName"])):
			if metric_dict["start_time"][i] == timestamp and not any(True for d in json_dict["functions"] if d["functionName"] == metric_dict["FunctionName"][i]):
				func_dict = {
				 				"functionName": metric_dict["FunctionName"][i],
				 				"start_time":  metric_dict["start_time"][i],
				 				"end_time":  metric_dict["end_time"][i],
				 				"runs": [],
				 				metric_dict["metric_name"][i]:metric_dict["metric_value"][i]
				 			}
				json_dict["functions"].append(func_dict)
			elif metric_dict["start_time"][i] == timestamp:
				index = find_index_of_list_of_dicts_by_value(json_dict["functions"],"functionName",metric_dict["FunctionName"][i])
				json_dict["functions"][index][metric_dict["metric_name"][i]] = metric_dict["metric_value"][i]

		for j in range(len(custom_dict["Function Name"])):
			if custom_dict["Start Time"][j] == timestamp:
				index = find_index_of_list_of_dicts_by_value(json_dict["functions"],"functionName",custom_dict["Function Name"][j])
				if index != -1:
					json_dict["functions"][index]["runs"].append({
																	"Interval": custom_dict["Interval"][j],
																	"Billed Duration (ms)": custom_dict["Billed Duration (ms)"][j],
																	"Memory Size (MB)": custom_dict["Memory Size (MB)"][j],
																	"Max Memory Used (MB)": custom_dict["Max Memory Used (MB)"][j],
																	"Unique ID": custom_dict["Unique ID"][j]
																 })
				else:
					func_dict = {
				 				"functionName": custom_dict["Function Name"][j],
				 				"start_time":  custom_dict["Start Time"][j],
				 				"end_time":  custom_dict["End Time"][j],
				 				"runs": [{
				 							"Interval": custom_dict["Interval"][j],
											"Billed Duration (ms)": custom_dict["Billed Duration (ms)"][j],
											"Memory Size (MB)": custom_dict["Memory Size (MB)"][j],
											"Max Memory Used (MB)": custom_dict["Max Memory Used (MB)"][j],
											"Unique ID": custom_dict["Unique ID"][j]
				 						}]
				 			}
					json_dict["functions"].append(func_dict)

		json_object = convert_to_json(json_dict, indent=4)

		timestamp = "-".join("_".join(timestamp.split(" ")).split(":"))
		
		with open(json_ingestion_location + json_ingestion_prefix + "_" + timestamp + ".json", "w") as outfile:
			outfile.write(json_object)