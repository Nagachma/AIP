from cProfile import run
import csv
import pandas as pd
import os
import yaml
from pymongo import MongoClient
from datetime import datetime
import hashlib
import random

with open('/data01/aurora_postgres/ingestion/ingestion_config.yml') as f:
    config = yaml.safe_load(f)

csvFilePath = config['aurorap_ingestion']['cloud_watch_csv']
piCsvFilePath = config['aurorap_ingestion']['pi_csv']
connCountCsvFilePath = config['aurorap_ingestion']['connCountCsvFilePath']
connUsedCsvFilePath = config['aurorap_ingestion']['connUsedCsvFilePath']
hotRateCsvFilePath = config['aurorap_ingestion']['hotRateCsvFilePath']
percentoftimeindexCsvFilePath = config['aurorap_ingestion']['percentoftimeindexCsvFilePath']
pgStatDatabaseCsvFilePath = config['aurorap_ingestion']['pgStatDatabaseCsvFilePath']
pgStatUserTablesCsvFilePath = config['aurorap_ingestion']['pgStatUserTablesCsvFilePath']
resForSuperCsvFilePath = config['aurorap_ingestion']['resForSuperCsvFilePath']
runTimeCsvFilePath = config['aurorap_ingestion']['runTimeCsvFilePath']
#customCsvFilePath = config['aurorap_ingestion']['pi_csv']
# output = config['aurorap_ingestion']['output_json']

# isExist = os.path.exists(output)
# if not isExist:
#     os.makedirs(output)

#local run
# csvFilePath = './csv/cw_aurorap_metrics_11042022.csv'
# piCsvFilePath = './csv/all_2022-11-04.csv'


df = pd.read_csv(csvFilePath)
header = list(df.columns)

df2 = pd.read_csv(piCsvFilePath)
header2 = list(df2.columns)

df3 = pd.read_csv(connCountCsvFilePath)
header3 = list(df3.columns)

df4 = pd.read_csv(connUsedCsvFilePath)
header4 = list(df4.columns)

df5 = pd.read_csv(hotRateCsvFilePath)
header5 = list(df5.columns)

df6 = pd.read_csv(percentoftimeindexCsvFilePath)
header6 = list(df6.columns)


df7 = pd.read_csv(pgStatDatabaseCsvFilePath)
header7 = list(df7.columns)

df8 = pd.read_csv(pgStatUserTablesCsvFilePath)
header8 = list(df8.columns)

df9 = pd.read_csv(resForSuperCsvFilePath)
header9 = list(df9.columns)


df10 = pd.read_csv(runTimeCsvFilePath)
header10 = list(df10.columns)

instance_name = list(df.DBInstanceIdentifier)
instance_name2 = list(df2.instance)
instance_name3 = (list(df3.db_instance_id))
instance_name4 = (list(df4.db_instance_id))
instance_name5 = (list(df5.db_instance_id))
instance_name6 = (list(df6.db_instance_id))
instance_name7 = (list(df7.db_instance_id))
instance_name8 = (list(df8.db_instance_id))
instance_name9 = (list(df9.db_instance_id))
instance_name10 = (list(df10.db_instance_id))
instance_name.extend(instance_name2)
instance_name.extend(instance_name3)
instance_name.extend(instance_name4)
instance_name.extend(instance_name5)
instance_name.extend(instance_name6)
instance_name.extend(instance_name7)
instance_name.extend(instance_name8)
instance_name.extend(instance_name9)
instance_name.extend(instance_name10)
instance_name = [*set(instance_name)]

timestamp = list(df.start_time)
timestamp = [*set(timestamp)]
timestamp = list(map(lambda timestp: timestp[0:16], timestamp))
timestamp2 = list(df2.metric_date)
timestamp2 = [*set(timestamp2)]
timestamp2 = list(map(lambda timestp: timestp[0:16], timestamp2))

timestamp3 = list(df3.metric_date)
timestamp3 = [*set(timestamp3)]
timestamp3 = list(map(lambda timestp: timestp[0:16], timestamp3))

timestamp4 = list(df4.metric_date)
timestamp4 = [*set(timestamp4)]
timestamp4 = list(map(lambda timestp: timestp[0:16], timestamp4))

# timestamp5 = list(df5.metric_date)
# timestamp5 = [*set(timestamp5)]
# timestamp5 = list(map(lambda timestp: timestp[0:16], timestamp5))

# timestamp6 = list(df6.metric_date)
# timestamp6 = [*set(timestamp6)]
# timestamp6 = list(map(lambda timestp: timestp[0:16], timestamp6))

timestamp7 = list(df7.metric_date)
timestamp7 = [*set(timestamp7)]
timestamp7 = list(map(lambda timestp: timestp[0:16], timestamp7))

# timestamp8 = list(df8.metric_date)
# timestamp8 = [*set(timestamp8)]
# timestamp8 = list(map(lambda timestp: timestp[0:16], timestamp8))

timestamp9 = list(df9.metric_date)
timestamp9 = [*set(timestamp9)]
timestamp9 = list(map(lambda timestp: timestp[0:16], timestamp9))

timestamp10 = list(df10.metric_date)
timestamp10 = [*set(timestamp10)]
timestamp10 = list(map(lambda timestp: timestp[0:16], timestamp10))



timestamp.extend(timestamp2)
timestamp.extend(timestamp3)
timestamp.extend(timestamp4)
# timestamp.extend(timestamp5)
# timestamp.extend(timestamp6)
timestamp.extend(timestamp7)
# timestamp.extend(timestamp8)
timestamp.extend(timestamp9)
timestamp.extend(timestamp10)
timestamp = [*set(timestamp)]
timestamp.sort()


source = config['source']
#local
# source = {"region":"eu-north-1", "env":"prod", "service_provider": "AWS"}

conn_count_datid = []
conn_count_datid = list(df3.datid)
conn_count_datid = [*set(conn_count_datid)]

# conn_used_datid = []
# conn_used_datid = list(df4.datid)
# conn_used_datid = [*set(conn_used_datid)]

hot_rate_relid = []
hot_rate_relid = list(df5.relid)
hot_rate_relid = [*set(hot_rate_relid)]

percent_of_time_index_relid = []
percent_of_time_index_relid = list(df6.relid)
percent_of_time_index_relid = [*set(percent_of_time_index_relid)]

pg_stat_database_datid = []
pg_stat_database_datid = list(df7.datid)
pg_stat_database_datid = [*set(pg_stat_database_datid)]

pg_stat_user_tables_relid = []
pg_stat_user_tables_relid = list(df8.relid)
pg_stat_user_tables_relid = [*set(pg_stat_user_tables_relid)]

runtime_pid = []
runtime_pid = list(df10.pid)
runtime_pid = [*set(runtime_pid)]

for i in timestamp:
    time = i
    time = datetime.strptime(time, '%Y-%m-%d %H:%M')
    final_output = {}
    instances = []
    

    for j in instance_name:

        instance_dict = {'instance_name': j, 'instance_created_unique_id': hashlib.sha224(repr(j+str(random.randint(0,999999))).encode('utf-8')).hexdigest()}
        #instance_dict = {'instance_created_unique_id': hashlib.sha224(repr(j).encode('utf-8')).hexdigest()}
        with open(csvFilePath) as for_values:
            heading = next(for_values)
            reader_obj = csv.reader(for_values)
            for row in reader_obj:
                if row[0][0:16] == i and row[2] == j:
                    instance_dict['start_time'] = row[0]
                    instance_dict['end_time'] = row[1]
                    if(row[4]!=""):
                        instance_dict[row[3]] = row[4]
                    # try:
                    #     value = float(value)
                    # except ValueError as ve:
                    #     # bucket_dict[row[3]] = row[4]
                    #     # bucket_dict[row[3]] = NULL
                    #     pass
                    # else:
                    #     instance_dict[row[3]] = float(value)

        with open(piCsvFilePath) as pi_csv_file:
            heading2 = next(pi_csv_file)
            reader_obj2 = csv.reader(pi_csv_file)
            for row in reader_obj2:
                if row[1] == j and row[0][0:16] == i:
                    if(row[3]!=""):
                        instance_dict[row[2]] = row[3]
                #    value = row[3] 
                #    try:
                #         value = float(value)
                #    except ValueError as ve:
                #         # bucket_dict[row[3]] = row[4]
                #         # bucket_dict[row[3]] = NULL
                #         pass
                #    else:
                #         instance_dict[row[2]] = float(value)


        with open(connUsedCsvFilePath) as conn_used_csv_file:
            heading3 = next(conn_used_csv_file)
            reader_obj3 = csv.reader(conn_used_csv_file)
            for row in reader_obj3:
                if row[2] == j and row[0][0:16] == i:
                    if(row[1]!=""):
                        instance_dict["conn_used"] = row[1]

        with open(resForSuperCsvFilePath) as res_for_super_file:
            heading4 = next(res_for_super_file)
            reader_obj4 = csv.reader(res_for_super_file)
            for row in reader_obj4:
                if row[2] == j and row[0][0:16] == i:
                    if(row[1]!=""):
                        instance_dict["res_for_super"] = row[1]

        conn_count_list = []
        for connCountDat in conn_count_datid:
            conn_count_flag = 0
            dict1 = {"datid": connCountDat}
            with open(connCountCsvFilePath) as conn_count_csv_file:
                heading5 = next(conn_count_csv_file)
                reader_obj5 = csv.reader(conn_count_csv_file)
                for row in reader_obj5:
                    if row[4] == j and row[0][0:16] == i and str(row[1]).strip() == str(connCountDat).strip():
                        conn_count_flag=1
                        if(row[2]!=""):
                            metric_name = "datname"
                            dict1[metric_name] = row[2]
                        if(row[3]!=""):
                            metric_name = "count"
                            dict1[metric_name] = row[3]
            if(conn_count_flag == 1):
                conn_count_list.append(dict1)
            

        instance_dict["conn_count"] = conn_count_list

        # hot_rate_list = []
        # for hotraterel in hot_rate_relid:
        #     hot_rate_flag = 0
        #     dict2 = {"relid": hotraterel}
        #     with open(hotRateCsvFilePath) as hot_rate_csv_file:
        #         heading6 = next(hot_rate_csv_file)
        #         reader_obj6 = csv.reader(hot_rate_csv_file)
        #         for row in reader_obj6:
        #             if row[4] == j and row[0][0:16] == i and str(row[1]).strip() == str(hotraterel).strip():
        #                 hot_rate_flag = 1
        #                 if(row[2]!=""):
        #                     metric_name = "relname"
        #                     dict2[metric_name] = row[2]
        #                 if(row[3]!=""):
        #                     metric_name = "hot_rate"
        #                     dict2[metric_name] = row[3]
        #     if(hot_rate_flag == 1):
        #         hot_rate_list.append(dict2)
            

        # instance_dict["hot_rate"] = hot_rate_list
        

        # percent_of_times_index_list = []
        # for percent_of_time_index_rel in percent_of_time_index_relid:
        #     percent_of_times_index_flag = 0
        #     dict3 = {"relid": percent_of_time_index_rel}
        #     with open(percentoftimeindexCsvFilePath) as percent_of_time_index_csv_file:
        #         heading7 = next(percent_of_time_index_csv_file)
        #         reader_obj7 = csv.reader(percent_of_time_index_csv_file)
        #         for row in reader_obj7:
        #             if row[5] == j and row[0][0:16] == i and str(row[1]).strip() == str(percent_of_time_index_rel).strip():
        #                 percent_of_times_index_flag = 1
        #                 if(row[2]!=""):
        #                     metric_name = "relname"
        #                     dict3[metric_name] = row[2]
        #                 if(row[3]!=""):
        #                     metric_name = "percent_of_times_index_used"
        #                     dict3[metric_name] = row[3]
        #                 if(row[4]!=""):
        #                     metric_name = "rows_in_table"
        #                     dict3[metric_name] = row[4]
        #     if(percent_of_times_index_flag == 1):
        #         percent_of_times_index_list.append(dict3)

        # instance_dict["percent_of_times_index"] = percent_of_times_index_list


        pg_stat_database_list = []
        for pg_stat_database_dat in pg_stat_database_datid:
            pg_stat_database_flag = 0
            dict4 = {"relid": pg_stat_database_dat}
            with open(pgStatDatabaseCsvFilePath) as pg_stat_database_csv_file:
                heading8 = next(pg_stat_database_csv_file)
                reader_obj8 = csv.reader(pg_stat_database_csv_file)
                for row in reader_obj8:
                    if row[9] == j and row[0][0:16] == i and str(row[1]).strip() == str(pg_stat_database_dat).strip():
                        pg_stat_database_flag = 1
                        if(row[2]!=""):
                            metric_name = "datname"
                            dict4[metric_name] = row[2]
                        if(row[3]!=""):
                            metric_name = "xact_rollback"
                            dict4[metric_name] = row[3]
                        if(row[4]!=""):
                            metric_name = "conflicts"
                            dict4[metric_name] = row[4]
                        if(row[5]!=""):
                            metric_name = "deadlocks"
                            dict4[metric_name] = row[5]
                        if(row[6]!=""):
                            metric_name = "hit_ratio"
                            dict4[metric_name] = row[6]
                        if(row[7]!=""):
                            metric_name = "temp_bytes"
                            dict4[metric_name] = row[7]
                        if(row[8]!=""):
                            metric_name = "temp_files"
                            dict4[metric_name] = row[8]
            if(pg_stat_database_flag == 1):
                pg_stat_database_list.append(dict4)

        instance_dict["pg_stat_database"] = pg_stat_database_list



        query_list = []
        for pid in runtime_pid:
            query_flag = 0
            dict6 = {"pid": pid}
            with open(runTimeCsvFilePath) as run_time_csv_file:
                heading10 = next(run_time_csv_file)
                reader_obj10 = csv.reader(run_time_csv_file)
                for row in reader_obj10:
                    if row[5] == j and row[0][0:16] == i and str(row[2]).strip() == str(pid).strip():
                        query_flag = 1
                        if(row[3]!=""):
                            metric_name = "query_total_time"
                            dict6[metric_name] = row[3]
                        if(row[4]!=""):
                            metric_name = "query_state"
                            dict6[metric_name] = row[4]
            if(query_flag == 1):
                query_list.append(dict6)
            

        instance_dict["queries"] = query_list



        # pg_stat_user_tables_list = []
        # for pg_stat_user_tables_rel in pg_stat_user_tables_relid:
        #     pg_stat_user_tables_flag = 0
        #     dict5 = {"relid": pg_stat_user_tables_rel}
        #     with open(pgStatUserTablesCsvFilePath) as pg_stat_user_tables_csv_file:
        #         heading9 = next(pg_stat_user_tables_csv_file)
        #         reader_obj9 = csv.reader(pg_stat_user_tables_csv_file)
        #         for row in reader_obj9:
        #             if row[12] == j and row[0][0:16] == i and str(row[1]).strip() == str(pg_stat_user_tables_rel).strip():
        #                 pg_stat_user_tables_flag = 1
        #                 if(row[2]!=""):
        #                     metric_name = "relname"
        #                     dict5[metric_name] = row[2]
        #                 if(row[3]!=""):
        #                     metric_name = "analyze_count"
        #                     dict5[metric_name] = row[3]
        #                 if(row[4]!=""):
        #                     metric_name = "autoanalyze_count"
        #                     dict5[metric_name] = row[4]
        #                 if(row[5]!=""):
        #                     metric_name = "autovacuum_count"
        #                     dict5[metric_name] = row[5]
        #                 if(row[6]!=""):
        #                     metric_name = "last_analyze"
        #                     dict5[metric_name] = row[6]
        #                 if(row[7]!=""):
        #                     metric_name = "last_autoanalyze"
        #                     dict5[metric_name] = row[7]
        #                 if(row[8]!=""):
        #                     metric_name = "last_vacuum"
        #                     dict5[metric_name] = row[8]
        #                 if(row[9]!=""):
        #                     metric_name = "last_autovacuum"
        #                     dict5[metric_name] = row[9]
        #                 if(row[10]!=""):
        #                     metric_name = "vacuum_count"
        #                     dict5[metric_name] = row[10]
        #                 if(row[11]!=""):
        #                     metric_name = "n_live_tup"
        #                     dict5[metric_name] = row[11]
        #     if(pg_stat_user_tables_flag == 1):
        #         pg_stat_user_tables_list.append(dict5)

        # instance_dict["pg_stat_user_tables"] = pg_stat_user_tables_list


        if len(instance_dict) > 4:
            instances.append(instance_dict)

    final_output["source"] = source
    final_output['ts'] = time
    final_output['instances'] = instances

    mongo_client = config['mongo_url']
    mongo_db = config['mongo_db']
    mongo_collection = config['redshift_metrics_info']['mongo_collection'] 
    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)
    collection.insert_one(final_output)
