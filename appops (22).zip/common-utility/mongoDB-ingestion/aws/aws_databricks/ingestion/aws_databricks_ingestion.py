from datetime import datetime, timezone
import pandas as pd
from pymongo import MongoClient
import csv

import os

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2

logger = []
exit_handler = []

def ingest_aws_databricks_csvs(config, logger, exit_handler):

    jobs_csv = config['awsdatabricks_metrics_info']['job_csv']
    clusters_csv = config['awsdatabricks_metrics_info']['cluster_csv']
    task_csv = config['awsdatabricks_metrics_info']['task_csv']

    df = pd.read_csv(clusters_csv)
    cluster_id = list(df.cluster_id)
    cluster_id = [*set(cluster_id)]

    df2 = pd.read_csv(jobs_csv)
    job_id = list(df2.job_id)
    job_id = [*set(job_id)]

    df3 = pd.read_csv(task_csv)

    ###########
    source = config['source']
    dict_list = []
    current_time = datetime.now(timezone.utc)

    final_output = {}
    time = current_time.strftime('%Y-%m-%d %H:%M')
    time = datetime.strptime(time, '%Y-%m-%d %H:%M')
    final_output['source'] = source
    final_output['ts'] = time
    clusters = []

    for i in cluster_id:
        insert_timestamp = current_time.strftime('%Y-%m-%d %H:%M:%S')
        insert_timestamp = datetime.strptime(insert_timestamp,'%Y-%m-%d %H:%M:%S')
        cluster_dict = {}
        cluster_dict = {'cluster_id': i, 'insert_timestamp': insert_timestamp}
        with open(clusters_csv) as for_values:
            heading = next(for_values)
            reader_obj = csv.reader(for_values)
            for row in reader_obj:
                if row[0] == i:
                    cluster_dict['creator_user_name'] = row[1]
                    cluster_dict['start_timestamp'] = row[2]
                    cluster_dict['cluster_name'] = row[3]
                    cluster_dict['availability'] = row[4]
                    cluster_dict['disk_count'] = row[5]
                    cluster_dict['disk_size'] = row[6]
                    cluster_dict['cluster_memory_mb'] = row[7]
                    cluster_dict['cluster_cores'] = row[8]
                    cluster_dict['start_time'] = row[9]
                    cluster_dict['last_activity_time'] = row[10]
                    cluster_dict['last_restarted_time'] = row[11]
                    cluster_dict['state'] = row[12]
                    cluster_dict['terminated_time'] = row[15]
                    cluster_dict['termination_reason'] = row[16]
                    cluster_dict['termination_status'] = row[17]
                    cluster_dict['cluster_run_time'] = row[18]

        with open(jobs_csv) as job_csv_file:
            heading2 = next(job_csv_file)
            reader_obj2 = csv.reader(job_csv_file)
            for row in reader_obj2:
                job_dict = {}
                if row[9] == i:
                    if 'Jobs' not in cluster_dict:
                        cluster_dict['Jobs'] = []
                    job_dict['job_id'] = row[0]
                    job_dict['job_run_id'] = row[1]
                    job_dict['job_creator_user_name'] = row[2]
                    job_dict['life_cycle_state'] = row[3]
                    job_dict['result_state'] = row[4]
                    job_dict['state_message'] = row[5]
                    job_dict['ebs_volume_type'] = row[6]
                    job_dict['ebs_volume_count'] = row[7]
                    job_dict['ebs_volume_size'] = row[8]
                    job_dict['job_start_time'] = row[10]
                    job_dict['job_end_time'] = row[11]
                    job_dict['setup_duration'] = row[12]
                    job_dict['execution_duration'] = row[13]
                    job_dict['cleanup_duration'] = row[14]
                    job_dict['run_duration'] = row[15]

                    with open(task_csv) as task_csv_file:
                        heading2 = next(task_csv_file)
                        reader_obj3 = csv.reader(task_csv_file)
                        for row1 in reader_obj3:
                            task_dict = {}
                            if row[0] == row1[0] and row[1] == row1[1]:
                                if 'Tasks' not in job_dict:
                                    job_dict['Tasks'] = []
                                task_dict['task'] = row1[2]
                                task_dict['task_details'] = row1[3]

                                job_dict['Tasks'].append(task_dict)

                    cluster_dict['Jobs'].append(job_dict)

        if len(cluster_dict) > 1:
            clusters.append(cluster_dict)    

    final_output['clusters'] = clusters

    dict_list.append(final_output)                       

    # Bulk insert all dictionaries to MongoDB
    mongo_client = config['mongo_url']
    mongo_db = config['mongo_db']
    mongo_collection = config['awsdatabricks_metrics_info']['mongo_collection']
    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)
    #print(dict_list)
    logger.info('New entry list size for AWS Databricks = {}'.format(len(dict_list)))
    if len(dict_list) > 0:
        collection.insert_many(dict_list)
        exit_handler(OK_CODE)
    else:
        logger.warn('Zero 0 new entries inserted to mongo db for AWS Databricks')
        exit_handler(WARNING_CODE)
