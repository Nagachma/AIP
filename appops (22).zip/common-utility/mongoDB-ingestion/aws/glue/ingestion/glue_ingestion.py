from cProfile import run
import csv
import json
import os
import pandas as pd
import yaml

with open('./ingestion_config.yml') as f:
        config = yaml.safe_load(f)

csvFilePath = config['glue_ingestion']['cloud_watch_csv']
custom = config['glue_ingestion']['custom_csv']
output = config['glue_ingestion']['output_json']

isExist = os.path.exists(output)
if not isExist:
    os.makedirs(output)

df = pd.read_csv(csvFilePath)
header = list(df.columns)

metric_name = list(df.metric_name)
metric_name = [*set(metric_name)]

timestamp = list(df.start_time)
timestamp = [*set(timestamp)]
timestamp.sort()
#timestamp = ['2022-08-11 00:00:00+00:00','2022-08-11 00:05:00+00:00','2022-08-11 00:10:00+00:00']

source = config['source']
for i in timestamp:
    jobs = []
    job_name = []
    with open(csvFilePath) as for_values:
        heading = next(for_values)
        reader_obj = csv.reader(for_values)
        for row in reader_obj:
            if (row[0] == i):
                job_name.append(row[2])
    job_name = [*set(job_name)]
    final_output = {}
    run_id = []
    name = i
    name = name.replace(" ","").replace(":","").replace("-","")
    name = name[:13]
    for j in job_name:
        dict = {}
        run_id = []
        runs = []
        with open(csvFilePath) as for_id:
            heading = next(for_id)
            reader_obj = csv.reader(for_id)
            for row in reader_obj:
                if (row[0] == i and row[2] == j):
                    run_id.append(row[3])
        run_id = [*set(run_id)]
        for id in run_id:
            
            run_dict = {}
            run_dict['job_run_id'] = id
            with open(csvFilePath) as for_values:
                heading = next(for_values)
                reader_obj = csv.reader(for_values)
                for row in reader_obj:
                    if (row[0] == i and row[2] == j and row[3] == id):
                        #run_dict[row[4]] = row[5]
                        value = row[5]
                        try:
                            value = float(value)
                        except ValueError:
                            run_dict[row[4]] = row[5]
                            #bucket_dict[row[3]] = NULL
                            #pass
                        else:
                            run_dict[row[4]] = float(value)
            runs.append(run_dict)   
        dict["jobname"] = j
        dict["runs"] = runs
        #break
        jobs.append(dict)

    final_output["source"] = source
    final_output["ts"] = i[0:16]
    final_output["jobs"] = jobs

    cus_df = pd.read_csv(custom)
    cus_header = list(cus_df.columns)

    length = len(final_output['jobs'])

    for x in range(length):
        for y in final_output['jobs'][x]['runs']:
            with open(custom) as for_custom:
                heading = next(for_custom)
                l_reader_obj = csv.reader(for_custom)
                for l_row in l_reader_obj:
                    if (y['job_run_id'] == l_row[1]):
                        count = 3
                        while (count <= 12):
                            y[cus_header[count]] = l_row[count]
                            count = count+1
        x = x+1


    json_object = json.dumps(final_output, indent=4)
 
    # Writing to sample.json
    with open(output+"glue_"+name+".json", "w") as outfile:
        outfile.write(json_object)
