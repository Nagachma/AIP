from cProfile import run
import csv
from gc import collect
import sys
import os
import pandas as pd
import yaml
from pymongo import MongoClient
from datetime import timezone, datetime
import datetime

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2

def ingest_glue_csvs(config,logger,exit_handler):

    csvFilePath = config['glue_metrics_info']['cloud_watch_csv']
    custom = config['glue_metrics_info']['custom_csv']

    df = pd.read_csv(csvFilePath)
    header = list(df.columns)

    metric_name = list(df.metric_name)
    metric_name = [*set(metric_name)]

    timestamp = list(df.start_time)
    timestamp = [*set(timestamp)]
    timestamp.sort()


    source = config['source']
    mongo_client = config['mongo_url']
    mongo_db = config['mongo_db']
    mongo_collection = config['glue_metrics_info']['mongo_collection']


    dict_list = []

    for i in timestamp:
        time = i
        time = time[0:18]
        time = datetime.datetime.strptime(time,'%Y-%m-%d %H:%M:%S')
        jobs = []
        job_name = []
        with open(csvFilePath) as for_values:
            heading = next(for_values)
            reader_obj = csv.reader(for_values)
            for row in reader_obj:
                if (row[0] == i):
                    job_name.append(row[2])
        job_name = [*set(job_name)]
        final_output = {}
        run_id = []
        name = i
        name = name.replace(" ","").replace(":","").replace("-","")
        name = name[:13]
        for j in job_name:
            dict = {}
            run_id = []
            runs = []
            with open(csvFilePath) as for_id:
                heading = next(for_id)
                reader_obj = csv.reader(for_id)
                for row in reader_obj:
                    if (row[0] == i and row[2] == j):
                        run_id.append(row[3])
            run_id = [*set(run_id)]
            for id in run_id:
                
                run_dict = {}
                run_dict['job_run_id'] = id
                with open(csvFilePath) as for_values:
                    heading = next(for_values)
                    reader_obj = csv.reader(for_values)
                    for row in reader_obj:
                        if (row[0] == i and row[2] == j and row[3] == id):
                            #run_dict[row[4]] = row[5]
                            value = row[5]
                            try:
                                value = float(value)
                            except ValueError:
                                run_dict[row[4]] = row[5]
                                #bucket_dict[row[3]] = NULL
                                #pass
                            else:
                                run_dict[row[4]] = float(value)
                runs.append(run_dict)   
            dict["jobname"] = j
            dict["runs"] = runs
            #break
            jobs.append(dict)

        final_output["source"] = source
        final_output["ts"] = time
        final_output["jobs"] = jobs

        cus_df = pd.read_csv(custom)
        cus_header = list(cus_df.columns)

        length = len(final_output['jobs'])

        for x in range(length):
            for y in final_output['jobs'][x]['runs']:
                with open(custom) as for_custom:
                    heading = next(for_custom)
                    l_reader_obj = csv.reader(for_custom)
                    for l_row in l_reader_obj:
                        if (y['job_run_id'] == l_row[1]):
                            count = 3
                            while (count <= 12):
                                y[cus_header[count]] = l_row[count]
                                count = count+1
            x = x+1

        dict_list.append(final_output)

    client = MongoClient(mongo_client)
    db = client.mongo_db
    collection = db.mongo_collection
    for i in dict_list:
        collection.insert_one(i)