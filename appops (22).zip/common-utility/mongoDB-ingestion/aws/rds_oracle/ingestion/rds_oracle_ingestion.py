# import datetime
import hashlib
import random
import re
from datetime import datetime

import pandas as pd
from pymongo import MongoClient

import csv

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2


def ingest_rds_oracle_csvs(config, logger, exit_handler):
    cw_csv_path = config['rdsoracle_metrics_info']['cw_csv']
    pi_csv_path = config['rdsoracle_metrics_info']['pi_csv']
    activeconn_csv_path = config['rdsoracle_metrics_info']['activeconn_csv']
    exectime_csv_path = config['rdsoracle_metrics_info']['exectime_csv']
    longquery_csv_path = config['rdsoracle_metrics_info']['longquery_csv']
    querycount_csv_path = config['rdsoracle_metrics_info']['querycount_csv']
    querystatus_csv_path = config['rdsoracle_metrics_info']['querystatus_csv']
    tablesize_csv_path = config['rdsoracle_metrics_info']['tablesize_csv']
    totalthreadcount_csv_path = config['rdsoracle_metrics_info']['totalthreadcount_csv']

    df_cw_csv_path = pd.read_csv(cw_csv_path)
    df_pi_csv_path = pd.read_csv(pi_csv_path)
    df_activeconn_csv_path = pd.read_csv(activeconn_csv_path)
    df_exectime_csv_path = pd.read_csv(exectime_csv_path)
    df_longquery_csv_path = pd.read_csv(longquery_csv_path)
    df_querycount_csv_path = pd.read_csv(querycount_csv_path)
    df_querystatus_csv_path = pd.read_csv(querystatus_csv_path)
    df_tablesize_csv = pd.read_csv(tablesize_csv_path)
    df_totalthreadcount_csv = pd.read_csv(totalthreadcount_csv_path)

    timestamp = list(df_cw_csv_path.start_time)
    timestamp.extend(list(df_pi_csv_path.metric_date))
    timestamp.extend(list(df_activeconn_csv_path.metric_date_time))
    timestamp.extend(list(df_exectime_csv_path.metric_date_time))
    timestamp.extend(list(df_longquery_csv_path.metric_date_time))
    timestamp.extend(list(df_querycount_csv_path.metric_date_time))
    timestamp.extend(list(df_querystatus_csv_path.metric_date_time))
    timestamp.extend(list(df_tablesize_csv.metric_date_time))
    timestamp.extend(list(df_totalthreadcount_csv.metric_date_time))
    timestamp = list(map(lambda timestp: timestp[0:16], timestamp))
    timestamp = [*set(timestamp)]
    timestamp.sort()

    instance_name = list(df_cw_csv_path.DBInstanceIdentifier)
    instance_name.extend(list(df_pi_csv_path.instance))
    instance_name.extend(list(df_activeconn_csv_path.dbinstance_name))
    instance_name.extend(list(df_exectime_csv_path.dbinstance_name))
    instance_name.extend(list(df_longquery_csv_path.dbinstance_name))
    instance_name.extend(list(df_querycount_csv_path.dbinstance_name))
    instance_name.extend(list(df_querystatus_csv_path.dbinstance_name))
    instance_name.extend(list(df_tablesize_csv.dbinstance_name))
    instance_name.extend(list(df_totalthreadcount_csv.dbinstance_name))
    instance_name = [*set(instance_name)]
    instance_name.sort()

    sql_id = list(df_activeconn_csv_path.sql_id)
    sql_id.extend(list(df_exectime_csv_path.sql_id))
    sql_id.extend(list(df_longquery_csv_path.sql_id))
    sql_id.extend(list(df_querystatus_csv_path.sql_id))
    sql_id = [*set(sql_id)]
    sql_id = [x for x in sql_id if str(x) != 'nan']
    sql_id.sort()

    dict_list = []
    source = config['source']

    for i in timestamp:
        time = i
        time = datetime.strptime(time, '%Y-%m-%d %H:%M')
        final_output = {}
        list_instances = []

        for j in instance_name:

            instances = {'instance_name': j, 'instance_created_unique_id': hashlib.sha224(
                repr(j + str(random.randint(0, 999999))).encode('utf-8')).hexdigest()}
            with open(cw_csv_path) as for_values:
                heading = next(for_values)
                reader_obj = csv.reader(for_values)
                for row in reader_obj:
                    if row[0][0:16] == i and row[2] == j:
                        instances['start_time'] = row[0]
                        instances['end_time'] = row[1]
                        if (row[4] != ""):
                            instances[row[3]] = row[4]

            with open(pi_csv_path) as pi_csv_file:
                heading2 = next(pi_csv_file)
                reader_obj2 = csv.reader(pi_csv_file)
                for row in reader_obj2:
                    if row[1] == j and row[0][0:16] == i:
                        if (row[3] != ""):
                            instances[row[2]] = row[3]

            schemas = {}
            list_schemas = []
            list_queries = []
            list_table_size = []
            list_querycount = []
            list_querystatus = []
            list_totalthreadcount = []
            for s in sql_id:
                queries = {'sql_id': s}
                activeconn = activeconn_csv_path
                with open(activeconn_csv_path) as activeconn_csv_path:
                    heading3 = next(activeconn_csv_path)
                    csvFile_header = list(df_activeconn_csv_path.columns)
                    reader_obj3 = csv.reader(activeconn_csv_path)
                    activeconn_csv_path = activeconn
                    for row in reader_obj3:
                        if row[len(row)-1] == j and row[0][0:16] == i and row[2] == s:
                            count = 1
                            while (count < (len(row) - 1)):
                                if csvFile_header[count] == 'sql_id':
                                    count = count + 1
                                    continue
                                queries[csvFile_header[count]] = row[count]
                                count = count + 1

                exectime = exectime_csv_path
                with open(exectime_csv_path) as exectime_csv_path:
                    heading4 = next(exectime_csv_path)
                    reader_obj4 = csv.reader(exectime_csv_path)
                    csvFile_header = list(df_exectime_csv_path.columns)
                    exectime_csv_path = exectime
                    for row in reader_obj4:
                        if row[len(row)-1] == j and row[0][0:16] == i and row[3] == s:
                            count = 1
                            while (count < (len(row) - 1)):
                                if csvFile_header[count] == 'sql_id':
                                    count = count + 1
                                    continue
                                queries[csvFile_header[count]] = row[count]
                                count = count + 1

                longquery = longquery_csv_path
                with open(longquery_csv_path) as longquery_csv_path:
                    heading5 = next(longquery_csv_path)
                    reader_obj5 = csv.reader(longquery_csv_path)
                    csvFile_header = list(df_longquery_csv_path.columns)
                    longquery_csv_path = longquery
                    for row in reader_obj5:
                        if row[len(row)-1] == j and row[0][0:16] == i and row[2] == s:
                            count = 1
                            while (count < (len(row) - 1)):
                                if csvFile_header[count] == 'sql_id':
                                    count = count + 1
                                    continue
                                queries[csvFile_header[count]] = row[count]
                                count = count + 1

                querystatus = querystatus_csv_path
                with open(querystatus_csv_path) as querystatus_csv_path:
                    heading5 = next(querystatus_csv_path)
                    reader_obj5 = csv.reader(querystatus_csv_path)
                    csvFile_header = list(df_querystatus_csv_path.columns)
                    querystatus_csv_path = querystatus
                    for row in reader_obj5:
                        if row[len(row) - 1] == j and row[0][0:16] == i and row[3] == s:
                            count = 1
                            while (count < (len(row) - 1)):
                                if csvFile_header[count] == 'sql_id':
                                    count = count + 1
                                    continue
                                queries[csvFile_header[count]] = row[count]
                                count = count + 1

                if queries is not None and len(queries) > 1:
                    list_queries.append(queries)
            if list_queries is not None and len(list_queries) > 0:
                schemas["queries"] = list_queries

            table_size = {}
            tablesize = tablesize_csv_path
            with open(tablesize_csv_path) as tablesize_csv_path:
                heading6 = next(tablesize_csv_path)
                csvFile_header = list(df_tablesize_csv.columns)
                reader_obj6 = csv.reader(tablesize_csv_path)
                tablesize_csv_path = tablesize
                for row in reader_obj6:
                    if row[len(row) - 1] == j and row[0][0:16] == i:
                        count = 1
                        while (count < (len(row) - 1)):
                            table_size[csvFile_header[count]] = row[count]
                            count = count + 1
            if table_size is not None and len(table_size) > 0:
                list_table_size.append(table_size)
            if list_table_size is not None and len(list_table_size) > 0:
                schemas["table_size"] = list_table_size

            querycount = {}
            querycnt = querycount_csv_path
            with open(querycount_csv_path) as querycount_csv_path:
                heading7 = next(querycount_csv_path)
                csvFile_header = list(df_querycount_csv_path.columns)
                reader_obj7 = csv.reader(querycount_csv_path)
                querycount_csv_path = querycnt
                for row in reader_obj7:
                    if row[len(row) - 1] == j and row[0][0:16] == i:
                        count = 1
                        while (count < (len(row) - 1)):
                            querycount[csvFile_header[count]] = row[count]
                            count = count + 1
            if querycount is not None and len(querycount) > 0:
                list_querycount.append(querycount)
            if list_querycount is not None and len(list_querycount) > 0:
                schemas["querycount"] = list_querycount

            totalthreadcount = {}
            totalthreadcnt = totalthreadcount_csv_path
            with open(totalthreadcount_csv_path) as totalthreadcount_csv_path:
                heading8 = next(totalthreadcount_csv_path)
                csvFile_header = list(df_totalthreadcount_csv.columns)
                reader_obj8 = csv.reader(totalthreadcount_csv_path)
                totalthreadcount_csv_path = totalthreadcnt
                for row in reader_obj8:
                    if row[len(row) - 1] == j and row[0][0:16] == i:
                        count = 1
                        while (count < (len(row) - 1)):
                            totalthreadcount[csvFile_header[count]] = row[count]
                            count = count + 1
            if totalthreadcount is not None and len(totalthreadcount) > 0:
                list_totalthreadcount.append(totalthreadcount)
            if list_totalthreadcount is not None and len(list_totalthreadcount) > 0:
                schemas["totalthreadcount"] = list_totalthreadcount

            if schemas is not None and len(schemas) > 0:
                list_schemas.append(schemas)
            if list_schemas is not None and len(list_schemas) > 0:
                instances["schemas"] = list_schemas

            if instances is not None and len(instances) > 0:
                list_instances.append(instances)

        final_output["source"] = source
        final_output["ts"] = time
        final_output["instances"] = list_instances

        dict_list.append(final_output)


    mongo_client = config['mongo_url']
    mongo_db = config['mongo_db']
    mongo_collection = config['rdsoracle_metrics_info']['mongo_collection']

    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)
    # Bulk insert all dictionaries to MongoDB
    # print(final_output)
    logger.info('New entry list size for RDS Oracle = {}'.format(len(dict_list)))
    if len(dict_list) > 0:
        collection.insert_many(dict_list)
        exit_handler(OK_CODE)
    else:
        logger.warn('Zero 0 new entries inserted to mongo db for RDS Oracle')
        exit_handler(WARNING_CODE)






