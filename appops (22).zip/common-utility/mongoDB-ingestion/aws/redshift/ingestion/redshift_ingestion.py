from cProfile import run
import csv
import json
import pandas as pd
import os
import yaml
from pymongo import MongoClient
from datetime import datetime
import hashlib
import random

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2

def ingest_redshift_csvs(config,logger,exit_handler):

    cw_csvFilePath = config['redshift_metrics_info']['cloud_watch_csv']
    custom_csv_Files = config['redshift_metrics_info']['db_metrics_csv']

    df1 = pd.read_csv(cw_csvFilePath)

    unique_clusters=[]
    unique_timestamps=[]
    unique_databases=[]
    unique_query_ids=[]

    for csvs in custom_csv_Files:
        df_csvFile = pd.read_csv(csvs)
        timestamp = list(df_csvFile.metric_date)
        timestamp = list(map(lambda timestp: timestp[0:16], timestamp))
        headers = list(df_csvFile.columns)
        if("cluster_id" in headers):
            clusters=list(df_csvFile.cluster_id)
            clusters = list(map(lambda c: str(c), clusters))
            unique_clusters.extend(clusters)
        if("query_id" in headers):
            query_ids=list(df_csvFile.query_id)
            unique_query_ids.extend(query_ids)
        if("db_name" in headers):
            db_names=list(df_csvFile.db_name)
            unique_databases.extend(db_names)
        unique_timestamps.extend(timestamp)
    
    # Unique clusters
    cluster_name = list(df1.ClusterIdentifier)
    unique_clusters.extend(cluster_name)
    unique_clusters = [*set(unique_clusters)]

    # Unique databases
    unique_databases = [*set(unique_databases)]

    # Unique Query Id
    unique_query_ids = [*set(unique_query_ids)]
    unique_query_ids.sort()

    # Unique Timestamp
    timestamp = list(df1.start_time)
    timestamp = list(map(lambda timestp: timestp[0:16], timestamp))
    unique_timestamps.extend(timestamp)
    unique_timestamps = [*set(unique_timestamps)]
    unique_timestamps.sort()

    source = config['source']
    dict_list = []

    for i in unique_timestamps:
        time = i
        time = datetime.strptime(time, '%Y-%m-%d %H:%M')
        final_output = {}
        clusters = []


        for j in unique_clusters:
            databases_dict=[]
            cluster_headers = list(df1.columns)
            cluster = {'cluster_name': j,'cluster_unique_id': hashlib.sha224(repr(j+str(random.randint(0,999999))).encode('utf-8')).hexdigest()}
            with open(cw_csvFilePath) as for_values:
                heading = next(for_values)
                reader_obj = csv.reader(for_values)
                for row in reader_obj:
                    if row[cluster_headers.index("start_time")][0:16] == i and row[cluster_headers.index("ClusterIdentifier")] == j:
                        cluster['start_time'] = row[cluster_headers.index("start_time")]
                        metric_name = row[cluster_headers.index("metric_name")]
                        value = row[cluster_headers.index("metric_value")]
                        if value is None or value == '':
                            pass
                        elif value is not None or value != '' and metric_name=='HealthStatus':
                            if int(float(value)) == 1:
                                cluster[metric_name] = 0
                            elif int(float(value)) == 0:
                                cluster[metric_name] = 1
                        else:
                            try:
                                value = float(value)
                            except ValueError as ve:
                                # non-float value
                                cluster[metric_name] = row[cluster_headers.index("metric_value")]
                            else:
                                # float value if no exception
                                cluster[metric_name] = float(value)
            for d in unique_databases:
                database_dict={}
                database_dict["database_name"]=d
                # queries=[]
                for q in unique_query_ids:
                    query={}
                    query["query_id"]=q
                    for csvs in custom_csv_Files:
                        df_csvFile = pd.read_csv(csvs)
                        headers = list(df_csvFile.columns)
                        with open(csvs) as custom_csv_file:
                            heading = next(custom_csv_file).strip()
                            reader_obj = csv.reader(custom_csv_file)
                            for row in reader_obj:
                                if row[headers.index("cluster_id")] == j and row[headers.index("metric_date")][0:16] == i:
                                    if row[headers.index("query_id")]==str(q) and row[headers.index("db_name")]==d:
                                        col=3
                                        value=row[col]
                                        for metric_name in headers[3:-1]:
                                            value=row[col]
                                            if value is None or value == '':
                                                pass
                                            else:
                                                try:
                                                    value = float(value)
                                                except ValueError as ve:
                                                    # non-float value
                                                    query[metric_name]=row[col]
                                                else:
                                                    # float value if no exception
                                                    query[metric_name] = float(value)
                                            col=col+1
                                            y=0
                                            isempty=True
                                            if "queries" not in database_dict:
                                                isempty=True
                                                database_dict["queries"]=[]
                                            else:
                                                isempty=False
                                                database_dict["queries"]
                                            if(isempty==False):
                                                temp=database_dict["queries"]
                                                for x in range(len(database_dict["queries"])):
                                                    if list(temp[x].keys())[0] == list(query.keys())[0] and list(temp[x].values())[0] == list(query.values())[0]:
                                                        dict_old = temp[x].copy()
                                                        temp.pop(x)
                                                        query = {**dict_old, **query}
                                                        temp.append(query)
                                                        database_dict["queries"]=temp
                                                        y = 1
                                                        break
                                            if(y==0):
                                                database_dict["queries"].append(query)
                        
                if(len(database_dict)>1):
                    databases_dict.append(database_dict)
            if(len(databases_dict)>0):
                cluster["databases"] = databases_dict
            
            clusters.append(cluster)

        final_output["source"] = source
        final_output['ts'] = time
        final_output['clusters'] = clusters

        dict_list.append(final_output)

    # Bulk insert all dictionaries to MongoDB
    mongo_client = config['mongo_url']
    mongo_db = config['mongo_db']
    mongo_collection = config['redshift_metrics_info']['mongo_collection'] 
    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)
    logger.info('New entry list size for Redshift = {}'.format(len(dict_list)))  
    if len(dict_list) > 0:
        collection.insert_many(dict_list)
        exit_handler(OK_CODE)
    else:
        logger.warn('Zero 0 new entries inserted to mongo db for Redshift')
        exit_handler(WARNING_CODE)

