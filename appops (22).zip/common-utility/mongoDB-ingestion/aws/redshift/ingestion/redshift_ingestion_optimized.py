from cProfile import run
import csv
import json
import pandas as pd
import os
import yaml
from pymongo import MongoClient
from datetime import datetime
import hashlib
import random
import numpy as np
from multiprocessing.pool import ThreadPool as Pool

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2


def multithreading_clusters(timestamp_filtered_cw_df, timestamp_filtered_custom_df, clusters, j, unique_databases, unique_query_ids):
    # Filtering the dataframes on basis of Cluster Name
    cluster_filtered_cw_df = timestamp_filtered_cw_df.loc[timestamp_filtered_cw_df['ClusterIdentifier'] == j]
    cluster_filtered_cw_df.replace(np.nan, 'None', inplace=True)

    cluster_filtered_custom_df = timestamp_filtered_custom_df.loc[
        timestamp_filtered_custom_df['cluster_id'] == j]
    cluster_filtered_custom_df = cluster_filtered_custom_df.drop(['cluster_id'], axis=1)

    # Initialize database list
    databases_dict = []
    cluster = {'cluster_name': j, 'cluster_unique_id': hashlib.sha3_256(
        repr(j + str(random.randint(0, 999999))).encode('utf-8')).hexdigest()}
    for index, row in cluster_filtered_cw_df.iterrows():
        metric_name = row['metric_name']
        value = row['metric_value']
        if value is None or value == '' or value == 'None':
            pass
        elif value is not None or value != '' and metric_name=='HealthStatus':
            if int(float(value)) == 1:
                cluster[metric_name] = 0
            elif int(float(value)) == 0:
                cluster[metric_name] = 1
        else:
            try:
                value = float(value)
            except ValueError as ve:
                # non-float value
                cluster[metric_name] = row["metric_value"]
            else:
                # float value if no exception
                cluster[metric_name] = float(value)

    for d in unique_databases:
        # Filtering custom dataframes on basis of database Name
        database_filter_custom_df = cluster_filtered_custom_df.loc[cluster_filtered_custom_df['db_name'] == d]
        database_filter_custom_df = database_filter_custom_df.drop(['db_name'], axis=1)
        database_dict = {}
        database_dict["database_name"] = d
        queries = []
        for q in unique_query_ids:
            # Filtering custom dataframes on basis of query_id
            query_filter_custom_df = database_filter_custom_df.loc[database_filter_custom_df['query_id'] == q]
            query_filter_custom_df.replace(np.nan, 'None', inplace=True)
            query = {}
            temp = query_filter_custom_df
            query = query_filter_custom_df.to_dict(orient='records')
            if len(query) > 0:
                query_dict = query[0]
                query_dict = {key: value for key, value in query_dict.items() if value != 'None'}
                queries.append(query_dict)

        if (len(queries) > 0):
            database_dict["queries"] = queries

        if (len(database_dict) > 1):
            databases_dict.append(database_dict)
    if (len(databases_dict) > 0):
        cluster["databases"] = databases_dict

    clusters.append(cluster)


def ingest_redshift_csvs(config, logger, exit_handler):
    t1 = datetime.now()

    cw_csvFilePath = config['redshift_metrics_info']['cloud_watch_csv']
    error_csvFilePath = config['redshift_metrics_info']['QueryErrorDetails_csv']
    time_consuming_csvFilePath = config['redshift_metrics_info']['TopTimeConsumingQueries_csv']
    wlm_query_csvFilePath = config['redshift_metrics_info']['WLMQueryExecutionTime_csv']

    df1 = pd.read_csv(cw_csvFilePath)

    # Reading CSVS
    cw_df = pd.read_csv(cw_csvFilePath)
    error_df = pd.read_csv(error_csvFilePath)
    time_consume_df = pd.read_csv(time_consuming_csvFilePath)
    wlm_df = pd.read_csv(wlm_query_csvFilePath)

    # Formatting timestamp column to %Y-%m-%d %H:%M format
    cw_df["start_time"] = pd.to_datetime(cw_df["start_time"]).dt.strftime('%Y-%m-%d %H:%M')
    error_df["metric_date"] = pd.to_datetime(error_df["metric_date"]).dt.strftime('%Y-%m-%d %H:%M')
    time_consume_df["metric_date"] = pd.to_datetime(time_consume_df["metric_date"]).dt.strftime('%Y-%m-%d %H:%M')
    wlm_df["metric_date"] = pd.to_datetime(wlm_df["metric_date"]).dt.strftime('%Y-%m-%d %H:%M')

    # Merging CSVS
    merge_1 = pd.merge(time_consume_df, wlm_df,
                       left_on=['metric_date', 'db_name', 'query_id', 'cluster_id', 'user_name'],
                       right_on=['metric_date', 'db_name', 'query_id', 'cluster_id', 'user_name'], how='outer')
    merged_2 = pd.merge(merge_1, error_df, left_on=['metric_date', 'db_name', 'query_id', 'cluster_id'],
                        right_on=['metric_date', 'db_name', 'query_id', 'cluster_id'], how='outer')
    merged_2.replace(np.nan, 'None', inplace=True)

    unique_clusters = []
    unique_timestamps = []
    unique_databases = []
    unique_query_ids = []

    # Unique clusters
    clusters = list(cw_df.ClusterIdentifier) + list(time_consume_df.cluster_id) + list(wlm_df.cluster_id) + list(
        error_df.cluster_id)
    clusters = list(map(lambda c: str(c), clusters))
    unique_clusters = [*set(clusters)]

    # Unique databases
    databases = list(time_consume_df.db_name) + list(wlm_df.db_name) + list(error_df.db_name)
    unique_databases = [*set(databases)]

    # Unique Query Id
    query_ids = list(time_consume_df.query_id) + list(wlm_df.query_id) + list(error_df.query_id)
    unique_query_ids = [*set(query_ids)]

    # Unique Timestamp
    timestamp = list(cw_df.start_time) + list(time_consume_df.metric_date) + list(wlm_df.metric_date) + list(
        error_df.metric_date)
    unique_timestamps = [*set(timestamp)]

    source = config['source']
    dict_list = []

    for i in unique_timestamps:
        # Filtering the dataframes on basis of timestamp
        timestamp_filtered_cw_df = cw_df.loc[cw_df['start_time'] == i]

        timestamp_filtered_custom_df = merged_2.loc[merged_2['metric_date'] == i]
        timestamp_filtered_custom_df = timestamp_filtered_custom_df.drop(['metric_date'], axis=1)

        time = i
        final_output = {}
        clusters = []

        # parallely processing multiple clusters using Pool
        with Pool(processes=len(unique_clusters)) as pool:
            args = [(timestamp_filtered_cw_df, timestamp_filtered_custom_df, clusters, j, unique_databases, unique_query_ids) for j in unique_clusters]
            pool.starmap(multithreading_clusters, args)
            pool.close()
            pool.join()

        final_output["source"] = source
        final_output['ts'] = datetime.strptime(time, '%Y-%m-%d %H:%M')
        final_output['clusters'] = clusters

        dict_list.append(final_output)

    # Bulk insert all dictionaries to MongoDB
    mongo_client = config['mongo_url']
    mongo_db = config['mongo_db']
    mongo_collection = config['redshift_metrics_info']['mongo_collection']
    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)
    logger.info('New entry list size for Redshift = {}'.format(len(dict_list)))
    if len(dict_list) > 0:
        collection.insert_many(dict_list)
        exit_handler(OK_CODE)
    else:
        logger.warn('Zero 0 new entries inserted to mongo db for Redshift')
        exit_handler(WARNING_CODE)
