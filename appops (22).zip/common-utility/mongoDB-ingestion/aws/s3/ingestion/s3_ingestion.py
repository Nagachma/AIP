from cProfile import run
import csv
import json
import pandas as pd
import os
import yaml
from pymongo import MongoClient
from datetime import datetime

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2

def ingest_s3_csvs(config,logger,exit_handler):

    csvFilePath = config['s3_metrics_info']['cloud_watch_csv']
    customCsvFilePath = config['s3_metrics_info']['custom_csv']

    df = pd.read_csv(csvFilePath)
    header = list(df.columns)

    df2 = pd.read_csv(customCsvFilePath)
    header2 = list(df2.columns)

    bucket_name = list(df.BucketName)
    bucket_name2 = list(df2.bucketName)
    bucket_name2 = [*set(bucket_name2)]

    bucket_name.extend(bucket_name2)
    bucket_name = [*set(bucket_name)]

    metric_name = list(df.metric_name)
    metric_name = [*set(metric_name)]

    timestamp = list(df.start_time)
    timestamp = [*set(timestamp)]
    timestamp = list(map(lambda timestp: timestp[0:16], timestamp))

    timestamp2 = list(df2.metric_date)
    timestamp2 = [*set(timestamp2)]
    timestamp2 = list(map(lambda timestp: timestp[0:16], timestamp2))


    timestamp.extend(timestamp2)
    timestamp = [*set(timestamp)]
    timestamp.sort()

    source = config['source']
    mongo_client = config['mongo_url']
    mongo_db = config['mongo_db']
    mongo_collection = config['s3_metrics_info']['mongo_collection']

    dict_list = []

    for i in timestamp:
        time = i
        time = datetime.strptime(time, '%Y-%m-%d %H:%M')
        final_output = {}
        buckets = []
        # name = i
        # name = name.replace(" ", "").replace(":", "").replace("-", "")
        # name = name[:13]

        for j in bucket_name:

            bucket_dict = {'bucket_name': j}
            with open(csvFilePath) as for_values:
                heading = next(for_values)
                reader_obj = csv.reader(for_values)
                for row in reader_obj:
                    if row[0][0:16] == i and row[2] == j:
                        bucket_dict['start_time'] = row[0]
                        bucket_dict['end_time'] = row[1]
                        value = row[4]
                        try:
                            value = float(value)
                        except ValueError as ve:
                            # bucket_dict[row[3]] = row[4]
                            # bucket_dict[row[3]] = NULL
                            pass
                        else:
                            bucket_dict[row[3]] = float(value)

            with open(customCsvFilePath) as custom_csv_file:
                heading2 = next(custom_csv_file)
                reader_obj2 = csv.reader(custom_csv_file)
                for row in reader_obj2:
                    bucket_event = {}
                    if row[10] == j and row[0][0:16] == i:
                        if 'Events' not in bucket_dict:
                            bucket_dict['Events'] = []
                        else:
                            bucket_dict['Events']

                        bucket_event['eventID'] = row[4]
                        bucket_event['eventTime'] = row[1]
                        bucket_event['eventSource'] = row[2]
                        bucket_event['eventName'] = row[3]
                        bucket_event['eventType'] = row[5]
                        bucket_event['awsRegion'] = row[6]
                        bucket_event['sourceIPAddress'] = row[7]
                        bucket_event['errorCode'] = row[8]
                        bucket_event['errorMessage'] = row[9]
                        bucket_event['bucketName'] = row[10]
                        bucket_event['key'] = row[11]
                        bucket_event['requestID'] = row[12]

                        bucket_dict['Events'].append(bucket_event)

            if len(bucket_dict) > 1:
                buckets.append(bucket_dict)

        final_output["source"] = source
        final_output['ts'] = time
        final_output['buckets'] = buckets

        dict_list.append(final_output)

    # Bulk insert all dictionaries to MongoDB
    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)
    collection.insert_many(dict_list)

