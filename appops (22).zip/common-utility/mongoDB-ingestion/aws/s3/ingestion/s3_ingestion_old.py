from cProfile import run
import csv
import json
import pandas as pd
import os
import yaml
from pymongo import MongoClient
from datetime import datetime

with open('./ingestion_config.yml') as f:
        config = yaml.safe_load(f)

csvFilePath = config['s3_ingestion']['cloud_watch_csv']
output = config['s3_ingestion']['output_json']

isExist = os.path.exists(output)
if not isExist:
    os.makedirs(output)

df = pd.read_csv(csvFilePath)
header = list(df.columns)

bucket_name = list(df.BucketName)
bucket_name = [*set(bucket_name)]


metric_name = list(df.metric_name)
metric_name = [*set(metric_name)]

timestamp = list(df.start_time)
timestamp = [*set(timestamp)]
timestamp.sort()


source = config['source']
for i in timestamp:
    time = i[0:18]
    time = datetime.strptime(time,'%Y-%m-%d %H:%M:%S')
    final_output = {}
    buckets = []
    name = i
    name = name.replace(" ","").replace(":","").replace("-","")
    name = name[:13]
    for j in bucket_name:
        bucket_dict = {}
        bucket_dict['bucket_name'] = j
        with open(csvFilePath) as for_values:
                heading = next(for_values)
                reader_obj = csv.reader(for_values)
                for row in reader_obj:
                    if (row[0] == i and row[2] == j):
                        bucket_dict['start_time'] = row[0]
                        bucket_dict['end_time'] = row[1]
                        value = row[4]
                        try:
                            value = float(value)
                        except ValueError:
                            #bucket_dict[row[3]] = row[4]
                            #bucket_dict[row[3]] = NULL
                            pass
                        else:
                            bucket_dict[row[3]] = float(value)
        if len(bucket_dict) > 1 :
            buckets.append(bucket_dict)
    
    final_output["source"] = source
    final_output['ts'] = time
    final_output['buckets'] = buckets

    #json_object = json.dumps(final_output, indent=4)

    client = MongoClient("mongodb://admin:admin@10.253.164.68:27017/?authMechanism=DEFAULT&tls=false")
    db = client.appops_dev
    collection = db.s3

    collection.insert_one(final_output)

    # Writing to sample.json
    # with open(output+"s3_"+name+".json", "w") as outfile:
    #     outfile.write(json_object)