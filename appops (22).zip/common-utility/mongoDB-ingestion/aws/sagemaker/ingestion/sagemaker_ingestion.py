from cProfile import run
import csv
import json
import os
import pandas as pd
import yaml

with open('./ingestion_config.yml') as f:
        config = yaml.safe_load(f)

processing_jobs = config['sagemaker_ingestion']['processing_jobs_csv']
training_jobs = config['sagemaker_ingestion']['training_jobs_csv']
transform_jobs = config['sagemaker_ingestion']['transform_jobs_csv']
endpoint = config['sagemaker_ingestion']['endpoint_csv']
ground_truth = config['sagemaker_ingestion']['ground_truth_csv']
pipeline = config['sagemaker_ingestion']['pipeline_csv']
workteam = config['sagemaker_ingestion']['workteam_csv']
output = config['sagemaker_ingestion']['output_csv']

isExist = os.path.exists(output)
if not isExist:
    os.makedirs(output)

df_processing_jobs = pd.read_csv(processing_jobs)

timestamp = list(df_processing_jobs.start_time)
timestamp = [*set(timestamp)]
timestamp.sort()
#timestamp = ['2022-08-11 00:00:00+00:00','2022-08-11 00:05:00+00:00','2022-08-11 00:10:00+00:00']

source = config['source']
for i in timestamp:
    final_output = {}
    name = i
    name = name.replace(" ", "").replace(":", "").replace("-", "")
    name = name[:13]

    jobs = []

    # processing_jobs_metrics
    host = []
    with open(processing_jobs) as for_values:
        heading = next(for_values)
        reader_obj = csv.reader(for_values)
        for row in reader_obj:
            if (row[0] == i):
                host.append(row[2])
    host = [*set(host)]

    for j in host:
        dict = {}
        dict["Host"] = j
        with open(processing_jobs) as for_host:
            heading = next(for_host)
            reader_obj = csv.reader(for_host)
            for row in reader_obj:
                if (row[0] == i and row[2] == j):
                    if row[4] != "":
                        metric_name = "ProcessingJobs." + row[3]
                        dict[metric_name] = row[4]

        jobs.append(dict)

    # training_jobs_metrics
    host = []
    with open(training_jobs) as for_values:
        heading = next(for_values)
        reader_obj = csv.reader(for_values)
        for row in reader_obj:
            if (row[0] == i):
                host.append(row[2])
    host = [*set(host)]

    for j in host:
        dict = {}
        dict["Host"] = j
        with open(training_jobs) as for_host:
            heading = next(for_host)
            reader_obj = csv.reader(for_host)
            for row in reader_obj:
                if (row[0] == i and row[2] == j):
                    if row[4] != "":
                        metric_name = "TrainingJobs." + row[3]
                        dict[metric_name] = row[4]

        jobs.append(dict)

    # transform_jobs_metrics
    host = []
    with open(transform_jobs) as for_values:
        heading = next(for_values)
        reader_obj = csv.reader(for_values)
        for row in reader_obj:
            if (row[0] == i):
                host.append(row[2])
    host = [*set(host)]

    for j in host:
        dict = {}
        dict["Host"] = j
        with open(transform_jobs) as for_host:
            heading = next(for_host)
            reader_obj = csv.reader(for_host)
            for row in reader_obj:
                if (row[0] == i and row[2] == j):
                    if row[4] !="":
                        metric_name = "TransformJobs." + row[3]
                        dict[metric_name] = row[4]

        jobs.append(dict)

    # endpoint_metrics
    endpoints = []
    endpointName = []
    with open(endpoint) as for_values:
        heading = next(for_values)
        reader_obj = csv.reader(for_values)
        for row in reader_obj:
            if (row[0] == i):
                endpointName.append(row[2])
    endpointName = [*set(endpointName)]

    for j in endpointName:
        dict = {}
        dict["EndpointName"] = j
        with open(endpoint) as for_endpoint_name:
            heading = next(for_endpoint_name)
            reader_obj = csv.reader(for_endpoint_name)
            for row in reader_obj:
                if (row[0] == i and row[2] == j):
                    if row[4] != "":
                        metric_name = "Endpoint." + row[3]
                        dict[metric_name] = row[4]

        endpoints.append(dict)

    # Ground_Truth_metrics
    groundTruths = []
    labelingJobName = []
    with open(ground_truth) as for_values:
        heading = next(for_values)
        reader_obj = csv.reader(for_values)
        for row in reader_obj:
            if (row[0] == i):
                labelingJobName.append(row[2])
    labelingJobName = [*set(labelingJobName)]

    for j in labelingJobName:
        dict = {}
        dict["LabelingJobName"] = j
        with open(ground_truth) as for_ground_truth:
            heading = next(for_ground_truth)
            reader_obj = csv.reader(for_ground_truth)
            for row in reader_obj:
                if (row[0] == i and row[2] == j):
                    if row[4] != "":
                        metric_name = "Groundtruth." + row[3]
                        dict[metric_name] = row[4]

        groundTruths.append(dict)

    # Pipeline_metrics
    pipelines = []
    pipelineName = []
    with open(pipeline) as for_values:
        heading = next(for_values)
        reader_obj = csv.reader(for_values)
        for row in reader_obj:
            if (row[0] == i):
                pipelineName.append(row[2])
    pipelineName = [*set(pipelineName)]

    for j in pipelineName:
        dict = {}
        dict["PipelineName"] = j
        with open(pipeline) as for_pipeline:
            heading = next(for_pipeline)
            reader_obj = csv.reader(for_pipeline)
            for row in reader_obj:
                if (row[0] == i and row[2] == j):
                    if row[4] != "":
                        metric_name = "Pipeline." + row[3]
                        dict[metric_name] = row[4]

        pipelines.append(dict)

    # Workteam_metrics
    workteams = []
    labelingJob = []
    with open(workteam) as for_values:
        heading = next(for_values)
        reader_obj = csv.reader(for_values)
        for row in reader_obj:
            if (row[0] == i):
                labelingJob.append(row[2])
    labelingJob = [*set(labelingJob)]

    for j in labelingJob:
        dict = {}
        dict["LabelingJob"] = j
        with open(workteam) as for_workteam:
            heading = next(for_workteam)
            reader_obj = csv.reader(for_workteam)
            for row in reader_obj:
                if (row[0] == i and row[2] == j):
                    if row[4] != "":
                        metric_name = "Workteam." + row[3]
                        dict[metric_name] = row[4]

        workteams.append(dict)

    final_output["source"] = source
    final_output["ts"] = i[0:16]
    final_output["jobs"] = jobs
    final_output["endpoints"] = endpoints
    final_output["GroundTruth"] = groundTruths
    final_output["Pipeline"] = pipelines
    final_output["Workteam"] = workteams

    json_object = json.dumps(final_output, indent=4)
 
    # Writing to sample.json
    with open(output+"sagemaker_"+name+".json", "w") as outfile:
        outfile.write(json_object)
