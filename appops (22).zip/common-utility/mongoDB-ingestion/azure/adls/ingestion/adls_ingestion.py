import os.path
from datetime import datetime

import pandas as pd
from pymongo import MongoClient

import csv

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2

logger = []
exit_handler = []

def is_csv_blank(file_path):
    with open(file_path, 'r') as file:
        first_line = file.readline().strip()
        return not bool(first_line)
def ingest_adls_csvs(config, logger, exit_handler):
    adls1csvFilePath = config['adls_metrics_info']['adls1_csv']
    adls2csvFilePath = config['adls_metrics_info']['adls2_csv']
    adls1_log_csv_file_path = config['adls_metrics_info']['adls1_log_analytics_csv']
    adls2_log_csv_file_path = config['adls_metrics_info']['adls2_log_analytics_csv']

    # Get names of the accounts and metric names, removing duplicates.
    adls1_account_name = []
    adls2_account_name = []
    timestamp1 = []
    timestamp2 = []
    # reading azure monitor csv
    if(os.path.exists(adls1csvFilePath) and not is_csv_blank(adls1csvFilePath)):
        df = pd.read_csv(adls1csvFilePath)
        header = list(df.columns)
        if 'gen1_adlsname' in df.columns:
            adls1_account_name = list(df.gen1_adlsname)
            adls1_account_name = [*set(adls1_account_name)]
        if 'start_time' in df.columns:
            timestamp1 = list(df.start_time)
            timestamp1 = [*set(timestamp1)]
            timestamp1 = list(map(lambda timestp: timestp[0:16], timestamp1))  # Remove seconds and timezone.
    if (os.path.exists(adls2csvFilePath)):
        df2 = pd.read_csv(adls2csvFilePath)
        header2 = list(df2.columns)
        if 'gen2_adlsname' in df2.columns:
            adls2_account_name = list(df2.gen2_adlsname)
            adls2_account_name = [*set(adls2_account_name)]
        if 'start_time' in df2.columns:
            timestamp2 = list(df2.start_time)
            timestamp2 = [*set(timestamp2)]
            timestamp2 = list(map(lambda timestp: timestp[0:16], timestamp2))




    # reading log analytics csv
    if (os.path.exists(adls1_log_csv_file_path)):
        df_log_gen1 = pd.read_csv(adls1_log_csv_file_path)
        header_ = list(df_log_gen1.columns)
        # Get names of the accounts
        gen1_account_names = list(df_log_gen1.AccountName)
        gen1_account_names = [*set(gen1_account_names)]
        gen1_account_names = list(map(lambda actname: actname.casefold(), gen1_account_names))

        timestamp_log_gen1 = list(df_log_gen1.StartTime)
        timestamp_log_gen1 = [*set(timestamp_log_gen1)]
        # merging names of the accounts
        adls1_account_name.extend(gen1_account_names)
        adls1_account_name = [*set(adls1_account_name)]
        timestamp_log_gen1 = list(map(lambda timestp: timestp[0:16], timestamp_log_gen1))

    if (os.path.exists(adls2_log_csv_file_path)):
        # Gen2 adls log csv
        df_log_gen2 = pd.read_csv(adls2_log_csv_file_path)
        header_gen2 = list(df_log_gen2.columns)
        # Get names of the accounts
        gen2_account_names = list(df_log_gen2.AccountName)
        gen2_account_names = [*set(gen2_account_names)]
        # merging names of the accounts
        adls2_account_name.extend(gen2_account_names)
        adls2_account_name = [*set(adls2_account_name)]

        timestamp_log_gen2 = list(df_log_gen2.StartTime)
        timestamp_log_gen2 = [*set(timestamp_log_gen2)]
        timestamp_log_gen2 = list(map(lambda timestp: timestp[0:16], timestamp_log_gen2))





    timestamp1.extend(timestamp2)
    timestamp1.extend(timestamp_log_gen1)
    timestamp1.extend(timestamp_log_gen2)
    timestamp = [*set(timestamp1)]
    timestamp.sort()

    source = config['azure_source']

    mongo_client = config['mongo_url']
    mongo_db = config['mongo_db']
    mongo_collection = config['adls_metrics_info']['mongo_collection']

    dict_list = []
    for i in timestamp:
        adls1_metrics = []
        adls2_metrics = []
        final_output = {}

        time = i
        # time = datetime.strptime(time, '%Y-%m-%d %H:%M')
        time = datetime.strptime(time, '%Y-%m-%d %H:%M')
        final_output['source'] = source
        final_output['ts'] = time

        for m in adls1_account_name:
            failure = False
            events1 = []
            dict1 = {'account_name': m}
            dict1["timestamp"] = i
            with open(adls1csvFilePath) as adls1values:
                heading = next(adls1values)
                reader_obj = csv.reader(adls1values)
                for row1 in reader_obj:
                    # If timestamp and account name match, add start time, end time, and value to account dict.
                    if row1[0][0:16] == i and row1[2] == m:
                        dict1['start_time'] = row1[0]
                        dict1['end_time'] = row1[1]
                        value = row1[4]
                        try:
                            value = float(value)
                        except ValueError as ve:
                            # bucket_dict[row[3]] = row[4]
                            # bucket_dict[row[3]] = NULL
                            pass
                        else:
                            dict1[row1[3]] = value
            with open(adls1_log_csv_file_path) as adls1errors:
                headers1 = next(adls1errors)
                reader_obj_log = csv.reader(adls1errors)
                if reader_obj_log is not None:
                    for row_log1 in reader_obj_log:
                        if row_log1 is not None and row_log1[0][0:16] == i and row_log1[5] == m:
                            failure = True
                            event1 = {}
                            event1['event_time'] = row_log1[2]
                            event1['UID'] = row_log1[3]
                            event1['OperationName'] = row_log1[6]
                            event1['StatusCode'] = row_log1[7]
                            events1.append(event1)

            if len(events1) > 0:
                dict1['hasFailure'] = failure
                dict1['error_events'] = events1
            else:
                dict1['hasFailure'] = failure

            if len(dict1) > 1:
                adls1_metrics.append(dict1)

        for m in adls2_account_name:
            failure2 = False
            events2 = []
            dict2 = {'account_name': m}
            dict2["timestamp"] = i

            with open(adls2csvFilePath) as adls2values:
                heading = next(adls2values)
                reader_obj = csv.reader(adls2values)
                for row2 in reader_obj:
                    # If timestamp and account name match, add start time, end time, and value to account dict.
                    if row2[0][0:16] == i and row2[2] == m:
                        dict2['start_time'] = row2[0]
                        dict2['end_time'] = row2[1]
                        value = row2[4]
                        try:
                            value = float(value)
                        except ValueError as ve:
                            # bucket_dict[row[3]] = row[4]
                            # bucket_dict[row[3]] = NULL
                            pass
                        else:
                            dict2[row2[3]] = value
            with open(adls2_log_csv_file_path) as adls2errors:
                headers2 = next(adls2errors)
                reader_obj_log = csv.reader(adls2errors)
                if reader_obj_log is not None:
                    for row_log2 in reader_obj_log:
                        if row_log2 is not None and row_log2[0][0:16] == i and row_log2[5] == m:
                            failure2 = True
                            event2 = {}
                            event2['event_time'] = row_log2[2]
                            event2['UID'] = row_log2[3]
                            event2['OperationName'] = row_log2[6]
                            event2['StatusCode'] = row_log2[7]
                            event2['StatusText'] = row_log2[8]
                            event2['DurationMs'] = row_log2[9]
                            event2['ServerLatencyMs'] = row_log2[10]
                            events2.append(event2)

            if len(events2) > 0:
                dict2['hasFailure'] = failure2
                dict2['error_events'] = events2
            else:
                dict2['hasFailure'] = failure2
            if len(dict2) > 1:
                adls2_metrics.append(dict2)

        if len(adls1_metrics) > 0:
            final_output['adls1'] = adls1_metrics
        if len(adls2_metrics) > 0:
            final_output['adls2'] = adls2_metrics
        dict_list.append(final_output)

    # Bulk insert all dictionaries to MongoDB
    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)
    logger.info(f"New entry list size for ADLS = {len(dict_list)}")
    if len(dict_list) > 0:
        collection.insert_many(dict_list)
        exit_handler(OK_CODE)
    else:
        logger.warn("Zero new entries inserted to mongodb for ADLS")
        exit_handler(WARNING_CODE)
