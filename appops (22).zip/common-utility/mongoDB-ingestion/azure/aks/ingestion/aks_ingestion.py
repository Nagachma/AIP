import hashlib
import random
from cProfile import run
import csv
from gc import collect
import json
import os
from matplotlib import collections
import pandas as pd
import yaml
from pymongo import MongoClient
from datetime import timezone, datetime
import datetime

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2


def ingest_aks_csvs(config, logger, exit_handler):
    csvFile1 = config['aks_metrics_info']['azure_monitor_aks_csv']
    csvFile2 = config['aks_metrics_info']['log_analytics_aks_csv']

    df_csvFile1 = pd.read_csv(csvFile1)

    timestamp = list(df_csvFile1.start_time)
    for csvFile in csvFile2:
        with open(csvFile) as for_values:
            df_csvFile2 = pd.read_csv(csvFile)
            heading = next(for_values)
            if heading[0:13] == 'TimeGenerated':
                timestamp.extend(list(df_csvFile2.TimeGenerated))
    timestamp = [*set(timestamp)]
    timestamp = list(map(lambda timestp: timestp[0:16], timestamp))
    timestamp = [*set(timestamp)]
    timestamp.sort()
    # timestamp = ['2022-09-22 12:15:00+00:00']

    aks_name = []
    aks_name = list(df_csvFile1.aksname)
    cluster_name = []
    for csvFile in csvFile2:
        with open(csvFile) as for_values:
            heading = next(for_values)
            reader_obj = csv.reader(for_values)
            for row in reader_obj:
                ls = row[len(row) - 1].split("/")
                cluster_name.append(ls[len(ls) - 1])
    aks_name = aks_name + cluster_name
    aks_name = [*set(aks_name)]
    aks_name.sort()

    dict_list = []


    source = config['azure_source']

    for i in timestamp:
        time = i
        # time = time[0:18]
        time = datetime.datetime.strptime(time, '%Y-%m-%d %H:%M')
        # print(time)
        final_output = {}
        name = i
        name = name.replace(" ", "").replace(":", "").replace("-", "")
        name = name[:13]

        managed_clusters = []

        for j in aks_name:
            dict = {}
            flag = 0
            dict["aks_name"] = j
            with open(csvFile1) as for_aks_name:
                heading = next(for_aks_name)
                reader_obj = csv.reader(for_aks_name)
                for row in reader_obj:
                    if (row[0][0:16] == i and row[2] == j):
                        if row[4] is None or row[4] == '':
                            pass
                        else:
                            try:
                                row[4] = float(row[4])
                            except ValueError as ve:
                                # non-float value
                                metric_name = row[3]
                                dict[metric_name] = row[4]
                            else:
                                # float value if no exception
                                metric_name = row[3]
                                dict[metric_name] = float(row[4])
                        # if (row[0][0:16] == i and row[2] == j):
                        #     if row[4] != "":
                        #         metric_name = row[3]
                        #         dict[metric_name] = row[4]

            list_computer = []
            list_container = []
            list_node = []
            for csvFile in csvFile2:
                df_csvFile2 = pd.read_csv(csvFile)
                csvFile2_header = list(df_csvFile2.columns)
                with open(csvFile) as for_values:
                    heading = next(for_values)
                    l_reader_obj = csv.reader(for_values)
                    for l_row in l_reader_obj:
                        computer = {}
                        container = {}
                        node = {}
                        ls = l_row[len(l_row) - 1].split("/")
                        if (l_row[0][0:16] == i and (ls[len(ls) - 1]) == j):
                            count = 1
                            a = 2
                            while (count < len(l_row) - 1):
                                if csvFile2_header[1] == 'ClusterName' and csvFile2_header[2] != "Computer":
                                    count = a
                                    if l_row[count] is not None and l_row[count] != '':
                                        try:
                                            l_row[count] = float(l_row[count])
                                        except ValueError as ve:
                                            # non-float value
                                            dict[csvFile2_header[count]] = l_row[count]
                                        else:
                                            # float value if no exception
                                            dict[csvFile2_header[count]] = float(l_row[count])
                                    a = a + 1
                                elif csvFile2_header[1] == 'Computer':
                                    if l_row[count] is not None and l_row[count] != '':
                                        try:
                                            l_row[count] = float(l_row[count])
                                        except ValueError as ve:
                                            # non-float value
                                            computer[csvFile2_header[count]] = l_row[count]
                                        else:
                                            # float value if no exception
                                            computer[csvFile2_header[count]] = float(l_row[count])
                                elif csvFile2_header[0] == 'InstanceName':
                                    continue
                                elif csvFile2_header[2] == 'AvgcpuRequestNanoCores':
                                    if l_row[count] is not None and l_row[count] != '':
                                        try:
                                            l_row[count] = float(l_row[count])
                                        except ValueError as ve:
                                            # non-float value
                                            container[csvFile2_header[count]] = l_row[count]
                                        else:
                                            # float value if no exception
                                            container[csvFile2_header[count]] = float(l_row[count])
                                elif csvFile2_header[2] == 'AvgcpuAllocatableNanoCores':
                                    if l_row[count] is not None and l_row[count] != '':
                                        try:
                                            l_row[count] = float(l_row[count])
                                        except ValueError as ve:
                                            # non-float value
                                            node[csvFile2_header[count]] = l_row[count]
                                        else:
                                            # float value if no exception
                                            node[csvFile2_header[count]] = float(l_row[count])
                                elif csvFile2_header[1] == 'TotalCount' or csvFile2_header[1] == 'MaxNodeDiskUsage':
                                    if l_row[count] is not None and l_row[count] != '':
                                        try:
                                            l_row[count] = float(l_row[count])
                                        except ValueError as ve:
                                            # non-float value
                                            dict[csvFile2_header[count]] = l_row[count]
                                        else:
                                            # float value if no exception
                                            dict[csvFile2_header[count]] = float(l_row[count])
                                elif csvFile2_header[1] == 'ClusterName' and csvFile2_header[2] == 'Computer':
                                    count = a
                                    if l_row[count] is not None and l_row[count] != '':
                                        try:
                                            l_row[count] = float(l_row[count])
                                        except ValueError as ve:
                                            # non-float value
                                            computer[csvFile2_header[count]] = l_row[count]
                                        else:
                                            # float value if no exception
                                            computer[csvFile2_header[count]] = float(l_row[count])
                                    a = a + 1

                                count = count + 1
                            if csvFile2_header[1] == 'Computer' or csvFile2_header[2] == 'Computer':
                                if len(list_computer) == 0 and len(computer) > 0:
                                    computer['computer_id'] = hashlib.sha224(repr("Computer"+str(random.randint(0,999999)) + str(random.randint(0, 999999))).encode('utf-8')).hexdigest()
                                    list_computer.append(computer)
                                else:
                                    x = 0
                                    y = 0
                                    for x in range(len(list_computer)):
                                        if list(list_computer[x].keys())[0] == list(computer.keys())[0] and list(list_computer[x].values())[0] == list(computer.values())[0]:
                                            dict_old_computer = list_computer[x].copy()
                                            list_computer.pop(x)
                                            computer = {**dict_old_computer, **computer}
                                            list_computer.append(computer)
                                            y = 1
                                            break
                                    if y == 0:
                                        list_computer.append(computer)
                            elif csvFile2_header[2] == 'AvgcpuRequestNanoCores':
                                if len(container) > 0:
                                    container['container_id'] = hashlib.sha224(repr("Container" + str(random.randint(0, 999999)) + str(random.randint(0, 999999))).encode('utf-8')).hexdigest()
                                    list_container.append(container)
                            elif csvFile2_header[2] == 'AvgcpuAllocatableNanoCores':
                                if len(node) > 0:
                                    node['node_id'] = hashlib.sha224(repr("Node" + str(random.randint(0, 999999)) + str(random.randint(0, 999999))).encode('utf-8')).hexdigest()
                                    list_node.append(node)
            # list_computer.append(computer)
            if len(list_computer) > 0:
                dict['Computer'] = list_computer
            if len(list_container) > 0:
                dict['Container'] = list_container
            if len(list_node) > 0:
                dict['Node'] = list_node
            managed_clusters.append(dict)

        final_output["source"] = source
        final_output["ts"] = time
        final_output["managed_clusters"] = managed_clusters

        dict_list.append(final_output)

    mongo_client = config['mongo_url']
    mongo_db = config['mongo_db']
    mongo_collection = config['aks_metrics_info']['mongo_collection']

    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)
    # Bulk insert all dictionaries to MongoDB
    # print(final_output)
    logger.info('New entry list size for Azure AKS = {}'.format(len(dict_list)))
    if len(dict_list) > 0:
        collection.insert_many(dict_list)
        exit_handler(OK_CODE)
    else:
        logger.warn('Zero 0 new entries inserted to mongo db for Azure AKS')
        exit_handler(WARNING_CODE)
