from cProfile import run
import csv
from gc import collect
import os
from matplotlib import collections
import pandas as pd
import yaml
import hashlib
from pymongo import MongoClient
from datetime import timezone, datetime
# import datetime
from vault_utility_v2 import vault_credentials



# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2

def ingest_azurecacheredis_csvs(config,logger,exit_handler):

    # CsvFilePaths

    azure_cache_metrics_csv=config['azurecacheredis_metrics_info']['azm_CsvFilePath']

    # attribute_csv=config['azurecacheredis_metrics_info']['attr_CsvFilePath']


    # ReadcsvtoDF
    if os.path.exists(azure_cache_metrics_csv):
        azure_cache_metrics_df=pd.read_csv(azure_cache_metrics_csv)
        # attribute_df=pd.read_csv(attribute_csv)
        timestampvalue1 = list(azure_cache_metrics_df["start_time"])
        timestampvalue = [*set(timestampvalue1)]
        # timestampvalue = timestampvalue[0]

    dict_list = []
    #Loading cache_name from vault
    azurecache_vault_path = "environment/1/azurerediscache"
    azurecache_vault_keys = ["cache_name"]
    configs = vault_credentials.get_secret_from_vault(azurecache_vault_path, azurecache_vault_keys)
    if 'cache_name' in configs:
        cache_name = str(configs['cache_name'])
    else:
        logger.error("No cache_name key found")
        raise Exception('No cache_name key found')

    cache_list = []
    # azurecache_name = cache_name
    cache_list.append(cache_name)

    for i in timestampvalue:

    # Create a Dict for azure_cache_metrics

        result = {}
        for key, group in azure_cache_metrics_df.groupby('azurecacheredisname'):
            key = key.lower()
            result[key] = {}
            for row in group.itertuples(index=False):
                if row[0] == i:
                    metric = row[3]
                    avg_value = row[4]

                    # avg_m = "Avg" + metric

                    result[key][metric] = avg_value

            result[key]["cachehitrate"] = str(100-float(result[key]["cachemissrate"]))
        # create a attribute_dictionary
        # attribute_dictionary = {}
        #
        # for row in attribute_df.itertuples(index=False):
        #     key = row[0]
        #     key = key.lower()
        #     inner_dict = {}
        #     for x, value in enumerate(row[1:], start=1):
        #         inner_dict[attribute_df.columns[x]] = value
        #     attribute_dictionary[key] = inner_dict

        final_dict = {key: {inner_key: inner_value for inner_key, inner_value in value.items() if inner_value == inner_value} for key, value in result.items()}

        for key, value in final_dict.items():
            del value['cache_name']



        timestamp=datetime.strptime(i,"%Y-%m-%d %H:%M:%S%z").strftime("%Y-%m-%d %H:%M")

        output=[]
        for key, groups in final_dict.items():
            new_result = {}

            if key in cache_list:
                new_result["name"] = key
                new_result["id"] = hashlib.sha3_256(repr(key).encode('utf-8')).hexdigest()
                for x, y in groups.items():
                    new_result[x] = y
                output.append(new_result)

        source = config['azure_source']

        final_output={}
        final_output["source"] = source
        timestamp = datetime.fromisoformat(timestamp)
        final_output["ts"] = timestamp

        final_output["azure_redis_cache"] = output
        dict_list.append(final_output)
    # Bulk insert all dictionaries to MongoDB
    mongo_client = config['mongo_url']
    mongo_db = config['mongo_db']
    mongo_collection = config['azurecacheredis_metrics_info']['mongo_collection']
    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)
    # print(dict_list)
    logger.info('New entry list size for Azure Cache Redis = {}'.format(len(dict_list)))
    if len(dict_list) > 0:
        collection.insert_many(dict_list)
        exit_handler(OK_CODE)
    else:
        logger.warn('Zero 0 new entries inserted to mongo db for Azure Functions')
        exit_handler(WARNING_CODE)
