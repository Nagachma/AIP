from cProfile import run
import csv
from gc import collect
import json
import os
from matplotlib import collections
import pandas as pd
import yaml
from pymongo import MongoClient
from datetime import timezone, datetime
import datetime


# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2

def ingest_azure_ml_csvs(config,logger,exit_handler):

    # Declarations
    az_monitor_csv = config['azureml_metrics_info']['azure_monitor_workspace_csv']
    custom_csv_Files = config['azureml_metrics_info']['log_analytics_csv']
    custom_workspace_names=[]
    custom_times=[]
    unique_clusters=[]
    unique_jobs=[]
    source = config['azure_source']
    dict_list=[]
    
    #### Listing out unique resources for LOG ANALYTICS ######
   
    for csvs in custom_csv_Files:
        df_csvFile = pd.read_csv(csvs)
        resource_ids = list(df_csvFile._ResourceId)
        start_times= list(df_csvFile.start_time)
        headers = list(df_csvFile.columns)
        if("ClusterName" in headers):
            clusters=list(df_csvFile.ClusterName)
            clusters = list(map(lambda c: str(c), clusters))
            unique_clusters.extend(clusters)
        if("JobName" in headers):
            jobs=list(df_csvFile.JobName)
            unique_jobs.extend(jobs)
        workspace_name=[x.split("/")[-1] for x in resource_ids]
        custom_workspace_names.extend(workspace_name)
        custom_times.extend(start_times)
    custom_times=[*set(custom_times)]
    custom_workspace_names = [*set(custom_workspace_names)]
    unique_clusters=[*set(unique_clusters)]
    unique_jobs=[*set(unique_jobs)]
    unique_clusters.sort()
    unique_jobs.sort()
    # print(unique_clusters)
    
    #### Listing out unique workspaces and timestamps for AZURE MONITOR ######
    df_csvFile = pd.read_csv(az_monitor_csv)
    # Listing out unique workspaces
    workspace_name = list(df_csvFile.azuremlname)
    timestamp = list(df_csvFile.start_time)
    workspace_name = [*set(workspace_name)]
    timestamp = [*set(timestamp)]

    # Combining unique workspace and timestamps for two sources
    workspace_name.extend(custom_workspace_names)
    all_workspace_names = [*set(workspace_name)]

    timestamp.extend(custom_times)
    timestamp = list(map(lambda timestp: timestp[0:16], timestamp))
    timestamp = [*set(timestamp)]
    timestamp.sort()
    # print(timestamp)
    # print(all_workspace_names)

    
    for i in timestamp:
        time = i
        time = datetime.datetime.strptime(time, '%Y-%m-%d %H:%M')
        final_output = {}
        workspaces = []
        for j in all_workspace_names:
            workspace={}
            workspace["workspace_name"] = j
            clusters=[]
            # Azure Monitor CSV Read
            with open(az_monitor_csv) as for_workspace_name:
                heading = next(for_workspace_name)
                reader_obj = csv.reader(for_workspace_name)
                for row in reader_obj:
                    if (row[0][0:16] == i and row[2] == j):
                        value = row[4]
                        metric_name = "Workspace." + row[3]
                        if value is None or value == '':
                            pass
                        else:
                            try:
                                value = float(value)
                            except ValueError as ve:
                                # non-float value
                                workspace[metric_name] = row[4]
                            else:
                                # float value if no exception
                                workspace[metric_name] = float(value)

    
            # Log Analytics CSV Read 
            for clust in unique_clusters:
                jobs=[]
                cluster={}
                cluster["ClusterName"]=clust
                for csvs in custom_csv_Files:
                    df_csvFile = pd.read_csv(csvs)
                    headers = list(df_csvFile.columns)
                    with open(csvs) as custom_csv_file:
                        heading = next(custom_csv_file).strip()
                        reader_obj = csv.reader(custom_csv_file)
                        for row in reader_obj:
                            if row[1].split("/")[-1] == j and row[0][0:16] == i and row[3]==clust:
                                if(row[2]=="AmlComputeClusterEvent"):
                                    col=4
                                    cluster["Time"]=row[0]
                                    for k in headers[4:]:
                                        value=row[col]
                                        if value is None or value == '':
                                            pass
                                        else:
                                            try:
                                                value = float(value)
                                            except ValueError as ve:
                                                # non-float value
                                                cluster[k]=row[col]
                                            else:
                                                # float value if no exception
                                                cluster[k] = float(value)
                                        col=col+1

                for unique_job in unique_jobs:
                    job={}
                    job["JobName"]=unique_job

                    for csvs in custom_csv_Files:
                        df_csvFile = pd.read_csv(csvs)
                        headers = list(df_csvFile.columns)
                        with open(csvs) as custom_csv_file:
                            heading = next(custom_csv_file).strip()
                            reader_obj = csv.reader(custom_csv_file)

                            for row in reader_obj:
                                if row[1].split("/")[-1] == j and row[0][0:16] == i and row[3]==clust:
                                    if(row[2] in ["AmlComputeJobEvent","AmlComputeCpuGpuUtilization"] and row[4].casefold()==unique_job.casefold()):
                                        col=3
                                        value=row[col]
                                        for k in headers[3:]:
                                            value=row[col]
                                            if value is None or value == '':
                                                pass
                                            else:
                                                try:
                                                    value = float(value)
                                                except ValueError as ve:
                                                    # non-float value
                                                    job[k]=row[col]
                                                else:
                                                    # float value if no exception
                                                    job[k] = float(value)
                                            col=col+1
                                        if(cluster.get("ClusterName")==job.get("ClusterName")):
                                            y=0
                                            isempty=True
                                            del job["ClusterName"]
                                            if "Jobs" not in cluster:
                                                isempty=True
                                                cluster["Jobs"]=[]
                                            else:
                                                isempty=False
                                                cluster["Jobs"]
                                            if(isempty==False):
                                                temp=cluster["Jobs"]
                                                for x in range(len(cluster["Jobs"])):
                                                    if list(temp[x].keys())[0] == list(job.keys())[0] and list(temp[x].values())[0] == list(job.values())[0]:
                                                        dict_old = temp[x].copy()
                                                        temp.pop(x)
                                                        job = {**dict_old, **job}
                                                        temp.append(job)
                                                        cluster["Jobs"]=temp
                                                        y = 1
                                                        break
                                            if(y==0):
                                                cluster["Jobs"].append(job)

                if(len(cluster)>1):
                    clusters.append(cluster)

            if(len(clusters)>0):
                workspace["Cluster"] = clusters
            workspaces.append(workspace)
          

        final_output["source"] = source
        final_output["ts"] = time
        final_output["workspaces"] = workspaces
        dict_list.append(final_output)
    

    # # Bulk insert all dictionaries to MongoDB
    mongo_client = config['mongo_url']
    mongo_db = config['mongo_db']
    mongo_collection = config['azureml_metrics_info']['mongo_collection'] 
    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)
    logger.info('New entry list size for Azure ML = {}'.format(len(dict_list)))  
    if len(dict_list) > 0:
        collection.insert_many(dict_list)
        exit_handler(OK_CODE)
    else:
        logger.warn('Zero 0 new entries inserted to mongo db for Azure ML')
        exit_handler(WARNING_CODE)

    