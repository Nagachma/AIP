import datetime
from datetime import datetime

import pandas as pd
from pymongo import MongoClient

import csv

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2


def ingest_azure_blobfuse_csvs(config, logger, exit_handler):
    # Declarations
    az_healthmonitor_csv = config['blobfuse_metrics_info']['azure_healthmonitor_blobfuse_csv']
    az_filecache_csv_Files = config['blobfuse_metrics_info']['azure_healthmonitor_filecache_csv']
    az_blobfusestats_csv_Files = config['blobfuse_metrics_info']['azure_healthmonitor_blobfusestats_csv']
    timestamp = []
    source = config['azure_source']
    dict_list = []


    # #### Listing out unique timestamps for AZURE HEALTH MONITOR ######
    df_csvFile = pd.read_csv(az_healthmonitor_csv)
    df_csvFile1 = pd.read_csv(az_filecache_csv_Files)
    df_csvFile2 = pd.read_csv(az_blobfusestats_csv_Files)

    timestamp.extend(list(df_csvFile.Timestamp))


    timestamp = list(map(lambda timestp: timestp[0:16], timestamp))
    timestamp = [*set(timestamp)]
    timestamp.sort()
    cc = 0
    for i in timestamp:
        time = i
        time = datetime.strptime(time, '%Y-%m-%d %H:%M')
        final_output = {}
        blobfuses=[]
        file_cache=[]
        file_caches=[]
        blobfusestats={}
        stats=[]

        with open(az_healthmonitor_csv) as for_blobfuse:
            header = df_csvFile.columns
            reader_obj = csv.reader(for_blobfuse)
            blobfuse = {}
            for col in reader_obj:
                if col[0][0:16] == i:
                    row1 = 0
                    for g in header:
                        value = col[row1]
                        if value is None or value == '':
                            pass
                        else:
                            try:
                                value = float(value)
                            except ValueError as ve:
                                # non-float value
                                blobfuse[g] = value
                            else:
                                # float value if no exception
                                blobfuse[g] = float(value)
                        row1 = row1 + 1

            with open(az_filecache_csv_Files) as for_filecache:
                header = df_csvFile1.columns
                reader_obj = csv.reader(for_filecache)

                for col in reader_obj:
                    file_cache = {}
                    if col[0][0:16] == i:
                        row1 = 0
                        for g in header:
                            value = col[row1]
                            if value is None or value == '':
                                pass
                            else:
                                try:
                                    value = float(value)
                                except ValueError as ve:
                                    # non-float value
                                    file_cache[g] = value
                                else:
                                    # float value if no exception
                                    file_cache[g] = float(value)
                            row1 = row1 + 1
                        if len(file_cache) > 1:
                            file_caches.append(file_cache)
            with open(az_blobfusestats_csv_Files) as for_azhm:
                header = (df_csvFile2.columns)
                reader_obj = csv.reader(for_azhm)
                for col in reader_obj:
                    blobfusestats = {}
                    if col[0][0:16] == i:
                        row = 0
                        for g in header:
                            value = col[row]
                            if value is None or value == '':
                                pass
                            else:
                                try:
                                    value = float(value)
                                except ValueError as ve:
                                    # non-float value
                                    blobfusestats[g] = value
                                else:
                                    # float value if no exception
                                    blobfusestats[g] = float(value)
                            row = row + 1
                        if len(blobfusestats) > 1:
                            stats.append(blobfusestats)

            if len(file_caches) > 0:
                blobfuse['file_cache'] = file_caches
            if len(stats) > 0:
                blobfuse['blobfusestats'] = stats
            blobfuses.append(blobfuse)
        #
        final_output["source"] = source
        final_output["ts"] = time
        final_output["blobfuse"] = blobfuses
        dict_list.append(final_output)
    # Bulk insert all dictionaries to MongoDB
    mongo_client = config['mongo_url_dev']
    mongo_db = config['mongo_db']
    mongo_collection = config['blobfuse_metrics_info']['mongo_collection']
    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)
    # print(dict_list)
    logger.info('New entry list size for Azure Blobfuse = {}'.format(len(dict_list)))
    if len(dict_list) > 0:
        collection.insert_many(dict_list)
        exit_handler(OK_CODE)
    else:
        logger.warn('Zero 0 new entries inserted to mongo db for Azure BlobFuse')
        exit_handler(WARNING_CODE)
