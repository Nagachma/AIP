import os.path
from datetime import datetime

import pandas as pd
from pymongo import MongoClient

import csv

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2

logger = []
exit_handler = []


def ingest_databricks_csvs(config, logger, exit_handler):
    databricksCsvFilePath1 = config['databricks_metrics_info']['graphType_csv']
    databricksCsvFilePath2 = config['databricks_metrics_info']['bulk_csv']
    databricksCsvFilePath3 = config['databricks_metrics_info']['cluster_csv']
    databricksCsvFilePath4 = config['databricks_metrics_info']['job_csv']
    cluster_metric_names = []
    workspaceNames = []
    clusterIds = []
    applicationIds = []
    executorIds = []
    timestamps = []
    jobIds = []
    runIds = []
    taskRunIds = []
    mongo_client = config['mongo_url']
    mongo_db = config['mongo_db']
    mongo_collection = config['databricks_metrics_info']['mongo_collection']
    dict_list = []
    for csvs in databricksCsvFilePath1:
        if os.path.exists(csvs):
            df = pd.read_csv(csvs)
            timeGenerated = list(df.TimeGenerated)
            workspace_name = list(df.workspace_name)
            clusterId = list(df.clusterId_s)
            applicationId = list(df.applicationId_s)
            executorId = list(df.executor)
            workspaceNames.extend(workspace_name)
            clusterIds.extend(clusterId)
            applicationIds.extend(applicationId)
            executorIds.extend(executorId)
            timestamps.extend(timeGenerated)

    for csvs in databricksCsvFilePath2:
        if os.path.exists(csvs):
            df = pd.read_csv(csvs)
            timeGenerated = list(df.TimeGenerated)
            workspace_name = list(df.workspace_name)
            clusterId = list(df.clusterId_s)
            applicationId = list(df.applicationId_s)
            executorId = list(df.executor)
            workspaceNames.extend(workspace_name)
            clusterIds.extend(clusterId)
            applicationIds.extend(applicationId)
            executorIds.extend(executorId)
            timestamps.extend(timeGenerated)

    for csvs in databricksCsvFilePath3:
        if os.path.exists(csvs):
            df = pd.read_csv(csvs)
            timeGenerated = list(df.TimeGenerated)
            metricName = list(df.metric_name)
            workspace_name = list(df.workspace_name)
            clusterId = list(df.clusterId_s)
            applicationId = list(df.applicationId_s)
            cluster_metric_names.extend(metricName)
            workspaceNames.extend(workspace_name)
            clusterIds.extend(clusterId)
            applicationIds.extend(applicationId)
            timestamps.extend(timeGenerated)

    if os.path.exists(databricksCsvFilePath4):
        df4 = pd.read_csv(databricksCsvFilePath4)
        run_headers = list(df4.columns)
        timeGenerated = list(df4.metric_start_time)
        clusterId = list(df4.cluster_id)
        jobId = list(df4.job_id)
        runId = list(df4.run_id)
        taskRunId = list(df4.task_run_id)
        workspaceNames.extend(list(df4.workspace_name))
        clusterIds.extend(clusterId)
        jobIds.extend(jobId)
        runIds.extend(runId)
        taskRunIds.extend(taskRunId)
        timestamps.extend(timeGenerated)

    # timestamps = [*set(timestamps)]
    timestamp = list(map(lambda timestp: timestp[0:16], timestamps))
    timestamp = [*set(timestamp)]
    timestamp.sort()
    cluster_metric_names = [*set(cluster_metric_names)]
    cluster_metric_names.sort()
    workspaceNames = [*set(workspaceNames)]
    workspaceNames.sort()
    clusterIds = [*set(clusterIds)]
    clusterIds.sort()
    # applicationIds = [*set(applicationIds)]
    # applicationIds.sort()
    executorIds = [*set(executorIds)]
    executorIds.sort()
    jobIds = [*set(jobIds)]
    jobIds.sort()
    runIds = [*set(runIds)]
    runIds.sort()
    taskRunIds = [*set(taskRunIds)]
    taskRunIds.sort()

    source = config['azure_source']

    for i in timestamp:
        time = i
        time = datetime.strptime(time, '%Y-%m-%d %H:%M')
        final_output = {}
        final_output['source'] = source
        final_output['ts'] = time

        workspaces = []
        clusters = []


        workspace = {}
        for w in workspaceNames:
            workspace['workspaceName'] = w
            workspace['timeGenerated'] = i
            workspace_count=0
            for c in clusterIds:
                cluster = {}
                cluster['ClusterId'] = c
                cluster_count =0
                for metrics in cluster_metric_names:
                    for n in databricksCsvFilePath3:
                        with open(n) as databrickvalues:
                            heading = next(databrickvalues)
                            reader_obj = csv.reader(databrickvalues)
                            for row in reader_obj:
                                if row[0][0:16] == i and row[1] == metrics and row[2] == w and row[3] == c:
                                    cluster['ClusterName']= row[4]
                                    value = row[6]
                                    if value is not None and value != '':
                                        cluster[row[1]] = value
                                        cluster_count+=1

                jobs = []
                job_id = None
                job_name= None
                run_id = None
                cluster_id = None
                for j in jobIds:
                    job_dict = {}
                    # tasks = []
                    runs = []

                    # job_dict['job_id'] = j
                    for r in runIds:
                        run_dict = {}
                        tasks = []
                        for t in taskRunIds:
                            task_dict = {}
                            with open(databricksCsvFilePath4) as jobdetails:
                                heading = next(jobdetails)
                                reader_obj = csv.reader(jobdetails)
                                for row in reader_obj:
                                    if row[0][0:16] == i  and row[2]==w and row[4] == str(j) and row[5] == str(r) and row[24] == str(t) and row[26] == c:
                                        cluster_id = row[26]
                                        job_name=row[3]
                                        job_id = row[4]
                                        run_id = row[5]
                                        count = 24
                                        has_value3 = False
                                        while count <= len(row) - 1:
                                            if count > 23 and row[count] is not None and row[count] != '':
                                                has_value3 = True
                                                if run_headers[count] == 'cluster_id':
                                                    pass
                                                else:
                                                    task_dict[run_headers[count]] = row[count]
                                            count = count + 1
                                        if task_dict and has_value3:
                                            tasks.append(task_dict)
                                        count = 5
                                        while count <= 23:
                                            if count > 4 and row[count] is not None and row[count] != '':
                                                run_dict[run_headers[count]] = row[count]
                                            count = count + 1
                        if str(r) == run_id and len(tasks) > 0:
                            run_dict['tasks'] = tasks
                        if run_dict:
                            runs.append(run_dict)

                    if str(j) == job_id and len(runs) > 0:
                        job_dict['job_id'] = str(j)
                        job_dict['job_name'] = job_name
                        job_dict['runs'] = runs
                    if job_dict:
                        jobs.append(job_dict)

                if c == cluster_id and len(jobs)>0:
                    cluster['jobs'] = jobs
                    cluster_count+=1

                executors = []
                for e in executorIds:
                    executor = {}
                    executor['executor'] = e
                    count=0
                    for m in databricksCsvFilePath1:
                        with open(m) as databrickvalues:
                            heading = next(databrickvalues)
                            reader_obj = csv.reader(databrickvalues)
                            for row in reader_obj:
                                if row[0][0:16] == i and row[2] == w and row[3] == c and row[6] == e:
                                    value = row[7]
                                    if value is not None and value != '':
                                        executor[row[1]] = value
                                        count+=1
                    for m in databricksCsvFilePath2:
                        with open(m) as databrickvalues:
                            heading = next(databrickvalues)
                            reader_obj = csv.reader(databrickvalues)
                            for row in reader_obj:
                                if row[0][0:16] == i and len(row) > 8 and row[2] == w and row[3] == c and row[6] == e:
                                    if row[7] == 0 and row[8] == 0:
                                        value = 0
                                    elif row[7] > row[8]:
                                        value = row[7]
                                    else:
                                        value = row[8]
                                    if value is not None and value != '':
                                        executor[row[1]] = value
                                elif row[0][0:16] == i and row[2] == w and row[3] == c and row[6] == e:
                                    value = row[7]
                                    if value is not None and value != '':
                                        executor[row[1]] = value
                                        count += 1
                    if count>0:
                        executors.append(executor)
                if len(executors)>0:
                    cluster["executor"] = executors

                if cluster_count!=0:
                    clusters.append(cluster)
                    workspace_count+=1
            workspace["cluster"] = clusters
            if workspace_count!=0:
                workspaces.append(workspace)


        final_output['workspaces'] = workspaces
        dict_list.append(final_output)

    # Bulk insert all dictionaries to MongoDB
    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)
    logger.info(f"New entry list size for DATABRICKS = {len(dict_list)}")
    if len(dict_list) > 0:
        collection.insert_many(dict_list)
        exit_handler(OK_CODE)
    else:
        logger.warn("Zero new entries inserted to mongodb for DATABRICKS")
        exit_handler(WARNING_CODE)
