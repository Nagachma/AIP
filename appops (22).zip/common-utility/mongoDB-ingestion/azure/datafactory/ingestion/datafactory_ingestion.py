import datetime
from datetime import datetime

import pandas as pd
from pymongo import MongoClient

import csv

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2


def ingest_datafactory_csvs(config, logger, exit_handler):
    azure_monitor_csv = config["datafactory_metrics_info"]["azure_monitor_csv"]
    pipeline_runs_csv = config["datafactory_metrics_info"]["pipeline_runs_csv"]
    activity_runs_csv = config["datafactory_metrics_info"]["activity_runs_csv"]

    factories = []
    df = pd.read_csv(azure_monitor_csv)
    am_header = list(df.columns)
    factories1 = list(df.datafactoryname)
    factories1 = [*set(factories1)]
    factories.extend(factories1)
    timestamp = list(df.start_time)
    timestamp = [*set(timestamp)]

    df3 = pd.read_csv(pipeline_runs_csv)
    pip_header = list(df3.columns)
    factories3 = list(df3.factoryName)
    factories3 = [*set(factories3)]
    factories.extend(factories3)
    timestamp3 = list(df3.TimeStamp)
    timestamp3 = [*set(timestamp3)]
    timestamp.extend(timestamp3)

    df4 = pd.read_csv(activity_runs_csv)
    act_header = list(df4.columns)
    factories4 = list(df4.factoryName)
    factories4 = [*set(factories4)]
    factories.extend(factories4)
    timestamp4 = list(df4.TimeStamp)
    timestamp4 = [*set(timestamp4)]
    timestamp.extend(timestamp4)

    timestamp = list(map(lambda timestp: timestp[0:16], timestamp))
    timestamp = [*set(timestamp)]
    timestamp.sort()

    factories = [*set(factories)]
    factories.sort()


    source = config['azure_source']

    dict_list = []

    mongo_client = config['mongo_url']
    mongo_db = config['mongo_db']
    mongo_collection = config['datafactory_metrics_info']['mongo_collection']

    for i in timestamp:
        time = i
        # time = time[0:16]
        time = datetime.strptime(time, '%Y-%m-%d %H:%M')

        amlen = {}
        # piplen = {}
        final_output = {}
        factory = []
        az_monitor = []
        for factory_name in factories:
            metric_dict = {"factoryName": factory_name}
            with open(azure_monitor_csv) as for_am:
                heading = next(for_am)
                am_reader_obj = csv.reader(for_am)
                for am_row in am_reader_obj:
                    if am_row[0][0:16] == i and am_row[2] == factory_name:
                        value = am_row[4]
                        if value is None or value == '':
                            pass
                        else:
                            try:
                                value = float(value)
                            except ValueError as ve:
                                # non-float value
                                metric_dict[am_row[3]] = am_row[4]
                            else:
                                # float value if no exception
                                metric_dict[am_row[3]] = float(value)
                    # print(metric_dict)

            # Pipeline run metrics
            pipelines = []
            pip_dict = {}
            pip_runs = {}

            with open(pipeline_runs_csv) as for_pip:
                heading = next(for_pip)
                reader_obj = csv.reader(for_pip)
                for row in reader_obj:
                    pip_dict = {}
                    has_value = False
                    if row[0][0:16] == i and row[1] == factory_name:
                        count = 0
                        while count <= len(row)-1:
                            # pip_dict[pip_header[count]] = row[count]
                            if count > 1 and row[count] is not None and row[count] != '':
                                has_value = True
                                pip_dict[pip_header[count]] = row[count]
                            count = count + 1
                    if pip_dict and has_value:
                        pipelines.append(pip_dict)

            # print(pipelines)
            metric_dict["pipeline_runs"] = pipelines
            # print(metric_dict)

            act_dict = {}
            activity = []
            # Activity runs metrics
            with open(activity_runs_csv) as for_act:
                heading = next(for_act)
                act_reader_obj = csv.reader(for_act)
                for row in act_reader_obj:
                    act_dict = {}
                    has_value = False
                    if row[0][0:16] == i and row[1] == factory_name:
                        count = 0
                        while count <= len(row)-1:
                            if count > 1 and row[count] is not None and row[count] != '':
                                has_value = True
                                act_dict[act_header[count]] = row[count]
                            count = count + 1
                    if act_dict and has_value:
                        activity.append(act_dict)
            # print(activity)
            metric_dict["activity_runs"] = activity
            # print(metric_dict)

            factory.append(metric_dict)
        final_output["source"] = source
        final_output["ts"] = time
        final_output["factory"] = factory
        # print(final_output)
        dict_list.append(final_output)

    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)

    logger.info(f"New entry list size = {len(dict_list)} for Azure Datafactory")

    # print(final_output)
    if len(dict_list) > 0:
        collection.insert_many(dict_list)
        exit_handler(OK_CODE)
    else:
        logger.warn("Zero new metrics inserted for Azure Datafactory")
        exit_handler(WARNING_CODE)
