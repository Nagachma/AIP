import datetime
import os.path
from datetime import datetime

import pandas as pd
from pymongo import MongoClient

import csv

from vault_utility_v2 import vault_credentials
# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2


def ingest_azure_hyperscalesql_csvs(config, logger, exit_handler):
    # Declarations
    global az_monitor_df
    az_monitor_csv = config['hyperscalesql_metrics_info']['azure_monitor_hyperscalesql_csv']
    active_locks_csv_file = config['hyperscalesql_metrics_info']['active_locks_CsvFilePath']
    buffer_memory_csv_file = config['hyperscalesql_metrics_info']['buffer_memory_utilization_per_database_CsvFilePath']
    cpu_utilization_csv_file = config['hyperscalesql_metrics_info']['cpu_utilization_CsvFilePath']
    maximum_connections_csv_file = config['hyperscalesql_metrics_info']['maximum_connections_CsvFilePath']
    object_causing_latch_contention_csv_file = config['hyperscalesql_metrics_info'][
        'object_causing_latch_contention_CsvFilePath']
    query_duration_csv_file = config['hyperscalesql_metrics_info']['query_duration_CsvFilePath']
    total_lock_and_latch_waits_csv_file = config['hyperscalesql_metrics_info']['total_lock_and_latch_waits_CsvFilePath']
    total_connections_csv_file = config['hyperscalesql_metrics_info']['total_connections_CsvFilePath']

    source = config['azure_source']
    dict_list = []
    server_names = []
    # databases = config['hyperscalesql_metrics_info']['hyperscale_db_names']
    # databases = [item for item in databases if not None]
    # databases = [*set(databases)]
    databases = []
    #Loading db_name from vault
    hyperscale_vault_path = "environment/1/hyperscale"
    hyperscale_vault_keys = ["db"]
    configs = vault_credentials.get_secret_from_vault(hyperscale_vault_path, hyperscale_vault_keys)
    if 'db' in configs:
        hyperscale_db_name = str(configs['db'])
    else:
        logger.error("No db key found")
        raise Exception('No db key found')
    # hyperscale_db_name = config['db']
    databases.append(hyperscale_db_name)
    # databases.sort()
    table_names = []
    timestamps = []

    #### Listing out unique resources for query ######

    # cpu_util_df = pd.DataFrame()
    # total_connections_df = pd.DataFrame()
    # maximum_connections_df = pd.DataFrame()
    # buff_mem_df = pd.DataFrame()
    # query_duration_df = pd.DataFrame()
    # total_lock_and_latch_waits_df = pd.DataFrame()
    # object_causing_latch_contention_df = pd.DataFrame()
    # active_locks_df = pd.DataFrame()
    # az_monitor_df = pd.DataFrame()

    if os.path.exists(cpu_utilization_csv_file):
        cpu_util_df = pd.read_csv(cpu_utilization_csv_file)
        cpu_util_df = cpu_util_df[cpu_util_df['DBName'].isin(databases)]
        server_name = list(cpu_util_df.server_name)
        server_names.extend(server_name)
        timestamp1 = list(cpu_util_df.metric_datetime)
        timestamps.extend(timestamp1)

    if os.path.exists(total_connections_csv_file):
        total_connections_df = pd.read_csv(total_connections_csv_file)
        server_name = list(total_connections_df.server_name)
        server_names.extend(server_name)
        timestamp1 = list(total_connections_df.metric_datetime)
        timestamps.extend(timestamp1)

    if os.path.exists(maximum_connections_csv_file):
        maximum_connections_df = pd.read_csv(maximum_connections_csv_file)
        server_name = list(maximum_connections_df.server_name)
        server_names.extend(server_name)
        timestamp1 = list(maximum_connections_df.metric_datetime)
        timestamps.extend(timestamp1)

    if os.path.exists(buffer_memory_csv_file):
        buff_mem_df = pd.read_csv(buffer_memory_csv_file)
        buff_mem_df = buff_mem_df[buff_mem_df['db_name'].isin(databases)]
        server_name = list(buff_mem_df.server_name)
        server_names.extend(server_name)
        timestamp2 = list(buff_mem_df.metric_datetime)
        timestamps.extend(timestamp2)

    if os.path.exists(query_duration_csv_file):
        query_duration_df = pd.read_csv(query_duration_csv_file)
        query_duration_df = query_duration_df[query_duration_df['sqldatabasesname'].isin(databases)]
        server_name = list(query_duration_df.server_name)
        server_names.extend(server_name)
        timestamp5 = list(query_duration_df.metric_datetime)
        timestamps.extend(timestamp5)
        query_headers = list(query_duration_df.columns)

    if os.path.exists(total_lock_and_latch_waits_csv_file):
        total_lock_and_latch_waits_df = pd.read_csv(total_lock_and_latch_waits_csv_file)
        total_lock_and_latch_waits_df = total_lock_and_latch_waits_df[
            total_lock_and_latch_waits_df['database_name'].isin(databases)]
        server_name = list(total_lock_and_latch_waits_df.server_name)
        server_names.extend(server_name)
        table_name = list(total_lock_and_latch_waits_df.table_name)
        table_names.extend(table_name)
        timestamp6 = list(total_lock_and_latch_waits_df.metric_datetime)
        timestamps.extend(timestamp6)
        table_headers = list(total_lock_and_latch_waits_df.columns)

    if os.path.exists(object_causing_latch_contention_csv_file):
        object_causing_latch_contention_df = pd.read_csv(object_causing_latch_contention_csv_file)
        object_causing_latch_contention_df = object_causing_latch_contention_df[
            object_causing_latch_contention_df['database_name'].isin(databases)]
        server_name = list(object_causing_latch_contention_df.server_name)
        server_names.extend(server_name)
        timestamp7 = list(object_causing_latch_contention_df.metric_datetime)
        timestamps.extend(timestamp7)

    if os.path.exists(active_locks_csv_file):
        active_locks_df = pd.read_csv(active_locks_csv_file)
        server14 = list(active_locks_df.server_name)
        server_names.extend(server14)
        timestamp14 = list(active_locks_df.metric_datetime)
        timestamps.extend(timestamp14)
        lock_headers = list(active_locks_df.columns)

    if os.path.exists(az_monitor_csv):
        az_monitor_df = pd.read_csv(az_monitor_csv)
        az_monitor_df = az_monitor_df[az_monitor_df['sqldatabasesname'].isin(databases)]
        timestamp0 = list(az_monitor_df.start_time)
        timestamps.extend(timestamp0)

    server_names = [item for item in server_names if item is not None]
    server_names = [*set(server_names)]
    server_names.sort()

    timestamps = [item for item in timestamps if item is not None]
    timestamps = list(map(lambda timestp: timestp[0:16], timestamps))
    timestamps = [*set(timestamps)]
    timestamps.sort()

    table_names = [item for item in table_names if item is not None]
    table_names = [*set(table_names)]
    table_names.sort()

    for i in timestamps:
        time = i
        time = datetime.strptime(time, '%Y-%m-%d %H:%M')
        final_output = {}
        servers = []
        for s in server_names:
            server = {'server_name': s}
            # with open(memory_monitor_latch_contention_csv_file) as mem:
            #     heading11 = next(mem)
            #     reader_obj11 = csv.reader(mem)
            #     for row11 in reader_obj11:
            #         if row11[1][0:16] == i and row11[0] == s:
            #             count1 = 2
            #             while count1 <= 10:
            #                 if count1 > 1 and row11[count1] is not None and row11[count1] != '':
            #                     server[memory_headers[count1]] = row11[count1]
            #                 count1 = count1 + 1

            with open(total_connections_csv_file) as tc:
                heading12 = next(tc)
                reader_obj12 = csv.reader(tc)
                for row12 in reader_obj12:
                    if row12[0] == s:
                        server['total_active_connections'] = row12[2]
                        server['client_machines'] = row12[3]

            with open(maximum_connections_csv_file) as mc:
                heading13 = next(mc)
                reader_obj13 = csv.reader(mc)
                for row13 in reader_obj13:
                    if row13[0] == s and row13[1][0:16] == i:
                        server['maximum_connections'] = row13[2]
                        server['login_attempts'] = row13[3]

            database_list = []
            for d in databases:
                db_dict = {'database_name': d}
                tmp_az_df = az_monitor_df[ az_monitor_df['sqldatabasesname'] == d]
                tmp_az_df['start_time'] = [str(ti)[0:16] for ti in tmp_az_df['start_time']]
                tmp_az_df = tmp_az_df[tmp_az_df['start_time'] == i]
                for i_az, r in tmp_az_df.iterrows():
                    db_dict[r['metric_name']] = r['metric_value']
                cpu_slowness_flag = False
                memory_slowness_flag = False
                # unresponsive_flag = False
                with open(cpu_utilization_csv_file) as cpu:
                    heading1 = next(cpu)
                    reader_obj1 = csv.reader(cpu)

                    for row1 in reader_obj1:
                        if row1[1][0:16] == i and row1[2] == d:
                            db_dict['cpu_utilization_time'] = row1[3]
                            db_dict['cpu_utilization_percentage'] = row1[4]
                            if float(row1[4]) > 80:
                                cpu_slowness_flag = True
                with open(buffer_memory_csv_file) as buffer:
                    heading2 = next(buffer)
                    reader_obj2 = csv.reader(buffer)

                    for row2 in reader_obj2:
                        if row2[0] == s and row2[1][0:16] == i and row2[2] == d:
                            db_dict['db_buffer_memory_utilization_MB'] = row2[5]
                            db_dict['db_buffer_memory_utilization_percent'] = row2[6]
                            if float(row2[6]) > 80:
                                memory_slowness_flag = True
                # if cpu_slowness_flag and memory_slowness_flag:
                #     db_dict['database_slowness_status'] = True
                with open(query_duration_csv_file) as run_query:
                    heading4 = next(run_query)
                    reader_obj4 = csv.reader(run_query)
                    queries = []
                    for row4 in reader_obj4:
                        query = {}
                        if row4[3][0:16] == i and row4[2] == d and row4[0] == s:
                            is_query_blocked = None
                            if row4[15] == str(0) or row4[11] is None:
                                is_query_blocked = False
                            elif row4[15] == str(1):
                                is_query_blocked = True
                            # total_elapsed_time=row4[24]
                            # cpu_time=row4[25]
                            # if total_elapsed_time > cpu_time:
                            #     slowness_flag=True
                            # else:
                            #     slowness_flag=False
                            count2 = 4
                            while count2 <= 28:
                                if count2 > 3 and row4[count2] is not None and row4[count2] != '':
                                    query[query_headers[count2]] = row4[count2]
                                count2 = count2 + 1
                            query['is_query_blocked'] = is_query_blocked
                            objects = []
                            if (row4[16] is not None and 'PAGELATCH_' in str(row4[16])):
                                # unresponsive_flag =True
                                query['query_unresponsive_status'] = True
                                with open(object_causing_latch_contention_csv_file) as latch_contention:
                                    heading6 = next(latch_contention)
                                    reader_obj6 = csv.reader(latch_contention)

                                    for row6 in reader_obj6:
                                        object = {}
                                        if row6[0][0:16] == i and row6[2] == d and row6[4] == row4[4] and row6[7] == \
                                                row4[15]:
                                            object['index_name'] = row6[3]
                                            object['object_id'] = row6[4]
                                            object['object_name'] = row6[5]
                                            object['schema_name'] = row6[6]
                                            object['object_session_id'] = row6[7]
                                            object['wait_type'] = row6[8]
                                            object['wait_duration_ms'] = row6[9]
                                            objects.append(object)
                                query['latch_contention_objects'] = objects
                            locks = []
                            if (row4[16] is not None and 'LCK_' in str(row4[16])):
                                # unresponsive_flag =True
                                query['query_unresponsive_status'] = True
                                with open(active_locks_csv_file) as lock_contention:
                                    heading7 = next(lock_contention)
                                    reader_obj7 = csv.reader(lock_contention)

                                    for row7 in reader_obj6:
                                        lock = {}
                                        if row7[1][0:16] == i and row7[4] == d and row7[6] == row4[4] and row7[21] == \
                                                row4[15]:
                                            count4 = 2
                                            while count4 <= 21:
                                                if count4 > 1 and row7[count4] is not None and row7[count4] != '':
                                                    lock[lock_headers[count4]] = row7[count4]
                                                count4 = count4 + 1
                                            locks.append(lock)
                                query['active_locks'] = locks
                            # fetching query_keys and removing wait_type and blocking_session_id as they are already being collected in active_locks and latch_contention_objects
                            query_keys = query.keys()
                            if "wait_type" in query_keys:
                                del query["wait_type"]
                            if "blocking_session_id" in query_keys:
                                del query["blocking_session_id"]
                            queries.append(query)
                    if len(queries) > 0:
                        db_dict['queries'] = queries

                # if unresponsive_flag:
                #     db_dict['database_unresponsive_status']= True
                with open(total_lock_and_latch_waits_csv_file) as lock_latch:
                    heading5 = next(lock_latch)
                    reader_obj5 = csv.reader(lock_latch)
                    waits = []
                    for row5 in reader_obj5:
                        tables = {}
                        if row5[0][0:16] == i and row5[3] == d:
                            # tables['table_name']=row5[4]
                            # tables['index_name']=row5[5]
                            # tables['index_id']=row5[6]
                            # tables['partition_number']=row5[7]
                            # tables['total_row_lock_wait_in_ms']=row5[8]
                            # tables['total_page_lock_wait_in_ms']=row5[9]
                            # tables['total_lock_wait_in_ms']=row5[10]
                            # tables['total_page_latch_wait_in_ms']=row5[11]
                            # tables['total_page_io_latch_wait_in_ms']=row5[12]
                            # tables['total_latch_wait_in_ms']=row5[13]
                            count3 = 4
                            while count3 <= 16:
                                if count3 > 1 and row5[count3] is not None and row5[count3] != '':
                                    tables[table_headers[count3]] = row5[count3]
                                count3 = count3 + 1
                            waits.append(tables)
                    if len(waits) > 0:
                        db_dict['waits'] = waits

                    # db_dict['latch_contention_objects']=objects
                database_list.append(db_dict)
            server['databases'] = database_list
            servers.append(server)

        final_output["source"] = source
        final_output["ts"] = time
        final_output["servers"] = servers
        dict_list.append(final_output)

    # # Bulk insert all dictionaries to MongoDB
    mongo_client = config['mongo_url']
    mongo_db = config['mongo_db']
    mongo_collection = config['hyperscalesql_metrics_info']['mongo_collection']
    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)
    # print(dict_list)
    logger.info('New entry list size for Azure hyperscale = {}'.format(len(dict_list)))
    if len(dict_list) > 0:
        collection.insert_many(dict_list)
        exit_handler(OK_CODE)
    else:
        logger.warn('Zero 0 new entries inserted to mongo db for Azure hyperscale')
        exit_handler(WARNING_CODE)
