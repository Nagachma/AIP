import datetime
import hashlib
import os.path
from datetime import datetime

import numpy as np
import pandas as pd
from pymongo import MongoClient

import csv

from vault_utility_v2 import vault_credentials

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2

def ingest_azure_hyperscalesql_csvs_v2(config, logger, exit_handler):
    # Declarations
    global az_monitor_df, cpu_util_df, buff_mem_df, query_duration_df, total_lock_and_latch_waits_df, object_causing_latch_contention_df, active_locks_df
    az_monitor_csv = config['hyperscalesql_metrics_info']['azure_monitor_hyperscalesql_csv']
    active_locks_csv_file = config['hyperscalesql_metrics_info']['active_locks_CsvFilePath']
    buffer_memory_csv_file = config['hyperscalesql_metrics_info']['buffer_memory_utilization_per_database_CsvFilePath']
    cpu_utilization_csv_file = config['hyperscalesql_metrics_info']['cpu_utilization_CsvFilePath']
    maximum_connections_csv_file = config['hyperscalesql_metrics_info']['maximum_connections_CsvFilePath']
    object_causing_latch_contention_csv_file = config['hyperscalesql_metrics_info'][
        'object_causing_latch_contention_CsvFilePath']
    query_duration_csv_file = config['hyperscalesql_metrics_info']['query_duration_CsvFilePath']
    total_lock_and_latch_waits_csv_file = config['hyperscalesql_metrics_info']['total_lock_and_latch_waits_CsvFilePath']
    total_connections_csv_file = config['hyperscalesql_metrics_info']['total_connections_CsvFilePath']

    # t1 = datetime.now()

    source = config['azure_source']
    dict_list = []
    server_names = []
    databases = []

    # Loading db_name from vault
    hyperscale_vault_path = "environment/1/hyperscalesql"
    hyperscale_vault_keys = ["db_name", "db_host"]
    configs = vault_credentials.get_secret_from_vault(hyperscale_vault_path, hyperscale_vault_keys)
    if 'db_name' in configs:
        hyperscale_db_name = str(configs['db_name'])
    else:
        logger.error("No db key found")
        raise Exception('No db key found')
    if 'db_host' in configs:
        hyperscale_server_name = str(configs['db_host']).split(".")[0]
    else:
        logger.error("No db host found")
        raise Exception('No db host found')
    databases.append(hyperscale_db_name)
    server_names.append(hyperscale_server_name)
    table_names = []

    if os.path.exists(cpu_utilization_csv_file):
        cpu_util_df = pd.read_csv(cpu_utilization_csv_file)
        cpu_util_df["start_time"] = pd.to_datetime(cpu_util_df["start_time"]).dt.strftime(
            '%Y-%m-%d %H:%M')
        cpu_util_df.rename(columns={'DBName': 'dbname', 'CPU_Time(Ms)': 'cpu_utilization_time',
                                    'CPUPercent': 'cpu_utilization_percentage'}, inplace=True)
    db_map1 = {}
    if os.path.exists(buffer_memory_csv_file):
        buff_mem_df = pd.read_csv(buffer_memory_csv_file)
        buff_mem_df["start_time"] = pd.to_datetime(buff_mem_df["start_time"]).dt.strftime('%Y-%m-%d %H:%M')
        buff_mem_df.rename(columns={'db_name': 'dbname', 'db_buffer_MB': 'db_buffer_memory_utilization_MB',
                                    'db_buffer_percent': 'db_buffer_memory_utilization_percent'}, inplace=True)

        temp_df1 = buff_mem_df[['database_id', 'dbname']].copy().groupby(['database_id', 'dbname'],
                                                                         as_index=False).size().drop(['size'], axis=1)
        db_map1 = dict(zip(temp_df1.dbname, temp_df1.database_id))

    if os.path.exists(query_duration_csv_file):
        query_duration_df = pd.read_csv(query_duration_csv_file)
        query_duration_df["start_time"] = pd.to_datetime(query_duration_df["start_time"]).dt.strftime('%Y-%m-%d %H:%M')
        query_duration_df.rename(columns={'sqldatabasesname': 'dbname'}, inplace=True)

    if os.path.exists(total_lock_and_latch_waits_csv_file):
        total_lock_and_latch_waits_df = pd.read_csv(total_lock_and_latch_waits_csv_file)
        total_lock_and_latch_waits_df["start_time"] = pd.to_datetime(
            total_lock_and_latch_waits_df["start_time"]).dt.strftime('%Y-%m-%d %H:%M')
        total_lock_and_latch_waits_df.rename(columns={'database_name': 'dbname'}, inplace=True)
        table_name = list(total_lock_and_latch_waits_df.table_name)
        table_names.extend(table_name)

    if os.path.exists(object_causing_latch_contention_csv_file):
        object_causing_latch_contention_df = pd.read_csv(object_causing_latch_contention_csv_file)
        object_causing_latch_contention_df["start_time"] = pd.to_datetime(
            object_causing_latch_contention_df["start_time"]).dt.strftime('%Y-%m-%d %H:%M')
        object_causing_latch_contention_df.rename(
            columns={'database_name': 'dbname', 'wait_duration_ms': 'latch_wait_duration_ms',
                     'session_id': 'latch_session_id'}, inplace=True)

    if os.path.exists(active_locks_csv_file):
        active_locks_df = pd.read_csv(active_locks_csv_file)
        active_locks_df["start_time"] = pd.to_datetime(active_locks_df["start_time"]).dt.strftime('%Y-%m-%d %H:%M')

    if os.path.exists(total_connections_csv_file):
        total_connections_df = pd.read_csv(total_connections_csv_file)
        total_connections_df["start_time"] = pd.to_datetime(total_connections_df["start_time"]).dt.strftime(
            '%Y-%m-%d %H:%M')

    if os.path.exists(maximum_connections_csv_file):
        maximum_connections_df = pd.read_csv(maximum_connections_csv_file)
        maximum_connections_df["start_time"] = pd.to_datetime(maximum_connections_df["start_time"]).dt.strftime(
            '%Y-%m-%d %H:%M')

    if os.path.exists(az_monitor_csv):
        az_monitor_df = pd.read_csv(az_monitor_csv)
        az_monitor_df = az_monitor_df[az_monitor_df['hyperscalesqlname'].isin(databases)]
        az_monitor_df["start_time"] = pd.to_datetime(az_monitor_df["start_time"]).dt.strftime(
            '%Y-%m-%d %H:%M')

    server_names = [item for item in server_names if not (pd.isnull(item)) == True]
    print("server_names before ", server_names)
    server_names = [*set(server_names)]
    server_names.sort()
    print("server_names ", server_names)

    databases = [item for item in databases if not (pd.isnull(item)) == True]
    databases = [*set(databases)]
    databases.sort()

    timestamps = list(cpu_util_df.start_time) + list(maximum_connections_df.start_time) + list(
        total_connections_df.start_time) + list(active_locks_df.start_time) + list(buff_mem_df.start_time) + list(
        total_lock_and_latch_waits_df.start_time) + list(object_causing_latch_contention_df.start_time) + list(
        az_monitor_df.start_time) + list(query_duration_df.start_time)
    timestamps = [item for item in timestamps if not (pd.isnull(item)) == True]
    timestamps = [*set(timestamps)]
    timestamps.sort()

    table_names = [item for item in table_names if item is not None]
    table_names = [*set(table_names)]
    table_names.sort()

    for i in timestamps:

        timestamp_filtered_cpu_utilization_df = cpu_util_df.loc[cpu_util_df['start_time'] == i]
        timestamp_filtered_active_locks_df = active_locks_df.loc[active_locks_df['start_time'] == i]
        timestamp_filtered_az_monitor_df = az_monitor_df.loc[az_monitor_df['start_time'] == i]
        timestamp_filtered_object_causing_latch_contention_df = object_causing_latch_contention_df.loc[
            object_causing_latch_contention_df['start_time'] == i]
        timestamp_filtered_total_lock_and_latch_waits_df = total_lock_and_latch_waits_df.loc[
            total_lock_and_latch_waits_df['start_time'] == i]
        timestamp_filtered_query_duration_df = query_duration_df.loc[query_duration_df['start_time'] == i]
        timestamp_filtered_buffer_memory_df = buff_mem_df.loc[buff_mem_df['start_time'] == i]
        timestamp_filtered_total_connections_df = total_connections_df.loc[total_connections_df['start_time'] == i]
        timestamp_filtered_maximum_connections_df = maximum_connections_df.loc[
            maximum_connections_df['start_time'] == i]

        timestamp_filtered_cpu_utilization_df = timestamp_filtered_cpu_utilization_df.drop(['start_time'], axis=1)
        timestamp_filtered_active_locks_df = timestamp_filtered_active_locks_df.drop(['start_time'], axis=1)
        timestamp_filtered_az_monitor_df = timestamp_filtered_az_monitor_df.drop(['start_time'], axis=1)
        timestamp_filtered_object_causing_latch_contention_df = timestamp_filtered_object_causing_latch_contention_df.drop(
            ['start_time'], axis=1)
        timestamp_filtered_total_lock_and_latch_waits_df = timestamp_filtered_total_lock_and_latch_waits_df.drop(
            ['start_time'], axis=1)
        timestamp_filtered_query_duration_df = timestamp_filtered_query_duration_df.drop(['start_time'], axis=1)
        timestamp_filtered_buffer_memory_df = timestamp_filtered_buffer_memory_df.drop(['start_time'], axis=1)
        timestamp_filtered_total_connections_df = timestamp_filtered_total_connections_df.drop(['start_time'], axis=1)
        timestamp_filtered_maximum_connections_df = timestamp_filtered_maximum_connections_df.drop(['start_time'],
                                                                                                   axis=1)

        time = i
        time = datetime.strptime(time, '%Y-%m-%d %H:%M')
        final_output = {}
        servers = []
        for s in server_names:
            server = {'server_name': s}

            server_filtered_cpu_utilization_df = timestamp_filtered_cpu_utilization_df
            server_filtered_active_locks_df = timestamp_filtered_active_locks_df.loc[
                timestamp_filtered_active_locks_df['server_name'] == s]
            server_filtered_az_monitor_df = timestamp_filtered_az_monitor_df
            server_filtered_object_causing_latch_contention_df = timestamp_filtered_object_causing_latch_contention_df
            server_filtered_total_lock_and_latch_waits_df = timestamp_filtered_total_lock_and_latch_waits_df
            server_filtered_query_duration_df = timestamp_filtered_query_duration_df.loc[
                timestamp_filtered_query_duration_df['server_name'] == s]
            server_filtered_buffer_memory_df = timestamp_filtered_buffer_memory_df.loc[
                timestamp_filtered_buffer_memory_df['server_name'] == s]
            server_filtered_total_connections_df = timestamp_filtered_total_connections_df.loc[
                timestamp_filtered_total_connections_df['server_name'] == s]
            server_filtered_maximum_connections_df = timestamp_filtered_maximum_connections_df.loc[
                timestamp_filtered_maximum_connections_df['server_name'] == s]

            server_filtered_active_locks_df = server_filtered_active_locks_df.drop(['server_name'], axis=1)
            server_filtered_query_duration_df = server_filtered_query_duration_df.drop(['server_name'], axis=1)
            server_filtered_buffer_memory_df = server_filtered_buffer_memory_df.drop(['server_name'], axis=1)
            server_filtered_total_connections_df = server_filtered_total_connections_df.drop(['server_name'], axis=1)
            server_filtered_maximum_connections_df = server_filtered_maximum_connections_df.drop(['server_name'],
                                                                                                 axis=1)

            ###### Total Connection CSV #######

            server_filtered_total_connections_df.replace(np.nan, 'None', inplace=True)
            total_connection_dict = server_filtered_total_connections_df.to_dict(orient='records')[
                0] if server_filtered_total_connections_df.to_dict(orient='records') else {}
            total_connection_dict = {key: value for key, value in total_connection_dict.items() if
                                     value != 'None' and value != ''}
            server = {**server, **total_connection_dict}

            ####### Maximum Connection CSV ######

            server_filtered_maximum_connections_df.replace(np.nan, 'None', inplace=True)
            maximum_connection_dict = server_filtered_maximum_connections_df.to_dict(orient='records')[
                0] if server_filtered_maximum_connections_df.to_dict(orient='records') else {}
            maximum_connection_dict = {key: value for key, value in maximum_connection_dict.items() if
                                       value != 'None' and value != ''}
            server = {**server, **maximum_connection_dict}

            database_list = []
            for d in databases:
                db_dict = {'database_name': d}
                if db_map1.get(d) is not None:
                    db_dict['database_id'] = db_map1.get(d)
                else:
                    db_dict['database_id'] = hashlib.sha3_256(
                        repr(d).encode('utf-8')).hexdigest()
                cpu_slowness_flag = False
                memory_slowness_flag = False

                database_filtered_az_monitor_df = server_filtered_az_monitor_df.loc[
                    server_filtered_az_monitor_df['hyperscalesqlname'] == d]
                database_filtered_cpu_utilization_df = server_filtered_cpu_utilization_df.loc[
                    server_filtered_cpu_utilization_df['dbname'] == d]
                database_filtered_buffer_memory_df = server_filtered_buffer_memory_df.loc[
                    server_filtered_buffer_memory_df['dbname'] == d]
                database_filtered_query_duration_df = server_filtered_query_duration_df.loc[
                    server_filtered_query_duration_df['dbname'] == d]
                database_filtered_object_causing_latch_contention_df = \
                server_filtered_object_causing_latch_contention_df.loc[
                    server_filtered_object_causing_latch_contention_df['dbname'] == d]
                database_filtered_active_locks_df = server_filtered_active_locks_df
                database_filtered_total_lock_and_latch_waits_df = server_filtered_total_lock_and_latch_waits_df.loc[
                    server_filtered_total_lock_and_latch_waits_df['dbname'] == d]

                database_filtered_az_monitor_df = database_filtered_az_monitor_df.drop(['hyperscalesqlname'], axis=1)
                database_filtered_cpu_utilization_df = database_filtered_cpu_utilization_df.drop(['dbname'], axis=1)
                database_filtered_buffer_memory_df = database_filtered_buffer_memory_df.drop(
                    ['dbname', 'database_id', 'db_buffer_pages', 'cntr_value'], axis=1)
                database_filtered_query_duration_df = database_filtered_query_duration_df.drop(
                    ['dbname', 'database_id'], axis=1)
                database_filtered_object_causing_latch_contention_df = database_filtered_object_causing_latch_contention_df.drop(
                    ['dbname'], axis=1)
                database_filtered_total_lock_and_latch_waits_df = database_filtered_total_lock_and_latch_waits_df.drop(
                    ['dbname', 'database_id'], axis=1)

                ####### Azure Monitor CSV ######

                database_filtered_az_monitor_df.replace(np.nan, 'None', inplace=True)

                for _, row in database_filtered_az_monitor_df.iterrows():
                    metric_name = row['metric_name']
                    metric_value = row['metric_value']

                    if metric_value is not None and metric_value != '':
                        # Create a dictionary for this row
                        result_dict = {metric_name: metric_value}
                        db_dict = {**db_dict, **result_dict}


                ###### CPU UTILIZATION CSV ######
                database_filtered_cpu_utilization_df.replace(np.nan, 'None', inplace=True)
                cpu_utilization_dict = database_filtered_cpu_utilization_df.to_dict(orient='records')[
                    0] if database_filtered_cpu_utilization_df.to_dict(orient='records') else {}
                cpu_utilization_dict = {key: value for key, value in cpu_utilization_dict.items() if
                                        value != 'None' and value != ''}
                db_dict = {**db_dict, **cpu_utilization_dict}

                ###### BUFFER MEMORY CSV ######
                database_filtered_buffer_memory_df.replace(np.nan, 'None', inplace=True)
                buffer_memory_dict = database_filtered_buffer_memory_df.to_dict(orient='records')[
                    0] if database_filtered_buffer_memory_df.to_dict(orient='records') else {}
                buffer_memory_dict = {key: value for key, value in buffer_memory_dict.items() if
                                      value != 'None' and value != ''}
                db_dict = {**db_dict, **buffer_memory_dict}

                ###### QUERY DURATION CSV ######
                database_filtered_query_duration_df.replace(np.nan, 'None', inplace=True)
                queries = []
                for index, row in database_filtered_query_duration_df.iterrows():

                    query = {}
                    is_query_blocked = None
                    if str(row['wait_time']) == str(0) or (
                            row['blocking_session_id'] is None or row['blocking_session_id'] == '0'):
                        is_query_blocked = False
                    else:
                        is_query_blocked = True
                    query['query_id'] = hashlib.sha3_256(
                        repr(row['query_text']).encode('utf-8')).hexdigest()

                    if row['STATUS'] != 'running':
                        query['STATUS'] = 3
                        row = row.drop(['STATUS'])
                    elif row['STATUS'] == 'running':
                        query['STATUS'] = 2
                        row = row.drop(['STATUS'])

                    row_dict = row.to_dict()
                    row_dict = {key: value for key, value in row_dict.items() if
                                value != 'None' and value != ''}
                    query = {**query, **row_dict}
                    query['is_query_blocked'] = is_query_blocked

                    if row['wait_type'] is not None and 'PAGELATCH_' in str(row['wait_type']):
                        query['query_unresponsive_status'] = True
                        session_id_filter_df = database_filtered_object_causing_latch_contention_df.loc[
                            database_filtered_object_causing_latch_contention_df['session_id'] == row[
                                'blocking_session_id']]
                        session_id_filter_df.drop(['session_id'], axis=1)

                        session_id_filter_df.replace(np.nan, 'None', inplace=True)
                        object_causing_latch_contention_list = session_id_filter_df.to_dict(
                            orient='records') if session_id_filter_df.to_dict(orient='records') else []
                        objects = [{key: value for key, value in dict_element.items() if
                                    value != 'None' and value != ''} for
                                   dict_element in object_causing_latch_contention_list]
                        if len(objects) > 0:
                            query['latch_contention_objects'] = objects
                    if row['wait_type'] is not None and 'LCK_' in str(row['wait_type']):
                        query['query_unresponsive_status'] = True
                        session_id_filter_df = database_filtered_active_locks_df.loc[
                            database_filtered_active_locks_df['blocking_session_id'] == row[
                                'blocking_session_id']]
                        session_id_filter_df.drop(['blocking_session_id'], axis=1)

                        session_id_filter_df.replace(np.nan, 'None', inplace=True)
                        active_locks_list = session_id_filter_df.to_dict(
                            orient='records') if session_id_filter_df.to_dict(orient='records') else []
                        locks = [{key: value for key, value in dict_element.items() if
                                  value != 'None' and value != ''} for
                                 dict_element in active_locks_list]
                        if len(locks) > 0:
                            query['active_locks'] = locks
                    queries.append(query)

                if len(queries) > 0:
                    db_dict['queries'] = queries

                # LOCK WAIT CSV
                database_filtered_total_lock_and_latch_waits_df.replace(np.nan, 'None', inplace=True)
                total_lock_and_latch_list = database_filtered_total_lock_and_latch_waits_df.to_dict(
                    orient='records') if database_filtered_buffer_memory_df.to_dict(orient='records') else []
                total_lock_and_latch_list = [{key: value for key, value in dict_element.items() if
                                              value != 'None' and value != ''} for dict_element
                                             in total_lock_and_latch_list]
                if len(total_lock_and_latch_list) > 0:
                    db_dict['waits'] = total_lock_and_latch_list

                    # db_dict['latch_contention_objects']=objects
                database_list.append(db_dict)
            server['databases'] = database_list
            servers.append(server)

        final_output["source"] = source
        final_output["ts"] = time
        if len(servers) > 0:
            final_output["servers"] = servers
            dict_list.append(final_output)

    print("hyperscale object count: {}".format(len(dict_list)))

    # # Bulk insert all dictionaries to MongoDB
    mongo_client = config['mongo_url']
    mongo_db = config['mongo_db']
    mongo_collection = config['hyperscalesql_metrics_info']['mongo_collection']
    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)

    # print(dict_list)
    logger.info('New entry list size for Azure hyperscale = {}'.format(len(dict_list)))
    if len(dict_list) > 0:
        collection.insert_many(dict_list)
        exit_handler(OK_CODE)
    else:
        logger.warn('Zero 0 new entries inserted to mongo db for Azure hyperscale')
        exit_handler(WARNING_CODE)

