import os.path
from datetime import datetime

import pandas as pd
from pymongo import MongoClient
import csv

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2

logger = []
exit_handler = []


def ingest_powerbi_csvs(config, logger, exit_handler):
    # power_bi_csv_file_path = config['powerbi_metrics_info']['powerbi_csv']
    cputime_and_queryduration = config['powerbi_metrics_info']['CpuTimeAndQueryDuration_CsvFilePath']
    failed_refresh = config['powerbi_metrics_info']['FailedRefresh_CsvFilePath']
    log_count = config['powerbi_metrics_info']['LogCount_CsvFilePath']
    succeeded_refresh = config['powerbi_metrics_info']['SucceededRefresh_CsvFilePath']
    unique_succeeded_queries = config['powerbi_metrics_info']['UniqueExecutedQueriesPerUser_CsvFilePath']
    unique_failed_queries = config['powerbi_metrics_info']['UniqueFailedQueriesPerUser_CsvFilePath']
    unique_user = config['powerbi_metrics_info']['UniqueUserCount_CsvFilePath']
    lastaccessed = config['powerbi_metrics_info']['LastAccessed_CsvFilePath']
    cputime_and_queryduration_values = pd.read_csv(cputime_and_queryduration)['ArtifactId'].values
    timestamps = []
    capacity_ids = []
    workspace_names = []
    operation_names = []
    artifact_ids = []
    queries = []
    users = []
    source = config['azure_source']
    mongo_client = config['mongo_url']
    mongo_db = config['mongo_db']
    mongo_collection = config['powerbi_metrics_info']['mongo_collection']
    dict_list = []
    artifact_map1 = None
    artifact_map2 = None
    if os.path.exists(cputime_and_queryduration):
        df = pd.read_csv(cputime_and_queryduration)
        temp_df1 = df[['ArtifactId', 'ArtifactName']].copy().groupby(['ArtifactId', 'ArtifactName'],
                                                                    as_index=False).size().drop(['size'], axis=1)
        temp_df2 = df[['ArtifactId', 'ArtifactKind']].copy().groupby(['ArtifactId', 'ArtifactKind'],
                                                                    as_index=False).size().drop(['size'], axis=1)
        artifact_map1 = dict(zip(temp_df1.ArtifactId, temp_df1.ArtifactName))
        artifact_map2 = dict(zip(temp_df2.ArtifactId, temp_df2.ArtifactKind))
        timeGenerated = list(df.start_time)
        capacityId = list(df.PremiumCapacityId)
        powerBIWorkspaceName = list(df.PowerBIWorkspaceName)
        operationName = list(df.OperationName)
        artifact_id = list(df.ArtifactId)
        query_text = list(df.EventText)
        timestamps.extend(timeGenerated)
        capacity_ids.extend(capacityId)
        workspace_names.extend(powerBIWorkspaceName)
        operation_names.extend(operationName)
        artifact_ids.extend(artifact_id)
        queries.extend(query_text)
    if os.path.exists(failed_refresh):
        df = pd.read_csv(failed_refresh)
        timeGenerated = list(df.start_time)
        capacityId = list(df.PremiumCapacityId)
        powerBIWorkspaceName = list(df.PowerBIWorkspaceName)
        artifact_id = list(df.ArtifactId)
        timestamps.extend(timeGenerated)
        capacity_ids.extend(capacityId)
        workspace_names.extend(powerBIWorkspaceName)
        artifact_ids.extend(artifact_id)
    if os.path.exists(succeeded_refresh):
        df = pd.read_csv(succeeded_refresh)
        timeGenerated = list(df.start_time)
        capacityId = list(df.PremiumCapacityId)
        powerBIWorkspaceName = list(df.PowerBIWorkspaceName)
        artifact_id = list(df.ArtifactId)
        timestamps.extend(timeGenerated)
        capacity_ids.extend(capacityId)
        workspace_names.extend(powerBIWorkspaceName)
        artifact_ids.extend(artifact_id)
    if os.path.exists(log_count):
        df = pd.read_csv(log_count)
        temp_df1 = df[['ArtifactId', 'ArtifactName']].copy().groupby(['ArtifactId', 'ArtifactName'],
                                                                     as_index=False).size().drop(['size'], axis=1)
        temp_df2 = df[['ArtifactId', 'ArtifactKind']].copy().groupby(['ArtifactId', 'ArtifactKind'],
                                                                     as_index=False).size().drop(['size'], axis=1)
        artifact_map1 = dict(zip(temp_df1.ArtifactId, temp_df1.ArtifactName))
        artifact_map2 = dict(zip(temp_df2.ArtifactId, temp_df2.ArtifactKind))
        timeGenerated = list(df.start_time)
        capacityId = list(df.PremiumCapacityId)
        powerBIWorkspaceName = list(df.PowerBIWorkspaceName)
        artifact_id = list(df.ArtifactId)
        # user = list(df.ExecutingUser)
        timestamps.extend(timeGenerated)
        capacity_ids.extend(capacityId)
        workspace_names.extend(powerBIWorkspaceName)
        artifact_ids.extend(artifact_id)
        # users.extend(user)
    if os.path.exists(unique_succeeded_queries):
        df = pd.read_csv(unique_succeeded_queries)
        timeGenerated = list(df.start_time)
        capacityId = list(df.PremiumCapacityId)
        powerBIWorkspaceName = list(df.PowerBIWorkspaceName)
        artifact_id = list(df.ArtifactId)
        user = list(df.ExecutingUser)
        timestamps.extend(timeGenerated)
        capacity_ids.extend(capacityId)
        workspace_names.extend(powerBIWorkspaceName)
        artifact_ids.extend(artifact_id)
        users.extend(user)
    if os.path.exists(unique_failed_queries):
        df = pd.read_csv(unique_failed_queries)
        timeGenerated = list(df.start_time)
        capacityId = list(df.PremiumCapacityId)
        powerBIWorkspaceName = list(df.PowerBIWorkspaceName)
        artifact_id = list(df.ArtifactId)
        user = list(df.ExecutingUser)
        timestamps.extend(timeGenerated)
        capacity_ids.extend(capacityId)
        workspace_names.extend(powerBIWorkspaceName)
        artifact_ids.extend(artifact_id)
        users.extend(user)
    if os.path.exists(unique_user):
        df = pd.read_csv(unique_user)
        timeGenerated = list(df.start_time)
        capacityId = list(df.PremiumCapacityId)
        powerBIWorkspaceName = list(df.PowerBIWorkspaceName)
        artifact_id = list(df.ArtifactId)
        timestamps.extend(timeGenerated)
        capacity_ids.extend(capacityId)
        workspace_names.extend(powerBIWorkspaceName)
        artifact_ids.extend(artifact_id)
    if os.path.exists(lastaccessed):

        lastaccessed_df = pd.read_csv(lastaccessed)
        temp_df1 = lastaccessed_df[['ArtifactId', 'ArtifactName']].copy().groupby(['ArtifactId', 'ArtifactName'],
                                                                     as_index=False).size().drop(['size'], axis=1)
        temp_df2 = lastaccessed_df[['ArtifactId', 'ArtifactKind']].copy().groupby(['ArtifactId', 'ArtifactKind'],
                                                                     as_index=False).size().drop(['size'], axis=1)
        artifact_map1 = dict(zip(temp_df1.ArtifactId, temp_df1.ArtifactName))
        artifact_map2 = dict(zip(temp_df2.ArtifactId, temp_df2.ArtifactKind))
        # timeGenerated = list(df.start_time)
        capacityId = list(lastaccessed_df.PremiumCapacityId)
        powerBIWorkspaceName = list(lastaccessed_df.PowerBIWorkspaceName)
        artifact_id = list(lastaccessed_df.ArtifactId)
        # timestamps.extend(timeGenerated)
        capacity_ids.extend(capacityId)
        workspace_names.extend(powerBIWorkspaceName)
        artifact_ids.extend(artifact_id)
    timestamps = [item for item in timestamps if not (pd.isnull(item)) == True]
    timestamp = list(map(lambda timestp: timestp[0:16], timestamps))
    timestamp = [*set(timestamp)]
    timestamp.sort()

    workspace_names = [item for item in workspace_names if not (pd.isnull(item)) == True]
    workspace_names = [*set(workspace_names)]
    workspace_names.sort()

    operation_names = [item for item in operation_names if not (pd.isnull(item)) == True]
    operation_names = [*set(operation_names)]
    operation_names.sort()

    artifact_ids = [item for item in artifact_ids if not (pd.isnull(item)) == True]
    artifact_ids = [*set(artifact_ids)]
    artifact_ids.sort()
    # artifact_names = [*set(artifact_names)]
    # artifact_names.sort()

    users = [item for item in users if not (pd.isnull(item)) == True]
    users = [*set(users)]
    users.sort()

    capacity_ids = [item for item in capacity_ids if not (pd.isnull(item)) == True]
    capacity_ids = [*set(capacity_ids)]
    capacity_ids.sort()

    queries = [item for item in queries if not (pd.isnull(item)) == True]
    queries = [*set(queries)]
    queries.sort()

    for i in timestamp:
        time = i
        time = datetime.strptime(time, '%Y-%m-%d %H:%M')
        final_output = {}
        final_output['source'] = source
        final_output['ts'] = time
        capacities = []
        for c in capacity_ids:
            capacity = {}
            capacity['premium_capacity_id'] = c
            workspaces = []
            for w in workspace_names:
                workspace = {}
                workspace['powerbi_workspace_name'] = w
                artifacts = []
                for a in artifact_ids:
                    artifact = {}
                    artifact['artifact_id'] = a
                    artifact['artifact_name'] = artifact_map1[a]
                    artifact['artifact_kind'] = artifact_map2[a]

                    with open(lastaccessed) as last_accessed:
                        heading = next(last_accessed)
                        reader_obj4last_accessed = csv.reader(last_accessed)
                        for row4_last_a in reader_obj4last_accessed:
                            if row4_last_a[2] == w and row4_last_a[1] == c and row4_last_a[3] == a:
                                last_accessed_temp = row4_last_a[7]
                                dt = datetime.strptime(last_accessed_temp, "%Y-%m-%d %H:%M:%S.%f%z")
                                year = dt.year
                                month = dt.month
                                day = dt.day
                                last_accessed_timestamp = "{}-{:02d}-{:02d}".format(year, month, day)
                                artifact['last_accessed'] = last_accessed_timestamp
                                artifact['tenant_id'] = row4_last_a[4]
                                artifact['subscription_id'] = row4_last_a[5]

                    with open(log_count) as log:
                        heading = next(log)
                        reader_obj4 = csv.reader(log)
                        for row4 in reader_obj4:
                            if row4[0][0:16] == i and row4[1] == w and row4[2] == c and row4[3] == a :
                                # artifact['subscription_id'] = row4[6]
                                # artifact['tenant_id'] = row4[7]
                                artifact['log_count'] = row4[8]

                    with open(succeeded_refresh) as s_refresh:
                        heading = next(s_refresh)
                        reader_obj00 = csv.reader(s_refresh)
                        for row00 in reader_obj00:
                            if row00[0][0:16] == i and row00[1] == w and row00[2] == c and row00[3] == a:
                                artifact['succeeded_refresh'] = row00[6]

                    with open(failed_refresh) as f_refresh:
                        heading = next(f_refresh)
                        reader_obj11 = csv.reader(f_refresh)
                        for row11 in reader_obj11:
                            if row11[0][0:16] == i and row11[1] == w and row11[2] == c and row11[3] == a:
                                artifact['failed_refresh'] = row11[6]

                    with open(unique_user) as u_user:
                        heading = next(u_user)
                        reader_obj12 = csv.reader(u_user)
                        for row12 in reader_obj12:
                            if row12[0][0:16] == i and row12[1] == w and row12[2] == c and row12[3] == a:
                                artifact['unique_user'] = row12[6]

                    # dax_queries = []
                    # for q in queries:
                    #     dax_query = {}
                    #     with open(cputime_and_queryduration) as execution_time:
                    #         heading = next(execution_time)
                    #         reader_obj1 = csv.reader(execution_time)
                    #         for row1 in reader_obj1:
                    #             if row1[0][0:16] == i and row1[1] == w and row1[2] == c and row1[5] == a and row1[
                    #                 11] == q:
                    #                 dax_query['dataset_mode'] = row1[9]
                    #                 dax_query['executingUser'] = row1[10]
                    #                 dax_query['eventText'] = q
                    #                 dax_query['status'] =row1[12]
                    #                 dax_query['max_cpu_time'] = row1[13]
                    #                 dax_query['max_duration'] = row1[14]
                    #                 dax_query['avg_cpu_time'] = row1[15]
                    #                 dax_query['avg_duration'] = row1[16]
                    #                 dax_queries.append(dax_query)
                    # artifact['dax_queries'] = dax_queries
                    executing_users = []
                    for u in users:
                        executing_user = {}
                        if a in cputime_and_queryduration_values:
                            executing_user['executing_user'] = u
                        with open(unique_succeeded_queries) as s_queries:
                            heading = next(s_queries)
                            reader_obj2 = csv.reader(s_queries)
                            for row2 in reader_obj2:
                                if row2[0][0:16] == i and row2[1] == w and row2[2] == c and row2[3] == a and row2[
                                    6] == u:
                                    executing_user['succeeded_queries'] = row2[7]
                        with open(unique_failed_queries) as f_queries:
                            heading = next(f_queries)
                            reader_obj3 = csv.reader(f_queries)
                            for row3 in reader_obj3:
                                if row3[0][0:16] == i and row3[1] == w and row3[2] == c and row3[3] == a and row3[
                                    6] == u:
                                    executing_user['failed_queries'] = row3[7]
                        # with open(log_count) as log:
                        #     heading = next(log)
                        #     reader_obj4 = csv.reader(log)
                        #     for row4 in reader_obj4:
                        #         if row4[0][0:16] == i and row4[1] == w and row4[2] == c and row4[3] == a and row4[
                        #             6] == u:
                        #             executing_user['log_count'] = row2[6]

                        dax_queries = []
                        for q in queries:
                            dax_query = {}
                            with open(cputime_and_queryduration) as execution_time:
                                heading = next(execution_time)
                                reader_obj1 = csv.reader(execution_time)
                                for row1 in reader_obj1:
                                    if row1[0][0:16] == i and row1[1] == w and row1[2] == c and row1[5] == a and row1[10] == u and row1[
                                        11] == q:
                                        dax_query['dataset_mode'] = row1[9]
                                        # dax_query['executingUser'] = row1[10]
                                        dax_query['executingUser'] = u
                                        dax_query['eventText'] = q
                                        dax_query['status'] = row1[12]
                                        dax_query['max_cpu_time'] = row1[13]
                                        dax_query['max_duration'] = row1[14]
                                        dax_query['avg_cpu_time'] = row1[15]
                                        dax_query['avg_duration'] = row1[16]
                                        dax_queries.append(dax_query)
                        if len(dax_queries)>0:
                            executing_user['dax_queries'] = dax_queries

                        executing_users.append(executing_user)
                    if len(executing_user) != 0:
                        artifact['executing_users'] = executing_users

                    artifacts.append(artifact)
                workspace['artifacts'] = artifacts
                workspaces.append(workspace)
            capacity['workspaces'] = workspaces
            capacities.append(capacity)

        # capacities.append(capacity)
        final_output['capacities'] = capacities
        dict_list.append(final_output)

    # Bulk insert all dictionaries to MongoDB
    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)
    # print(dict_list)
    logger.info(f"New entry list size for ADLS = {len(dict_list)}")
    if len(dict_list) > 0:
        collection.insert_many(dict_list)
        exit_handler(OK_CODE)
    else:
        logger.warn("Zero new entries inserted to mongodb for ADLS")
        exit_handler(WARNING_CODE)
