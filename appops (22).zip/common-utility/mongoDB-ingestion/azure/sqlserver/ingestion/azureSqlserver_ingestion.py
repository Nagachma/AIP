import datetime
from datetime import datetime

import pandas as pd
from pymongo import MongoClient

import csv

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2


def ingest_azure_sqlserver_csvs(config, logger, exit_handler):
    # Declarations
    az_monitor_csv = config['sqldatabases_metrics_info']['azure_monitor_sqlserver_csv']
    custom_csv_Files = config['sqldatabases_metrics_info']['db-connector_csv']
    all_server_names = []
    custom_times = []
    unique_databases = []
    timestamp = []
    source = config['azure_source']
    dict_list = []

    #### Listing out unique resources for query ######
    for csvs in custom_csv_Files:
        # print("loop count = "+ str(cnt+1))
        df_csvFile = pd.read_csv(csvs)
        server_names = list(df_csvFile.server_name)
        headers = list(df_csvFile.columns)
        if "sqldatabasesname" in headers:
            custom_databases = df_csvFile.sqldatabasesname
            unique_databases.extend(custom_databases)
        start_times = list(df_csvFile.metric_datetime)
        all_server_names.extend(server_names)
        # custom_databases.extend(databases)
        custom_times.extend(start_times)
    custom_times = [*set(custom_times)]
    timestamp.extend(custom_times)
    all_server_names = [*set(all_server_names)]
    unique_databases = [*set(unique_databases)]

    # #### Listing out unique servers, databases and timestamps for AZURE MONITOR ######
    df_csvFile = pd.read_csv(az_monitor_csv)
    # # Listing out unique servers
    server_names = list(df_csvFile.server_name)
    databases = list(df_csvFile.sqldatabasesname)
    timestamp.extend(list(df_csvFile.start_time))
    server_name = [*set(server_names)]
    databases = [*set(databases)]

    # # Combining unique servers, timestamps and databases from two sources
    all_server_names.extend(server_name)
    all_server_names = [*set(all_server_names)]

    unique_databases.extend(databases)
    unique_databases = [x for x in unique_databases if str(x) != 'nan']
    unique_databases = [*set(unique_databases)]

    timestamp = list(map(lambda timestp: timestp[0:16], timestamp))
    timestamp = [*set(timestamp)]
    timestamp.sort()

    cc = 0
    for i in timestamp:
        time = i
        time = datetime.strptime(time, '%Y-%m-%d %H:%M')
        final_output = {}

        servers = []
        for j in all_server_names:
            cc = cc + 1
            dict = {"server_name": j, "start_time": time}
            databases_list = []

            for db in unique_databases:
                database = {"database_name": db}
                queries = []

                # Azure monitor csv
                with open(az_monitor_csv) as for_server_name:
                    heading = next(for_server_name)
                    reader_obj = csv.reader(for_server_name)
                    for col in reader_obj:
                        if col[0][0:16] == i and col[3] == j and col[2] == db:

                            value = col[5]
                            metric_name = col[4]

                            if value is None or value == "":
                                pass
                            else:
                                try:
                                    value = float(value)
                                except ValueError as ve:
                                    # non-float value
                                    database[metric_name] = value
                                else:
                                    database[metric_name] = float(value)

                # for query1 in unique_databases:
                for db_csv in custom_csv_Files:
                    df_csvFile2 = pd.read_csv(db_csv)
                    csvFile2_header = list(df_csvFile2.columns)
                    with open(db_csv) as for_values:
                        l_reader_obj = csv.reader(for_values)

                        for l_col in l_reader_obj:
                            query = {"sqldatabasesname": db}
                            size = len(l_col)
                            if len(dict) > 1:
                                if l_col[size - 1][0:16] == i and l_col[size - 3] == j and l_col[size - 2] == db:
                                    row = 0
                                    for k in csvFile2_header:
                                        value = l_col[row]
                                        # print(value)
                                        if value is None or value == '':
                                            pass
                                        else:
                                            try:
                                                value = float(value)
                                            except ValueError as ve:
                                                # non-float value
                                                query[k] = value
                                            else:
                                                # float value if no exception
                                                query[k] = float(value)
                                        row = row + 1

                            if len(query) > 1:
                                queries.append(query)
                if len(queries) > 0:
                    database["queries"] = queries

                if len(database) > 1:
                    databases_list.append(database)
            if len(databases_list) > 0:
                dict['databases'] = databases_list
            servers.append(dict)

        final_output["source"] = source
        final_output["ts"] = time
        final_output["servers"] = servers
        dict_list.append(final_output)

    # # Bulk insert all dictionaries to MongoDB
    mongo_client = config['mongo_url']
    mongo_db = config['mongo_db']
    mongo_collection = config['sqldatabases_metrics_info']['mongo_collection']
    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)
    # print(dict_list)
    logger.info('New entry list size for Azure sql_server = {}'.format(len(dict_list)))
    if len(dict_list) > 0:
        collection.insert_many(dict_list)
        exit_handler(OK_CODE)
    else:
        logger.warn('Zero 0 new entries inserted to mongo db for Azure sql_server')
        exit_handler(WARNING_CODE)
