# import datetime
from datetime import datetime

import pandas as pd
from pymongo import MongoClient

import csv

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2


def ingest_synapse_csvs(config, logger, exit_handler):
    csv_file1 = config['synapse_metrics_info']['azure_monitor_workspace_csv']
    csv_file2 = config['synapse_metrics_info']['azure_monitor_big_data_pools_csv']
    csv_file3 = config['synapse_metrics_info']['azure_monitor_sql_pool_csv']
    csv_file4 = config['synapse_metrics_info']['db_top10longqueries_csv']

    df_csv_file1 = pd.read_csv(csv_file1)
    df_csv_file2 = pd.read_csv(csv_file2)
    df_csv_file3 = pd.read_csv(csv_file3)
    df_csv_file4 = pd.read_csv(csv_file4)

    timestamp = list(df_csv_file1.start_time)
    timestamp.extend(list(df_csv_file2.start_time))
    timestamp.extend(list(df_csv_file3.start_time))
    timestamp.extend(list(df_csv_file4.metric_datetime))
    timestamp = list(map(lambda timestp: timestp[0:16], timestamp))
    timestamp = [*set(timestamp)]
    timestamp.sort()
    # timestamp = ['2022-09-22 12:15:00+00:00']

    # csvFile1_metrics
    workspace_name = []
    workspace_name = list(df_csv_file1.workspace_synapsename)
    workspace_name.extend(list(df_csv_file2.workspace_name))
    workspace_name.extend(list(df_csv_file3.workspace_name))
    workspace_name.extend(list(df_csv_file4.instance_name))
    workspace_name = [*set(workspace_name)]
    dict_list = []
    source = config['azure_source']

    sql_pool_name = []
    sql_pool_name = list(df_csv_file3.sqlpool_synapsename)
    sql_pool_name.extend(list(df_csv_file4.database_name))
    sql_pool_name = [x for x in sql_pool_name if str(x) != 'nan']
    sql_pool_name = [*set(sql_pool_name)]

    big_data_pool_name = []
    big_data_pool_name = list(df_csv_file2.bigdatapools_synapsename)
    big_data_pool_name = [*set(big_data_pool_name)]

    for i in timestamp:
        time = i
        # time = time[0:18]
        time = datetime.strptime(time, '%Y-%m-%d %H:%M')
        # print(time)
        final_output = {}
        name = i
        name = name.replace(" ", "").replace(":", "").replace("-", "")
        name = name[:13]

        workspaces = []

        for j in workspace_name:
            dict = {"workspace_name": j}
            with open(csv_file1) as for_workspace_name:
                heading = next(for_workspace_name)
                reader_obj = csv.reader(for_workspace_name)
                for row in reader_obj:
                    if row[0][0:16] == i and row[2] == j:
                        if row[4] is None or row[4] == '':
                            pass
                        else:
                            try:
                                row[4] = float(row[4])
                            except ValueError as ve:
                                # non-float value
                                metric_name = "Workspace." + row[3]
                                dict[metric_name] = row[4]
                            else:
                                # float value if no exception
                                metric_name = "Workspace." + row[3]
                                dict[metric_name] = float(row[4])
                        # if row[4] != "":
                        #     metric_name = "Workspace." + row[3]
                        #     dict[metric_name] = row[4]

            # # csvFile2_metrics
            bigDataPools = []

            for big_data_pool in big_data_pool_name:
                dict1 = {"big_data_pool_name": big_data_pool}
                with open(csv_file2) as for_big_data_pool_name:
                    heading = next(for_big_data_pool_name)
                    reader_obj = csv.reader(for_big_data_pool_name)
                    for row in reader_obj:
                        if row[0][0:16] == i and row[3] == j and row[2] == big_data_pool:
                            if row[5] is None or row[5] == '':
                                pass
                            else:
                                try:
                                    row[5] = float(row[5])
                                except ValueError as ve:
                                    # non-float value
                                    metric_name = "BigDataPool." + row[4]
                                    dict1[metric_name] = row[5]
                                else:
                                    # float value if no exception
                                    metric_name = "BigDataPool." + row[4]
                                    dict1[metric_name] = float(row[5])
                            # if row[5] != "":
                            #     metric_name = "BigDataPool." + row[4]
                            #     dict1[metric_name] = row[5]
                bigDataPools.append(dict1)

            if bigDataPools is not None and len(bigDataPools) > 0:
                dict["bigDataPools"] = bigDataPools
            # workspaces.append(bigDataPools)

            # csvFile3_metrics
            sqlPools = []

            for sql_pool in sql_pool_name:
                # print(sql_pool)
                dict2 = {"sql_pool_name": sql_pool}
                with open(csv_file3) as for_sql_pool_name:
                    heading = next(for_sql_pool_name)
                    reader_obj = csv.reader(for_sql_pool_name)
                    for row in reader_obj:
                        if row[0][0:16] == i and row[3] == j and row[2] == sql_pool:
                            if row[5] is None or row[5] == '':
                                pass
                            else:
                                try:
                                    row[5] = float(row[5])
                                except ValueError as ve:
                                    # non-float value
                                    metric_name = "SQLPool." + row[4]
                                    dict2[metric_name] = row[5]
                                else:
                                    # float value if no exception
                                    metric_name = "SQLPool." + row[4]
                                    dict2[metric_name] = float(row[5])
                            # if row[5] != "":
                            #     metric_name = "SQLPool." + row[4]
                            #     dict2[metric_name] = row[5]
                list_custom = []
                dict3 = {}
                csvFile4_header = list(df_csv_file4.columns)
                with open(csv_file4) as for_sql_pool_name:
                    heading = next(for_sql_pool_name)
                    reader_obj = csv.reader(for_sql_pool_name)
                    for row in reader_obj:
                        count = 0
                        row_length = len(row)
                        if row[row_length-1][0:16] == i and row[row_length-3] == j and row[row_length-2] == sql_pool:
                            while count < row_length:
                                if count == (row_length - 3) or count == (row_length - 2):
                                    count = count + 1
                                    continue
                                if row[count] is not None and row[count] != '':
                                    dict3[csvFile4_header[count]] = row[count]
                                count = count + 1
                            if dict3 is not None and len(dict3) > 0:
                                list_custom.append(dict3)
                                dict3 = {}
                    if list_custom is not None and len(list_custom) > 0:
                        dict2["queries"] = list_custom
                sqlPools.append(dict2)

            if sqlPools is not None and len(sqlPools) > 0:
                dict["sqlPools"] = sqlPools
            workspaces.append(dict)
            # workspaces.append(sqlPools)

        final_output["source"] = source
        final_output["ts"] = time
        final_output["workspaces"] = workspaces

        dict_list.append(final_output)

    mongo_client = config['mongo_url']
    mongo_db = config['mongo_db']
    mongo_collection = config['synapse_metrics_info']['mongo_collection']

    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)
    # Bulk insert all dictionaries to MongoDB
    # print(final_output)
    logger.info('New entry list size for Azure Synapse = {}'.format(len(dict_list)))
    if len(dict_list) > 0:
        collection.insert_many(dict_list)
        exit_handler(OK_CODE)
    else:
        logger.warn('Zero 0 new entries inserted to mongo db for Azure Synapse')
        exit_handler(WARNING_CODE)
