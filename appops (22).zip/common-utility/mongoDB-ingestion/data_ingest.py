import re
from os import makedirs
#from os import scandir
from os.path import exists
from os.path import isfile as is_file
from os.path import join as join_path
from shutil import copyfile
import pandas as pd
import platform

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2


def clean_data(file, logger):
	"""
	Read file and clean with pandas dataframe. Return cleaned data
	"""
	try:
		data = pd.read_csv(file, lineterminator='\n')
		# data.dropna(inplace=True)

		# Clean headers
		data.columns = data.columns.str.replace('[\n,\r,\t]', '',regex=True)

		# Clean data
		data = data.replace({',': ' '}, regex=True)
		data = data.replace({'\n': ''}, regex=True)
		data = data.replace({'\r': ' '}, regex=True)
		data = data.replace({'\t': ' '}, regex=True)
		data = data.replace({'"': ''}, regex=True)
		data = data.replace({"'": ''}, regex=True)
		data = data.replace({'Infinity': ''}, regex=True)

		# Strip trailing whitespace from all columns
		data = data.applymap(lambda x: x.strip() if isinstance(x, str) else x)
		data = data.applymap(lambda x: round(x, 3) if isinstance(x, float) else x)

		return data
	except pd.errors.EmptyDataError as ede:
		logger.error("Empty Data in csv file: "+ file + " : {repr(ede)}")
		return pd.DataFrame()


def ingest_csv_data(service,config,logger,exit_handler):

	# set platform filesystem seperator
	if platform.system() == 'Windows':
		sep = '\\'
	else:
		sep = '/'

	# Ingestion metrics based on datasource information
	for key, value in config.items():

		service_name = key.split("_")[0].lower()

		if (service.lower() != service_name):
			continue

		# Make ingrestion directories if it doesn't exist
		# TO DO: Check write access to create this directory
		if not exists(value['csv_ingestion_location']):
			makedirs(value['csv_ingestion_location'] )
		if not exists(value['json_ingestion_location']):
			makedirs(value['json_ingestion_location'] )

		# get all possible file locations for where metric CSVs could be (cw, custom, etc.)
		metric_locs = [loc for loc in value.keys() if loc.endswith("_csv_metric_location")]

		for loc in metric_locs:
			metric_type = loc.split("_csv_metric_location")[0]

			if not exists(value[loc]):
				logger.warning("The metric CSV directory for '" + metric_type + "' (" + value[loc] +  ") configured in the '" + service_name + "' section of the config.yaml does not exist.")
				logger.warning("There is nothing to do. Please create the directory and place the correct CSV files here and try again.\n")
				exit_handler(WARNING_CODE)

			# Get list of files from metrics directory
			files = [f for f in scandir(value[loc]) if is_file(join_path(value[loc], f.name))]
			if len(files) == 0:
				logger.warning("The metric CSV directory for '" + metric_type + "' (" + value[loc] +  ") configured in the '" + service_name + "' section of the config.yaml does not contain any files.")
				logger.warning("There is nothing to do. Place the correct CSV files here and try again.\n")
				exit_handler(WARNING_CODE)

			for file in files:
				f_name = file.name.split("_")
				metric_type_len = len(metric_type.split("_")) - 1
				if len(f_name) == 4 + metric_type_len:
					if len(f_name) > 4:
						temp_f_name = file.name.split(metric_type)[1]
						f_name = [metric_type] + temp_f_name.split("_")[1:]
					if f_name[0] != metric_type or f_name[1] != service_name or f_name[2] != "metrics" or not f_name[3].split(".")[0].isnumeric() or f_name[3].split(".")[1] != "csv":
						logger.warning("Removing the file called '"+ file.name + "' from  the list of files to process as it does not follow the proper naming convention.")
						logger.warning("The file name should be in this format: <metric_type>_<service_name>_metrics_<date(YYYYMMDD)>.")
						files.remove(file)
				else:
					logger.warning("Removing the file called '"+ file.name + "' from list of files to process as it does not follow the proper naming convention.")
					logger.warning("The file name should be in this format: <metric_type>_<service_name>_metrics_<date(YYYYMMDD)>.")
					files.remove(file)

			if len(files) == 0:
				logger.warning("The metric CSV directory for '" + metric_type + "' (" + value[loc] +  ") configured in the '" + service_name + "' section of the config.yaml does not contain any files with the correct name.")
				logger.warning("There is nothing to do. Place the correct CSV files here and try again.\n")
				exit_handler(WARNING_CODE)


			# we only want the most recent file
			file = max(files, key=lambda f: f.stat().st_mtime)
			file = file.path

			# Clean and prepare the file for ingestion
			# Set correct prefix
			if value['csv_ingestion_prefix'] != None:
				csv_ingestion_prefix = metric_type + "_" + value['csv_ingestion_prefix']
			else:
				csv_ingestion_prefix = metric_type + "_" + '_'.join(file.split(sep)[-1].split('_')[:-1])

			# If there is no previous file, pass on file as diff file
			prev_file_path = value['csv_ingestion_location'] + csv_ingestion_prefix + '_prev.csv'
			if not exists(prev_file_path) or (re.search(r'^\s*$', open(prev_file_path, 'r').read())):
				df = clean_data(file, logger)
				df.to_csv(value['csv_ingestion_location'] + csv_ingestion_prefix + '_prev.csv', index=False)
				copyfile(value['csv_ingestion_location'] + csv_ingestion_prefix + '_prev.csv', value['csv_ingestion_location'] + csv_ingestion_prefix + '_diff.csv')

			# If there is a previous file, compare and record the differences and then replace it
			else:
				prev_df = pd.read_csv(prev_file_path)
				prev_df = prev_df.applymap(lambda x: round(x, 3) if isinstance(x, float) else x)
				new_df = clean_data(file, logger)
				diff_df = pd.concat([prev_df,prev_df,new_df]).drop_duplicates(keep=False)
				# this is only for sqlserver & hyperscale
				# TODO: uncomment for above mentioned serives
				# diff_df_columns=list(diff_df.columns)
				# new_diff_df=pd.DataFrame()
				# print("Metric type is : ",metric_type)
				# if len(list(diff_df.index))>0:
				# 	new_diff_df = pd.DataFrame(columns=diff_df_columns)
				# 	for i,r in diff_df.iterrows():
				# 		if r['start_time'] in list(prev_df.start_time) :
				# 			continue
				# 		else:
				# 			# new_diff_df.append(r)
				# 			new_diff_df=pd.concat([new_diff_df, r.to_frame().T])
				# else:
				# 	new_diff_df = diff_df
				# check to see if timestamp in new file is present in previously processed data.

				if service_name != 'awsdatabricks':
					ts_col = value.get('timestamp_columns', {}).get(metric_type)
					if ts_col is None:
						if ("start_time" in diff_df and diff_df["start_time"].isin(prev_df["start_time"]).any()) or ("Start Time" in diff_df and diff_df["Start Time"].isin(prev_df["Start Time"]).any()):
							logger.error(
								"'" + file + "' contains metrics with a timestamp that has already been processed.\n")
							exit_handler(ERROR_CODE)
					else:
						if ts_col in diff_df and diff_df[ts_col].isin(prev_df[ts_col]).any():
							logger.error("'" + file + "' contains metrics with a timestamp that has already been processed.\n")
							exit_handler(ERROR_CODE)

				new_df.to_csv(value['csv_ingestion_location'] + csv_ingestion_prefix + '_prev.csv', index=False)
				diff_df.to_csv(value['csv_ingestion_location'] + csv_ingestion_prefix + '_diff.csv', index=False)
