# import datetime
import re
from datetime import datetime

import pandas as pd
from pymongo import MongoClient

import csv

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2


def ingest_bigquery_csvs(config, logger, exit_handler):
    csv_file = config['bigquery_metrics_info']['gcp_metadata_csv']
    csv_file1 = config['bigquery_metrics_info']['project_csv']
    csv_file2 = config['bigquery_metrics_info']['datasets_csv']
    csv_file3 = config['bigquery_metrics_info']['tables_csv']

    df_csv_file = pd.read_csv(csv_file)
    df_csv_file1 = pd.read_csv(csv_file1)
    df_csv_file2 = pd.read_csv(csv_file2)
    df_csv_file3 = pd.read_csv(csv_file3)

    timestamp = list(df_csv_file1.start_time)
    timestamp.extend(list(df_csv_file2.start_time))
    timestamp.extend(list(df_csv_file3.start_time))
    timestamp.extend(list(df_csv_file.start_time))
    timestamp = [*set(timestamp)]
    timestamp = list(map(lambda timestp: timestp[0:16], timestamp))
    timestamp.sort()

    # csvFile1_metrics
    project_id = []
    project_id = list(df_csv_file1.project_id)
    project_id.extend(list(df_csv_file2.project_id))
    project_id.extend(list(df_csv_file3.project_id))
    project_id = [*set(project_id)]
    project_id.sort()

    dataset_id = []
    dataset_id = list(df_csv_file2.dataset_id)
    dataset_id.extend(list(df_csv_file3.dataset_id))
    dataset_id = [*set(dataset_id)]
    dataset_id.sort()

    tbl = []
    tbl = list(df_csv_file3.table)
    tbl = [*set(tbl)]
    table = []
    for t in tbl:
        table.append(str(t))
    table.sort()

    dict_list = []
    source = config['gcp_source']

    for i in timestamp:
        time = i
        time = datetime.strptime(time, '%Y-%m-%d %H:%M')

        final_output = {}
        name = i
        name = name.replace(" ", "").replace(":", "").replace("-", "")
        name = name[:13]

        projects = []
        dict1 = {}
        dict2 = {}
        list_dataset = []

        for j in project_id:
            dict = {"project_id": j}
            with open(csv_file1) as for_next:
                heading = next(for_next)
                reader_obj = csv.reader(for_next)
                for row in reader_obj:
                    if row[0][0:16] == i and row[2] == j:
                        if row[5] is None or row[5] == '':
                            pass
                        else:
                            try:
                                row[5] = float(row[5])
                            except ValueError as ve:
                                # non-float value
                                metric_name = row[4]
                                dict[metric_name] = row[5]
                            else:
                                # float value if no exception
                                metric_name = row[4]
                                dict[metric_name] = float(row[5])

            for d in dataset_id:
                list_table = []
                dict1 = {}
                with open(csv_file2) as for_next:
                    heading = next(for_next)
                    reader_obj = csv.reader(for_next)
                    for row in reader_obj:
                        if row[0][0:16] == i and row[2] == j and row[3] == d:
                            dict1 = {"dataset_id": d}
                            if row[6] is None or row[6] == '':
                                pass
                            else:
                                try:
                                    row[6] = float(row[6])
                                except ValueError as ve:
                                    # non-float value
                                    metric_name = row[5]
                                    dict1[metric_name] = row[6]
                                else:
                                    # float value if no exception
                                    metric_name = row[5]
                                    dict1[metric_name] = float(row[6])

                if dict1 is not None and len(dict1) > 0:
                    for t in table:
                        dict2 = {}
                        with open(csv_file3) as for_next:
                            heading = next(for_next)
                            reader_obj = csv.reader(for_next)
                            for row in reader_obj:
                                if row[0][0:16] == i and row[2] == j and row[3] == d and row[4] == t:
                                    dict2 = {"table_name": t}
                                    if row[7] is None or row[7] == '':
                                        pass
                                    else:
                                        try:
                                            row[7] = float(row[7])
                                        except ValueError as ve:
                                            # non-float value
                                            metric_name = row[6]
                                            dict2[metric_name] = row[7]
                                        else:
                                            # float value if no exception
                                            metric_name = row[6]
                                            dict2[metric_name] = float(row[7])
                            if dict2 is not None and len(dict2) > 0:
                                list_table.append(dict2)
                if list_table is not None and len(list_table) > 0:
                    dict1["table"] = list_table
                if dict1 is not None and len(dict1) > 0:
                    list_dataset.append(dict1)
            if list_dataset is not None and len(list_dataset) > 0:
                dict["datasets"] = list_dataset
            csvFile_header = list(df_csv_file.columns)
            list_jobs = []
            with open(csv_file) as for_next:
                heading = next(for_next)
                reader_obj = csv.reader(for_next)
                for row in reader_obj:
                    dict3 = {}
                    count = 1
                    r = row[15].replace(": ", " ").replace("  ", " ").replace("[{", "").replace("}]", "")
                    s = r.split(" ")
                    if row[22][0:16] == i and row[0] == j:
                        while count < (len(row) - 3):
                            if count == 14:
                                count = count + 1
                                continue
                            if row[count] is not None and row[count] != '' and row[count] != '[]' and row[count] != '{}':
                                dict3[csvFile_header[count]] = row[count]
                            count = count + 1
                        if dict3 is not None and len(dict3) > 0:
                            list_jobs.append(dict3)
            if list_jobs is not None and len(list_jobs) > 0:
                dict["jobs"] = list_jobs
            projects.append(dict)


        final_output["source"] = source
        final_output["ts"] = time
        final_output["projects"] = projects

        dict_list.append(final_output)

    mongo_client = config['mongo_url_dev']
    mongo_db = config['mongo_db']
    mongo_collection = config['bigquery_metrics_info']['mongo_collection']

    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)
    # Bulk insert all dictionaries to MongoDB
    # print(final_output)
    logger.info('New entry list size for GCP BigQuery = {}'.format(len(dict_list)))
    if len(dict_list) > 0:
        collection.insert_many(dict_list)
        exit_handler(OK_CODE)
    else:
        logger.warn('Zero 0 new entries inserted to mongo db for BigQuery')
        exit_handler(WARNING_CODE)
