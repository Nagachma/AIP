"""
Module to ingest csvs to mongo db.
"""
import pandas as pd

from pymongo import MongoClient
from datetime import datetime

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2


def preprocess_start_time(df):
    df['start_time'] = [start_time[:-9] if start_time[-1] != 'Z' else str(start_time[:-4]).replace('T', ' ')
                        for start_time in df['start_time']]
    return df


def ingest_cloud_scheduler_csvs(config, logger, exit_handler):
    csv_file_path = config['cloudscheduler_metrics_info']['jobs_csv']
    custom_csv_file_path = config['cloudscheduler_metrics_info']['jobsfailure_csv']

    jobs_df = pd.read_csv(csv_file_path)

    jobs_failure_df = pd.read_csv(custom_csv_file_path)

    job_names = list(set(list(jobs_df.job_id) + list(jobs_failure_df.job_id)))

    job_names.sort()

    jobs_df = preprocess_start_time(jobs_df)

    jobs_failure_df = preprocess_start_time(jobs_failure_df)

    timestamp = [*set(list(jobs_df.start_time) + list(jobs_failure_df.start_time))]
    timestamp.sort()

    source = config['gcp_source']

    mongo_client = config['mongo_url']
    mongo_db = config['mongo_db']
    mongo_collection = config['cloudscheduler_metrics_info']['mongo_collection']

    dict_list = []
    for i in timestamp:
        cloud_scheduler_metrics = []
        final_output = {}

        time = i
        time = datetime.strptime(time, '%Y-%m-%d %H:%M')
        final_output['source'] = source
        final_output['ts'] = time
        for j in job_names:
            temp_dict = {'job_id': j}
            temp_jobs = jobs_df.where((jobs_df["job_id"] == j) & (jobs_df["start_time"] == i)).dropna()
            temp_jobs_failure = jobs_failure_df \
                .where((jobs_failure_df["job_id"] == j) & (jobs_failure_df["start_time"] == i)).dropna()
            if not temp_jobs.empty:
                for metric_name, metric_value in zip(temp_jobs.metric_name, temp_jobs.metric_value):
                    temp_dict[metric_name] = metric_value
            if not temp_jobs_failure.empty:
                temp_dict['job_start_count'] = list(temp_jobs_failure.job_start_count)[0]
                temp_dict['job_failure_count'] = list(temp_jobs_failure.job_failure_count)[0]
                temp_dict['job_failure_rate'] = list(temp_jobs_failure.job_failure_rate)[0]
            cloud_scheduler_metrics.append(temp_dict)

        if len(cloud_scheduler_metrics) > 0:
            final_output['jobs'] = cloud_scheduler_metrics
        dict_list.append(final_output)

    # Bulk insert all dictionaries to MongoDB
    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)

    logger.info(f"New entry list size for Cloud Scheduler = {len(dict_list)}")
    if len(dict_list) > 0:
        collection.insert_many(dict_list)
        exit_handler(OK_CODE)
    else:
        logger.warn("Zero new entries inserted to mongodb for Cloud Scheduler")
        exit_handler(WARNING_CODE)
