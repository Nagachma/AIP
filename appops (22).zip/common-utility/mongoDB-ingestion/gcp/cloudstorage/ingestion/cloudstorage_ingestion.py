import os.path
import uuid
from datetime import datetime

import pandas as pd
from pymongo import MongoClient

import csv

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2

logger = []
exit_handler = []


def ingest_cloudstorage_csvs(config, logger, exit_handler):
    generalcsvFilePath = config['cloudstorage_metrics_info']['cloudstorage_general_csv']
    responsecsvFilePath = config['cloudstorage_metrics_info']['cloudstorage_errorstatus_csv']
    latencycsvFilePath = config['cloudstorage_metrics_info']['cloudstorage_latency_csv']
    timestamp=[]
    buckets=[]
    responses=[]
    if os.path.exists(generalcsvFilePath):
        df1 = pd.read_csv(generalcsvFilePath)
        # header = list(df.columns)
        # Get names of the buckets and metric names, removing duplicates.
        cloudstorage_bucket_name = list(df1.bucket_name)
        buckets.extend(cloudstorage_bucket_name)
        timestamp1 = list(df1.start_time)
        timestamp.extend(timestamp1)
    if os.path.exists(responsecsvFilePath):
        df2 =pd.read_csv(responsecsvFilePath)
        cloudstorage_bucket_name = list(df2.bucket_name)
        buckets.extend(cloudstorage_bucket_name)
        timestamp2 = list(df2.start_time)
        timestamp.extend(timestamp2)
        response_code=list(df2.response_code)
        responses.extend(response_code)

    if os.path.exists(latencycsvFilePath):
        df3= pd.read_csv(latencycsvFilePath)
        cloudstorage_bucket_name = list(df3.bucket_name)
        buckets.extend(cloudstorage_bucket_name)
        timestamp3 = list(df3.start_time)
        timestamp.extend(timestamp3)

    new_list = [item for item in timestamp if not (pd.isnull(item)) == True]
    new_list= list(map(lambda timestp: timestp[0:16], new_list))  # Remove seconds and timezone.
    new_list.sort()
    timestamps = [*set(new_list)]
    cloudstorage_bucket_names = [*set([item for item in buckets if not (pd.isnull(item)) == True])]
    response_codes=[*set(responses)]
    response_codes.sort()
    source = config['gcp_source']

    mongo_client = config['mongo_url']
    mongo_db = config['mongo_db']
    mongo_collection = config['cloudstorage_metrics_info']['mongo_collection']

    dict_list = []
    for i in timestamps:
        cloudstorage_metrics = []
        final_output = {}

        time = i
        time = datetime.strptime(time, '%Y-%m-%d %H:%M')
        final_output['source'] = source
        final_output['ts'] = time
        for m in cloudstorage_bucket_names:
            dict1 = {}
            with open(generalcsvFilePath) as cloudstoragevalues:
                heading = next(cloudstoragevalues)
                reader_obj = csv.reader(cloudstoragevalues)
                for row in reader_obj:
                    # If timestamp and bucket name match, add start time, end time, and value to bucket dict.
                    if row[0][0:16] == i and row[3] == m:
                        # dict1 = {'bucket_name': m}
                        dict1['bucket_name'] = m
                        dict1['start_time'] = row[0]
                        dict1['end_time'] = row[1]
                        value = row[6]
                        dict1[row[5]] = value

                # cloudstorage_metrics.append(dict1)
            with open(latencycsvFilePath) as latencies:
                heading = next(latencies)
                reader_obj = csv.reader(latencies)
                for row in reader_obj:
                    if row[0][0:16] == i and row[1] == m and row[2] !='' and row[3] !='' and row[4] !='' and row[5] !='':
                        dict1['upload_latency']= row[2]
                        dict1['download_latency']= row[3]
                        dict1['delete_latency']= row[4]
                        dict1['metadata_latency']= row[5]

            dict1['has_errors'] = False
            errors_response = []
            with open(responsecsvFilePath) as errors:
                heading= next(errors)
                reader_obj = csv.reader(errors)
                for row in reader_obj:
                    error = {}
                    if row[0][0:16] == i and row[3] == m and row[4]!='OK':
                        dict1['has_errors'] = True
                        error['uuid'] = uuid.uuid4().hex
                        error['start_time']= row[0][0:16]
                        error['end_time']= row[0][0:16]
                        value = row[7]
                        error[row[6]] = value
                        error['response_code'] = row[4]
                        if error:
                            errors_response.append(error)

            if len(errors_response) > 0:
                dict1['responses']=errors_response

            if dict1:
                cloudstorage_metrics.append(dict1)
        if len(cloudstorage_metrics) > 0:
            final_output['buckets'] = cloudstorage_metrics
        dict_list.append(final_output)

    # Bulk insert all dictionaries to MongoDB
    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)
    # print(dict_list)
    logger.info(f"New entry list size for ADLS = {len(dict_list)}")
    if len(dict_list) > 0:
        collection.insert_many(dict_list)
        exit_handler(OK_CODE)
    else:
        logger.warn("Zero new entries inserted to mongodb for ADLS")
        exit_handler(WARNING_CODE)
