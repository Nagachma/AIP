# import datetime
import re
from datetime import datetime

import pandas as pd
from pymongo import MongoClient

import csv

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2


def ingest_composer_csvs(config, logger, exit_handler):
    csv_file1 = config['composer_metrics_info']['api_csv']
    csv_file2 = config['composer_metrics_info']['environment_csv']
    csv_file3 = config['composer_metrics_info']['pool_csv']
    csv_file4 = config['composer_metrics_info']['queue_csv']
    csv_file5 = config['composer_metrics_info']['state_csv']
    csv_file6 = config['composer_metrics_info']['task_csv']
    csv_file7 = config['composer_metrics_info']['type_csv']
    csv_file8 = config['composer_metrics_info']['webserver_csv']
    csv_file9 = config['composer_metrics_info']['workflow_csv']

    df_csv_file1 = pd.read_csv(csv_file1)
    df_csv_file2 = pd.read_csv(csv_file2)
    df_csv_file3 = pd.read_csv(csv_file3)
    df_csv_file4 = pd.read_csv(csv_file4)
    df_csv_file5 = pd.read_csv(csv_file5)
    df_csv_file6 = pd.read_csv(csv_file6)
    df_csv_file7 = pd.read_csv(csv_file7)
    df_csv_file8 = pd.read_csv(csv_file8)
    df_csv_file9 = pd.read_csv(csv_file9)

    timestamp = list(df_csv_file1.start_time)
    timestamp.extend(list(df_csv_file2.start_time))
    timestamp.extend(list(df_csv_file3.start_time))
    timestamp.extend(list(df_csv_file4.start_time))
    timestamp.extend(list(df_csv_file5.start_time))
    timestamp.extend(list(df_csv_file6.start_time))
    timestamp.extend(list(df_csv_file7.start_time))
    timestamp.extend(list(df_csv_file8.start_time))
    timestamp.extend(list(df_csv_file9.start_time))
    timestamp = [*set(timestamp)]
    timestamp = list(map(lambda timestp: timestp[0:16], timestamp))
    timestamp.sort()

    # csvFile1_metrics
    project_id = []
    project_id = list(df_csv_file1.project_id)
    project_id.extend(list(df_csv_file2.project_id))
    project_id.extend(list(df_csv_file3.project_id))
    project_id.extend(list(df_csv_file4.project_id))
    project_id.extend(list(df_csv_file5.project_id))
    project_id.extend(list(df_csv_file6.project_id))
    project_id.extend(list(df_csv_file7.project_id))
    project_id.extend(list(df_csv_file8.project_id))
    project_id.extend(list(df_csv_file9.project_id))
    project_id = [*set(project_id)]
    project_id.sort()

    environment_name = []
    environment_name = list(df_csv_file1.environment_name)
    environment_name.extend(list(df_csv_file2.environment_name))
    environment_name.extend(list(df_csv_file3.environment_name))
    environment_name.extend(list(df_csv_file4.environment_name))
    environment_name.extend(list(df_csv_file5.environment_name))
    environment_name.extend(list(df_csv_file7.environment_name))
    environment_name.extend(list(df_csv_file8.environment_name))
    environment_name = [*set(environment_name)]
    environment_name.sort()

    pl = []
    pl = list(df_csv_file3.pool_name)
    pl = [*set(pl)]
    pools = []
    for p in pl:
        pools.append(str(p))
    pools.sort()

    queues = []
    queues = list(df_csv_file4.queue_name)
    queues = [*set(queues)]
    queues.sort()

    webservers = []
    webservers = list(df_csv_file8.instance_id)
    webservers = [*set(webservers)]
    webservers.sort()

    workflows = []
    workflows = list(df_csv_file6.workflow_name)
    workflows = list(df_csv_file9.workflow_name)
    workflows = [*set(workflows)]
    workflows.sort()

    tasks = []
    tasks = list(df_csv_file6.task_name)
    tasks = [*set(tasks)]
    tasks.sort()

    dict_list = []
    source = config['gcp_source']

    for i in timestamp:
        time = i
        time = datetime.strptime(time, '%Y-%m-%d %H:%M')

        final_output = {}
        name = i
        name = name.replace(" ", "").replace(":", "").replace("-", "")
        name = name[:13]

        projects = []
        environment = {}

        list_environment = []
        list_pool = []
        list_queue = []
        list_webserver = []
        list_workflow = []
        list_task = []

        for j in project_id:
            dict = {"project_id": j}
            for e in environment_name:
                environment["environment_name"] = e
                with open(csv_file1) as for_next:
                    heading = next(for_next)
                    reader_obj = csv.reader(for_next)
                    for row in reader_obj:
                        if row[0][0:16] == i and row[2] == j and row[4] == e:
                            if row[7] is None or row[7] == '':
                                pass
                            else:
                                try:
                                    row[7] = float(row[7])
                                except ValueError as ve:
                                    # non-float value
                                    metric_name = row[6]
                                    environment[metric_name] = row[7]
                                    if row[3] is not None or row[3] != '':
                                        environment["environment_api_request_status"] = row[3]
                                else:
                                    # float value if no exception
                                    metric_name = row[6]
                                    environment[metric_name] = float(row[7])
                                    if row[3] is not None or row[3] != '':
                                        environment["environment_api_request_status"] = row[3]

                with open(csv_file2) as for_next:
                    heading = next(for_next)
                    reader_obj = csv.reader(for_next)
                    for row in reader_obj:
                        if row[0][0:16] == i and row[2] == j and row[3] == e:
                            if row[6] is None or row[6] == '':
                                pass
                            else:
                                try:
                                    row[6] = float(row[6])
                                except ValueError as ve:
                                    # non-float value
                                    metric_name = row[5]
                                    environment[metric_name] = row[6]
                                else:
                                    # float value if no exception
                                    metric_name = row[5]
                                    environment[metric_name] = float(row[6])

                with open(csv_file5) as for_next:
                    heading = next(for_next)
                    reader_obj = csv.reader(for_next)
                    for row in reader_obj:
                        if row[0][0:16] == i and row[2] == j and row[3] == e:
                            if row[7] is None or row[7] == '':
                                pass
                            else:
                                try:
                                    row[7] = float(row[7])
                                except ValueError as ve:
                                    # non-float value
                                    metric_name = row[6]
                                    environment[metric_name] = row[7]
                                else:
                                    # float value if no exception
                                    metric_name = row[6]
                                    environment[metric_name] = float(row[7])

                with open(csv_file7) as for_next:
                    heading = next(for_next)
                    reader_obj = csv.reader(for_next)
                    for row in reader_obj:
                        if row[0][0:16] == i and row[2] == j and row[3] == e:
                            if row[6] is None or row[6] == '':
                                pass
                            else:
                                try:
                                    row[6] = float(row[6])
                                except ValueError as ve:
                                    # non-float value
                                    metric_name = row[5]
                                    environment[metric_name] = row[6]
                                else:
                                    # float value if no exception
                                    metric_name = row[5]
                                    environment[metric_name] = float(row[6])

                for p in pools:
                    pool = {"pool_name": p}
                    with open(csv_file3) as for_next:
                        heading = next(for_next)
                        reader_obj = csv.reader(for_next)
                        for row in reader_obj:
                            if row[0][0:16] == i and row[2] == j and row[3] == e and row[4] == p:
                                if row[7] is None or row[7] == '':
                                    pass
                                else:
                                    try:
                                        row[7] = float(row[7])
                                    except ValueError as ve:
                                        # non-float value
                                        metric_name = row[6]
                                        pool[metric_name] = row[7]
                                    else:
                                        # float value if no exception
                                        metric_name = row[6]
                                        pool[metric_name] = float(row[7])
                    if pool is not None and len(pool) > 1:
                        list_pool.append(pool)
                if list_pool is not None and len(list_pool) > 0:
                    environment["pools"] = list_pool

                for q in queues:
                    queue = {"queue_name": q}
                    with open(csv_file4) as for_next:
                        heading = next(for_next)
                        reader_obj = csv.reader(for_next)
                        for row in reader_obj:
                            if row[0][0:16] == i and row[2] == j and row[3] == e and row[4] == q:
                                if row[7] is None or row[7] == '':
                                    pass
                                else:
                                    try:
                                        row[7] = float(row[7])
                                    except ValueError as ve:
                                        # non-float value
                                        metric_name = row[6]
                                        queue[metric_name] = row[7]
                                    else:
                                        # float value if no exception
                                        metric_name = row[6]
                                        queue[metric_name] = float(row[7])
                    if queue is not None and len(queue) > 1:
                        list_queue.append(queue)
                if list_queue is not None and len(list_queue) > 0:
                    environment["queues"] = list_queue

                for w in webservers:
                    webserver = {"instance_id": w}
                    with open(csv_file8) as for_next:
                        heading = next(for_next)
                        reader_obj = csv.reader(for_next)
                        for row in reader_obj:
                            if row[0][0:16] == i and row[2] == j and row[3] == e and row[4] == w:
                                if row[7] is None or row[7] == '':
                                    pass
                                else:
                                    try:
                                        row[7] = float(row[7])
                                    except ValueError as ve:
                                        # non-float value
                                        metric_name = row[6]
                                        webserver[metric_name] = row[7]
                                    else:
                                        # float value if no exception
                                        metric_name = row[6]
                                        webserver[metric_name] = float(row[7])
                    if webserver is not None and len(webserver) > 1:
                        list_webserver.append(webserver)
                if list_webserver is not None and len(list_webserver) > 0:
                    environment["webservers"] = list_webserver

                for work in workflows:
                    workflow = {"workflow_name": work}
                    with open(csv_file9) as for_next:
                        heading = next(for_next)
                        reader_obj = csv.reader(for_next)
                        for row in reader_obj:
                            if row[0][0:16] == i and row[2] == j and row[3] == work and row[3].split(".")[0] == e:
                                if row[7] is None or row[7] == '':
                                    pass
                                else:
                                    try:
                                        row[7] = float(row[7])
                                    except ValueError as ve:
                                        # non-float value
                                        metric_name = row[6]
                                        workflow[metric_name] = row[7]
                                        if row[4] is not None or row[4] != '':
                                            workflow["workflow_run_status"] = row[4]
                                    else:
                                        # float value if no exception
                                        metric_name = row[6]
                                        workflow[metric_name] = float(row[7])
                                        if row[4] is not None or row[4] != '':
                                            workflow["workflow_run_status"] = row[4]
                        for t in tasks:
                            task = {"task_name": t}
                            with open(csv_file6) as for_next:
                                heading = next(for_next)
                                reader_obj = csv.reader(for_next)
                                for row in reader_obj:
                                    if row[0][0:16] == i and row[2] == j and row[3] == work and row[5] == t and row[3].split(".")[0] == e:
                                        if row[9] is None or row[9] == '':
                                            pass
                                        else:
                                            try:
                                                row[9] = float(row[9])
                                            except ValueError as ve:
                                                # non-float value
                                                metric_name = row[8]
                                                task[metric_name] = row[9]
                                                if row[4] is not None or row[4] != '':
                                                    task["workflow_task_run_state"] = row[4]
                                            else:
                                                # float value if no exception
                                                metric_name = row[8]
                                                task[metric_name] = float(row[9])
                                                if row[4] is not None or row[4] != '':
                                                    task["workflow_task_run_state"] = row[4]
                            if task is not None and len(task) > 1:
                                list_task.append(task)
                        if list_task is not None and len(list_task) > 0:
                            workflow["tasks"] = list_task
                    if workflow is not None and len(workflow) > 1:
                        list_workflow.append(workflow)
                if list_workflow is not None and len(list_workflow) > 0:
                    environment["workflows"] = list_workflow

                if environment is not None and len(environment) > 1:
                    list_environment.append(environment)
            if list_environment is not None and len(list_environment) > 0:
                dict["environments"] = list_environment

            if dict is not None and len(dict) > 0:
                projects.append(dict)

        final_output["source"] = source
        final_output["ts"] = time
        final_output["projects"] = projects

        dict_list.append(final_output)

    mongo_client = config['mongo_url_dev']
    mongo_db = config['mongo_db']
    mongo_collection = config['composer_metrics_info']['mongo_collection']

    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)
    # Bulk insert all dictionaries to MongoDB
    # print(final_output)
    logger.info('New entry list size for GCP Composer = {}'.format(len(dict_list)))
    if len(dict_list) > 0:
        collection.insert_many(dict_list)
        exit_handler(OK_CODE)
    else:
        logger.warn('Zero 0 new entries inserted to mongo db for Composer')
        exit_handler(WARNING_CODE)
