from cProfile import run
import csv
from gc import collect
import json
import os
from matplotlib import collections
import pandas as pd
import yaml
from pymongo import MongoClient
from datetime import timezone, datetime
import datetime


# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2

def ingest_dataflow_csvs(config,logger,exit_handler):

    # Declarations
    jobs_csv = config['dataflow_metrics_info']['jobs_csv']
    endpoints_csv = config['dataflow_metrics_info']['endpoints_csv']
    workers_csv = config['dataflow_metrics_info']['workers_csv']
    pubsub_csv = config['dataflow_metrics_info']['pubsubs_csv']

    unique_jobs=[]
    source = config['gcp_source']
    dict_list=[]

    #Reading the csv files
    df_csvFile1 = pd.read_csv(jobs_csv)
    df_csvFile2 = pd.read_csv(endpoints_csv)
    df_csvFile3 = pd.read_csv(workers_csv)
    df_csvFile4 = pd.read_csv(pubsub_csv)

    #Unique timestamps
    timestamp = list(df_csvFile1.start_time)
    timestamp.extend(df_csvFile2.start_time)
    timestamp.extend(df_csvFile3.start_time)
    timestamp.extend(df_csvFile4.start_time)

    timestamp = list(map(lambda timestp: timestp[0:16], timestamp))
    timestamp = [*set(timestamp)]
    timestamp.sort()

    #Unique Job Ids
    job_ids=list(df_csvFile1.job_id)
    job_ids.extend(df_csvFile3.job_id)
    job_ids = [*set(job_ids)]

    #Unique worker ids
    worker_ids=list(df_csvFile3.worker_id)
    worker_ids = [*set(worker_ids)]

    #Unique endpoints
    endpoint_name=list(df_csvFile2.endpoint)
    endpoint_name = [*set(endpoint_name)]

    #Unique pubsub topic ids
    topic_ids=list(df_csvFile4.topic_id)
    topic_ids = [*set(topic_ids)]

    
    for i in timestamp:
        time = i
        time = datetime.datetime.strptime(time, '%Y-%m-%d %H:%M')
        final_output = {}
        project_id=""

        jobs = []
        for j in job_ids:
            dict={}
            dict["JobId"] = j
            job_headers = list(df_csvFile1.columns)
            #JOB CSV Read
            with open(jobs_csv) as for_job_ids:
                heading = next(for_job_ids)
                reader_obj = csv.reader(for_job_ids)
                for row in reader_obj:
                    if (row[job_headers.index("start_time")][0:16] == i and row[job_headers.index("job_id")] == j):
                        dict["JobName"] = row[job_headers.index("job_name")]
                        dict["start_time"] = row[job_headers.index("start_time")]
                        # project_id=row[job_headers.index("project_id")]
                        value = row[job_headers.index("metric_value")]
                        metric_name = row[job_headers.index("metric_name")]
                        if value is None or value == '':
                            pass
                        else:
                            try:
                                value = float(value)
                            except ValueError as ve:
                                # non-float value
                                dict[metric_name] = row[job_headers.index("metric_value")]
                            else:
                                # float value if no exception
                                dict[metric_name] = float(value)
            
            for t in topic_ids:
                pubsub_headers = list(df_csvFile4.columns)
                pubsub={}
                pubsub["TopicId"] = t
                with open(pubsub_csv) as for_topic_ids:
                    heading = next(for_topic_ids)
                    reader_obj = csv.reader(for_topic_ids)
                    for row in reader_obj:
                        if (row[pubsub_headers.index("start_time")][0:16] == i and row[pubsub_headers.index("job_id")] == j and row[pubsub_headers.index("topic_id")] == t):
                            # pubsub["JobName"] = row[3]
                            value = row[pubsub_headers.index("metric_value")]
                            metric_name = row[pubsub_headers.index("metric_name")]
                            if value is None or value == '':
                                pass
                            else:
                                try:
                                    value = float(value)
                                except ValueError as ve:
                                    # non-float value
                                    pubsub[metric_name] = row[pubsub_headers.index("metric_value")]
                                else:
                                    # float value if no exception
                                    pubsub[metric_name] = float(value)
                            y=0
                            if "pubsubs" not in dict:
                                isempty=True
                                dict["pubsubs"]=[]
                            else:
                                isempty=False
                                dict["pubsubs"]
                            if(isempty==False):
                                temp=dict["pubsubs"]
                                for x in range(len(dict["pubsubs"])):
                                    if list(temp[x].keys())[0] == list(pubsub.keys())[0] and list(temp[x].values())[0] == list(pubsub.values())[0]:
                                        dict_old = temp[x].copy()
                                        temp.pop(x)
                                        pubsub = {**dict_old, **pubsub}
                                        temp.append(pubsub)
                                        dict["pubsubs"]=temp
                                        y = 1
                                        break
                            if(y==0):
                                dict["pubsubs"].append(pubsub)

            for w in worker_ids:
                worker_headers = list(df_csvFile3.columns)
                worker={}
                worker["WorkerId"] = w
                with open(workers_csv) as for_worker_ids:
                    heading = next(for_worker_ids)
                    reader_obj = csv.reader(for_worker_ids)
                    for row in reader_obj:
                        if (row[worker_headers.index("start_time")][0:16] == i and row[worker_headers.index("job_id")] == j and row[worker_headers.index("worker_id")] == w):
                            # worker["JobName"] = row[3]
                            value = row[worker_headers.index("metric_value")]
                            metric_name = row[worker_headers.index("metric_name")]
                            if value is None or value == '':
                                pass
                            else:
                                try:
                                    value = float(value)
                                except ValueError as ve:
                                    # non-float value
                                    worker[metric_name] = row[worker_headers.index("metric_value")]
                                else:
                                    # float value if no exception
                                    worker[metric_name] = float(value)
                            y=0
                            if "workers" not in dict:
                                isempty=True
                                dict["workers"]=[]
                            else:
                                isempty=False
                                dict["workers"]
                            if(isempty==False):
                                temp=dict["workers"]
                                for x in range(len(dict["workers"])):
                                    if list(temp[x].keys())[0] == list(worker.keys())[0] and list(temp[x].values())[0] == list(worker.values())[0]:
                                        dict_old = temp[x].copy()
                                        temp.pop(x)
                                        worker = {**dict_old, **worker}
                                        temp.append(worker)
                                        dict["workers"]=temp
                                        y = 1
                                        break
                            if(y==0):
                                dict["workers"].append(worker)
            if(len(dict)>1):
                jobs.append(dict)
        
        endpoints = []
        for e in endpoint_name:
            endpoint_headers = list(df_csvFile2.columns)
            dict = {}
            dict["EndpointName"] = e
            with open(endpoints_csv) as for_endpoint_names:
                heading = next(for_endpoint_names)
                reader_obj = csv.reader(for_endpoint_names)
                for row in reader_obj:
                    if (row[endpoint_headers.index("start_time")][0:16] == i and row[endpoint_headers.index("endpoint")] == e):
                        # dict["Job Name"] = row[3]
                        value = row[endpoint_headers.index("metric_value")]
                        metric_name = row[endpoint_headers.index("metric_name")]
                        if value is None or value == '':
                            pass
                        else:
                            try:
                                value = float(value)
                            except ValueError as ve:
                                # non-float value
                                dict[metric_name] = row[endpoint_headers.index("metric_value")]
                            else:
                                # float value if no exception
                                dict[metric_name] = float(value)
            if(len(dict)>1):
                endpoints.append(dict)

        final_output["source"] = source
        final_output["ts"] = time
        final_output["jobs"] = jobs
        final_output["endpoints"] = endpoints
        dict_list.append(final_output)
    

    # Bulk insert all dictionaries to MongoDB
    mongo_client = config['mongo_url_qa']
    mongo_db = config['mongo_db']
    mongo_collection = config['dataflow_metrics_info']['mongo_collection'] 
    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)
    logger.info('New entry list size for Dataflow = {}'.format(len(dict_list)))  
    if len(dict_list) > 0:
        collection.insert_many(dict_list)
        exit_handler(OK_CODE)
    else:
        logger.warn('Zero 0 new entries inserted to mongo db for Dataflow')
        exit_handler(WARNING_CODE)

    