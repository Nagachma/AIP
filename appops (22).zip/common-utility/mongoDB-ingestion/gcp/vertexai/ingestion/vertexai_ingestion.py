from datetime import datetime
import pandas as pd
from pymongo import MongoClient

import csv

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2

logger = []
exit_handler = []


def ingest_vertexai_csvs(config, logger, exit_handler):
    endpoint_csv = config['vertexai_metrics_info']['endpoint_csv_metric_location']
    training_csv = config['vertexai_metrics_info']['training_csv_metric_location']
    featurestore_csv = config['vertexai_metrics_info']['featurestore_csv_metric_location']


    df = pd.read_csv(endpoint_csv)
    endpoint_id_name = list(df.endpoint_id)
    endpoint_id_name = [*set(endpoint_id_name)]
    endpoint_id_name.sort()

    df2 = pd.read_csv(training_csv)
    job_id_name = list(df2.job_id)
    job_id_name = [*set(job_id_name)]
    job_id_name.sort()

    df3 = pd.read_csv(featurestore_csv)
    featurestore_id_name = list(df3.featurestore_id)
    featurestore_id_name = [*set(featurestore_id_name)]
    featurestore_id_name.sort()

    endpoint_id_name = list(df.endpoint_id)
    endpoint_id_name = [*set(endpoint_id_name)]
    endpoint_id_name.sort()

    job_id_name = list(df2.job_id)
    job_id_name = [*set(job_id_name)]
    job_id_name.sort()


    ###########
    timestamp = list(df.start_time)
    timestamp = [*set(timestamp)]
    timestamp = list(map(lambda timestp: timestp[0:16], timestamp))

    timestamp2 = list(df2.start_time)
    timestamp2 = [*set(timestamp2)]
    timestamp2 = list(map(lambda timestp: timestp[0:16], timestamp2))

    timestamp3 = list(df3.start_time)
    timestamp3 = [*set(timestamp3)]
    timestamp3 = list(map(lambda timestp: timestp[0:16], timestamp3))

    timestamp.extend(timestamp2)
    timestamp = [*set(timestamp)]
    timestamp.sort()

    timestamp.extend(timestamp3)
    timestamp = [*set(timestamp)]
    timestamp.sort()

    ################
    source = config['gcp_source']
    dict_list = []

    for i in timestamp:

        final_output = {}
        time = i
        time = datetime.strptime(time, '%Y-%m-%d %H:%M')
        final_output['source'] = source
        final_output['ts'] = time
        endpoint_metrics = []
        for m in endpoint_id_name:
            dict1 = {'endpoint_id': m}
            with open (endpoint_csv) as endpointvalues:#with open('C:\\Users\\ross.charles.nitura\\PycharmProjects\\pythonProject_test\\MongoDB-ingestion\\gcp\\vertexai\\metrics\\gcpm\\endpoint\\endpoint_vertexai_metrics_20230124.csv') as endpointvalues:
                heading = next(endpointvalues)
                reader_obj = csv.reader(endpointvalues)
                for row in reader_obj:
                    # If timestamp and bucket name match, add start time, end time, and value to bucket dict.
                    if row[0][0:16] == str(i) and row[4] == str(m):
                        dict1['start_time'] = row[0]
                        dict1['end_time'] = row[1]
                        dict1['project_id']= row[2]
                        dict1['deployed_model_id'] = row[3]
                        value = row[7]
                        dict1[row[6]] = value
                endpoint_metrics.append(dict1)

            if len(endpoint_metrics) > 1:
                final_output['endpoints'] = endpoint_metrics

        jobid_metrics = []
        for n in job_id_name:
            dict2 = {'job_id': n}
            with open (training_csv) as trainingvalues:
                heading2 = next(trainingvalues)
                reader_obj2 = csv.reader(trainingvalues)
                for row2 in reader_obj2:
                    # If timestamp and bucket name match, add start time, end time, and value to bucket dict.
                    if row2[0][0:16] == str(i) and row2[3] == str(n):
                        dict2['start_time'] = row2[0]
                        dict2['end_time'] = row2[1]
                        dict2['project_id'] = row2[2]
                        value2 = row2[6]
                        dict2[row2[5]] = value2
                jobid_metrics.append(dict2)

            if len(jobid_metrics) > 1:
                final_output['training'] = jobid_metrics

        featurestore_metrics = []
        for n in featurestore_id_name:
            dict3 = {'job_id': n}
            with open(featurestore_csv) as featurestorevaluesvalues:
                heading3 = next(featurestorevaluesvalues)
                reader_obj3 = csv.reader(featurestorevaluesvalues)
                for row3 in reader_obj3:
                    # If timestamp and bucket name match, add start time, end time, and value to bucket dict.
                    if row3[0][0:16] == str(i) and row3[3] == str(n):
                        dict3['start_time'] = row3[0]
                        dict3['end_time'] = row3[1]
                        dict3['project_id'] = row3[2]
                        value3 = row3[6]
                        dict3[row3[5]] = value3
                featurestore_metrics.append(dict3)

            if len(featurestore_metrics) > 1:
                final_output['featurestore'] = featurestore_metrics

        final_output["training"] = jobid_metrics
        final_output["endpoints"] = endpoint_metrics
        final_output['featurestore'] = featurestore_metrics
        dict_list.append(final_output)

    # Bulk insert all dictionaries to MongoDB
    mongo_client = config['mongo_url_dev']
    mongo_db = config['mongo_db']
    mongo_collection = config['vertexai_metrics_info']['mongo_collection']
    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)
    logger.info('New entry list size for Vertex AI = {}'.format(len(dict_list)))
    if len(dict_list) > 0:
        collection.insert_many(dict_list)
        exit_handler(OK_CODE)
    else:
        logger.warn('Zero 0 new entries inserted to mongo db for Vertex AI')
        exit_handler(WARNING_CODE)
