import logging
from datetime import datetime
from getpass import getuser as get_user
from os import access as check_access
from os import makedirs
from os import R_OK,W_OK
from os import system as system_call
from os.path import exists
from os.path import isfile as is_file
from os.path import isdir as is_directory
from os.path import join as join_path
from os.path import dirname,realpath
from sys import argv
from sys import exit as exit_python
import mysql.connector
from MongoUtil import MongoUtil

from vault_utility_v2 import vault_credentials
from yaml import safe_load as load_yaml_file
from yaml import YAMLError

from thirdpartytools.sqlserver_on_vm.ingestion.sqlserver_on_vm_ingestion import ingest_sqlserver_csvs
from data_ingest import clean_data,ingest_csv_data
from aws.Lambda.ingestion.lambda_ingestion import find_index_of_list_of_dicts_by_value,ingest_lambda_csvs
from aws.glue.ingestion.glue_ingestion_v1 import ingest_glue_csvs
from aws.s3.ingestion.s3_ingestion import ingest_s3_csvs
from aws.sagemaker.ingestion.sagemaker_ingestion_v1 import ingest_sagemaker_csvs
from aws.redshift.ingestion.redshift_ingestion_optimized import ingest_redshift_csvs
from aws.rds_oracle.ingestion.rds_oracle_ingestion import ingest_rds_oracle_csvs
from azure.synapse.ingestion.synapse_ingestion import ingest_synapse_csvs
from azure.adls.ingestion.adls_ingestion import ingest_adls_csvs
from azure.azure_ml.ingestion.azureML_ingestion import ingest_azure_ml_csvs
from azure.databricks.ingestion.databricks_ingestion  import ingest_databricks_csvs
from azure.aks.ingestion.aks_ingestion import ingest_aks_csvs
from azure.sqlserver.ingestion.azureSqlserver_ingestion import ingest_azure_sqlserver_csvs
from azure.datafactory.ingestion.datafactory_ingestion import ingest_datafactory_csvs
from azure.blobfuse.ingestion.azureBlobfuse_ingestion import ingest_azure_blobfuse_csvs
from gcp.cloudstorage.ingestion.cloudstorage_ingestion import ingest_cloudstorage_csvs
from gcp.dataflow.ingestion.dataflow_ingestion import ingest_dataflow_csvs
from gcp.bigquery.ingestion.bigquery_ingestion import ingest_bigquery_csvs
from gcp.cloudscheduler.ingestion.cloudscheduler_ingestion import ingest_cloud_scheduler_csvs
from gcp.composer.ingestion.composer_ingestion import ingest_composer_csvs
from gcp.vertexai.ingestion.vertexai_ingestion import ingest_vertexai_csvs
from thirdpartytools.tableau.ingestion.tableau_ingestion_v3 import ingest_tableau_csvs
from thirdpartytools.postgres.ingestion.postgres_ingestion_v1 import ingest_postgres_metrics
from thirdpartytools.ropen.ingestion.ropen_ingestion import ingest_ropen_csvs
from thirdpartytools.mongo.ingestion.mongo_ingestion import ingest_mongo_csvs
from thirdpartytools.redis.ingestion.redis_ingestion import ingest_redis_csvs
from thirdpartytools.linux.ingestion.linux_ingestion import ingest_linux_csvs
from thirdpartytools.informatica.ingestion.informatica_ingestion import ingest_informatica_csvs
from thirdpartytools.informaticapowerexchange.ingestion.informaticapowerexchange_ingestion import ingest_powerexchange_csvs
from thirdpartytools.informaticastatuschecker.ingestion.informatica_status_checker import ingest_service_status_csvs
from azure.power_bi.ingestion.power_bi_ingestion import ingest_powerbi_csvs
from azure.azure_cache_redis.ingestion.azure_cache_redis_ingestion import ingest_azurecacheredis_csvs
from thirdpartytools.dm_dcs.ingestion.conn_disk_ingestion import ingest_disk_csvs
from azure.hyperscalesql.ingestion.hyperscale_optimized import ingest_azure_hyperscalesql_csvs_v2
from thirdpartytools.sftp.ingestion.sftp_ingestion import ingest_sftp_csvs
from thirdpartytools.informaticawindows.ingestion.informaticawindows_ingestion import ingest_informaticawindows_csvs
from aws.aws_databricks.ingestion.aws_databricks_ingestion import ingest_aws_databricks_csvs
# get the actual logging object specific to this program
logger = logging.getLogger(__name__)
# set default logging level to INFO
logger.setLevel(logging.INFO)

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2



def update_xops_hearbeat(error_code):
    '''
    Update the heartbeat status of the service in Xops DB

    Args: status code of the service ingestion process
    '''
    # Database connection configuration from vault
    xops_cred = vault_credentials.get_secret_from_vault(config['xops_vault_path'], config['xops_vault_keys'])
    jdbc_url = xops_cred.get('jdbc-url') if xops_cred.get('jdbc-url') else ""
    connect_detail = {
        'host': jdbc_url.split("/")[-2].split(":")[0],
        'user': xops_cred.get('username') if xops_cred.get('username') else "",
        'password': xops_cred.get('password') if xops_cred.get('password') else "",
        'database': jdbc_url.split("/")[-1]
    }
    
    # Basic ids from configs
    env = config['database_env']
    organization_id = config['organization_id']
    sub_organization_id = config['sub_organization_id']
    service_name = config[service+'_metrics_info']['alias']

    try:
        # Establish a connection
        conn = mysql.connector.connect(**connect_detail)
        cursor = conn.cursor()
        
        # Find the environment_id id from xops
        env_query = "select environment_id from environments where environment_name= %s and organization_id= %s and sub_organization_id= %s"
        cursor.execute(env_query, (str(env), str(organization_id), str(sub_organization_id)))
        environment_id = cursor.fetchone()[0]

        
        # Find the service id from xops
        service_id_query = "SELECT service_id FROM services WHERE LOWER(service_name) = %s"
        cursor.execute(service_id_query, (service_name.lower(),))
        service_id = cursor.fetchall()
        if len(service_id) > 0:
            service_id = service_id[0][0]
        else:
            service_id = ''

        if error_code in [OK_CODE, WARNING_CODE]:
            check_query="SELECT * from {} where service_id = %s".format(config['service_heart_beat_table'])
            cursor.execute(check_query,(service_id,))
            results = cursor.fetchall()
            current_time = datetime.utcnow()
            
            if not results:
                # Query for insert
                insert_query = "INSERT INTO {} (service_id, environment_id,successfull_ingestion_time,insert_timestamp,inserted_by,updated_by) VALUES (%s, %s, %s, %s, %s, %s)".format(config['service_heart_beat_table'])
                data_to_insert = (service_id, environment_id, current_time,current_time,'Appops Code','Appops Code')
                cursor.execute(insert_query, data_to_insert)
                logger.info("Status Updated in Xops Database: Insertion")
            else:
                # Query for update
                update_query = "UPDATE {} SET successfull_ingestion_time = %s , update_timestamp = %s WHERE environment_id = %s and service_id = %s".format(config['service_heart_beat_table'])
                
                # Values to update and the condition
                update_values = (current_time,current_time,environment_id,service_id)
                
                # Execute Query
                cursor.execute(update_query, update_values)
                logger.info("Status Updated in Xops Database: Updated")
            
            # Commit the changes
            conn.commit()

    except Exception as e:
        logger.error(f"Exception occured while sending heartbeat for service [{service}]: {e}")
    finally:
        # Close Connection
        cursor.close()
        conn.close()
        logger.info('Xops Connection closed')


def send_heartbeat(error_code):
    '''
    Update the heartbeat status of the service in MongoDB

    Args: status code of the service ingestion process
    '''
    mongo_util = None
    try:
        mongo_util = MongoUtil(config['mongo_url'], config['mongo_db'], config['heartbeat_collection'], logger)
        new_connector = {
            "connector": service,
            "status_code": error_code
        }
        update_connector = {
            "connectors.$.status_code": error_code
        }
        # update last successful time only if ingestion is successful or there are no new records
        if error_code in [OK_CODE, WARNING_CODE]:
            current_time = datetime.utcnow()
            new_connector["last_successful_ingestion_time"] = current_time
            update_connector["connectors.$.last_successful_ingestion_time"] = current_time

        if mongo_util.count() == 0:
            # Collection is empty, insert the first document
            first_connector = {
                "connectors": [
                    new_connector
                ]
            }
            mongo_util.insert(first_connector)
        else:
            # Check if connector already exists
            existing_connector = mongo_util.read({"connectors.connector": service})

            if existing_connector:
                # Update existing connector's info
                mongo_util.upsert(
                    {"connectors.connector": service},
                    {"$set": update_connector}
                )
            else:
                # Insert new connector
                mongo_util.upsert({}, {"$push": {"connectors": new_connector}})

    except Exception as e:
        logger.error(f"Exception occured while sending heartbeat for service [{service}]: {e}")

    finally:
        if mongo_util: mongo_util.close_connection()


def exit_handler(error_code=OK_CODE):
    # check to see if logger has file handler attached
    if len(logger.handlers) == 1 and isinstance(logger.handlers[0],logging.FileHandler):
        if error_code == ERROR_CODE:
            logger.error("Program failed due to Error. See Above Error for more details.")
        elif error_code == WARNING_CODE:
            logger.warning("Program finished with Warning(s). See Above Warning(s) for more details.")
        else:
            logger.info("Program finished successfully.")

        # get filename
        log_filename = logger.handlers[0].baseFilename
        # close the file
        logger.handlers[0].close()
        # remove the handler, as no use to us closed
        logger.removeHandler(logger.handlers[0])
    else:
        log_filename = ""

    if log_filename != "":
        if error_code == ERROR_CODE:
            logger.error("Program failed due to Error. Please check logs (" + log_filename + ") for more details.")
        elif error_code == WARNING_CODE:
            logger.warning("Program finished with Warnings. Please check logs (" + log_filename + ") for more details.")
        else:
            logger.info("Program finished successfully.")
    else:
        if error_code == ERROR_CODE:
            logger.error("\nProgram failed due to Error.")
        elif error_code == WARNING_CODE:
            logger.warning("\nProgram finished with Warnings.")
        else:
            logger.info("\nProgram finished successfully.")

    update_xops_hearbeat(error_code)
    send_heartbeat(error_code)

    exit_python()

def create_log_handler():
    # get the current date and time
    cur_date = datetime.today()
    service_name = argv[1].strip().lower()
    pwd = dirname(realpath(__file__))
    log_dirname = "logs"
    log_dir = join_path(pwd,log_dirname)
    log_filename = "mongoDB-ingestion_" + cur_date.strftime('%Y-%m-%d_%H-%M') + f"_{service_name}.log"
    log_file = join_path(log_dir,log_filename)

    if not exists(log_dir):
        if not check_access(pwd,W_OK):
            logger.error("ERROR: Logging directory '"+ log_dir +"' does not exist and user '"+ get_user() +"' does not have WRITE access to create it.")
            logger.error("ERROR: Please create this directory or run this program with a user who has WRITE access and try again.")
            exit_handler(ERROR_CODE)
        else:
            makedirs(log_dir,mode=0o755)

    if not is_directory(log_dir):
        logger.error("ERROR: Logging directory '"+ log_dir +"' exists but is a file instead of a directory.")
        logger.error("ERROR: Please re-create this as a directory and try again.")
        exit_handler(ERROR_CODE)
    else:
        if not check_access(log_dir,W_OK):
            logger.error("ERROR: The user '"+ get_user() +"' does not have WRITE access to create the log file inside of the logging directory '" + log_dir + "'.")
            logger.error("ERROR: Please update permissions on this directory or run this program with a user who has WRITE access and try again.")
            exit_handler(ERROR_CODE)

    # create a FileHandler for log to be written to
    handler = logging.FileHandler(log_file,mode='w')
    # set the format of log mesages to '[YYYY-MM-DD hh:mm:ss.mls] Level: Message'
    handler.setFormatter(logging.Formatter("[%(asctime)s.%(msecs).03d] %(levelname)s: %(message)s",'%Y-%m-%d %H:%M:%S'))
    # add the handler to the logger
    logger.addHandler(handler)

def load_cfg(config):
    """
    Read and load data from config.yaml file
    """
    with open(config, 'r') as stream:
        try:
            cfg = {}
            cfg = load_yaml_file(stream)
        except YAMLError as e:
            logger.error("YAML config loading error: " + str(e) + "\n")
            exit_handler(ERROR_CODE)
        else:
            return cfg

def pre_error_handling(config_filename):
    if len(argv) - 1 < 1:
        logger.error("To run this program you need to pass in a name of a single cloud service as an argument.")
        logger.error("You did not pass any arguments. Please add one and try again.\n")
        exit_handler(ERROR_CODE)
    elif len(argv) -1 > 1:
        logger.error("To run this program you need to pass in a name of a single cloud service as an argument.")
        logger.error("You passed in more than 1 argument. Please remove any extra and try again.\n")
        exit_handler(ERROR_CODE)

    service = argv[1].strip().lower()
    valid_services = ["glue","s3","lambda","sagemaker","synapse","adls","hyperscalesql","azureml","aks","datafactory","databricks","cloudstorage","dataflow","bigquery","cloudscheduler", "sqldatabases","composer","vertexai", "tableau", "redshift", "rdsoracle", "postgres", "ropen", "mongodb","sqlserver","redis", "linux","informatica","powerexchangejvm","informaticajvm","informaticastatuschecker","powerbi", "disk","sftp", "azurecacheredis","blobfuse","informaticawindows","awsdatabricks"]
    if service not in valid_services:
        logger.error("The service name you provided is not in list of valid services that this program supports.")
        logger.error("Please double check your spelling and try again.\n")
        logger.info("Valid Services:")
        for index, serv in enumerate(valid_services):
            if index == len(valid_services) - 1:
                logger.info("\t" + serv + "\n")
            else:
                logger.info("\t" + serv)
        exit_handler(ERROR_CODE)

    pwd = dirname(realpath(__file__))
    config_file = join_path(pwd,config_filename)
    if exists(config_file) and check_access(config_file,R_OK):
        config = load_cfg(config_file)
    elif not exists(config_file):
        logger.error("The configuration YAML file called '" + config_file + "' does not exist.")
        logger.error("Please make sure it exists and is in the same directory as this program, and try again.\n")
        exit_handler(ERROR_CODE)
    elif not check_access(config_file,R_OK):
        logger.error("The user '" + get_user() + "' does not have READ access to the required configuration YAML file: '" + config_file + "'.")
        logger.error("Please run this program as a different user who has access, or update accesses on this file so this user can read this file, and try again.\n")
        exit_handler(ERROR_CODE)

    if service + "_metrics_info" not in config.keys():
        logger.error("You have entered a valid cloud service (" + service + ") as an argument to this program.")
        logger.error("However, the configuration YAML File '" + config_file + "'")
        logger.error("does not have required top level section entitled '" + service + "_metrics_info" +"'.")
        logger.error("Please update the YAML file and try again.\n")
        exit_handler(ERROR_CODE)

    return service,config

if __name__ == '__main__':
    create_log_handler()
    logger.info("Program Started...")

    service,config = pre_error_handling("config.yaml")
    cred = vault_credentials.get_secret_from_vault(config['vault_path'], config['vault_keys'])
    config = {**config, **cred}
    logger.info("Running for the service called '" + service + "'.")

    logger.info("Ingesting Metric CSVs...")
    #ingest_csv_data(service,config,logger,exit_handler)
    logger.info("Merging CSVs and inserting JSON like data into MongoDB...")

    if service == "glue":
        ingest_glue_csvs(config,logger,exit_handler)
    elif service == "s3":
        ingest_s3_csvs(config,logger,exit_handler)
    elif service == "lambda":
        ingest_lambda_csvs(config,logger,exit_handler)
    elif service == "sagemaker":
        ingest_sagemaker_csvs(config,logger,exit_handler)
    elif service == "synapse":
        ingest_synapse_csvs(config,logger,exit_handler)
    elif service == "adls":
        ingest_adls_csvs(config,logger,exit_handler)
    elif service == "azureml":
        ingest_azure_ml_csvs(config,logger,exit_handler)
    elif service == "sqldatabases":
        ingest_azure_sqlserver_csvs(config, logger, exit_handler)
    elif service == "databricks":
        ingest_databricks_csvs(config,logger,exit_handler)
    elif service == "aks":
        ingest_aks_csvs(config,logger,exit_handler)
    elif service == "datafactory":
        ingest_datafactory_csvs(config,logger,exit_handler)
    elif service == "cloudstorage":
        ingest_cloudstorage_csvs(config,logger,exit_handler)
    elif service == "dataflow":
        ingest_dataflow_csvs(config,logger,exit_handler)
    elif service == "bigquery":
        ingest_bigquery_csvs(config,logger,exit_handler)
    elif service == "cloudscheduler":
        ingest_cloud_scheduler_csvs(config, logger, exit_handler)
    elif service == "composer":
        ingest_composer_csvs(config,logger,exit_handler)
    elif service == "vertexai":
        ingest_vertexai_csvs(config,logger,exit_handler)
    elif service == "tableau":
        ingest_tableau_csvs(config,logger,exit_handler)
    elif service == "redshift":
        ingest_redshift_csvs(config,logger,exit_handler)
    elif service == "rdsoracle":
        ingest_rds_oracle_csvs(config,logger,exit_handler)
    elif service == "postgres":
        ingest_postgres_metrics(config,logger,exit_handler)
    elif service == "ropen":
        ingest_ropen_csvs(config,logger,exit_handler)
    elif service == "mongodb":
        ingest_mongo_csvs(config,logger,exit_handler)
    elif service == "sqlserver":
        ingest_sqlserver_csvs(config,logger,exit_handler)
    elif service == "redis":
        ingest_redis_csvs(config, logger, exit_handler)
    elif service == "linux":
        ingest_linux_csvs(config, logger, exit_handler)
    elif service == "powerbi":
        ingest_powerbi_csvs(config,logger,exit_handler)
    elif service == "informatica":
        ingest_informatica_csvs(config, logger, exit_handler)
    elif service == "powerexchangejvm":
        ingest_powerexchange_csvs(config,logger,exit_handler)
    elif service == "informaticastatuschecker":
        ingest_service_status_csvs(config,logger,exit_handler)
    elif service == "disk":
        ingest_disk_csvs(config,logger,exit_handler)
    elif service == "hyperscalesql":
        ingest_azure_hyperscalesql_csvs_v2(config,logger,exit_handler)
    elif service == "sftp":
        ingest_sftp_csvs(config, logger, exit_handler)
    elif service == "azurecacheredis":
        ingest_azurecacheredis_csvs(config, logger, exit_handler)
    elif service == "blobfuse":
        ingest_azure_blobfuse_csvs(config, logger, exit_handler)
    elif service == "informaticawindows":
        ingest_informaticawindows_csvs(config, logger, exit_handler)
    elif service == "awsdatabricks":
        ingest_aws_databricks_csvs(config,logger,exit_handler)
    exit_handler(OK_CODE)
