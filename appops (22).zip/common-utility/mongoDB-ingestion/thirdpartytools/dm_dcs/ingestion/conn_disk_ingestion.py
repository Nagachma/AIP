"""
Module to ingest csvs to mongo db.
"""
import csv

import pandas as pd
import numpy as np
from pymongo import MongoClient
from datetime import datetime

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2

def ingest_disk_csvs(config, logger, exit_handler):
    csv_file1 = config['disk_metrics_info']['conn_csv']

    df_csv_file1 = pd.read_csv(csv_file1)

    timestamp = list(df_csv_file1.Timestamp)
    timestamp = list(map(lambda timestp: timestp[0:16], timestamp))
    timestamp = [*set(timestamp)]
    timestamp.sort()

    instance_ip = list(df_csv_file1.server_ip)
    instance_ip = [*set(instance_ip)]
    instance_ip.sort()

    dict_list = []
    source = config['thirdparty_source']

    for i in timestamp:
        final_output = {}
        disk_conn = []
        time = i
        time = datetime.strptime(time, '%Y-%m-%d %H:%M')

        for j in instance_ip:
            disks = []
            dsks = {}
            dsks['instance_ip'] = j
            with open(csv_file1) as for_instance_ip:
                heading = next(for_instance_ip)
                csvFile1_header = list(df_csv_file1.columns)
                reader_obj = csv.reader(for_instance_ip)
                for row in reader_obj:
                    dict = {}
                    if row[0][0:16] == i and row[2] == j:
                        dsks['instance_name'] = row[1]
                        count = 3
                        while count < len(row):
                            if row[count] is None or row[count] == '':
                                count = count + 1
                                continue
                            elif row[count] is not None or row[count] != '':
                                if row[count] == 'PASSED' or row[count] == '0':
                                    dict[csvFile1_header[count]] = 0
                                elif row[count] == 'FAILED' or row[count] == '1':
                                    dict[csvFile1_header[count]] = 1
                                count = count + 1
                        if dict is not None and len(dict) > 0:
                            disks.append(dict)
                if disks is not None and len(disks) > 0:
                    dsks['disks'] = disks
            if dsks is not None and len(dsks) > 1:
                disk_conn.append(dsks)
        final_output["source"] = source
        final_output["ts"] = time
        final_output["disk_connectivity"] = disk_conn

        dict_list.append(final_output)

    mongo_client = config['mongo_url']
    mongo_db = config['mongo_db']
    mongo_collection = config['disk_metrics_info']['mongo_collection']

    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)
    # Bulk insert all dictionaries to MongoDB
    # print(final_output)
    logger.info('New entry list size for disk connectivity = {}'.format(len(dict_list)))
    if len(dict_list) > 0:
        collection.insert_many(dict_list)
        exit_handler(OK_CODE)
    else:
        logger.warn('Zero 0 new entries inserted to mongo db for disk connectivity')
        exit_handler(WARNING_CODE)