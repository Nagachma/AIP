"""
Module to ingest csvs to mongo db.
"""
import uuid
from zoneinfo import ZoneInfo
import numpy as np
import pandas as pd
from pymongo import MongoClient
from datetime import datetime, timedelta

"""
__author__ = "Sachin Maurya"
__copyright__ = "Copyright 2023, The OrchastrAI Project"
__license__ = "GPL"
__version__ = "1.0.0"
__email__ = "sachin.maurya@accenture.com"
"""

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2

def round_dt(dt, delta):
    return datetime.min + round((dt - datetime.min) / delta) * delta

def preprocess_start_time(df):
    df['START_TIME'] = [start_time[:-9] if start_time[-1] != 'Z' else str(start_time[:-4]).replace('T', ' ')
                        for start_time in df['START_TIME']]
    return df
def logp_preprocess_start_time(df):
    df['Start_Time'] = [start_time[:-9] if start_time[-1] != 'Z' else str(start_time[:-4]).replace('T', ' ')
                        for start_time in df['Start_Time']]
    return df


def ingest_powerexchange_csvs(config, logger, exit_handler):
    csv_file_path = config['informaticapowerexchange_metrics_info']['infadb_csv']
    infadb_df = pd.read_csv(csv_file_path)

    infadb_df_dict = dict(tuple(infadb_df.groupby('COLLECTION_START_TIME')))
    for ts, dfs in infadb_df_dict.items():
        infadb_df = dfs
        df11 = infadb_df.rename(columns={'FOLDER_NAME': 'Folder_Name','WORKFLOW_NAME':'Workflow_Name','START_TIME':'Start_Time','END_TIME':'End_Time'})
        infas_df = df11
        infas_df['Start_Time'] = pd.to_datetime(infas_df['Start_Time'], errors='coerce')
        infas_df['End_Time'] = pd.to_datetime(infas_df['End_Time'], errors='coerce')
        infas_df['DURATION_IN_SECONDS'] = infas_df['EXECUTION_TIME']

        infas_df.replace(np.nan, 'None', inplace=True)
        infas_df['Workflow_Name'] = infas_df.apply(lambda row: str(row['Workflow_Name']) + '[' + str((row['SITE_NO'])) + ']' if row['SITE_NO'] != 'None' and row['SITE_NO'] != '' else str(row['Workflow_Name']), axis=1)
        source = config['source']
        source['region'] = 'N.A.'
        source['service_provider'] = config["informaticapowerexchange_metrics_info"]['service_provider']

        mongo_client = config['mongo_url']
        mongo_db = config['mongo_db']
        mongo_collection = config['informaticapowerexchange_metrics_info']['mongo_collection']

        dict_list = []
        final_output = {}

        delta = timedelta(minutes=5)
        time = datetime.strptime(datetime.today().strftime('%m-%d-%Y %H:%M:%S'),'%m-%d-%Y %H:%M:%S')
        time = datetime.strptime(str (ts), '%m-%d-%Y %H:%M:%S')
        time = round_dt(time, delta)
        utcTimestamp = time.replace(tzinfo=ZoneInfo("America/New_York")).astimezone(ZoneInfo('UTC')).strftime("%Y-%m-%d %H:%M:%S")
        utcTimestamp = datetime.strptime(utcTimestamp, '%Y-%m-%d %H:%M:%S')
        final_output['source'] = source
        final_output['ts'] = utcTimestamp
        tmpDf = infas_df[
                ['Start_Time', 'End_Time',
                 'WORKFLOW_EXECUTION_ID',
                 'Workflow_Name', 'SUCCESSFUL_SOURCE_ROWS',
                 'FAILED_SOURCE_ROWS', 'SUCCESSFUL_TARGET_ROWS', 'FAILED_TARGET_ROWS', 'STATUS', 'DURATION_IN_SECONDS',
                 'TASK_NAME','INTEGRATION_SERVICE','Folder_Name'
                 ]]

        tmp_dict = {k: v.drop('Workflow_Name', axis=1).reset_index(drop=True) for k, v in tmpDf.groupby('Workflow_Name')}
        list_of_workflows = []
        for (k,v) in tmp_dict.items():
            inner_dict_of_list = {'Workflow_Name':k}
            tpDf = pd.DataFrame([{**x[i]} for i, x in v.stack().groupby(level=0)])
            tpDf = tpDf.rename(columns={'STATUS': 'Task_Status'})
            tpDf.fillna("None", inplace=True)
            if 'WORKFLOW_EXECUTION_ID' in tpDf:
                tpDf['End_Time'].replace([pd.Timestamp('1753-01-01 00:00:00')], datetime.strptime('1990-01-01 12:00:00', '%Y-%m-%d %H:%M:%S'),inplace=True)
                tpDf['End_Time'].replace('None', datetime.strptime('1990-01-01 12:00:00', '%Y-%m-%d %H:%M:%S'),inplace=True)
                tpDf['Start_Time'] = tpDf['Start_Time'].dt.tz_localize('America/New_York').dt.tz_convert('UTC').dt.tz_localize(None)
                tpDf['End_Time'] = tpDf['End_Time'].dt.tz_localize('America/New_York').dt.tz_convert('UTC').dt.tz_localize(None)
                tpDf['run_id'] = [str(uuid.uuid4()) for _ in range(len(tpDf.index))]
                success_msg = 0
                duration = 0
                for task_dict in tpDf.to_dict(orient='records'):
                    for a,b in task_dict.items():
                        if a == 'DURATION_IN_SECONDS':
                            duration = b
                        if a == 'Task_Status' and (b == 1):
                            success_msg = 1
                        if a == 'Task_Status' and (b == 2):
                            success_msg = 2
                inner_dict_of_list['Workflow_Status'] = success_msg
                inner_dict_of_list['DURATION_IN_SECONDS'] = duration
                tpDf = tpDf.drop(['DURATION_IN_SECONDS'], axis=1)
                inner_dict_of_list['Tasks'] =  tpDf.to_dict(orient='records')
            else:
                tmp_list = tpDf.to_dict(orient='records')
                for dict_miss in tmp_list:
                    for x,y in dict_miss.items():
                        inner_dict_of_list[x] = y
                inner_dict_of_list['Workflow_Status'] = 1
                inner_dict_of_list['run_id'] = str(uuid.uuid4())
                inner_dict_of_list['DURATION_IN_SECONDS'] = 0
                inner_dict_of_list['Tasks'] = []
            list_of_workflows.append(inner_dict_of_list)

        final_output['workflows'] = list_of_workflows
        dict_list.append(final_output)

        # Bulk insert all dictionaries to MongoDB
        client = MongoClient(mongo_client)
        db = client.get_database(mongo_db)
        collection = db.get_collection(mongo_collection)

        logger.info(f"New entry list size for Informatica = {len(dict_list)}")
        if len(dict_list) > 0:
            collection.insert_many(dict_list)
            exit_handler(OK_CODE)
        else:
            logger.warn("Zero new entries inserted to mongodb for Informatica")
            exit_handler(WARNING_CODE)

