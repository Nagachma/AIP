"""
Module to ingest csvs to mongo db.
"""
from zoneinfo import ZoneInfo
import pandas as pd
from pymongo import MongoClient
from datetime import datetime, timedelta

"""
__author__ = "Sachin Maurya"
__copyright__ = "Copyright 2023, The OrchastrAI Project"
__license__ = "GPL"
__version__ = "1.0.0"
__email__ = "sachin.maurya@accenture.com"
"""

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2


def round_dt(dt, delta):
    return datetime.min + round((dt - datetime.min) / delta) * delta

def preprocess_start_time(df):
    df['START_TIME'] = [start_time[:-9] if start_time[-1] != 'Z' else str(start_time[:-4]).replace('T', ' ')
                        for start_time in df['START_TIME']]
    return df
def logp_preprocess_start_time(df):
    df['Start_Time'] = [start_time[:-9] if start_time[-1] != 'Z' else str(start_time[:-4]).replace('T', ' ')
                        for start_time in df['Start_Time']]
    return df


def ingest_service_status_csvs(config, logger, exit_handler):
    integrationservice_csv_file_path = config['informaticastatuschecker_metrics_info']['servicestatus_csv']
    integrationservice_infadb_df = pd.read_csv(integrationservice_csv_file_path)

    timestamp = list(integrationservice_infadb_df.collection_time.unique())
    infadb_df_dict = dict(tuple(integrationservice_infadb_df.groupby('collection_time')))
    workflow_inserted = False
    for ts,dfs in infadb_df_dict.items():
        source = config['source']
        source['region'] = 'N.A.'
        source['service_provider'] = config["informaticastatuschecker_metrics_info"]['service_provider']

        mongo_client = config['mongo_url']
        mongo_db = config['mongo_db']
        mongo_collection = config['informaticastatuschecker_metrics_info']['mongo_collection']

        dict_list = []
        final_output = {}
        delta = timedelta(minutes=5)
        time = datetime.strptime(str (ts), '%m-%d-%Y %H:%M')
        time = round_dt(time, delta)
        utcTimestamp = time.replace(tzinfo=ZoneInfo("America/New_York")).astimezone(ZoneInfo('UTC')).strftime("%Y-%m-%d %H:%M:%S")
        final_output['source'] = source
        utcTimestamp = datetime.strptime(utcTimestamp, '%Y-%m-%d %H:%M:%S')
        final_output['ts'] = utcTimestamp
        tmpDf = integrationservice_infadb_df[['domain_name', 'service_name','node_name','service_status', 'message']]

        tmp_dict = {k: v.drop('domain_name', axis=1).reset_index(drop=True) for k, v in integrationservice_infadb_df.groupby('domain_name')}
        list_of_workflows = []
        domain_list = []
        for (k,v) in tmp_dict.items():
            tpDf = pd.DataFrame([{**x[i]} for i, x in v.stack().groupby(level=0)])
            service_tmp_dict = {k: v.drop('service_name', axis=1).reset_index(drop=True) for k, v in
                        tpDf.groupby(['service_name','service_status'])}
            service_dict_list = []
            for (k1, v1) in service_tmp_dict.items():
                service_dict = {}
                node_list_tpDf = list(pd.DataFrame([{**x[i]} for i, x in v1.stack().groupby(level=0)])['node_name'])
                nodes_list = []
                for node in node_list_tpDf:
                    node_dict = {}
                    node_dict['node_name'] = node
                    nodes_list.append(node_dict)
                service_dict['nodes'] = nodes_list
                service_dict['service_name'] = k1[0]
                service_dict['service_status'] = int(k1[1])
                service_dict['message'] = list(pd.DataFrame([{**x[i]} for i, x in v1.stack().groupby(level=0)])['message'])[0]
                service_dict_list.append(service_dict)
            domain_dict = {}
            domain_dict['domain_name'] = k
            domain_dict['services'] = service_dict_list
            domain_list.append(domain_dict)

        final_output['domains'] = domain_list
        # dataset1 = pd.DataFrame(integrationservice_infadb_df, columns=['service_name', 'service_status','domain_name','node_name'])
        # df_min_max1 = dataset1.groupby(['service_name','service_status'], as_index=False).size().drop(['size'], axis=1)
        # workflow_duration_dict1 = dict(zip(df_min_max1.service_name, df_min_max1.service_status))
        # list_of_services = []
        # for k, v in workflow_duration_dict1.items():
        #     services = {}
        #     services['service_name'] = k
        #     services['service_status'] = v
        #     list_of_services.append(services)
        #
        # final_output['services'] = list_of_services
        dict_list.append(final_output)

        # Bulk insert all dictionaries to MongoDB
        client = MongoClient(mongo_client)
        db = client.get_database(mongo_db)
        collection = db.get_collection(mongo_collection)

        logger.info(f"New entry list size for Informatica staus checker= {len(dict_list)}")
        if len(dict_list) > 0:
            collection.insert_many(dict_list)
            exit_handler(OK_CODE)
        else:
            logger.warn("Zero new entries inserted to mongodb for Informatica status checker")
            exit_handler(WARNING_CODE)
