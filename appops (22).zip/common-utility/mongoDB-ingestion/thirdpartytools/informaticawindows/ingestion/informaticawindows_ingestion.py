"""
Module to ingest csvs to mongo db.
"""
import uuid
from zoneinfo import ZoneInfo
import pandas as pd
import numpy as np
from pymongo import MongoClient
from datetime import datetime, timedelta

"""
__author__ = "Sachin Maurya"
__copyright__ = "Copyright 2023, The OrchastrAI Project"
__license__ = "GPL"
__version__ = "1.0.0"
__email__ = "sachin.maurya@accenture.com"
"""

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2


def round_dt(dt, delta):
    return datetime.min + round((dt - datetime.min) / delta) * delta

def preprocess_start_time(df):
    df['START_TIME'] = [start_time[:-9] if start_time[-1] != 'Z' else str(start_time[:-4]).replace('T', ' ')
                        for start_time in df['START_TIME']]
    return df
def logp_preprocess_start_time(df):
    df['Start_Time'] = [start_time[:-9] if start_time[-1] != 'Z' else str(start_time[:-4]).replace('T', ' ')
                        for start_time in df['Start_Time']]
    return df


def ingest_informaticawindows_csvs(config, logger, exit_handler):
    csv_file_path = config['informaticawindows_metrics_info']['infadb_csv']
    logp_csv_file_path = config['informaticawindows_metrics_info']['logparser_csv']


    infadb_df = pd.read_csv(csv_file_path)
    logp_infadb_df = pd.read_csv(logp_csv_file_path)

    infadb_df_dict = dict(tuple(infadb_df.groupby('COLLECTION_START_TIME')))
    for ts,dfs in infadb_df_dict.items():
        infadb_df = dfs
        logp_infadb_df=logp_infadb_df.rename(columns={'Workflow_Execution_ID':'WORKFLOW_EXECUTION_ID','Session_Name':'TASK_NAME','Stale_Data':'Stale_data_DBConnect_status'})
        df11 = infadb_df.rename(columns={'FOLDER_NAME': 'Folder_Name','WORKFLOW_NAME':'Workflow_Name','START_TIME':'Start_Time','END_TIME':'End_Time'})
        infas_df = df11
        infas_df = pd.merge(df11, logp_infadb_df, left_on=['Start_Time','End_Time','Folder_Name', 'Workflow_Name','WORKFLOW_EXECUTION_ID','TASK_NAME'], right_on=['Start_Time','End_Time','Folder_Name', 'Workflow_Name','WORKFLOW_EXECUTION_ID','TASK_NAME'],how='left')



        infas_df['Start_Time'] = pd.to_datetime(infas_df['Start_Time'], errors='coerce')
        infas_df['End_Time'] = pd.to_datetime(infas_df['End_Time'], errors='coerce')
        infas_df['DURATION_IN_SECONDS'] = (infas_df['WORFLOW_EXECUTION_TIME'])

        infas_df.replace(np.nan, 'None', inplace=True)
        #infas_df['Workflow_Name'] = infas_df.apply(lambda row: str(row['Workflow_Name']) + '[' + str(str(row['SITE_NO']) + ']') if row['SITE_NO'] != 'None' and row['SITE_NO'] != '' else str(row['Workflow_Name']), axis=1)

        dataset = pd.DataFrame(infas_df, columns=['Workflow_Name', 'Start_Time','End_Time'])
        df_min_max = dataset.groupby(['Workflow_Name'] ,as_index=False)
        df2 = df_min_max.agg(Minimum_Date=('Start_Time', np.min), Maximum_Date=('End_Time', np.max))
        df2['Maximum_Date'] = pd.to_datetime(df2['Maximum_Date'])
        df2['Minimum_Date'] = pd.to_datetime(df2['Minimum_Date'])
        df2['workflow_duration'] = (df2['Maximum_Date'] - df2['Minimum_Date']).dt.total_seconds()
        # df2["workflow_duration"] = pd.Timedelta((df2.Maximum_Date - df2.Minimum_Date)).seconds
        df2 = df2.drop(['Maximum_Date','Minimum_Date'], axis=1)
        workflow_duration_dict = dict(zip(df2.Workflow_Name, df2.workflow_duration))

        for k,v in workflow_duration_dict.items():
            infas_df.loc[infas_df['Workflow_Name'] == k, 'DURATION_IN_SECONDS'] = v

        source = config['source']
        source['region'] = 'N.A.'
        source['service_provider'] = config["informaticawindows_metrics_info"]['service_provider']

        mongo_client = config['mongo_url']
        mongo_db = config['mongo_db']
        mongo_collection = config['informaticawindows_metrics_info']['mongo_collection']

        dict_list = []
        final_output = {}
        delta = timedelta(minutes=5)
        time = datetime.strptime(str (ts), '%m-%d-%Y %H:%M:%S')
        time = round_dt(time, delta)
        utcTimestamp = time.replace(tzinfo=ZoneInfo("America/New_York")).astimezone(ZoneInfo('UTC')).strftime("%Y-%m-%d %H:%M:%S")
        final_output['source'] = source
        utcTimestamp = datetime.strptime(utcTimestamp, '%Y-%m-%d %H:%M:%S')
        final_output['ts'] = utcTimestamp
        tmpDf = infas_df[
                ['Start_Time', 'End_Time',
                 'WORKFLOW_EXECUTION_ID',
                 'Workflow_Name', 'SUCCESSFUL_SOURCE_ROWS',
                 'FAILED_SOURCE_ROWS', 'SUCCESSFUL_TARGET_ROWS', 'FAILED_TARGET_ROWS', 'STATUS', 'DURATION_IN_SECONDS',
                 'AggIndexCacheSizeMB', 'AggDataCacheSizeMB', 'JnrIndexCacheSizeMB', 'JnrDataCacheSizeMB',
                 'TASK_NAME','INTEGRATION_SERVICE','Folder_Name','RUN_ERR_MSG','pid','Stale_data_DBConnect_status'
                 ]]
        #tmpDf.replace(np.nan, 'None', inplace=True)
        #tmpDf['SITE_NO'] = tmpDf['SITE_NO'].str.replace(".", "")
        missingfiles_tmp_df = tmpDf
        tmp_dict = {k: v.drop('Workflow_Name', axis=1).reset_index(drop=True) for k, v in missingfiles_tmp_df.groupby('Workflow_Name')}
        list_of_workflows = []
        for (k,v) in tmp_dict.items():
            tpDf = pd.DataFrame([{**x[i]} for i, x in v.stack().groupby(level=0)])
            tpDf = tpDf.rename(columns={'STATUS': 'Task_Status'})
            tpDf.fillna("None", inplace=True)
            if 'WORKFLOW_EXECUTION_ID' in tpDf:
                tpDf['End_Time'].replace([pd.Timestamp('1753-01-01 00:00:00')], datetime.strptime('1990-01-01 12:00:00', '%Y-%m-%d %H:%M:%S'),inplace=True)
                tpDf['End_Time'].replace('None', datetime.strptime('1990-01-01 12:00:00', '%Y-%m-%d %H:%M:%S'),inplace=True)
                tpDf['Start_Time'] = tpDf['Start_Time'].dt.tz_localize('America/New_York').dt.tz_convert('UTC').dt.tz_localize(None)
                tpDf['End_Time'] = tpDf['End_Time'].dt.tz_localize('America/New_York').dt.tz_convert('UTC').dt.tz_localize(None)
                tpDf['run_id'] = [str(uuid.uuid4()) for _ in range(len(tpDf.index))]
                tpDf.replace('None', '', inplace=True)
                #site_no = tpDf['SITE_NO'].value_counts(sort=False).idxmax()
                #if site_no is not None and site_no != '':
                inner_dict_of_list = {'Workflow_Name': k}
                #else:
                #    inner_dict_of_list = {'Workflow_Name': k}
                success_msg = 0
                duration = 0
                for task_dict in tpDf.to_dict(orient='records'):
                    for a,b in task_dict.items():
                        if a == 'DURATION_IN_SECONDS':
                            duration = b
                        if a == 'Task_Status' and (b == 1):
                            success_msg = 1
                        if a == 'Task_Status' and (b == 2):
                            success_msg = 2

                inner_dict_of_list['Workflow_Status'] = success_msg
                inner_dict_of_list['DURATION_IN_SECONDS'] = duration
                if (tpDf['RUN_ERR_MSG'].str.contains('SOURCE_FILE_CHECK] failed')).any():
                    inner_dict_of_list['missing_file_Status'] = 1
                else:
                    inner_dict_of_list['missing_file_Status'] = 0
                tpDf = tpDf.drop(['DURATION_IN_SECONDS'], axis=1)
                tpDf.drop(['RUN_ERR_MSG'], axis=1,inplace=True)
                inner_dict_of_list['Tasks'] =  tpDf.to_dict(orient='records')
            else:
                inner_dict_of_list = {'Workflow_Name': k}
                tmp_list = tpDf.to_dict(orient='records')
                for dict_miss in tmp_list:
                    for x,y in dict_miss.items():
                        inner_dict_of_list[x] = y
                inner_dict_of_list['Workflow_Status'] = 1
                inner_dict_of_list['run_id'] = str(uuid.uuid4())
                inner_dict_of_list['DURATION_IN_SECONDS'] = 0
                inner_dict_of_list['Tasks'] = []
            list_of_workflows.append(inner_dict_of_list)

        final_output['workflows'] = list_of_workflows
        dict_list.append(final_output)

        # Bulk insert all dictionaries to MongoDB
        client = MongoClient(mongo_client)
        db = client.get_database(mongo_db)
        collection = db.get_collection(mongo_collection)

        logger.info(f"New entry list size for Informaticawindows = {len(dict_list)}")
        if len(dict_list) > 0:
            collection.insert_many(dict_list)
            exit_handler(OK_CODE)
        else:
            logger.warn("Zero new entries inserted to mongodb for Informaticawindows")
            exit_handler(WARNING_CODE)