"""
Module to ingest csvs to mongo db.
"""
import pandas as pd
import numpy as np
from pymongo import MongoClient
import datetime

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2


def preprocess_timestamp(df):
    df['timestamp'] = pd.to_datetime(df['timestamp'], format='%Y-%m-%d %H:%M:00+00:00')
    return df


def cast_int64(df):
    for col in df.select_dtypes(include=np.int64).columns.tolist():
        df[col] = df[col].astype(float)


def ingest_linux_csvs(config, logger, exit_handler):
    pass
    process_csv_path = config['linux_metrics_info']['process_csv']
    iostat_csv_path = config['linux_metrics_info']['iostat_csv']
    sadf_csv_path = config['linux_metrics_info']['sadf_csv']

    process_df = pd.read_csv(process_csv_path)

    iostat_df = pd.read_csv(iostat_csv_path)

    sadf_df = pd.read_csv(sadf_csv_path)

    preprocess_timestamp(process_df)
    preprocess_timestamp(iostat_df)
    preprocess_timestamp(sadf_df)

    cast_int64(process_df)
    cast_int64(iostat_df)
    cast_int64(sadf_df)

    timestamp = [*set(iostat_df.timestamp)]
    timestamp.sort()

    source = config['thirdparty_source']

    mongo_client = config['mongo_url']
    mongo_db = config['mongo_db']
    mongo_collection = config['linux_metrics_info']['mongo_collection']

    dict_list = []
    for i in timestamp:

        final_output = {'source': source, 'ts': i}

        unique_node_names = [*set(iostat_df[iostat_df['timestamp'] == i].node_name)]

        unique_node_names.sort()

        instances = []
        for node_name_tmp in unique_node_names:
            iostat_temp_df = iostat_df[(iostat_df['timestamp'] == i) & (iostat_df['node_name'] == node_name_tmp)]
            sadf_temp_df = sadf_df[(sadf_df['timestamp'] == i) & (sadf_df['hostname'] == node_name_tmp) &
                                   (sadf_df['CPU'] == -1)]

            instance = {'nodename': node_name_tmp, 'sysname': iostat_temp_df.sys_name[0],
                        'release': iostat_temp_df.release[0], 'machine': iostat_temp_df.machine[0],
                        'number-of-cpus': iostat_temp_df.number_of_cpus[0]}

            stat = {
                "avg-cpu": {
                    "user": iostat_temp_df.user[0],
                    "nice": iostat_temp_df.nice[0],
                    "system": iostat_temp_df.system[0],
                    "iowait": iostat_temp_df.iowait[0],
                    "steal": iostat_temp_df.steal[0],
                    "idle": iostat_temp_df.idle[0]
                },
                "sadf_metrics": {
                    "CPU": sadf_temp_df.CPU[0],
                    "%user": sadf_temp_df['%user'][0],
                    "%nice": sadf_temp_df['%nice'][0],
                    "%system": sadf_temp_df['%system'][0],
                    "%iowait": sadf_temp_df['%iowait'][0],
                    "%steal": sadf_temp_df['%steal'][0],
                    "%idle": sadf_temp_df['%idle[...]'][0],
                    "proc/s": sadf_temp_df['proc/s'][0],
                    "cswch/s": sadf_temp_df['cswch/s'][0],
                    "pswpin/s": sadf_temp_df['pswpin/s'][0],
                    "pswpout/s": sadf_temp_df['pswpout/s'][0],
                    "pgpgin/s": sadf_temp_df['pgpgin/s'][0],
                    "pgpgout/s": sadf_temp_df['pgpgout/s'][0],
                    "fault/s": sadf_temp_df['fault/s'][0],
                    "majflt/s": sadf_temp_df['majflt/s'][0],
                    "pgfree/s": sadf_temp_df['pgfree/s'][0],
                    "pgscank/s": sadf_temp_df['pgscank/s'][0],
                    "pgscand/s": sadf_temp_df['pgscand/s'][0],
                    "pgsteal/s": sadf_temp_df['pgsteal/s'][0],
                    "%vmeff": sadf_temp_df['%vmeff'][0],
                    "tps": sadf_temp_df['tps'][0],
                    "rtps": sadf_temp_df['rtps'][0],
                    "wtps": sadf_temp_df['wtps'][0],
                    "dtps": sadf_temp_df['dtps'][0],
                    "bread/s": sadf_temp_df['bread/s'][0],
                    "bwrtn/s": sadf_temp_df['bwrtn/s'][0],
                    "bdscd/s": sadf_temp_df['bdscd/s'][0],
                    "kbmemfree": sadf_temp_df['kbmemfree'][0],
                    "kbavail": sadf_temp_df['kbavail'][0],
                    "kbmemused": sadf_temp_df['kbmemused'][0],
                    "%memused": sadf_temp_df['%memused'][0],
                    "kbbuffers": sadf_temp_df['kbbuffers'][0],
                    "kbcached": sadf_temp_df['kbcached'][0],
                    "kbcommit": sadf_temp_df['kbcommit'][0],
                    "%commit": sadf_temp_df['%commit'][0],
                    "kbactive": sadf_temp_df['kbactive'][0],
                    "kbinact": sadf_temp_df['kbinact'][0],
                    "kbdirty": sadf_temp_df['kbdirty'][0],
                    "kbswpfree": sadf_temp_df['kbswpfree'][0],
                    "kbswpused": sadf_temp_df['kbswpused'][0],
                    "%swpused": sadf_temp_df['%swpused'][0],
                    "kbswpcad": sadf_temp_df['kbswpcad'][0],
                    "%swpcad": sadf_temp_df['%swpcad'][0],
                    "dentunusd": sadf_temp_df['dentunusd'][0],
                    "file-nr": sadf_temp_df['file-nr'][0],
                    "inode-nr": sadf_temp_df['inode-nr'][0],
                    "pty-nr": sadf_temp_df['pty-nr'][0],
                    "runq-sz": sadf_temp_df['runq-sz'][0],
                    "plist-sz": sadf_temp_df['plist-sz'][0],
                    "ldavg-1": sadf_temp_df['ldavg-1'][0],
                    "ldavg-5": sadf_temp_df['ldavg-5'][0],
                    "ldavg-15": sadf_temp_df['ldavg-15'][0],
                    "blocked": sadf_temp_df['blocked'][0],
                }
            }

            disk = []
            for j, row in iostat_df.iterrows():
                disk.append(
                    {
                        "disk_device": row['disk_device'],
                        "tps": row['tps'],
                        "kB_read/s": row['kB_read_s'],
                        "kB_wrtn/s": row['kB_wrtn_s'],
                        "kB_dscd/s": row['kB_dscd_s'],
                        "kB_read": row['kB_read'],
                        "kB_wrtn": row['kB_wrtn'],
                        "kB_dscd": row['kB_dscd']
                    }
                )

            stat['disk'] = disk

            instance['statistics'] = [stat]

            processes = []

            for j, row in process_df[
                (process_df['timestamp'] == i) & (process_df['node_name'] == node_name_tmp)].iterrows():
                processes.append({
                    'pid': row['PID'],
                    'elapsed': row['ELAPSED'],
                    'UID': row['UID'],
                    'user': row['USER'],
                    'per_usr': row['%usr'],
                    'per_system': row['%system'],
                    'per_guest': row['%guest'],
                    'per_cpu': row['%CPU'],
                    'cpu': row['CPU'],
                    'minflt_s': row['minflt/s'],
                    'majflt_s': row['majflt/s'],
                    'vsz': row['VSZ'],
                    'rss': row['RSS'],
                    'per_mem': row['%MEM_y'],
                    'kB_rd_s': row['kB_rd/s'],
                    'kB_wr_s': row['kB_wr/s'],
                    'kB_ccwr_s': row['kB_ccwr/s'],
                    'iodelay': row['iodelay'],
                    'threads': row['threads']
                })

            instance['processes'] = processes

            instances.append(instance)

        final_output['instances'] = instances

        dict_list.append(final_output)

    # Bulk insert all dictionaries to MongoDB
    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)

    logger.info(f"New entry list size for Linux = {len(dict_list)}")

    if len(dict_list) > 0:
        collection.insert_many(dict_list)
        exit_handler(OK_CODE)
    else:
        logger.warn("Zero new entries inserted to mongodb for Linux")
        exit_handler(WARNING_CODE)
