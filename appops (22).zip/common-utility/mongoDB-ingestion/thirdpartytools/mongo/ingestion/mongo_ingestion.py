"""
Module to ingest csvs to mongo db.
"""
import ast
import pandas as pd
from pymongo import MongoClient
from datetime import datetime

"""
__author__ = "Sachin Maurya"
__copyright__ = "Copyright 2023, The OrchastrAI Project"
__license__ = "GPL"
__version__ = "1.0.0"
__email__ = "sachin.maurya@accenture.com"
"""

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2


def preprocess_start_time(df):
    df['START_TIME'] = [start_time[:-9] if start_time[-1] != 'Z' else str(start_time[:-4]).replace('T', ' ')
                        for start_time in df['START_TIME']]
    return df
def logp_preprocess_start_time(df):
    df['Start_Time'] = [start_time[:-9] if start_time[-1] != 'Z' else str(start_time[:-4]).replace('T', ' ')
                        for start_time in df['Start_Time']]
    return df

def replace(s):
    return ast.literal_eval(s.replace(r'"{', "{").replace(r'}"', "}"))

def ingest_mongo_csvs(config, logger, exit_handler):
    serverstatus_csv = config['mongodb_metrics_info']['serverstatus_csv']
    dbstats_csv = config['mongodb_metrics_info']['dbstats_csv']
    collstats_csv = config['mongodb_metrics_info']['collstats_csv']
    # replsetgetstatus_csv = config['mongodb_metrics_info']['replsetgetstatus_csv']
    currentop_csv = config['mongodb_metrics_info']['currentop_csv']

    serverstatus_df = pd.read_csv(serverstatus_csv)
    dbstats_df = pd.read_csv(dbstats_csv)
    collstats_df = pd.read_csv(collstats_csv)
    # replsetgetstatus_df = pd.read_csv(replsetgetstatus_csv)
    currentop_df = pd.read_csv(currentop_csv)
    instances = []
    server_dict = {}
    server_dict_list = serverstatus_df.to_dict(orient="records")
    for d in server_dict_list:
        for key, value in d.items():
            if "{" in str(value):
                value = (str(value)).replace("#","'").replace("%",",").replace("@","\\")
                d[key] = replace(value)
    db_list = []
    db_dict_list = dbstats_df.to_dict(orient="record")
    for d in db_dict_list:
        for key, value in d.items():
            if "{" in str(value):
                value = (str(value)).replace("#", "'").replace("%", ",").replace("@", "\\")
                d[key] = replace(value)

    ctop_dict_list = currentop_df.to_dict(orient="records")
    for d in ctop_dict_list:
        for key, value in d.items():
            if "{" in str(value):
                value = (str(value)).replace("#", "'").replace("%", ",").replace("@", "-")
                d[key] = replace(value)

    for db in db_dict_list:
        colls_dict_list = collstats_df.to_dict(orient="records")
        for d in colls_dict_list:
            for key,value in d.items():
                if "{" in str(value):
                    value = (str(value)).replace("#", "'").replace("%", ",").replace("@", "\\")
                    d[key] = replace(value)
        coll_list_tmp = []
        for colls in colls_dict_list:
            db_name = (str(colls["ns"])).split(".")[0]
            coll_names = list(ctop_dict_list[0]['totals'].keys())
            req_mets = ['ns','totalSize']
            for k in list(colls):
                if k not in req_mets:
                    colls.pop(k)
            for coll_top_k, coll_top_v in dict(ctop_dict_list[0]['totals']).items():
                if (str(colls["ns"])) == coll_top_k:
                    if 'note' != coll_top_v:
                        for k,v in dict(coll_top_v).items():
                            for w,x in dict(v).items():
                                colls[k+'_'+w] = x
            if db_name==db["db"]:
                coll_list_tmp.append(colls)
        db["collections"] = coll_list_tmp
    db_mets = ['db','collections','dataSize','storageSize']
    for db in db_dict_list:
        for k in list(db):
            if k not in db_mets:
                db.pop(k)

    server_mets = ['host','version','freeMonitoring','opLatencies','opcounters','transactions','databases']
    for server in server_dict_list:
        for k in list(server):
            if k not in server_mets:
                server.pop(k)
    for server in server_dict_list:
        server["databases"] = db_dict_list
        # repl_dict_list = replsetgetstatus_df.to_dict(orient="records")
    #     for d in repl_dict_list:
    #         for key, value in d.items():
    #             if "{" in str(value):
    #                 value = (str(value)).replace("#", "'").replace("%", ",").replace("@", "\\")
    #                 d[key] = replace(value)
    #     server["replset"] = repl_dict_list
    #


        # server["currentop"] = ctop_dict_list

    source = config['source']
    source['region'] = 'N.A.'
    source['service_provider'] = config["mongodb_metrics_info"]['service_provider']

    mongo_client = config['mongo_url']
    mongo_db = config['mongo_db']
    mongo_collection = config['mongodb_metrics_info']['mongo_collection']

    dict_list = []
    final_output = {}

    time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    time = datetime.strptime(str (time), '%Y-%m-%d %H:%M:%S')
    final_output['source'] = source
    final_output['ts'] = time
    final_output['metrics'] = server_dict_list



    dict_list.append(final_output)

    # Bulk insert all dictionaries to MongoDB
    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)

    logger.info(f"New entry list size for Informatica = {len(dict_list)}")
    if len(dict_list) > 0:
        collection.insert_many(dict_list)
        exit_handler(OK_CODE)
    else:
        logger.warn("Zero new entries inserted to mongodb for Informatica")
        exit_handler(WARNING_CODE)
