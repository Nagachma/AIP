from cProfile import run
import csv
import pandas as pd
import os
import yaml
import numpy as np
from pymongo import MongoClient
from datetime import datetime
import hashlib
import random

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2

logger = []
exit_handler = []


def ingest_postgres_metrics(config, logger, exit_handler):
    connCountCsvFilePath = config['postgres_metrics_info']['connCountCsvFilePath']
    # connUsedCsvFilePath = config['postgres_metrics_info']['connUsedCsvFilePath']
    pgStatDatabaseCsvFilePath = config['postgres_metrics_info']['pgStatDatabaseCsvFilePath']
    pgStatUserTablesCsvFilePath = config['postgres_metrics_info']['pgStatUserTablesCsvFilePath']
    queryDurationCsvFilePath = config['postgres_metrics_info']['queryDurationCsvFilePath']
    resForSuperCsvFilePath = config['postgres_metrics_info']['resForSuperCsvFilePath']
    hotRateCsvFilePath = config['postgres_metrics_info']['hotRateCsvFilePath']
    maxConnCsvFilePath = config['postgres_metrics_info']['maxConnCsvFilePath']
    memInfoCsvFilePath = config['postgres_metrics_info']['memInfoCsvFilePath']
    # percentoftimeindexCsvFilePath = config['postgres_metrics_info']['percentoftimeindexCsvFilePath']


    # Reading CSVS
    connCount_df = pd.read_csv(connCountCsvFilePath)
    pgStatDatabase_df = pd.read_csv(pgStatDatabaseCsvFilePath)
    pgStatUserTables_df = pd.read_csv(pgStatUserTablesCsvFilePath)
    queryDuration_df = pd.read_csv(queryDurationCsvFilePath)
    resForSuper_df = pd.read_csv(resForSuperCsvFilePath)
    hotRate_df = pd.read_csv(hotRateCsvFilePath)
    maxConn_df = pd.read_csv(maxConnCsvFilePath)
    memInfo_df = pd.read_csv(memInfoCsvFilePath)

    # Formatting timestamp column to %Y-%m-%d %H:%M format
    connCount_df["metric_date"] = pd.to_datetime(connCount_df["metric_date"]).dt.strftime('%Y-%m-%d %H:%M')
    pgStatDatabase_df["metric_date"] = pd.to_datetime(pgStatDatabase_df["metric_date"]).dt.strftime('%Y-%m-%d %H:%M')
    pgStatUserTables_df["metric_date"] = pd.to_datetime(pgStatUserTables_df["metric_date"]).dt.strftime('%Y-%m-%d %H:%M')
    queryDuration_df["metric_date"] = pd.to_datetime(queryDuration_df["metric_date"]).dt.strftime('%Y-%m-%d %H:%M')
    resForSuper_df["metric_date"] = pd.to_datetime(resForSuper_df["metric_date"]).dt.strftime('%Y-%m-%d %H:%M')
    hotRate_df["metric_date"] = pd.to_datetime(hotRate_df["metric_date"]).dt.strftime('%Y-%m-%d %H:%M')
    maxConn_df["metric_date"] = pd.to_datetime(maxConn_df["metric_date"]).dt.strftime('%Y-%m-%d %H:%M')
    memInfo_df["metric_date"] = pd.to_datetime(memInfo_df["metric_date"]).dt.strftime('%Y-%m-%d %H:%M')

    # Merging CSVS
    merged_1 = pd.merge(connCount_df, pgStatDatabase_df, left_on=['metric_date', 'datname', 'db_hostname'],
                       right_on=['metric_date', 'datname', 'db_hostname'], how='outer')
    merged_1.replace(np.nan, 'None', inplace=True)


    merged_2 = pd.merge(pgStatUserTables_df, hotRate_df, left_on=['metric_date', 'datname', 'relname', 'db_hostname'],
                        right_on=['metric_date', 'datname', 'relname', 'db_hostname'], how='outer')
    merged_2.replace(np.nan, 'None', inplace=True)


    unique_instances = []
    unique_databases = []
    unique_pids = []
    unique_tables = []
    unique_timestamps = []

    # Unique instances
    instances = list(connCount_df.db_hostname) + list(pgStatDatabase_df.db_hostname) + list(pgStatUserTables_df.db_hostname) + list(
        queryDuration_df.db_hostname) + list(resForSuper_df.db_hostname) + list(hotRate_df.db_hostname) + list(
        maxConn_df.db_hostname) + list(memInfo_df.db_hostname)
    instances = list(map(lambda c: str(c), instances))
    unique_instances = [*set(instances)]

    # Unique databases
    databases = list(connCount_df.datname) + list(pgStatDatabase_df.datname) + list(pgStatUserTables_df.datname) + list(
        queryDuration_df.datname) + list(hotRate_df.datname)
    databases = list(map(lambda c: str(c), databases))
    unique_databases = [*set(databases)]

    # Unique pid's
    pids = list(queryDuration_df.pid)
    unique_pids = [*set(pids)]

    # Unique tables
    tables = list(pgStatUserTables_df.relname) + list(hotRate_df.relname)
    unique_tables = [*set(tables)]

    # Unique Timestamp
    timestamp = list(connCount_df.metric_date) + list(pgStatDatabase_df.metric_date) + list(pgStatUserTables_df.metric_date) + list(
        queryDuration_df.metric_date) + list(resForSuper_df.metric_date) + list(hotRate_df.metric_date) + list(maxConn_df.metric_date) + list(
        memInfo_df.metric_date)
    unique_timestamps = [*set(timestamp)]
    print("unique timestamps", unique_timestamps)


    dict_list = []
    source = config['source']

    for i in unique_timestamps:

        # Filtering the dataframes on basis of timestamp
        timestamp_filtered_custom_dat_df = merged_1.loc[merged_1['metric_date'] == i]
        timestamp_filtered_custom_dat_df = timestamp_filtered_custom_dat_df.drop(['metric_date'], axis=1)

        timestamp_filtered_custom_table_df = merged_2.loc[merged_2['metric_date'] == i]
        timestamp_filtered_custom_table_df = timestamp_filtered_custom_table_df.drop(['metric_date'], axis=1)

        timestamp_filtered_query_df = queryDuration_df.loc[queryDuration_df['metric_date'] == i]
        timestamp_filtered_query_df = timestamp_filtered_query_df.drop(['metric_date'], axis=1)

        timestamp_filtered_resForSuper_df = resForSuper_df.loc[resForSuper_df['metric_date'] == i]
        timestamp_filtered_resForSuper_df = timestamp_filtered_resForSuper_df.drop(['metric_date'], axis=1)

        timestamp_filtered_maxConn_df = maxConn_df.loc[maxConn_df['metric_date'] == i]
        timestamp_filtered_maxConn_df = timestamp_filtered_maxConn_df.drop(['metric_date'], axis=1)

        timestamp_filtered_memInfo_df = memInfo_df.loc[memInfo_df['metric_date'] == i]
        timestamp_filtered_memInfo_df = timestamp_filtered_memInfo_df.drop(['metric_date'], axis=1)

        time = i
        time = datetime.strptime(time, '%Y-%m-%d %H:%M')
        final_output = {}
        list_instances = []

        for j in unique_instances:

            # Filtering the dataframes on basis of Instance Name
            instance_filtered_custom_dat_df = timestamp_filtered_custom_dat_df.loc[timestamp_filtered_custom_dat_df['db_hostname'] == j]
            instance_filtered_custom_dat_df = instance_filtered_custom_dat_df.drop(['db_hostname'], axis=1)

            instance_filtered_custom_table_df = timestamp_filtered_custom_table_df.loc[timestamp_filtered_custom_table_df['db_hostname'] == j]
            instance_filtered_custom_table_df = instance_filtered_custom_table_df.drop(['db_hostname'], axis=1)

            instance_filtered_query_df = timestamp_filtered_query_df.loc[timestamp_filtered_query_df['db_hostname'] == j]
            instance_filtered_query_df = instance_filtered_query_df.drop(['db_hostname'], axis=1)

            instance_filtered_resForSuper_df = timestamp_filtered_resForSuper_df.loc[timestamp_filtered_resForSuper_df['db_hostname'] == j]
            instance_filtered_resForSuper_df = instance_filtered_resForSuper_df.drop(['db_hostname'], axis=1)

            instance_filtered_maxConn_df = timestamp_filtered_maxConn_df.loc[timestamp_filtered_maxConn_df['db_hostname'] == j]
            instance_filtered_maxConn_df = instance_filtered_maxConn_df.drop(['db_hostname'], axis=1)

            instance_filtered_memInfo_df = timestamp_filtered_memInfo_df.loc[timestamp_filtered_memInfo_df['db_hostname'] == j]
            instance_filtered_memInfo_df = instance_filtered_memInfo_df.drop(['db_hostname'], axis=1)


            # Initialize database list
            databases_dict = []
            instances = {'instance_name': j, 'instance_created_unique_id': hashlib.sha224(
                repr(j + str(random.randint(0, 999999))).encode('utf-8')).hexdigest()}
            # instance_dict = {'instance_created_unique_id': hashlib.sha224(repr(j).encode('utf-8')).hexdigest()}


            rfs = instance_filtered_resForSuper_df.to_dict(orient='records')
            if (len(rfs) > 0):
                rfs_dict = rfs[0]
                rfs_dict = {key: value for key, value in rfs_dict.items() if value != 'None'}
                # keys = list(rfs_dict.keys())
                values = list(rfs_dict.values())
                instances["res_for_super"] = values[0]


            mc = instance_filtered_maxConn_df.to_dict(orient='records')
            if (len(mc) > 0):
                mc_dict = mc[0]
                mc_dict = {key: value for key, value in mc_dict.items() if value != 'None'}
                # keys = list(mc_dict.keys())
                values = list(mc_dict.values())
                instances["max_conn"] = values[0]


            mi = instance_filtered_memInfo_df.to_dict(orient='records')
            if (len(mi) > 0):
                for k in range(0, len(mi)):
                    mi_dict = mi[k]
                    mi_dict = {key: value for key, value in mi_dict.items() if value != 'None'}
                    # keys = list(mi_dict.keys())
                    values = list(mi_dict.values())
                    instances["MemInfo_"+ values[0]] = values[1]


            for d in unique_databases:
                # Filtering custom dataframes on basis of database Name
                database_filter_custom_dat_df = instance_filtered_custom_dat_df.loc[instance_filtered_custom_dat_df['datname'] == d]
                database_filter_custom_dat_df = database_filter_custom_dat_df.drop(['datname'], axis=1)
                database_filter_custom_dat_df = database_filter_custom_dat_df.drop(['datid_x', 'datid_y'], axis=1)

                database_filter_custom_table_df = instance_filtered_custom_table_df.loc[instance_filtered_custom_table_df['datname'] == d]
                database_filter_custom_table_df = database_filter_custom_table_df.drop(['datname'], axis=1)

                database_filter_query_df = instance_filtered_query_df.loc[instance_filtered_query_df['datname'] == d]
                database_filter_query_df = database_filter_query_df.drop(['datname'], axis=1)

                database_dict = {}
                database_dict["database_name"] = d

                dat = {}
                temp1 = database_filter_custom_dat_df
                dat = database_filter_custom_dat_df.to_dict(orient='records')
                if (len(dat) > 0):
                    dat_dict = dat[0]
                    dat_dict = {key: value for key, value in dat_dict.items() if value != 'None'}
                    # Changing metric name "count" to "connection_count"
                    dat_dict = {'connection_count' if key == 'count' else key: value for key, value in dat_dict.items()}
                    keys = list(dat_dict.keys())
                    values = list(dat_dict.values())
                    for j in range(0, len(keys)):
                        database_dict[keys[j]] = values[j]


                queries = []
                for q in unique_pids:
                    # Filtering dataframes on basis of pid's
                    query_filter_query_df = database_filter_query_df.loc[database_filter_query_df['pid'] == q]
                    qd = {}
                    temp2 = query_filter_query_df
                    qd = query_filter_query_df.to_dict(orient='records')
                    if (len(qd) > 0):
                        qd_dict = qd[0]
                        qd_dict = {key: value for key, value in qd_dict.items() if value != 'None'}
                        queries.append(qd_dict)

                if (len(queries) > 0):
                    database_dict["query_duration"] = queries


                tables = []
                for t in unique_tables:
                    # Filtering custom dataframes on basis of tables
                    table_filter_custom_table_df = database_filter_custom_table_df.loc[
                        database_filter_custom_table_df['relname'] == t]
                    table_filter_custom_table_df = table_filter_custom_table_df.drop(['relid_x', 'relid_y'], axis=1)
                    table = {}
                    temp2 = table_filter_custom_table_df
                    table = table_filter_custom_table_df.to_dict(orient='records')
                    if (len(table) > 0):
                        table_dict = table[0]
                        table_dict = {key: value for key, value in table_dict.items() if value != 'None'}
                        # Changing metric name "relname" to "table_name"
                        table_dict = {'table_name' if key == 'relname' else key: value for key, value in table_dict.items()}
                        tables.append(table_dict)

                if (len(tables) > 0):
                    database_dict["tables"] = tables

                if (len(database_dict) > 1):
                    databases_dict.append(database_dict)
            if (len(databases_dict) > 0):
                instances["databases"] = databases_dict

            list_instances.append(instances)

        final_output["source"] = source
        final_output['ts'] = time
        final_output['instances'] = list_instances

        dict_list.append(final_output)


    # Bulk insert all dictionaries to MongoDB
    mongo_client = config['mongo_url']
    mongo_db = config['mongo_db']
    mongo_collection = config['postgres_metrics_info']['mongo_collection']

    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)
    logger.info(f"New entry list size for Postgres = {len(dict_list)}")
    if len(dict_list) > 0:
        collection.insert_many(dict_list)
        exit_handler(OK_CODE)
    else:
        logger.warn("Zero new entries inserted to mongodb for Postgres")
        exit_handler(WARNING_CODE)