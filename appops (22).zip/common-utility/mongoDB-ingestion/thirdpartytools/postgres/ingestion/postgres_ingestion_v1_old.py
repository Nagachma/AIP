from cProfile import run
import csv
import pandas as pd
import os
import yaml
from pymongo import MongoClient
from datetime import datetime
import hashlib
import random

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2

logger = []
exit_handler = []
def ingest_postgres_metrics(config, logger, exit_handler):
    connCountCsvFilePath = config['postgres_metrics_info']['connCountCsvFilePath']
    # connUsedCsvFilePath = config['postgres_metrics_info']['connUsedCsvFilePath']
    pgStatDatabaseCsvFilePath = config['postgres_metrics_info']['pgStatDatabaseCsvFilePath']
    pgStatUserTablesCsvFilePath = config['postgres_metrics_info']['pgStatUserTablesCsvFilePath']
    queryDurationCsvFilePath = config['postgres_metrics_info']['queryDurationCsvFilePath']
    resForSuperCsvFilePath = config['postgres_metrics_info']['resForSuperCsvFilePath']
    hotRateCsvFilePath = config['postgres_metrics_info']['hotRateCsvFilePath']
    maxConnCsvFilePath = config['postgres_metrics_info']['maxConnCsvFilePath']
    memInfoCsvFilePath = config['postgres_metrics_info']['memInfoCsvFilePath']
    # percentoftimeindexCsvFilePath = config['postgres_metrics_info']['percentoftimeindexCsvFilePath']

    if os.path.exists(connCountCsvFilePath):
        df1=pd.read_csv(connCountCsvFilePath)

    # if os.path.exists(connUsedCsvFilePath):
    #     df2=pd.read_csv(connUsedCsvFilePath)

    if os.path.exists(pgStatDatabaseCsvFilePath):
        df3=pd.read_csv(pgStatDatabaseCsvFilePath)

    if os.path.exists(pgStatUserTablesCsvFilePath):
        df4=pd.read_csv(pgStatUserTablesCsvFilePath)

    if os.path.exists(queryDurationCsvFilePath):
        df5=pd.read_csv(queryDurationCsvFilePath)

    if os.path.exists(resForSuperCsvFilePath):
        df6=pd.read_csv(resForSuperCsvFilePath)

    if os.path.exists(hotRateCsvFilePath):
        df7=pd.read_csv(hotRateCsvFilePath)

    if os.path.exists(maxConnCsvFilePath):
        df8=pd.read_csv(maxConnCsvFilePath)

    if os.path.exists(memInfoCsvFilePath):
        df9=pd.read_csv(memInfoCsvFilePath)

    # if os.path.exists(percentoftimeindexCsvFilePath):
    #     df10=pd.read_csv(percentoftimeindexCsvFilePath)


    instance_name = list(df1.db_hostname)
    # instance_name2 = list(df2.db_hostname)
    instance_name3 = (list(df3.db_hostname))
    instance_name4 = (list(df4.db_hostname))
    instance_name5 = (list(df5.db_hostname))
    instance_name6 = (list(df6.db_hostname))
    instance_name7 = (list(df7.db_hostname))
    instance_name8 = (list(df8.db_hostname))
    instance_name9 = (list(df9.db_hostname))
    # instance_name10 = (list(df10.db_hostname))

    database_name = list(df1.datname)
    # database_name2 = list(df2.datname)
    database_name3 = (list(df3.datname))
    database_name4 = (list(df4.datname))
    database_name5 = (list(df5.datname))
    database_name7 = (list(df7.datname))
    # database_name10 = (list(df10.db_hostname))
    database_name.extend(database_name3)
    database_name.extend(database_name4)
    database_name.extend(database_name5)
    database_name.extend(database_name7)
    # database_name.extend(database_name10)
    database_name = [*set(database_name)]
    database_id =list(df1.datid)
    database_id2 =list(df3.datid)
    database_id.extend(database_id2)
    database_id =[*set(database_id)]
    db_map={}
    # for d in database_id:

    table_name=list(df4.relname)
    table_name = [*set(table_name)]


    # instance_name.extend(instance_name2)
    instance_name.extend(instance_name3)
    instance_name.extend(instance_name4)
    instance_name.extend(instance_name5)
    instance_name.extend(instance_name6)
    instance_name.extend(instance_name7)
    instance_name.extend(instance_name8)
    instance_name.extend(instance_name9)
    # instance_name.extend(instance_name10)
    instance_name = [*set(instance_name)]

    timestamp = list(df1.metric_date)
    timestamp = [*set(timestamp)]
    timestamp = list(map(lambda timestp: timestp[0:16], timestamp))

    # timestamp2 = list(df2.metric_date)
    # timestamp2 = [*set(timestamp2)]
    # timestamp2 = list(map(lambda timestp: timestp[0:16], timestamp2))

    timestamp3 = list(df3.metric_date)
    timestamp3 = [*set(timestamp3)]
    timestamp3 = list(map(lambda timestp: timestp[0:16], timestamp3))

    timestamp4 = list(df4.metric_date)
    timestamp4 = [*set(timestamp4)]
    timestamp4 = list(map(lambda timestp: timestp[0:16], timestamp4))

    timestamp5 = list(df5.metric_date)
    timestamp5 = [*set(timestamp5)]
    timestamp5 = list(map(lambda timestp: timestp[0:16], timestamp5))

    timestamp6 = list(df6.metric_date)
    timestamp6 = [*set(timestamp6)]
    timestamp6 = list(map(lambda timestp: timestp[0:16], timestamp6))

    timestamp7 = list(df7.metric_date)
    timestamp7 = [*set(timestamp7)]
    timestamp7 = list(map(lambda timestp: timestp[0:16], timestamp7))

    timestamp8 = list(df8.metric_date)
    timestamp8 = [*set(timestamp8)]
    timestamp8 = list(map(lambda timestp: timestp[0:16], timestamp8))

    timestamp9 = list(df9.metric_date)
    timestamp9 = [*set(timestamp9)]
    timestamp9 = list(map(lambda timestp: timestp[0:16], timestamp9))

    # timestamp10 = list(df10.metric_date)
    # timestamp10 = [*set(timestamp10)]
    # timestamp10 = list(map(lambda timestp: timestp[0:16], timestamp10))

    # timestamp.extend(timestamp2)
    timestamp.extend(timestamp3)
    timestamp.extend(timestamp4)
    timestamp.extend(timestamp5)
    timestamp.extend(timestamp6)
    timestamp.extend(timestamp7)
    timestamp.extend(timestamp8)
    timestamp.extend(timestamp9)
    # timestamp.extend(timestamp10)
    timestamp = [*set(timestamp)]
    timestamp.sort()

    source = config['source']

    dict_list = []


    for i in timestamp:
        time = i
        time = datetime.strptime(time, '%Y-%m-%d %H:%M')
        final_output = {}
        instances = []

        for j in instance_name:

            instance_dict = {'instance_name': j, 'instance_created_unique_id': hashlib.sha224(
                repr(j + str(random.randint(0, 999999))).encode('utf-8')).hexdigest()}
            # instance_dict = {'instance_created_unique_id': hashlib.sha224(repr(j).encode('utf-8')).hexdigest()}

            with open(resForSuperCsvFilePath) as res_for_super_file:
                heading1 = next(res_for_super_file)
                reader_obj1 = csv.reader(res_for_super_file)
                for row in reader_obj1:
                    if row[2] == j and row[0][0:16] == i:
                        # if (row[1] != ""):
                        #     instance_dict["res_for_super"] = row[1]
                        metric_name="res_for_super"
                        value=row[1]
                        if value is None or value == '':
                            pass
                        else:
                            try:
                                value = float(value)
                            except ValueError as ve:
                                # non-float value
                                instance_dict[metric_name]=row[1]
                            else:
                                # float value if no exception
                                instance_dict[metric_name] = float(value)

            with open(maxConnCsvFilePath) as max_conn_file:
                heading2 = next(max_conn_file)
                reader_obj2 = csv.reader(max_conn_file)
                for row in reader_obj2:
                    if row[2] == j and row[0][0:16] == i:
                        # if (row[1] != ""):
                        #     instance_dict["max_conn"] = row[1]
                        metric_name="max_conn"
                        value=row[1]
                        if value is None or value == '':
                            pass
                        else:
                            try:
                                value = float(value)
                            except ValueError as ve:
                                # non-float value
                                instance_dict[metric_name]=row[1]
                            else:
                                # float value if no exception
                                instance_dict[metric_name] = float(value)

            with open(memInfoCsvFilePath) as memory_info_file:
                heading3 = next(memory_info_file)
                reader_obj3= csv.reader(memory_info_file)
                mem_info_dict={}
                for row in reader_obj3:
                    if row[3] == j and row[0][0:16] == i:
                        if (row[1] != ""):
                            metric_name="MemInfo_"+row[1]
                            value=row[2]
                            if value is None or value == '':
                                pass
                            else:
                                try:
                                    value = float(value)
                                except ValueError as ve:
                                    # non-float value
                                    instance_dict[metric_name]=row[2]
                                else:
                                    # float value if no exception
                                    instance_dict[metric_name] = float(value)

            databases=[]
            for d in database_name:
                database={}
                database["database_name"]=d
                with open(connCountCsvFilePath) as conn_count_csv_file:
                    heading4 = next(conn_count_csv_file)
                    reader_obj4 = csv.reader(conn_count_csv_file)
                    for row in reader_obj4:
                        if row[4] == j and row[0][0:16] == i and row[2]==d:
                            # if (row[3] != ""):
                            #     database["connection_count"] = row[3]
                            metric_name="connection_count"
                            value=row[3]
                            if value is None or value == '':
                                pass
                            else:
                                try:
                                    value = float(value)
                                except ValueError as ve:
                                    # non-float value
                                    database[metric_name]=row[3]
                                else:
                                    # float value if no exception
                                    database[metric_name] = float(value)

                with open(queryDurationCsvFilePath) as query_duration_file:
                    heading5 = next(query_duration_file)
                    reader_obj5 = csv.reader(query_duration_file)
                    queries=[]
                    for row in reader_obj5:
                        query={}
                        if row[7] == j and row[0][0:16] == i and row[1] == d:
                            if row[5] is None or row[5] == '':
                                pass
                            else:
                                query["query"]=str(row[2])
                                query["pid"]=row[4]
                                query["start_time"]=row[3]
                                query["duration"]=row[5]
                                query["state"]=row[6]
                        if query:
                            queries.append(query)
                    if len(queries)>0:
                        database["query_duration"]=queries

                with open(pgStatDatabaseCsvFilePath) as pg_stat_database_csv_file:
                    heading6 = next(pg_stat_database_csv_file)
                    headers = list(df3.columns)
                    reader_obj6=csv.reader(pg_stat_database_csv_file)
                    for row in reader_obj6:
                        if row[9] == j and row[0][0:16] == i and row[2] == d:
                            col=3
                            for metric_name in headers[3:-1]:
                                value=row[col]
                                if value is None or value == '':
                                    pass
                                else:
                                    try:
                                        value = float(value)
                                    except ValueError as ve:
                                        # non-float value
                                        database[metric_name]=row[col]
                                    else:
                                        # float value if no exception
                                        database[metric_name] = float(value)
                                col=col+1

                tables=[]
                for t in table_name:
                    table={}
                    table["table_name"]=t
                    with open(hotRateCsvFilePath) as hot_rate_csv_file:
                        heading7 = next(hot_rate_csv_file)
                        reader_obj7 = csv.reader(hot_rate_csv_file)
                        for row in reader_obj7:
                            if row[5] == j and row[0][0:16] == i and row[1] == d and row[3]==t:
                                value=row[4]
                                metric_name="hot_rate"
                                if value is None or value == '':
                                    pass
                                else:
                                    try:
                                        value = float(value)
                                    except ValueError as ve:
                                        # non-float value
                                        table[metric_name]=row[4]
                                    else:
                                        # float value if no exception
                                        table[metric_name] = float(value)
                    
                    
                    with open(pgStatUserTablesCsvFilePath) as pg_stat_user_csv_file:
                        heading8 = next(pg_stat_user_csv_file)
                        headers = list(df4.columns)
                        reader_obj8=csv.reader((pg_stat_user_csv_file))
                        for row in reader_obj8:
                            if row[13] == j and row[0][0:16] == i and row[1] == d and row[3]==t:
                                col=4
                                for metric_name in headers[4:-1]:
                                    value=row[col]
                                    if value is None or value == '':
                                        pass
                                    else:
                                        try:
                                            value = float(value)
                                        except ValueError as ve:
                                            # non-float value
                                            table[metric_name]=row[col]
                                        else:
                                            # float value if no exception
                                            table[metric_name] = float(value)
                                    col=col+1
                    if len(table)>1:
                        tables.append(table)
                if len(tables)>0:
                    database["tables"]=tables
                if len(database)>1:
                    databases.append(database)
            if len(databases)>0:
                instance_dict["databases"]=databases
            if instance_dict:
                instances.append(instance_dict)

        final_output["source"] = source
        final_output['ts'] = time
        final_output['instances'] = instances

        dict_list.append(final_output)

    # Bulk insert all dictionaries to MongoDB
    mongo_client = config['mongo_url']
    mongo_db = config['mongo_db']
    mongo_collection = config['postgres_metrics_info']['mongo_collection']
    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)
    logger.info(f"New entry list size for Postgres = {len(dict_list)}")
    if len(dict_list) > 0:
        collection.insert_many(dict_list)
        exit_handler(OK_CODE)
    else:
        logger.warn("Zero new entries inserted to mongodb for Postgres")
        exit_handler(WARNING_CODE)
