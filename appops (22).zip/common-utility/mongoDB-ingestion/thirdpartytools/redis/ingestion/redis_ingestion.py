"""
Module to ingest csvs to mongo db.
"""
import numpy as np
import pandas as pd
from pymongo import MongoClient

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2


def preprocess_timestamp(df):
    df['timestamp'] = pd.to_datetime(df['timestamp'], format='%Y-%m-%d %H:%M:00+00:00')
    return df


def cast_int64(df):
    for col in df.select_dtypes(include=np.int64).columns.tolist():
        df[col] = df[col].astype(float)


def ingest_redis_csvs(config, logger, exit_handler):
    info_redis_csv_path = config['redis_metrics_info']['info_csv']
    latency_redis_csv_path = config['redis_metrics_info']['latency_csv']

    info_redis_df = pd.read_csv(info_redis_csv_path)
    latency_redis_df = pd.read_csv(latency_redis_csv_path)

    preprocess_timestamp(info_redis_df)
    preprocess_timestamp(latency_redis_df)

    cast_int64(info_redis_df)
    cast_int64(latency_redis_df)

    timestamp = [*set(info_redis_df.timestamp)]
    timestamp.sort()

    source = config['thirdparty_source']

    mongo_client = config['mongo_url']
    mongo_db = config['mongo_db']
    mongo_collection = config['redis_metrics_info']['mongo_collection']

    dict_list = []
    for i in timestamp:

        final_output = {'source': source, 'ts': i}
        instances = []
        temp = dict()
        for j, row in info_redis_df[(info_redis_df['timestamp'] == i)].iterrows():
            temp['ip'] = row['ip']
            temp['redis_version'] = row['redis_version']
            temp['redis_build_id'] = row['redis_build_id']
            temp['redis_mode'] = row['redis_mode']
            temp['process_id'] = row['process_id']
            temp['process_supervised'] = row['process_supervised']
            temp['run_id'] = row['run_id']
            temp['io_threads_active'] = row['io_threads_active']
            temp['connected_clients'] = row['connected_clients']
            temp['cluster_connections'] = row['cluster_connections']
            temp['maxclients'] = row['maxclients']
            temp['client_recent_max_input_buffer'] = row['client_recent_max_input_buffer']
            temp['client_recent_max_output_buffer'] = row['client_recent_max_output_buffer']
            temp['blocked_clients'] = row['blocked_clients']
            temp['tracking_clients'] = row['tracking_clients']
            temp['clients_in_timeout_table'] = row['clients_in_timeout_table']
            temp['used_memory'] = row['used_memory']
            temp['used_memory_human'] = row['used_memory_human']
            temp['used_memory_rss'] = row['used_memory_rss']
            temp['used_memory_rss_human'] = row['used_memory_rss_human']
            temp['used_memory_peak'] = row['used_memory_peak']
            temp['used_memory_peak_human'] = row['used_memory_peak_human']
            temp['used_memory_peak_perc'] = row['used_memory_peak_perc']
            temp['used_memory_overhead'] = row['used_memory_overhead']
            temp['used_memory_startup'] = row['used_memory_startup']
            temp['used_memory_dataset'] = row['used_memory_dataset']
            temp['used_memory_dataset_perc'] = row['used_memory_dataset_perc']
            temp['total_system_memory'] = row['total_system_memory']
            temp['total_system_memory_human'] = row['total_system_memory_human']
            temp['used_memory_lua'] = row['used_memory_lua']
            temp['used_memory_lua_human'] = row['used_memory_lua_human']
            temp['used_memory_scripts'] = row['used_memory_scripts']
            temp['used_memory_scripts_human'] = row['used_memory_scripts_human']
            temp['maxmemory'] = row['maxmemory']
            temp['mem_clients_slaves'] = row['mem_clients_slaves']
            temp['mem_clients_normal'] = row['mem_clients_normal']
            temp['mem_cluster_links'] = row['mem_cluster_links']
            temp['mem_aof_buffer'] = row['mem_aof_buffer']
            temp['mem_replication_backlog'] = row['mem_replication_backlog']
            temp['mem_total_replication_buffers'] = row['mem_total_replication_buffers']
            temp['mem_allocator'] = row['mem_allocator']
            temp['total_connections_received'] = row['total_connections_received']
            temp['total_commands_processed'] = row['total_commands_processed']
            temp['rejected_connections'] = row['rejected_connections']
            temp['used_cpu_sys'] = row['used_cpu_sys']
            temp['used_cpu_user'] = row['used_cpu_user']
            temp['used_cpu_sys_children'] = row['used_cpu_sys_children']
            temp['used_cpu_user_children'] = row['used_cpu_user_children']
            temp['used_cpu_sys_main_thread'] = row['used_cpu_sys_main_thread']
            temp['used_cpu_user_main_thread'] = row['used_cpu_user_main_thread']
            temp['errorstat_ERR'] = row['errorstat_ERR']
            temp['cluster_enabled'] = row['cluster_enabled']

        for j, row in latency_redis_df[
         (latency_redis_df['timestamp'] == i) & (temp['ip'] == latency_redis_df['ip'])].iterrows():
            temp['latency_percentiles_usec_hello_p50'] = row["latency_percentiles_usec_hello_p50"]
            temp['latency_percentiles_usec_hello_p99'] = row["latency_percentiles_usec_hello_p99"]
            temp['latency_percentiles_usec_hello_p999'] = row["latency_percentiles_usec_hello_p99.9"]
            temp['latency_percentiles_usec_ping_p50'] = row["latency_percentiles_usec_ping_p50"]
            temp['latency_percentiles_usec_ping_p99'] = row["latency_percentiles_usec_ping_p99"]
            temp['latency_percentiles_usec_ping_p999'] = row["latency_percentiles_usec_ping_p99.9"]
            temp['latency_percentiles_usec_command_docs_p50'] = row["latency_percentiles_usec_command|docs_p50"]
            temp['latency_percentiles_usec_command_docs_p99'] = row["latency_percentiles_usec_command|docs_p99"]
            temp['latency_percentiles_usec_command_docs_p999'] = row["latency_percentiles_usec_command|docs_p99.9"]
            temp['latency_percentiles_usec_memory_stats_p50'] = row["latency_percentiles_usec_memory|stats_p50"]
            temp['latency_percentiles_usec_memory_stats_p99'] = row["latency_percentiles_usec_memory|stats_p99"]
            temp['latency_percentiles_usec_memory_stats_p999'] = row["latency_percentiles_usec_memory|stats_p99.9"]
            temp['latency_percentiles_usec_memory_doctor_p50'] = row["latency_percentiles_usec_memory|doctor_p50"]
            temp['latency_percentiles_usec_memory_doctor_p99'] = row["latency_percentiles_usec_memory|doctor_p99"]
            temp['latency_percentiles_usec_memory_doctor_p999'] = row["latency_percentiles_usec_memory|doctor_p99.9"]
            temp['latency_percentiles_usec_info_p50'] = row["latency_percentiles_usec_info_p50"]
            temp['latency_percentiles_usec_info_p99'] = row["latency_percentiles_usec_info_p99"]
            temp['latency_percentiles_usec_info_p999'] = row["latency_percentiles_usec_info_p99.9"]
            temp['latency_percentiles_usec_latency_graph_p50'] = row["latency_percentiles_usec_latency|graph_p50"]
            temp['latency_percentiles_usec_latency_graph_p99'] = row["latency_percentiles_usec_latency|graph_p99"]
            temp['latency_percentiles_usec_latency_graph_p999'] = row["latency_percentiles_usec_latency|graph_p99.9"]
            temp['latency_percentiles_usec_latency_latest_p50'] = row["latency_percentiles_usec_latency|latest_p50"]
            temp['latency_percentiles_usec_latency_latest_p99'] = row["latency_percentiles_usec_latency|latest_p99"]
            temp['latency_percentiles_usec_latency_latest_p999'] = row["latency_percentiles_usec_latency|latest_p99.9"]
            temp['latency_percentiles_usec_latency_history_p50'] = row["latency_percentiles_usec_latency|history_p50"]
            temp['latency_percentiles_usec_latency_history_p99'] = row["latency_percentiles_usec_latency|history_p99"]
            temp['latency_percentiles_usec_latency_history_p999'] = row[
                "latency_percentiles_usec_latency|history_p99.9"]
            temp['latency_percentiles_usec_slowlog_get_p50'] = row["latency_percentiles_usec_slowlog|get_p50"]
            temp['latency_percentiles_usec_slowlog_get_p99'] = row["latency_percentiles_usec_slowlog|get_p99"]
            temp['latency_percentiles_usec_slowlog_get_p999'] = row["latency_percentiles_usec_slowlog|get_p99.9"]
            temp['latency_percentiles_usec_slowlog_help_p50'] = row["latency_percentiles_usec_slowlog|help_p50"]
            temp['latency_percentiles_usec_slowlog_help_p99'] = row["latency_percentiles_usec_slowlog|help_p99"]
            temp['latency_percentiles_usec_slowlog_help_p999'] = row["latency_percentiles_usec_slowlog|help_p99.9"]

        instances.append(temp)
        final_output['instances'] = instances

        dict_list.append(final_output)

    # Bulk insert all dictionaries to MongoDB
    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)

    logger.info(f"New entry list size for Redis = {len(dict_list)}")

    if len(dict_list) > 0:
        collection.insert_many(dict_list)
        exit_handler(OK_CODE)
    else:
        logger.warn("Zero new entries inserted to mongodb for Redis")
        exit_handler(WARNING_CODE)
