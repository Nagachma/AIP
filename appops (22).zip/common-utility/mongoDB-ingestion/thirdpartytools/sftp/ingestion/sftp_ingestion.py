"""
Module to ingest csvs to mongo db.
"""
import csv

import pandas as pd
import numpy as np
from pymongo import MongoClient
from datetime import datetime

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2


def convert_to_ascii(page_id_string):
    return ''.join(str(ord(c)) for c in page_id_string)
def ingest_sftp_csvs(config, logger, exit_handler):
    csv_file1 = config['sftp_metrics_info']['conn_csv']

    df_csv_file1 = pd.read_csv(csv_file1)

    timestamp = list(df_csv_file1.Timestamp)
    timestamp = [*set(timestamp)]
    timestamp = list(map(lambda timestp: timestp[0:16], timestamp))
    timestamp.sort()

    host = list(df_csv_file1.host)
    host = [*set(host)]
    host.sort()

    dict_list = []
    source = config['thirdparty_source']

    for i in timestamp:
        time = i
        time = datetime.strptime(time, '%Y-%m-%d %H:%M')

        final_output = {}

        conn_status = []
        dict = {}

        for j in host:
            with open(csv_file1) as for_host:
                heading = next(for_host)
                csvFile1_header = list(df_csv_file1.columns)
                reader_obj = csv.reader(for_host)
                for row in reader_obj:
                    if row[0][0:16] == i and row[1] == j:
                        count = 1
                        while count < len(row):
                            if row[count] is None or row[count] == '':
                                count = count + 1
                                continue
                            elif row[count] is not None or row[count] != '':
                                if csvFile1_header[count] == "username":
                                    dict["username_ascii"] = convert_to_ascii(row[count])
                                if csvFile1_header[count] == "server_reachability" or csvFile1_header[
                                    count] == "server_connectivity":
                                    dict[csvFile1_header[count]] = int(row[count])
                                else:
                                    dict[csvFile1_header[count]] = row[count]
                                count = count + 1
            conn_status.append(dict)

        final_output["source"] = source
        final_output["ts"] = time
        final_output["connection_status"] = conn_status

        dict_list.append(final_output)

    mongo_client = config['mongo_url_dev']
    mongo_db = config['mongo_db']
    mongo_collection = config['sftp_metrics_info']['mongo_collection']

    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)
    # Bulk insert all dictionaries to MongoDB
    logger.info('New entry list size for SFTP = {}'.format(len(dict_list)))
    if len(dict_list) > 0:
        collection.insert_many(dict_list)
        exit_handler(OK_CODE)
    else:
        logger.warn('Zero 0 new entries inserted to mongo db for SFTP')
        exit_handler(WARNING_CODE)