import datetime
import os.path
from datetime import datetime

import pandas as pd
from pymongo import MongoClient

import csv

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2


def ingest_sqlserver_csvs(config, logger, exit_handler):
    # Declarations
    active_locks_csv_file = config['sqlserver_metrics_info']['active_locks_CsvFilePath']
    buffer_memory_csv_file = config['sqlserver_metrics_info']['buffer_memory_utilization_per_database_CsvFilePath']
    cpu_utilization_csv_file = config['sqlserver_metrics_info']['cpu_utilization_CsvFilePath']
    maximum_connections_csv_file = config['sqlserver_metrics_info']['maximum_connections_CsvFilePath']
    memory_monitor_latch_contention_csv_file = config['sqlserver_metrics_info']['memory_monitor_CsvFilePath']
    object_causing_latch_contention_csv_file = config['sqlserver_metrics_info']['object_causing_latch_contention_CsvFilePath']
    query_duration_csv_file = config['sqlserver_metrics_info']['query_duration_CsvFilePath']
    total_lock_and_latch_waits_csv_file = config['sqlserver_metrics_info']['total_lock_and_latch_waits_CsvFilePath']
    total_connections_csv_file = config['sqlserver_metrics_info']['total_connections_CsvFilePath']
    source = config['thirdparty_source']
    dict_list = []
    server_names=[]
    databases=[]
    database_ids=[]
    table_names=[]
    timestamps=[]
    db_map1 = None
    #### Listing out unique resources for query ######
    if os.path.exists(cpu_utilization_csv_file):
        df1=pd.read_csv(cpu_utilization_csv_file)
        database1=list(df1.DBName)
        timestamp1=list(df1.start_time)
        databases.extend(database1)
        timestamps.extend(timestamp1)

    if os.path.exists(buffer_memory_csv_file):
        df2=pd.read_csv(buffer_memory_csv_file)
        database2=list(df2.db_name)
        timestamp2=list(df2.start_time)
        databases.extend(database2)
        timestamps.extend(timestamp2)
        temp_df1 = df2[['database_id', 'db_name']].copy().groupby(['database_id', 'db_name'],
                                                                     as_index=False).size().drop(['size'], axis=1)
        db_map1 = dict(zip(temp_df1.db_name, temp_df1.database_id))


    if os.path.exists(query_duration_csv_file):
        df5=pd.read_csv(query_duration_csv_file)
        server_name=list(df5.server_name)
        server_names.extend(server_name)
        database5 = list(df5.sqldatabasesname)
        databases.extend(database5)
        timestamp5 = list(df5.start_time)
        timestamps.extend(timestamp5)
        query_headers=list(df5.columns)


    if os.path.exists(total_lock_and_latch_waits_csv_file):
        df6=pd.read_csv(total_lock_and_latch_waits_csv_file)
        database6 = list(df6.database_name)
        databases.extend(database6)
        table_name=list(df6.table_name)
        table_names.extend(table_name)
        timestamp6 = list(df6.start_time)
        timestamps.extend(timestamp6)
        table_headers = list(df6.columns)

    if os.path.exists(object_causing_latch_contention_csv_file):
        df7=pd.read_csv(object_causing_latch_contention_csv_file)
        database7 = list(df7.database_name)
        databases.extend(database7)
        timestamp7 = list(df7.start_time)
        timestamps.extend(timestamp7)

    if os.path.exists(memory_monitor_latch_contention_csv_file):
        df11=pd.read_csv(memory_monitor_latch_contention_csv_file)
        server11 = list(df11.server_name)
        server_names.extend(server11)
        timestamp11 = list(df11.start_time)
        timestamps.extend(timestamp11)
        memory_headers = list(df11.columns)

    if os.path.exists(active_locks_csv_file):
        df14=pd.read_csv(active_locks_csv_file)
        server14 = list(df14.server_name)
        server_names.extend(server14)
        timestamp14 = list(df14.start_time)
        timestamps.extend(timestamp14)
        lock_headers = list(df14.columns)
        lock_headers = [s for s in lock_headers if s != "blocking_session_id"]

    timestamps = [item for item in timestamps if not(pd.isnull(item)) == True]
    timestamps = list(map(lambda timestp: timestp[0:16], timestamps))
    timestamps = [*set(timestamps)]
    timestamps.sort()

    server_names = [item for item in server_names if not (pd.isnull(item)) == True]
    server_names = [*set(server_names)]
    server_names.sort()

    databases = [item for item in databases if not (pd.isnull(item)) == True]
    databases = [*set(databases)]
    databases.sort()

    table_names = [item for item in table_names if not (pd.isnull(item)) == True]
    table_names = [*set(table_names)]
    table_names.sort()

    for i in timestamps:
        time = i
        time = datetime.strptime(time, '%Y-%m-%d %H:%M')
        final_output = {}
        servers=[]
        for s in server_names:
            server={}
            server['server_name']=s
            with open(memory_monitor_latch_contention_csv_file)  as mem:
                heading11=next(mem)
                reader_obj11=csv.reader(mem)
                for row11 in reader_obj11:
                    if row11[1][0:16]==i and row11[0]==s:
                        count1 = 2
                        while count1 <=10:
                            if count1 > 1 and row11[count1] is not None and row11[count1] != '':
                                server[memory_headers[count1]]=row11[count1]
                            count1=count1+1

            with open(total_connections_csv_file)  as tc:
                heading12=next(tc)
                reader_obj12=csv.reader(tc)
                for row12 in reader_obj12:
                    if row12[0]==s:
                        server['total_active_connections']=row12[1]
                        server['client_machines']=row12[2]

            with open(maximum_connections_csv_file)  as mc:
                heading13=next(mc)
                reader_obj13=csv.reader(mc)
                for row13 in reader_obj13:
                    if row13[0]==s and row13[1][0:16]==i:
                        server['maximum_connections']=row13[2]
                        server['login_attempts']=row13[3]

            database_list=[]
            for d in databases:
                db_dict={}
                db_dict['database_id']=db_map1[d]
                db_dict['database_name']=d
                cpu_slowness_flag = False
                memory_slowness_flag = False
                # unresponsive_flag = False
                with open(cpu_utilization_csv_file) as cpu:
                    heading1=next(cpu)
                    reader_obj1=csv.reader(cpu)

                    for row1 in reader_obj1:
                        if row1[0][0:16] == i and row1[1]==d:
                            db_dict['cpu_utilization_time']=row1[2]
                            db_dict['cpu_utilization_percentage']=row1[3]
                            if float(row1[3]) > 80:
                                cpu_slowness_flag=True
                with open(buffer_memory_csv_file) as buffer:
                    heading2=next(buffer)
                    reader_obj2=csv.reader(buffer)

                    for row2 in reader_obj2:
                        if row2[0]==s and row2[1][0:16] == i and row2[2]==d:
                            db_dict['db_buffer_memory_utilization_MB']=row2[5]
                            db_dict['db_buffer_memory_utilization_percent']=row2[6]
                            if float(row2[6]) > 80:
                                memory_slowness_flag=True
                if cpu_slowness_flag and memory_slowness_flag:
                    db_dict['database_slowness_status']=True
                with open(query_duration_csv_file) as run_query:
                    heading4=next(run_query)
                    reader_obj4=csv.reader(run_query)
                    queries=[]
                    for row4 in reader_obj4:
                        query={}
                        if row4[3][0:16] == i and row4[2]==d and row4[0]==s:
                            is_query_blocked = None
                            if row4[15] == str(0) or (row4[13] is None or row4[13] == '0'):
                                is_query_blocked= False
                            # elif row4[15]==str(1):
                            else:
                                is_query_blocked =True
                            count2 = 4
                            while count2 <= 26:
                                if count2 > 3 and row4[count2] is not None and row4[count2] != '':
                                    if query_headers[count2] == 'STATUS' and row4[count2] != 'running':
                                        query['STATUS'] = 3
                                    elif query_headers[count2] == 'STATUS' and row4[count2] == 'running':
                                        query['STATUS'] = 2
                                    else:
                                        query[query_headers[count2]] = row4[count2]
                                count2 = count2 + 1
                            query['is_query_blocked'] = is_query_blocked
                            objects = []
                            if (row4[16] is not None and 'PAGELATCH_' in str(row4[16]) ):
                                # unresponsive_flag =True
                                query['query_unresponsive_status'] = True
                                with open(object_causing_latch_contention_csv_file) as latch_contention:
                                    heading6 = next(latch_contention)
                                    reader_obj6 = csv.reader(latch_contention)

                                    for row6 in reader_obj6:
                                        object = {}
                                        if row6[0][0:16] == i and row6[1] == d and row6[6]==row4[13]:
                                            object['index_name'] = row6[2]
                                            object['object_id'] = row6[3]
                                            object['object_name'] = row6[4]
                                            object['schema_name'] = row6[5]
                                            object['wait_duration_ms'] = row6[8]
                                            object['latch_session_id'] = row6[6]
                                            objects.append(object)
                                query['latch_contention_objects'] = objects
                            locks=[]
                            if (row4[16] is not None and 'LCK_' in str(row4[16]) ):
                                # unresponsive_flag =True
                                query['query_unresponsive_status'] = True
                                with open(active_locks_csv_file) as lock_contention:
                                    heading7 = next(lock_contention)
                                    reader_obj7 = csv.reader(lock_contention)

                                    for row7 in reader_obj7:
                                        lock = {}
                                        if row7[1][0:16] == i and row7[21]==row4[13]:
                                            count4 = 2
                                            while count4 <= 21:
                                                if count4 > 1 and row7[count4] is not None and row7[count4] != '':
                                                    lock[lock_headers[count4]] = row7[count4]
                                                count4 = count4 + 1
                                            locks.append(lock)
                                query['active_locks'] = locks
                            queries.append(query)
                    if len(queries)>0:
                        db_dict['queries']=queries

                # if unresponsive_flag:
                #     db_dict['database_unresponsive_status']= True
                with open(total_lock_and_latch_waits_csv_file) as lock_latch:
                    heading5=next(lock_latch)
                    reader_obj5=csv.reader(lock_latch)
                    waits=[]
                    for row5 in reader_obj5:
                        tables={}
                        if row5[0][0:16] == i and row5[2] == d:
                            count3 = 3
                            while count3 <= 13:
                                if count3 > 1 and row5[count3] is not None and row5[count3] != '':
                                    tables[table_headers[count3]] = row5[count3]
                                count3 = count3 + 1
                            waits.append(tables)
                    if len(waits)>0:
                        db_dict['waits']=waits


                    # db_dict['latch_contention_objects']=objects
                database_list.append(db_dict)
            server['databases']=database_list
            servers.append(server)

        final_output["source"] = source
        final_output["ts"] = time
        final_output["servers"] = servers
        dict_list.append(final_output)

    # # Bulk insert all dictionaries to MongoDB
    mongo_client = config['mongo_url']
    mongo_db = config['mongo_db']
    mongo_collection = config['sqlserver_metrics_info']['mongo_collection']
    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)
    # print(dict_list)
    logger.info('New entry list size for Azure sql_server = {}'.format(len(dict_list)))
    if len(dict_list) > 0:
        collection.insert_many(dict_list)
        exit_handler(OK_CODE)
    else:
        logger.warn('Zero 0 new entries inserted to mongo db for Azure sql_server')
        exit_handler(WARNING_CODE)
