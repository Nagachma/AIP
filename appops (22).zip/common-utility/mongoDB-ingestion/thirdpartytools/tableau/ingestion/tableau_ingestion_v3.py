import tempfile
import csv
import pandas as pd
import os
from pymongo import MongoClient
from datetime import datetime


# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2

logger = []
exit_handler = []


def ingest_tableau_csvs(config, logger, exit_handler):
    # getting csv paths from config
    global df_active_users, df_background_job_failure, df_extract_failure_per_site, df_load_time, df_view_accessed, df_proces, average_load_time_df
    process_csv = config['tableau_metrics_info']['processwise_csv']
    active_users = config['tableau_metrics_info']['db_active_users_per_workbook_csv']
    background_job_failure = config['tableau_metrics_info']['db_background_job_failure_per_site_csv']
    extract_failure_per_site = config['tableau_metrics_info']['db_extract_failure_per_site_csv']
    load_time = config['tableau_metrics_info']['db_load_time_csv']
    view_accessed = config['tableau_metrics_info']['db_view_accessed_per_workbook_csv']
    workbook_details = config['tableau_metrics_info']['db_workbook_details_csv']

    average_load_time_df = {}
    workbook_map0 = {}
    workbook_map1 = {}
    workbook_map2 = {}
    workbook_map3 = {}

    # checking if the csvs are present or not
    if os.path.exists(process_csv):
        df_proces = pd.read_csv(process_csv)
        df_proces["TimeStamp"] = pd.to_datetime(df_proces["TimeStamp"]).dt.strftime('%Y-%m-%d %H:%M')

    if os.path.exists(active_users):
        df_active_users = pd.read_csv(active_users)
        df_active_users["start_time"] = pd.to_datetime(df_active_users["start_time"]).dt.strftime('%Y-%m-%d %H:%M')
        df_active_users.rename(columns={'count': 'active_users'}, inplace=True)

    if os.path.exists(background_job_failure):
        df_background_job_failure = pd.read_csv(background_job_failure)
        df_background_job_failure["start_time"] = pd.to_datetime(df_background_job_failure["start_time"]).dt.strftime(
            '%Y-%m-%d %H:%M')

    if os.path.exists(extract_failure_per_site):
        df_extract_failure_per_site = pd.read_csv(extract_failure_per_site)
        df_extract_failure_per_site["start_time"] = pd.to_datetime(df_extract_failure_per_site["start_time"]).dt.strftime('%Y-%m-%d %H:%M')

    if os.path.exists(load_time):
        df_load_time = pd.read_csv(load_time)
        df_load_time["start_time"] = pd.to_datetime(df_load_time["start_time"]).dt.strftime('%Y-%m-%d %H:%M')
        # Group by 'workbook_id' and calculate the average load_time
        average_load_time_df = df_load_time.groupby(['workbook_id', 'start_time'], as_index=False).agg(
            average_load_time=('load_time', 'mean'),
            start_time=('start_time', 'first'),
            end_time=('end_time', 'first'),
            sites_name=('sites_name', 'first'),
            sites_id=('sites_id', 'first'),
            project_name=('project_name', 'first'),
            project_id=('project_id', 'first')
        )

    if os.path.exists(view_accessed):
        df_view_accessed = pd.read_csv(view_accessed)
        df_view_accessed["start_time"] = pd.to_datetime(df_view_accessed["start_time"]).dt.strftime('%Y-%m-%d %H:%M')
        df_view_accessed.rename(columns={'count': 'view_accessed'}, inplace=True)

    if os.path.exists(workbook_details):
        df_workbook_details = pd.read_csv(workbook_details)
        # timestamp6 = list(df_workbook_details.start_time)
        # timestamp.extend(timestamp6)
        # workbook_id4 = list(df_workbook_details.id)
        # workbook_id.extend(workbook_id4)
        # temp_df1 = df_workbook_details[['name', 'id']].copy().groupby(['name', 'id'], as_index=False).size().drop(
        #     ['size'], axis=1)
        # temp_df2 = df_workbook_details[['name', 'size']].copy().rename(columns={'size': 'workbook_size'}).groupby(['name', 'workbook_size'], as_index=False).size().drop(
        #     ['size'], axis=1)
        #
        # workbook_map1 = dict(zip(temp_df1.name, temp_df1.id))
        # workbook_map2 = dict(zip(temp_df2.name, temp_df2.workbook_size))

        # Group by 'workbook_id' and get unique tuples for each group
        grouped_data = df_workbook_details.groupby('id', as_index=False, group_keys=False).apply(
            lambda group: group.drop_duplicates(subset=['name', 'site_id', 'project_id', 'size_bytes']))

        workbook_map0 = dict(zip(grouped_data.id, grouped_data.name))
        workbook_map1 = dict(zip(grouped_data.id, grouped_data.size_bytes))
        workbook_map2 = dict(zip(grouped_data.id, grouped_data.site_id))
        workbook_map3 = dict(zip(grouped_data.id, grouped_data.project_id))

    timestamp = list(df_proces.TimeStamp) + list(df_active_users.start_time) + list(
        df_background_job_failure.start_time) + list(df_extract_failure_per_site.start_time) + list(
        average_load_time_df.start_time) + list(df_view_accessed.start_time)
    timestamp = [*set(timestamp)]
    timestamp.sort()

    workbook_id = list(df_view_accessed.workbook_id) + list(average_load_time_df.workbook_id) + list(
        df_active_users.workbook_id)
    workbook_id = [*set(workbook_id)]
    workbook_id.sort()

    site_id = list(df_extract_failure_per_site.site_id) + list(df_background_job_failure.site_id)
    site_id = [*set(site_id)]
    site_id.sort()

    source = config['azure_source']

    mongo_client = config['mongo_url']
    mongo_db = config['mongo_db']
    mongo_collection = config['tableau_metrics_info']['mongo_collection']

    temp_csv_file = tempfile.NamedTemporaryFile(suffix='.csv', delete=False)
    average_load_time_df.to_csv(temp_csv_file.name, index=False)
    temp_csv_file.close()
    dict_list = []
    for i in timestamp:
        time = i
        time = datetime.strptime(time, '%Y-%m-%d %H:%M')
        final_output = {}
        workbooks = []

        df_proces_temp = df_proces.loc[df_proces['TimeStamp'] == i]
        df_active_users_temp = df_active_users.loc[df_active_users['start_time'] == i]
        df_background_job_failure_temp = df_background_job_failure.loc[df_background_job_failure['start_time'] == i]
        df_extract_failure_per_site_temp = df_extract_failure_per_site.loc[df_extract_failure_per_site['start_time'] == i]
        df_view_accessed_temp = df_view_accessed.loc[df_view_accessed['start_time'] == i]

        for j in workbook_id:

            df_active_users_final = df_active_users_temp.loc[df_active_users_temp['workbook_id'] == j]
            df_active_users_final = df_active_users_final.drop(
                ['start_time', 'end_time', 'workbook_name', 'workbook_id'], axis=1)
            df_view_accessed_final = df_view_accessed_temp.loc[df_view_accessed_temp['workbook_id'] == j]
            df_view_accessed_final = df_view_accessed_final.drop(
                ['start_time', 'end_time', 'workbook_name', 'workbook_id'], axis=1)

            workbook_dict = {}
            workbook_dict['workbook_name'] = workbook_map0[j]
            workbook_dict['workbook_id'] = j
            workbook_dict['workbook_size_bytes'] = workbook_map1[j]

            with open(temp_csv_file.name, 'r') as load:

                heading = next(load)
                reader_obj_load = csv.reader(load)
                for row0 in reader_obj_load:
                    temp_list = []

                    for wb in workbooks:
                        temp_list.append(wb['workbook_id'])

                    if row0[2][0:16] == i and row0[0] == str(j) and int(float(row0[5])) == workbook_map2[j] and row0[
                        0] not in temp_list:
                        workbook_dict['start_time'] = row0[2][0:16]
                        workbook_dict['end_time'] = row0[3][0:16]
                        workbook_dict['load_time'] = str(round(float(row0[1]), 3))
                        workbook_dict['site_name'] = row0[4]
                        workbook_dict['site_id'] = int(float(row0[5]))
                        workbook_dict['project_name'] = row0[6]
                        workbook_dict['project_id'] = row0[7]

                        dict_active_users = df_active_users_final.to_dict(orient='records')[0] if df_active_users_final.to_dict(orient='records') else {}
                        dict_active_users = {key: value for key, value in dict_active_users.items() if value != 'None' and value != '' and pd.isna(value) is False}
                        workbook_dict = {**workbook_dict, **dict_active_users}

                        dict_view_accessed = df_view_accessed_final.to_dict(orient='records')[0] if df_view_accessed_final.to_dict(orient='records') else {}
                        dict_view_accessed = {key: value for key, value in dict_view_accessed.items() if value != 'None' and value != '' and pd.isna(value) is False}
                        workbook_dict = {**workbook_dict, **dict_view_accessed}

                        for index, row in df_background_job_failure_temp.iterrows():
                            if str(row['site_id']) == str(int(float(row0[5]))):
                                if row['background_job_failure'] is not None and row['background_job_failure'] != '' and pd.isna(row['background_job_failure']) is False:
                                    workbook_dict['background_job_failure'] = int(row['background_job_failure'])

                        for index, row in df_extract_failure_per_site_temp.iterrows():
                            if str(row['site_id']) == str(int(float(row0[5]))):
                                if row['extract_failure'] is not None and row['extract_failure'] != '' and pd.isna(row['extract_failure']) is False:
                                    workbook_dict['extract_refresh_fails'] = int(row['extract_failure'])

                        for index, row in df_proces_temp.iterrows():
                            p_c = {}
                            if 'processwise' not in workbook_dict:
                                workbook_dict['processwise'] = []

                            if row['Id'] != "" and row['Id'] is not None and pd.isna(row['Id']) is False:
                                p_c['process_id'] = row['Id']
                                workbook_unique_id = str(j) + str(workbook_map2[j]) + str(
                                    workbook_map3[j]) + str(row['Id'])
                                p_c['unique_id'] = workbook_unique_id
                            # if (row[0] != ""):
                            #     p_c['process_name'] = row[0]
                            # p_c['unique_id'] = hashlib.sha224(repr(i + row[1]).encode('utf-8')).hexdigest()
                            # if (row[2] != ""):
                            #     p_c['priority_class'] = row[2]
                            if row['HandleCount'] != "" and row['HandleCount'] is not None and pd.isna(row['HandleCount']) is False:
                                p_c['handle_count'] = row['HandleCount']
                            if row['WorkingSet'] != "" and row['WorkingSet'] is not None and pd.isna(row['WorkingSet']) is False:
                                p_c['working_set'] = row['WorkingSet']
                            if row['PagedMemorySize'] != "" and row['PagedMemorySize'] is not None and pd.isna(row['PagedMemorySize']) is False:
                                p_c['paged_memory_size'] = row['PagedMemorySize']
                            if row['PrivateMemorySize'] != "" and row['PrivateMemorySize'] is not None and pd.isna(row['PrivateMemorySize']) is False:
                                p_c['private_memory_size'] = row['PrivateMemorySize']
                            if row['VirtualMemorySize'] != "" and row['VirtualMemorySize'] is not None and pd.isna(row['VirtualMemorySize']) is False:
                                p_c['virtual_memory_size'] = row['VirtualMemorySize']
                            # if (row[9] != ""):
                            #     p_c['total_processor_time'] = row[9]
                            # if (row[10] != ""):
                            #     p_c['session_identifier'] = row[10]
                            if row['VM'] != "" and row['VM'] is not None and pd.isna(row['VM']) is False:
                                p_c['VM'] = row['VM']
                            if row['NPM'] != "" and row['NPM'] is not None and pd.isna(row['NPM']) is False:
                                p_c['NPM'] = row['NPM']
                            if row['PM'] != "" and row['PM'] is not None and pd.isna(row['PM']) is False:
                                p_c['PM'] = row['PM']
                            if row['CPU'] != "" and row['CPU'] is not None and pd.isna(row['CPU']) is False:
                                p_c['cpu'] = row['CPU']
                            if row['ExitCode'] != "" and row['ExitCode'] is not None and pd.isna(row['ExitCode']) is False:
                                p_c['exit_code'] = row['ExitCode']
                            if row['HasExited'] != "" and row['HasExited'] is not None and pd.isna(row['HasExited']) is False:
                                p_c['has_exited'] = row['HasExited']
                            if row['ExitTime'] != "" and row['ExitTime'] is not None and pd.isna(row['ExitTime']) is False:
                                p_c['exit_time'] = row['ExitTime']
                            # if (row[33] != ""):
                            #     p_c['max_working_set'] = row[33]
                            # if (row[34] != ""):
                            #     p_c['min_working_set'] = row[34]
                            # if (row[36] != ""):
                            #     p_c['non_paged_system_memory_size'] = row[36]
                            if row['PagedSystemMemorySize'] != "" and row['PagedSystemMemorySize'] is not None and pd.isna(row['PagedSystemMemorySize']) is False:
                                p_c['paged_system_memory_size'] = row['PagedSystemMemorySize']
                            # if (row[47] != ""):
                            #     p_c['priority_bost_enabled'] = row[47]
                            # if (row[49] != ""):
                            #     p_c['privileged_processor_time'] = row[49]
                            # if (row[51] != ""):
                            #     p_c['processor_afinity'] = row[51]
                            # if (row[52] != ""):
                            #     p_c['responding'] = row[52]
                            if row['UserProcessorTime'] != "" and row['UserProcessorTime'] is not None and pd.isna(row['UserProcessorTime']) is False:
                                p_c['user_processor_time'] = row['UserProcessorTime']

                            workbook_dict['processwise'].append(p_c)

            if len(workbook_dict) > 3:
                workbooks.append(workbook_dict)

        final_output["source"] = source
        final_output['ts'] = time
        if len(workbooks) > 0:
            final_output['workbooks'] = workbooks
        if len(final_output) > 2:
            dict_list.append(final_output)

    # Bulk insert all dictionaries to MongoDB
    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)
    logger.info(f"New entry list size for TABLEAU = {len(dict_list)}")
    if len(dict_list) > 0:
        collection.insert_many(dict_list)
        exit_handler(OK_CODE)
    else:
        logger.warn("Zero new entries inserted to mongodb for TABLEAU")
        exit_handler(WARNING_CODE)