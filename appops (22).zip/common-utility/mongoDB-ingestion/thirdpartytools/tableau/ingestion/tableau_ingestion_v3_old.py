import tempfile
from cProfile import run
import csv
import json
import pandas as pd
import os
import yaml
from pymongo import MongoClient
from datetime import datetime

# import hashlib

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2

logger = []
exit_handler = []


def ingest_tableau_csvs(config, logger, exit_handler):
    # getting csv paths from config
    process_csv = config['tableau_metrics_info']['processwise_csv']
    active_users = config['tableau_metrics_info']['db_active_users_per_workbook_csv']
    background_job_failure = config['tableau_metrics_info']['db_background_job_failure_per_site_csv']
    extract_failure_per_site = config['tableau_metrics_info']['db_extract_failure_per_site_csv']
    load_time = config['tableau_metrics_info']['db_load_time_csv']
    view_accessed = config['tableau_metrics_info']['db_view_accessed_per_workbook_csv']
    workbook_details = config['tableau_metrics_info']['db_workbook_details_csv']

    average_load_time_df = {}
    timestamp=[]
    workbook_id = []
    site_id =[]
    workbook_map0={}
    workbook_map1={}
    workbook_map2={}
    workbook_map3={}

    # checking if the csvs are present or not
    if os.path.exists(process_csv):
        df_proces = pd.read_csv(process_csv)
        timestamp0 = list(df_proces.TimeStamp)
        timestamp0 = list(map(lambda timestp: datetime.strptime(timestp, '%Y-%m-%d %H:%M:%S'), timestamp0))
        timestamp0 = list(map(lambda timestp: timestp.strftime('%Y-%m-%d %H:%M:%S'), timestamp0))
        timestamp.extend(timestamp0)
    if os.path.exists(active_users):
        df_active_users = pd.read_csv(active_users)
        timestamp1 = list(df_active_users.start_time)
        timestamp.extend(timestamp1)
        workbook_id1 = list(df_active_users.workbook_id)
        workbook_id.extend(workbook_id1)

    if os.path.exists(background_job_failure):
        df_background_job_failure = pd.read_csv(background_job_failure)
        timestamp2 = list(df_background_job_failure.start_time)
        timestamp.extend(timestamp2)
        site_id1 = list(df_background_job_failure.site_id)
        site_id.extend(site_id1)

    if os.path.exists(extract_failure_per_site):
        df_extract_failure_per_site = pd.read_csv(extract_failure_per_site)
        timestamp3 = list(df_extract_failure_per_site.start_time)
        timestamp.extend(timestamp3)
        site_id2 = list(df_extract_failure_per_site.site_id)
        site_id.extend(site_id2)

    if os.path.exists(load_time):
        df_load_time = pd.read_csv(load_time)

        # Group by 'workbook_id' and calculate the average load_time
        average_load_time_df = df_load_time.groupby(['workbook_id','start_time'], as_index=False).agg(
            average_load_time=('load_time', 'mean'),
            start_time=('start_time', 'first'),
            end_time=('end_time', 'first'),
            sites_name=('sites_name', 'first'),
            sites_id=('sites_id', 'first'),
            project_name=('project_name', 'first'),
            project_id=('project_id', 'first')
        )
        timestamp4 = list(average_load_time_df.start_time)
        timestamp.extend(timestamp4)
        workbook_id2 = list(average_load_time_df.workbook_id)
        workbook_id.extend(workbook_id2)

    if os.path.exists(view_accessed):
        df_view_accessed = pd.read_csv(view_accessed)
        timestamp5 = list(df_view_accessed.start_time)
        timestamp.extend(timestamp5)
        workbook_id3 = list(df_view_accessed.workbook_id)
        workbook_id.extend(workbook_id3)

    if os.path.exists(workbook_details):
        df_workbook_details = pd.read_csv(workbook_details)
        # timestamp6 = list(df_workbook_details.start_time)
        # timestamp.extend(timestamp6)
        # workbook_id4 = list(df_workbook_details.id)
        # workbook_id.extend(workbook_id4)
        # temp_df1 = df_workbook_details[['name', 'id']].copy().groupby(['name', 'id'], as_index=False).size().drop(
        #     ['size'], axis=1)
        # temp_df2 = df_workbook_details[['name', 'size']].copy().rename(columns={'size': 'workbook_size'}).groupby(['name', 'workbook_size'], as_index=False).size().drop(
        #     ['size'], axis=1)
        #
        # workbook_map1 = dict(zip(temp_df1.name, temp_df1.id))
        # workbook_map2 = dict(zip(temp_df2.name, temp_df2.workbook_size))

        # Group by 'workbook_id' and get unique tuples for each group
        grouped_data = df_workbook_details.groupby('id', as_index=False,  group_keys=False).apply(
        lambda group: group.drop_duplicates(subset=['name', 'site_id','project_id', 'size_bytes' ]))

        workbook_map0 = dict(zip(grouped_data.id, grouped_data.name))
        workbook_map1 = dict(zip(grouped_data.id, grouped_data.size_bytes))
        workbook_map2 = dict(zip(grouped_data.id, grouped_data.site_id))
        workbook_map3 = dict(zip(grouped_data.id, grouped_data.project_id))



    timestamp = list(map(lambda timestp: timestp[0:16], timestamp))
    timestamp = [*set(timestamp)]
    timestamp.sort()
    workbook_id = [*set(workbook_id)]
    workbook_id.sort()
    site_id = [*set(site_id)]
    site_id.sort()

    source = config['azure_source']

    mongo_client = config['mongo_url']
    mongo_db = config['mongo_db']
    mongo_collection = config['tableau_metrics_info']['mongo_collection']


    temp_csv_file = tempfile.NamedTemporaryFile(suffix='.csv', delete=False)
    average_load_time_df.to_csv(temp_csv_file.name, index=False)
    temp_csv_file.close()

    dict_list = []
    for i in timestamp:
        time = i
        time = datetime.strptime(time, '%Y-%m-%d %H:%M')
        final_output = {}
        workbooks = []

        for j in workbook_id:

            workbook_dict = {}
            workbook_dict['workbook_name'] = workbook_map0[j]
            workbook_dict['workbook_id'] = j
            workbook_dict['workbook_size_bytes'] = workbook_map1[j]

            with open(temp_csv_file.name, 'r') as load:

                heading = next(load)
                reader_obj_load = csv.reader(load)
                for row0 in reader_obj_load:
                    temp_list = []

                    for wb in workbooks:
                        temp_list.append(wb['workbook_id'])

                    if row0[2][0:16] == i and row0[0] == str(j) and int(float(row0[5])) == workbook_map2[j] and row0[0] not in temp_list:
                        workbook_dict['start_time'] = row0[2][0:16]
                        workbook_dict['end_time'] = row0[3][0:16]
                        workbook_dict['load_time'] = str(round(float(row0[1]), 3))
                        workbook_dict['site_name'] = row0[4]
                        workbook_dict['site_id'] = int(float(row0[5]))
                        workbook_dict['project_name'] = row0[6]
                        workbook_dict['project_id'] = row0[7]

                        if os.path.exists(active_users):
                            with open(active_users) as users:
                                heading = next(users)
                                reader_obj_user = csv.reader(users)
                                for row1 in reader_obj_user:
                                    if row1[0][0:16] == i and row1[4]==str(j):
                                        value = row1[2]
                                        try:
                                            value = int(value)
                                        except ValueError as ve:
                                            # bucket_dict[row[3]] = row[4]
                                            # bucket_dict[row[3]] = NULL
                                            pass
                                        else:
                                            workbook_dict['active_users'] = int(value)

                        if os.path.exists(background_job_failure):
                            with open(background_job_failure) as background_job:
                                heading = next(background_job)
                                reader_obj_job = csv.reader(background_job)
                                for row2 in reader_obj_job:
                                    if row2[0][0:16] == i and row2[2]==str(int(float(row0[5]))):
                                        value2 = row2[3]
                                        try:
                                            value2 = int(value2)
                                        except ValueError as ve:
                                            # bucket_dict[row[3]] = row[4]
                                            # bucket_dict[row[3]] = NULL
                                            pass
                                        else:
                                            workbook_dict['background_job_failure'] = int(value2)

                        if os.path.exists(extract_failure_per_site):
                            with open(extract_failure_per_site) as extract_failure:
                                heading = next(extract_failure)
                                reader_obj_extract = csv.reader(extract_failure)
                                for row3 in reader_obj_extract:
                                    if row3[0][0:16] == i and row3[2]==str(int(float(row0[5]))):
                                        value3 = row3[3]
                                        try:
                                            value3 = int(value3)
                                        except ValueError as ve:
                                            # bucket_dict[row[3]] = row[4]
                                            # bucket_dict[row[3]] = NULL
                                            pass
                                        else:
                                            workbook_dict['extract_refresh_fails'] = int(value3)

                        if os.path.exists(view_accessed):
                            with open(view_accessed) as tva:
                                heading3 = next(tva)
                                reader_obj_view = csv.reader(tva)
                                for row4 in reader_obj_view:
                                    if row4[0][0:16] == i and row4[4]==str(j):
                                        value4 = row4[2]
                                        try:
                                            value4 = int(value4)
                                        except ValueError as ve:
                                            # bucket_dict[row[3]] = row[4]
                                            # bucket_dict[row[3]] = NULL
                                            pass
                                        else:
                                            workbook_dict['view_accessed'] = int(value4)


                        if os.path.exists(process_csv):
                            with open(process_csv) as pc:
                                heading4 = next(pc)
                                reader_obj4 = csv.reader(pc)
                                for row in reader_obj4:
                                    p_c = {}
                                    if row[67][0:16] == i or row[67][0:16] == datetime.strptime(i, '%Y-%m-%d %H:%M').strftime('%d-%m-%Y %H:%M'):
                                        if 'processwise' not in workbook_dict:
                                            workbook_dict['processwise'] = []

                                        if (row[1] != ""):
                                            p_c['process_id'] = row[1]
                                            workbook_unique_id = str(j) + str(workbook_map2[j]) + str(workbook_map3[j])+row[1]
                                            p_c['unique_id']=workbook_unique_id
                                        # if (row[0] != ""):
                                        #     p_c['process_name'] = row[0]
                                        # p_c['unique_id'] = hashlib.sha224(repr(i + row[1]).encode('utf-8')).hexdigest()
                                        # if (row[2] != ""):
                                        #     p_c['priority_class'] = row[2]
                                        if (row[4] != ""):
                                            p_c['handle_count'] = row[4]
                                        if (row[5] != ""):
                                            p_c['working_set'] = row[5]
                                        if (row[6] != ""):
                                            p_c['paged_memory_size'] = row[6]
                                        if (row[7] != ""):
                                            p_c['private_memory_size'] = row[7]
                                        if (row[8] != ""):
                                            p_c['virtual_memory_size'] = row[8]
                                        # if (row[9] != ""):
                                        #     p_c['total_processor_time'] = row[9]
                                        # if (row[10] != ""):
                                        #     p_c['session_identifier'] = row[10]
                                        if (row[12] != ""):
                                            p_c['VM'] = row[12]
                                        if (row[15] != ""):
                                            p_c['NPM'] = row[15]
                                        if (row[15] != ""):
                                            p_c['PM'] = row[14]
                                        if (row[18] != ""):
                                            p_c['cpu'] = row[18]
                                        if (row[24] != ""):
                                            p_c['exit_code'] = row[24]
                                        if (row[25] != ""):
                                            p_c['has_exited'] = row[25]
                                        if (row[26] != ""):
                                            p_c['exit_time'] = row[26]
                                        # if (row[33] != ""):
                                        #     p_c['max_working_set'] = row[33]
                                        # if (row[34] != ""):
                                        #     p_c['min_working_set'] = row[34]
                                        # if (row[36] != ""):
                                        #     p_c['non_paged_system_memory_size'] = row[36]
                                        if (row[39] != ""):
                                            p_c['paged_system_memory_size'] = row[39]
                                        # if (row[47] != ""):
                                        #     p_c['priority_bost_enabled'] = row[47]
                                        # if (row[49] != ""):
                                        #     p_c['privileged_processor_time'] = row[49]
                                        # if (row[51] != ""):
                                        #     p_c['processor_afinity'] = row[51]
                                        # if (row[52] != ""):
                                        #     p_c['responding'] = row[52]
                                        if (row[58] != ""):
                                            p_c['user_processor_time'] = row[58]

                                        workbook_dict['processwise'].append(p_c)

            if len(workbook_dict)>3:
                workbooks.append(workbook_dict)

        final_output["source"] = source
        final_output['ts'] = time
        if len(workbooks)>0:
            final_output['workbooks'] = workbooks
        if len(final_output)>2:
            dict_list.append(final_output)


    # Bulk insert all dictionaries to MongoDB
    client = MongoClient(mongo_client)
    db = client.get_database(mongo_db)
    collection = db.get_collection(mongo_collection)
    logger.info(f"New entry list size for TABLEAU = {len(dict_list)}")
    if len(dict_list) > 0:
        collection.insert_many(dict_list)
        exit_handler(OK_CODE)
    else:
        logger.warn("Zero new entries inserted to mongodb for TABLEAU")
        exit_handler(WARNING_CODE)
