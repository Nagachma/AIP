"""
Timestamp Conversion in UTC
"""
#__author__ = 'arunabha.a.das'

from datetime import datetime as df
import pytz

def convert_Timezone(time,zone):
    try:
        # print(zone)
        if(len(zone)==0):
            zone='UTC'
        if zone in pytz.all_timezones:
            pass
        else:
            raise Exception("Not a valid Timezone in input")
        date_time_str = str(time)
        if(len(date_time_str) > 19):
            #With Zone
            date_time_obj = df.fromisoformat(date_time_str)
            if(date_time_obj.tzname()=='UTC'):
                return date_time_obj         
        else: 
            #Without Zone 
            date_time_obj = df.strptime(date_time_str, '%Y-%m-%d %H:%M:%S')
            # print("Timestamp Value -> "+str(date_time_obj))
            # print("Inserted Timezone is in -> " + zone)
            timezone = pytz.timezone(zone)
            date_time_obj = timezone.localize(date_time_obj)
        
        timeInUTC=date_time_obj.astimezone(pytz.timezone('UTC'))
        return timeInUTC
    except Exception as e:
        raise