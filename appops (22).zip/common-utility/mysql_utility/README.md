# DM APPOPS-MYSQL UTILITY

## Description
This script helps to connect to MySQL database using credentials and fetch a set of config values.

## Pre-requisite:
- Python 3.9 or greater
- Install `cryptography`, `mysql-connector-python`, `PyYaml` pip packages
- Set following environment variable on the OS:
  - `export ENVIRONMENT_ID=1` ## Environment ID of the xOps Environment that is onboarded (From environments table)

    
## To utilize the script in another script:

  1. Import the mysql_utility.config_parameters module in the main script and call get_environment_parameter method by passing the names of configs.
     Example -
     ```python 
     from mysql_utility.config_parameters import ConfigParameters
     ...
     cp = ConfigParameters(credential_file='path to CREDENTIAL_FILE')  ## initialize the class, pass the MySQL credential YAML file path
     azure_config = cp.get_environment_parameter(['azure_tenant_id', 'azure_subscription_id'],  ## names of config parameters
                                                'ENVIRONMENT_ID') ## if no environment_id passed then it takes from env_variable 
                                                                  ## ENVIRONMENT_ID
     print(azure_config['azure_subscription_id'])
     print(azure_config['azure_tenant_id'])
     ```
  2. Setup the MySQL credential file -
     ```yaml
        encrypted: 0  # flag indicating whether values in this YAML are encrypted or plain text; 0 -> Not encrypted, 1 -> encrypted
        encryption_key_file: './usr_key.bin'  # encryption key file path
        encrypted_fields: ['password']  # fields which are encrypted
        user: xops  # Username of the MySQL db
        password:         # Password of MySQL db user
        host: mysql.hostname.url  # URL of MySQL db
        database: xops  # DB name 
        connection_timeout: 5  # Timeout of DB connection in seconds
     ```
     To encrypt the user and/or password use the script `common-utility/db-connector/enc_dec_text.py`


## Build wheel file - for packaging the utility and using in other scripts:
  Run below command from project directory [common-utility/mysql_utility] -
  ```bash
  python setup.py bdist_wheel --universal
  ```

## Installing wheel file:
  Run pip install with .whl file extension-
  ```bash
  pip install mysql_utility-0.0.1-py2.py3-none-any.whl
  ```