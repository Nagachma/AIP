import os
import yaml
from mysql_utility.m_connect import MConnect
from mysql_utility.mconfig import mconfig


class ConfigParameters:
    def __init__(self, config_path='', credential_file='', mysql_config=None):
        self.credential_file = credential_file
        self.mysql_config = mysql_config
        config = {}
        try:
            if config_path and config_path != '':
                with open(config_path) as config_file:
                    config = yaml.safe_load(config_file)
        except yaml.YAMLError as yme:
            print(repr(yme))
        if config_path is None or config_path == '':
            config = mconfig
        self.config = config
        self.env_table_name = config.get('env_table_name')
        self.service_onboarded_table = config.get('service_onboarded_table')
        self.services_table = config.get('services_table')
        self.mysql_connector = MConnect(config=mysql_config)

    def get_service_parameter(self, params, service_id=0, service_name=''):
        result = {}
        if service_id == 0 and not service_name:
            print("No service id or service name")
            return result
        else:
            for param in params:
                if service_id != 0:
                    query = "select {} from {} where service_id=%s".format(param, self.service_onboarded_table)
                    tuple_params = (service_id,)
                elif service_name.strip() != '':
                    query = "select {} from {} join {} using(service_id) where service_name=%s".format(param,
                                                                                                       self.service_onboarded_table,
                                                                                                       self.services_table)
                    tuple_params = (service_name,)
                else:
                    return result

                rs = self.mysql_connector.execute_query(query, tuple_params)
                if len(rs) > 0:
                    result[param] = rs[0][param]
        return result

    def get_environment_parameter(self, params, environment_id=0):
        result = {}

        if not os.environ.get('ENVIRONMENT_ID') and environment_id == 0:
            print('No env id found')
            return result
        elif environment_id != 0:
            env_id = environment_id
        else:
            env_id = os.environ.get('ENVIRONMENT_ID')

        if params:
            for param in params:
                query = "select {} from {} where environment_id=%s".format(param, self.env_table_name)
                print(query)
                rs = self.mysql_connector.execute_query(query, (env_id,))
                if len(rs) > 0:
                    result[param] = rs[0][param]
        return result
