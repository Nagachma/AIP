import mysql.connector
import yaml
from cryptography.fernet import Fernet


class MConnect:
    def __init__(self, credential_file='', config=None):
        self.credential_file = credential_file
        self.config = config
        if not config and not credential_file:
            print("No config or credential file provided")
            raise
        elif credential_file:
            try:
                with open(self.credential_file) as config_file:
                    self.config = yaml.safe_load(config_file)
                    if self.config.get('encrypted') and self.config.get('encryption_key_file'):
                        encryption_key_file = self.config.get('encryption_key_file')
                        with open(encryption_key_file, 'rb') as file_object:
                            for line in file_object:
                                str_mk = line
                        fernet = Fernet(str_mk)
                        mod_config = self.config
                        for item in self.config.keys():
                            if item in self.config.get('encrypted_fields'):
                                enc_message = bytes(self.config[item], 'utf-8')
                                dec_message = fernet.decrypt(enc_message).decode()
                                mod_config[item] = dec_message
                        self.config = mod_config
                    self.config.pop('encrypted', None)
                    self.config.pop('encryption_key_file', None)
                    self.config.pop('encrypted_fields', None)
            except yaml.YAMLError as yme:
                print(repr(yme))
                raise
        elif config:
            pass
        else:
            pass

    def execute_query(self, query_str: str, parameters: tuple):
        """
        This method takes in a mysql query and returns the corresponding result set. Returns empty set if any mysql
        error occurs.

        :param query_str the mysql query to execute
        :param parameters the parameters of mysql query
        :return: result_set
        """
        result_set = []

        try:
            cnx = mysql.connector.connect(**self.config)
            cursor = cnx.cursor(dictionary=True)

            if parameters:
                cursor.execute(query_str, parameters)
            else:
                cursor.execute(query_str)

            for row in cursor:
                result_set.append(row)

            cursor.close()
            cnx.close()

        except mysql.connector.Error as e:
            print(f'repr{e}')

        return result_set
