mconfig = {'env_table_name': 'environments',
          'service_onboarded_table': 'service_onboarded',
          'services_table': 'services'
          }
