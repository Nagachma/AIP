import setuptools

setuptools.setup(
    name='mysql_utility',
    version='1.0.0-beta',
    author='Soumya Datta',
    author_email='souma.datta@accenture.com',
    description='Testing installation of Package',
    long_description='',
    long_description_content_type="text/markdown",
    license='MIT',
    packages=['mysql_utility'],
    install_requires=['mysql-connector-python', 'PyYAML'],
)
