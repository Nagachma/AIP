# DM APPOPS-VAULT CREDENTIALS UTILITY

## Description:
This script helps to connect to any HASHICORP VAULT using token and fetch a set of secret values.

## Pre-requisite:
- Python 3.9 or greater
- Install hvac pip package
- Set following environment variable on the OS:
  - VAULT_URL=https://vault-devops.dev.accentureanalytics.com/
  - VAULT_TOKEN=xxxxxxxxxxxxxxxxxx
  - VAULT_SECRET_PATH=environment/1/cloudcredential
  - VAULT_SECRET_MOUNT_POINT=secret (*optional*)

## Execution:
- To execute the script standalone:
  ```bash
  python vault_credentials.py
  ```

- To utilize the script in another script:
  1. Copy vault_credentials.py from vault_utility folder into same directory as the other script.
  2. Install pip package hvac (If not already installed)
  3. Set the environment variables as mentioned above in pre-requisite
  4. Import the vault_credentials.py in the other script and call get_secret_from_vault method by passing the names of secrets.
     Example -
     ```python 
     import vault_credentials
     ...
     secret_keys = vault_credentials.get_secret_from_vault(['clientID', 'clientSecret', 'tenantID'])
     ```
  6. Execute your other script.


## Build wheel file - for packaging the utility and using in other scripts:
  Run below command from project directory [common-utility/vault_utility] -
  ```bash
  python setup.py bdist_wheel --universal
  ```

## Install wheel file:
  Run pip install *.whl
  ```bash
  pip install vault_utility-0.0.1-py2.py3-none-any.whl
  ```