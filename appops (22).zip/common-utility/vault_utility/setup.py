import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name='vault_utility',
    version='0.0.1',
    author='Soumya Datta',
    author_email='souma.datta@accenture.com',
    description='Testing installation of Package',
    long_description=long_description,
    long_description_content_type="text/markdown",
    license='MIT',
    packages=['vault_utility'],
    install_requires=['hvac'],
)
