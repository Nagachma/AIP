import os
import hvac


def get_keys_from_vault(url, token, secret_path):
    # # Authentication
    client = hvac.Client(
        url=url,
        verify=False,
        token=token
    )

    # Reading a secret
    # read_response = client.secrets.kv.read_secret_version(path='environment/1/cloudcredential')
    if os.environ.get('VAULT_SECRET_MOUNT_POINT'):
        # if mount point is in env variable
        read_response = client.secrets.kv.v2.read_secret_version(path=secret_path, mount_point=os.environ['VAULT_SECRET_MOUNT_POINT'])
    else:
        # else assume default mount point
        read_response = client.secrets.kv.v2.read_secret_version(path=secret_path)
    secret_data = read_response['data']['data']

    return secret_data


def get_secret_from_vault(key_names):
    """
    Fetch secret values from HashiCorp Vault
    :param key_names list of key names for which key values will be fetched from vault
    :return: dict - a dictionary of secret values for each key name sent in param
    """
    secret_data = get_keys_from_vault(url=os.environ['VAULT_URL'], token=os.environ['VAULT_TOKEN'],
                                      secret_path=os.environ['VAULT_SECRET_PATH'])
    response = {}
    for key_name in key_names:
        if key_name in secret_data:
            response[key_name] = secret_data[key_name]
    return response


if __name__ == '__main__':
    # For testing only
    pass
