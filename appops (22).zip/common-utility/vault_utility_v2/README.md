# DM APPOPS-VAULT CREDENTIALS UTILITY VERSION 2

## Description
This script helps to connect to any HASHICORP VAULT using token and fetch a set of secret values.

## Pre-requisite
- Python 3.9 or greater
- Install hvac & Fernet pip package
- Set following environment variable on the OS:
  - VAULT_URL=https://vault-devops.dev.accentureanalytics.com/
  - VAULT_SECRET_MOUNT_POINT=secret (*optional*)

## Execution
- To execute the encrypt.py script
  1. Run the encrypt.py script by passing actual VAULT TOKEN as argument.(For security reasons to not store it in code)
  2. The output of code will be a key, save the key and update the same in vault_credentials.py and save it, rest follow the "Build Wheel File" procedure mentioned below.
  
- To execute the script standalone:
  ```bash
  python vault_credentials.py
  ```

- To utilize the script in another script:
  1. Copy vault_credentials.py from vault_utility folder into same directory as the other script.
  2. Install pip package hvac & Fernet (If not already installed)
  3. Set the environment variables as mentioned above in pre-requisite
  4. Import the vault_credentials.py in the other script and call get_secret_from_vault method by passing vault secret path and the names of secrets.
     Example -
     ```python 
     import vault_credentials
     ...
     vault_path="environment/1/cloudcredential"   #You can store the vault path in config also
     secret_keys = vault_credentials.get_secret_from_vault(vault_path,['clientID', 'clientSecret', 'tenantID'])
     ```
  6. Execute your other script.


## Build wheel file
  Run below command from root project directory -
  ```bash
  python setup.py bdist_wheel --universal
  ```

## Install wheel file
  Run pip install *.whl
  ```bash
  pip install your_wheel_file_name.whl
  ```