from cryptography.fernet import Fernet
import os
import sys
import logging
logger = logging.getLogger('encrypt.py')
logger.setLevel(logging.DEBUG)
# create console handler and set level to debug
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
# add formatter to ch
ch.setFormatter(formatter)
# add ch to logger
logger.addHandler(ch)

# key is generated, store the Key in safe place
key = Fernet.generate_key()

# value of key is assigned to a variable
f = Fernet(key)
logger.info("The Key is: {}".format(key))

if len(sys.argv) > 1:
    vt = sys.argv[1]

# logger.info(vt)

# the plaintext is converted to ciphertext
token = f.encrypt(vt.encode())
logger.info("The Encrypted Token is: {}".format(token.decode()))

# Set the environment variable
os.environ['V_TOKEN'] = token.decode()

#check if Env variable set or not
if 'V_TOKEN' in os.environ:
    logger.info('Environment variable was set successfully.')
else:
    logger.error('Failed to set the environment variable.')