## Metric Collection Framework

### Pre-requisites
1. Python 3.9 or greater
2. IDE like PyCharm for code development and testing. 

### Pre steps
1. Copy `dm-metric-collection/` folder and `tools/` folder to the base home directory (e.g. '/data01/appops/') on the VM (deep monitoring node)
2. Create a python virtual env in base home directory:
   ```shell
   python3.9 -m venv py39venv
   ```
   This will create a directory like `/data01/appops/py39venv`
3. To activate the python virtual environment run this - `source /data01/appops/py39venv/bin/activate`
3. Install pip packages of the scripts by using individual `requirements.txt` files under each script folders (`aws/common/`, `aws/custom/`, `azure/common/`, etc.)
   Run using this command to install pip requirements file - `/data01/appops/py39venv/bin/python -m pip install -r requirements.txt`
4. Install mysql_utility and vault_utility packages from `common-utility` folder. Get the pip install commands from individual Readme files -
   - common-utility/vault_utility/README.md
   - common-utility/mysql_utility/README.md
5. CD (change directory) into `dm-metric-collection/` and Set up the main config.yaml per services for which metric collection is required
5. Set up the individual config.yaml files of custom scripts per service (if required)

### Environment variables

- Login using the dm service user cred into the DM node (VM) 
- Open the ~/.bash_profile and add following environment variable to it -
   ```shell
   export AZURE_ENVIRONMENT_ID=4    # environment_id FROM MYSQL XOPS DB environments table
   export VAULT_SECRET_PATH=environment/1/cloudcredential
   export VAULT_TOKEN=hvs.xxxxxxxxxxxxxxxxxxxxx
   export VAULT_URL=https://vault.hostname.com/
   ```

### Set Base home directory & Python interpreter in main config.yaml
E.g.: 
```yaml
BASE_HOME_DIR: /data01/appops/
PYTHON_INTERPRETER: /bin/python3.9
```

### Set CSV paths in individual service's config file
E.g.: ADLS2
```yaml

GEN2_ADLS:
  csvpath: 'tools\azure\adls\collection\az-monitor\metrics'
```

### Execution
```shell
python3 main.py --platform=azure --service=adls2
```

### Logs
Create log directory per platform. E.g.: `dm-metric-collection/logs/azure/`

### Crontab expression to setup continuos collection & ingestion
```shell
# ADLS2 Collection
*/5 * * * * /bin/su -c "/data01/appops/py39venv/bin/python3 /data01/appops/dm-metric-collection/main.py --platform=azure --service=adls2 > /data01/appops/dm-metric-collection/logs/azure/adls2_azm.log 2>&1" - svc_user
```