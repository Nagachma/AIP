"""
Cloudwatch fetch
"""
#!/usr/bin/python
#pylint:disable=no-self-use,no-member,not-context-manager,bad-continuation,anomalous-backslash-in-string,line-too-long,invalid-name,too-many-locals,too-many-boolean-expressions,too-many-branches,unused-variable,redefined-outer-name,broad-except,too-many-arguments,too-many-nested-blocks,too-many-statements,superfluous-parens,logging-format-interpolation,no-else-continue,redefined-builtin,consider-iterating-dictionary,no-else-return
#__author__ = 'utpalendu.ray'
import logging
import csv
import os
import traceback
from datetime import datetime
import multiprocessing as mp
from multiprocessing import Process
import platform
import glob
import time
import argparse
import boto3
#import botocore
#from botocore.errorfactory import *
import arrow
import yaml

logger = logging.getLogger('getcloudwatchmetrics')
logger.setLevel(logging.DEBUG)
# create console handler and set level to debug
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
# add formatter to ch
ch.setFormatter(formatter)
# add ch to logger
logger.addHandler(ch)

def valid_dimentions(cloudwatch, servicename, metric_name):
    """
        checking for valid dimensions for CloudWatch metrics
    """
    alldim = []
    namespace = 'AWS/{}'.format(servicename)
    paginator = cloudwatch.get_paginator('list_metrics')
    for response in paginator.paginate(Namespace=namespace, MetricName=metric_name):
        for itemdetails in response['Metrics']:
            dim = itemdetails['Dimensions']
            for newitem in dim:
                if newitem['Name'] not in alldim:
                    alldim.append(newitem['Name'])
    return alldim

def get_list_of_resouces(cloudwatch, filtername, namespace, metric_name):
    """
    return list of unique resource list
    """
    unique_list_of_resource = []
    serviceid = ''
    #next_token=''
    # while next_token is not None:
    #response = getlistmetric(cloudwatch=cloudwatch, Namespace=namespace)
    # List merics through the pagination interfaceg
    paginator = cloudwatch.get_paginator('list_metrics')
    for response in paginator.paginate(Namespace=namespace, MetricName=metric_name):
        for item in response['Metrics']:
            for val in item['Dimensions']:
                if val['Name'] == filtername:
                    serviceid = val['Value']
                    unique_list_of_resource.append(serviceid)
    return list(set(unique_list_of_resource))

def get_id(cloudwatch, filtername, namespace, metric_name):
    """
    Get the id of instance
    """
    # Create CloudWatch client
    serviceid = ''
    # List metrics through the pagination interface
    paginator = cloudwatch.get_paginator('list_metrics')
    for response in paginator.paginate(Namespace=namespace, MetricName=metric_name):
        for item in response['Metrics']:
            for val in item['Dimensions']:
                if val['Name'] == filtername:
                    serviceid = val['Value']
                    return serviceid
        return serviceid
def load_configuration(lconfig):
    """Read and load data from config.yaml file"""
    cfg = {}  # Check if this is a dict
    try:
        with open(lconfig, 'r') as yamlfile:
            cfg = yaml.load(yamlfile, Loader=yaml.FullLoader)
    except yaml.YAMLError as exc:
        logger.exception(exc)
    except Exception as e:
        logger.exception(e)
    return cfg

def get_instances(config):
    """
    Get the all instances for a particular account
    """
    access_id = os.environ['AWS_ACCESS_KEY_ID']
    secret_key = os.environ['AWS_SECRET_ACCESS_KEY']
    region = config['AWS']['region']
    ec2 = boto3.client('ec2', aws_access_key_id=access_id, aws_secret_access_key=secret_key, region_name=region)
    response = ec2.describe_instances()
    instance_details = {}
    details = {}
    for reservation in response["Reservations"]:
        for instance in reservation["Instances"]:
            desc = ''
            if not 'PrivateIpAddress' in instance:
                continue
            details['IP'] = instance['PrivateIpAddress']
            for tag in instance['Tags']:
                if tag['Key'] == 'Name':
                    desc = tag['Value']
            if desc:
                details['desc'] = desc
            else:
                details['desc'] = instance['KeyName']
            details['type'] = instance['InstanceType']
            instance_details[instance["InstanceId"]] = details
            details = {}
    return instance_details

def get_instance_details(instance_id, config):
    """"
    Helper function for details of a instance
    """
    instancedict = {}
    details = get_instances(config)
    if instance_id in details:
        instancedict = details.get(instance_id, '')
    return instancedict
def maxOfAverageList(in_list):
    """
    Maximum of list
    """
    empty = ''
    if in_list:
        return max(in_list)
    return empty

def avgOfAverageList(in_list):
    """
    avg of list
    """
    empty = ''
    if in_list:
        return sum(in_list)/len(in_list)
    return empty

def samplecountOfAverageList(in_list):
    """
    avg of list
    """
    numbers_list = []
    for record in in_list:
        numbers_list.append(record['SampleCount'])
    return sum(numbers_list)/len(numbers_list)

def getlistmetric(**kwargs):
    """
        get list of metrics
    """
    if kwargs.get('NextToken') is None or kwargs.get('NextToken') == '':
        return kwargs.get('cloudwatch').list_metrics(Namespace=kwargs.get("namespace"), MaxDatapoints=100000)
    else:
        return kwargs.get('cloudwatch').list_metrics(Namespace=kwargs.get("namespace"), MaxDatapoints=10000)

def getmetricdata(**kwargs):
    """
        paginate through output data until it reach end of data point
    """
    if kwargs.get('NextToken') is None or kwargs.get('NextToken') == '':
        return kwargs.get('cloudwatch').get_metric_data(MetricDataQueries=kwargs.get("MetricDataQueries"),
            StartTime=kwargs.get("StartTime"),
            EndTime=kwargs.get("EndTime"),
            MaxDatapoints=100000
            )
    else:
        return kwargs.get('cloudwatch').get_metric_data(MetricDataQueries=kwargs.get("MetricDataQueries"),
            StartTime=kwargs.get("StartTime"),
            EndTime=kwargs.get("EndTime"),
            NextToken=kwargs.get("NextToken"),
            MaxDatapoints=100000
            )
def getgluelistofjobs(**kwargs):
    """
            paginate through output data until it reach end of data point
        """
    if kwargs.get('NextToken') is None or kwargs.get('NextToken') == '':
        return kwargs.get('glue').list_jobs(MaxResults=100)
    else:
        return kwargs.get('glue').list_jobs(NextToken=kwargs.get("NextToken"), MaxDatapoints=100)

def getmaxData(start_time, end_time, conf, service, tps_lock, count, timezone):
    """
    Fetching AWS Data
    """
    shift_time = "00"
    if timezone.upper() == 'EDT':
        shift_time = "240"
    if timezone.upper() == 'EST':
        shift_time = "300"
    if timezone.upper() == 'IST':
        shift_time = "330"
    else:
        shift_time = "00"
    local_start_time = arrow.get(start_time).shift(minutes=int(shift_time)).to('utc').datetime
    local_end_time = arrow.get(end_time).shift(minutes=int(shift_time)).to('utc').datetime
    utc_start_time = arrow.get(start_time).to('utc').datetime
    utc_end_time = arrow.get(end_time).to('utc').datetime
    syear = utc_start_time.year
    smonth = utc_start_time.month
    sday = utc_start_time.day
    shh = utc_start_time.hour
    smm = utc_start_time.minute
    sss = utc_start_time.second
    eyear = utc_end_time.year
    emonth = utc_end_time.month
    eday = utc_end_time.day
    ehh = utc_end_time.hour
    emm = utc_end_time.minute
    ess = utc_end_time.second
    region = conf['AWS']['region']
    if os.environ.get('AWS_ACCESS_KEY_ID') is not None:
        access_id = os.environ['AWS_ACCESS_KEY_ID']
    #else:
    #    access_id = aws_access_key_id
    if os.environ.get('AWS_SECRET_ACCESS_KEY') is not None:
        secret_key = os.environ['AWS_SECRET_ACCESS_KEY']
    tps_limit = conf['TPS_LIMIT']
    stat = conf[service]['statistical_aggregation']
    metrics_list = conf[service]['METRIC_LIST']
    try:
        # AWS CloudWatch connection
        cloudwatch = boto3.client('cloudwatch', aws_access_key_id=access_id, aws_secret_access_key=secret_key,
                                  region_name=region)
    except Exception as e:
        logger.error(traceback.format_exc())
    result = []
    interval_time_in_min = conf['INTERVAL']
    interval_time_in_min = int(interval_time_in_min) * 60
    # getting resource list key name
    filter = list(conf[service]['resource_list'].keys())[0]
    query = {}
    data = {}
    all_stat = {}
    #for item in list_of_dim:
    all_valid_id = conf[service]['resource_list'][filter]
    allquery = []
    result = []
    original_metric_name = {}
    # get list glue jobs
    list_of_glue_jobs = []
    if service.lower() == "glue":
        if all_valid_id:
            list_of_glue_jobs = all_valid_id
        else:
            try:
                client = boto3.client('glue', aws_access_key_id=access_id, aws_secret_access_key=secret_key, region_name=region)
                next_token = ''
                while next_token is not None:
                    listoutput = getgluelistofjobs(glue=client, NextToken=next_token)
                    if listoutput:
                        list_of_glue_jobs = listoutput['JobNames']
                        if 'NextToken' in listoutput:
                            next_token = listoutput['NextToken']
                        else:
                            next_token = None
            except Exception as e:
                logger.error(traceback.format_exc())

    for metric_key, metric_record in metrics_list.items():
        metric_name = metric_record['name']
        alphanumeric = [character for character in metric_name if character.isalnum()]
        alphanumeric = "".join(alphanumeric)
        original_metric_name[alphanumeric.lower()] = metric_name
    total_metric_count = 0
    for metric_key, metric_record in metrics_list.items():
        total_metric_count += 1
        logger.info("total_metric_count ={}".format(str(total_metric_count)))
        allquery = []
        temp_stat = {}
        metric_name = metric_record['name']
        namespace = metric_record['namespace']
        metric_dimentions = metric_record['dimentions']
        metric_dimentions = ','.join(metric_dimentions)
        if 'statistical_aggregation' in metric_record:
            stat = metric_record['statistical_aggregation']
        else:
            stat = conf[service]['statistical_aggregation']
        temp_stat[metric_name.lower()] = stat
        all_stat[metric_name.lower()] = stat
        metric_key = "SEARCH('{" + namespace + ',' + \
                     str(metric_dimentions) + '}' + ' MetricName='+"\"" + metric_name + "\"" + "'" + ',' + "'" + stat + "'" + ', ' + \
                     str(interval_time_in_min) + ")"
        logger.info("collecting metrics for {} from {} to {} range".format(metric_name, str(start_time), str(end_time)))
        alphanumeric = [character for character in metric_name if character.isalnum()]
        alphanumeric = "".join(alphanumeric)
        query['Id'] = str(alphanumeric).lower()
        query['Expression'] = metric_key
        query['ReturnData'] = True
        allquery.append(query)
        query = {}
        output = {}
        try:
            tps_lock.acquire()
            if count.value < tps_limit:
                count.value = count.value + 1
            else:
                time.sleep(.5)
                count.value = 0
            tps_lock.release()
        except Exception as e:
            logger.error(traceback.format_exc())
        try:
            client = boto3.client('glue', aws_access_key_id=access_id, aws_secret_access_key=secret_key, region_name=region)
            next_token = ''
            while next_token is not None:
                output = getmetricdata(cloudwatch=cloudwatch, MetricDataQueries=allquery, StartTime=datetime(syear, smonth, sday, shh, smm, sss),
                EndTime=datetime(eyear, emonth, eday, ehh, emm, ess), ScanBy='TimestampDescending', NextToken=next_token)
                next_token = None
                if output['MetricDataResults']:
                    for itemdata in output['MetricDataResults']:
                        if itemdata['StatusCode'] == 'PartialData':
                            next_token = output['NextToken']
                        data = {}
                        # namespace, resource, metricname
                        metric_labels = itemdata['Label'].split(' ')
                        if len(metric_labels) == 3:
                           id = metric_labels[1]
                        elif len(metric_labels) == 2:
                            id = metric_labels[0]
                        elif len(metric_labels) == 1 and conf[service].get('SINGLE_INSTANCE'):
                            # set this value if there is only 1 instance in the service
                            id = all_valid_id[0]
                        else:
                            id = metric_labels[0]
                        metric_name = itemdata['Id']
                        val = itemdata['Values']
                        if len(val) != 0:
                            if stat == 'Maximum':
                                val = max(val)
                            elif stat == 'Minimum':
                                val = min(val)
                            else:
                                val = sum(val)/len(val)
                        else:
                            val = ''
                        data['start_time'] = start_time
                        data['end_time'] = end_time
                        #condition for input list of instance id is empty
                        if service.lower() == 'glue':
                            if id == "ALL":
                                continue
                            if val == '':
                                continue
                            for jobname in list_of_glue_jobs:
                                try:
                                    response = client.get_job_run(JobName=jobname,
                                                                  RunId=id,
                                                                  PredecessorsIncluded=False)
                                    if response:
                                        get_job_name = response['JobRun']['JobName']
                                        #data['job_name'] = response['JobRun']['JobName']
                                        if len(all_valid_id) == 0:
                                            data[filter] = response['JobRun']['JobName']
                                            data['job_run_id'] = id
                                        # check instance id is present in input list
                                        elif get_job_name in all_valid_id:
                                            data[filter] = response['JobRun']['JobName']
                                            data['job_run_id'] = id
                                        else:
                                            # if does not present then do not consider
                                            continue
                                except client.exceptions.EntityNotFoundException as e:
                                    continue
                                except Exception as e:
                                    logger.error(traceback.format_exc())
                        else:
                            if len(all_valid_id) == 0:
                                data[filter] = id
                            #check instance id is present in input list
                            elif id in all_valid_id:
                                data[filter] = id
                            else:
                                #if does not present then do not consider
                                continue
                        data['metric_name'] = original_metric_name[metric_name.lower()]
                        data['metric_value'] = val
                        data['statistic'] = all_stat[original_metric_name[metric_name].lower()]#stat
                        data['frequency'] = int(interval_time_in_min)/60
                        result.append(data)
                        data = {}
                        if itemdata['StatusCode'] == 'PartialData':
                            next_token = output['NextToken']
                        #else:
                        #    next_token = None
                    #next_token = None
                else:
                    all_resources = get_list_of_resouces(cloudwatch, filter, namespace, metric_name)
                    for each_resource in all_resources:
                        for metric_key, metric_record in metrics_list.items():
                            if metric_name != metric_record['name']:
                                continue
                            metric_name = metric_record['name']
                            namespace = metric_record['namespace']
                            data['start_time'] = start_time
                            data['end_time'] = end_time
                            # condition for input list gof instance id is empty
                            if service.lower() == 'glue':
                                for jobname in list_of_glue_jobs:
                                    try:
                                        response = client.get_job_run(JobName=jobname,
                                                                      RunId=id,
                                                                      PredecessorsIncluded=False)
                                        if response:
                                            get_job_name = response['JobRun']['JobName']
                                            #data['job_name'] = response['JobRun']['JobName']
                                            if len(all_valid_id) == 0:
                                                data[filter] = response['JobRun']['JobName']
                                                data['job_run_id'] = id
                                            # check instance id is present in input list
                                            elif get_job_name in all_valid_id:
                                                data[filter] = response['JobRun']['JobName']
                                                data['job_run_id'] = id
                                            else:
                                                # if does not present then do not consider
                                                continue
                                    except client.exceptions.EntityNotFoundException as e:
                                        data[filter] = ''
                                        data['job_run_id'] = id
                                    except Exception as e:
                                        logger.error(traceback.format_exc())
                            else:
                                if len(all_valid_id) == 0:
                                    data[filter] = each_resource
                                    # check instance id is present in input list
                                elif each_resource in all_valid_id:
                                    data[filter] = each_resource
                                else:
                                    # if does not present then do not consider
                                    continue
                            data['metric_name'] = original_metric_name[metric_name.lower()]#metric_name
                            data['metric_value'] = ''
                            data['statistic'] = stat
                            data['frequency'] = int(int(interval_time_in_min)/60)
                            result.append(data)
                            data = {}
                    next_token = None
        except Exception as e:
            logger.error(traceback.format_exc())
    return result
# save to csv file
def saveCSV(lock, result, output_filename):
    # type: (object, object, object) -> object
    """
    Saving the metrics data to csv
    """
    lock.acquire()
    header = True
    try:
        with open(output_filename, 'a', newline='') as csvfile:
            writer = csv.writer(csvfile)
            for row in result:
                if header and os.stat(output_filename).st_size == 0:
                    writer.writerow(row.keys())
                    header = False
                writer.writerow(row.values())
    except Exception as e:
        logger.error(traceback.format_exc())
    lock.release()

# main logic
def getcloudwatchmetrics(lock, config, service, tps_lock, count):
    """
    Main method
    """
    #global output_file_name
    cwd = os.getcwd()
    output_file_name = ''
    timezone = config['TIMEZONE']
    # if it is continuous data collection
    if not config['HISTORICAL']:
        # get frequency from config file
        interval_time_in_min = config['INTERVAL']
        # start time should be previous 5 min
        #start_time = datetime.now() - timedelta(minutes=(interval_time_in_min))
        start_time = arrow.utcnow().shift(minutes=-int(interval_time_in_min))
        endtime = arrow.utcnow()
        #replacing sec with 00 to make simple
        start_time = start_time.replace(year=start_time.year, month=start_time.month, day=start_time.day, hour=start_time.hour, minute=start_time.minute, second=00)
        start_time = start_time.strftime('%Y-%m-%d %H:%M:%S')
        shift_time = arrow.get(start_time)
        endtime = endtime.replace(year=endtime.year, month=endtime.month, day=endtime.day, hour=endtime.hour, minute=endtime.minute, second=00)
        endtime = endtime.strftime('%Y-%m-%d %H:%M:%S')
        utc_start_time = arrow.get(start_time).to('utc').datetime
        #min = utc_start_time.minute
        utc_end_time = arrow.get(endtime).to('utc').datetime
        utc_five_min_interval_backup = shift_time.shift(minutes=+int(interval_time_in_min))
        utc_five_min_interval = utc_five_min_interval_backup.to('utc').datetime
    else:
        startday = config['START_DATE']
        endday = config['END_DATE']
        shift_time = "00"
        if timezone.upper() == 'EDT':
            shift_time = "-240"
        if timezone.upper() == 'EST':
            shift_time = "-300"
        if timezone.upper() == 'IST':
            shift_time = "-330"
        utc_start_time = arrow.get(startday).shift(minutes=int(shift_time)).to('utc').datetime
        start_time = arrow.get(startday).shift(minutes=int(shift_time))
        #endday = '2020-07-30 16:00:00'
        utc_end_time = arrow.get(endday).shift(minutes=int(shift_time)).to('utc').datetime
        interval_time_in_min = config['INTERVAL']
        utc_five_min_interval_backup = start_time.shift(minutes=+int(interval_time_in_min))
        utc_five_min_interval = utc_five_min_interval_backup.to('utc').datetime
    while utc_start_time < utc_end_time:
        if utc_start_time.hour == 24 and utc_start_time.minute == 0 and utc_start_time.second == 0:
            utc_last_five_min_interval = utc_five_min_interval
            utc_last_five_min_interval = utc_last_five_min_interval.replace(year=utc_start_time.year, month=utc_start_time.month, day=utc_start_time.day, hour=utc_start_time.hour, minute=59, second=59)
            result = getmaxData(utc_start_time, utc_last_five_min_interval, config, service, tps_lock, count, timezone)
        else:
            result = getmaxData(utc_start_time, utc_five_min_interval, config, service, tps_lock, count, timezone)
        month = ''
        day = ''
        if len(str(utc_start_time.month)) == 1:
            month = '0'+str(utc_start_time.month)
        else:
            month = str(utc_start_time.month)
        if len(str(utc_start_time.day)) == 1:
            day = '0'+str(utc_start_time.day)
        else:
            day = str(utc_start_time.day)
        pwd = os.path.dirname(os.path.realpath(__file__))
        if config[service]['csvpath'] != '':
            if platform.system() == 'Windows':
                output_file_path = config[service]['csvpath'] + '\\' + "cw_" + service.lower() +"_metrics_" + str(month) + \
                                   str(day) + str(utc_start_time.year) + ".csv"
            else:
                output_file_path = config[service]['csvpath'] + '/' + "cw_" + service.lower() + "_metrics_" + str(month) + str(
                    day) + str(utc_start_time.year) + ".csv"
        else:
            output_file_name = "cw_" + service.lower() + "_metrics_" + str(month) + str(day) + str(utc_start_time.year) + ".csv"
            if platform.system() == 'Windows':
                output_file_path = "{0}{1}{2}".format(pwd, '\\', output_file_name)
            else:
                output_file_path = "{0}{1}{2}".format(pwd, '/', output_file_name)
        logger.info("output_file_path= {0}".format(output_file_path))
        saveCSV(lock, result, output_file_path)
        utc_start_time = utc_five_min_interval
        new_utc_five_min_interval = utc_five_min_interval_backup.shift(minutes=+int(interval_time_in_min))
        utc_five_min_interval_backup = new_utc_five_min_interval
        utc_five_min_interval = new_utc_five_min_interval.to('utc').datetime

def uploadfiletos3(config, filename, filepath, s3buckname):
    """
    upload csv files into s3 bucket
    """
    region = config['AWS']['region']
    access_id = os.environ['AWS_ACCESS_KEY_ID']
    secret_key = os.environ['AWS_SECRET_ACCESS_KEY']
    #testFile = 'cloudwatch/' + filename
    testFile = 'DM'+ '/' + filename
    s3 = boto3.client('s3', aws_access_key_id=access_id, aws_secret_access_key=secret_key, region_name=region)
    with open(filepath, 'rb') as data:
        try:
            logger.info(" -------- uploading file to s3 bucket ---------- ")
            logging.info(s3.put_object(Bucket=s3buckname, Key=testFile, Body=data))
        except Exception as e:
            logger.error(traceback.format_exc())
        #s3.upload_fileobj(data, s3buckname, testFile)

def execute(**inputs):
    # Get input from command line
    command_line_input = False
    parser = argparse.ArgumentParser()
    args = parser.parse_args()
    start_date = inputs.get('start_date')
    end_date = inputs.get('end_date')
    config_path = inputs.get('config_path')
    service_name = inputs.get('service_name')

    service_enable = {}
    starttime = datetime.now()
    logger.info(" --- calling cloudwatch fetch metric function ---- ")
    pwd = os.path.dirname(os.path.realpath(__file__))
    logger.info(str(pwd))
    # if platform.system() == 'Windows':
    #     cwd = "{0}{1}{2}".format(pwd, '\\', 'config.yaml')
    # else:
    #     cwd = "{0}{1}{2}".format(pwd, '/', 'config.yaml')
    config = load_configuration(config_path)
    if command_line_input:
        config['START_DATE'] = start_date
        config['END_DATE'] = end_date
    for service_name in config['SERVICES']['LIST']:
        service_found = False
        for service in config:
            if service == '.' + service_name:
                tool_found = True  # service is found in data node though prefixed with (.)
                logger.warning("WARNING: Node <{}> is marked to exclude from processing [prefixed with dot (.)]. Skipping...".format(service))
            else:
                if service == 'TOOLS':
                    # Skip as TOOLS is being processed in the beginning for iterating on list
                    continue
                elif service == service_name:  # This is to avoid hardcoding of service name in code
                    service_found = True
                    logger.info('----------------Processing {} from {}----------------'.format(service, config))
                    service_enable[service] = 1

    #fetch the details and pass the function
    lock = mp.Lock()
    count = mp.Value('i', 0)
    tps_lock = mp.Lock()
    procs = []

    for service in service_enable.keys():
        # Setup a list of processes that we want to run
        #getcloudwatchmetrics(lock, config, service, tps_lock, count)
        processes = Process(target=getcloudwatchmetrics, args=(lock, config, service, tps_lock, count))
        procs.append(processes)
        processes.start()

    for proc in procs:
        proc.join()

    if config['S3_UPLOAD']:
        bucketname = config['BUCKETNAME']
        result = glob.glob('*.{}'.format('csv'))
        for item in result:
            if platform.system() == 'Windows':
                path = "{0}{1}{2}".format(pwd, '\\', item)
            else:
                path = "{0}{1}{2}".format(pwd, '/', item)
            uploadfiletos3(config, item, path, bucketname)
    logger.info("---- End of logging ----")
    endtime = datetime.now()
    diff = endtime - starttime
    msg = "Total execution time ={0}".format(divmod(diff.total_seconds(), 60))
    logger.info(msg)

