#HOW TO RUN PERFORMANCE METRICS:
* main script - collect_rds_counter_metrics.py
* add the credentials in the format {'<db-instance-id>':'<db resource identifier>'} to config.yaml inside config folder.
* run the command as python3.9 collect_rds_counter_metrics.py <json metric location>
* for e.g - python3.9 collect_rds_counter_metrics.py /data01/pe-dm-rds/performance_insights/rds_performance_insights/jsons/counter_metric/os/tasks_metric.json
* metrics will be collected in the csvs folder under counter_metrics.