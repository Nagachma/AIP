import pandas as pd
import sys

pd.set_option('display.max_columns', None)

data = pd.read_csv(sys.argv[1], delimiter=',', index_col=False)

l = len(data.iloc[1]['statement'])

#data['statement'] = data['statement'].strip()
data = data.replace('\n','', regex=True)

l2 = len(data.iloc[1]['statement'])


data.to_csv(sys.argv[1].split("/")[-1], sep=';', index=False)
