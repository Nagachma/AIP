#!/bin/sh

ts=$(TZ="UTC" date --date="yesterday" +%Y-%m-%d)

# Folders within the server where metric related files are stored
folders=(/home/oauser/rds/csvs/db_load/ /home/oauser/rds/csvs/counter_metric/db/ /home/oauser/rds/csvs/counter_metric/os/)

# Move files from yesterday into archive
for folder in "${folders[@]}"; do
	mv $folder/*$ts.csv $folder/archive
done

# Default value for number of days for which csv files needs to be retained on local server
KEEP_DAYS=7
if [ $# -eq "1" ]; then
    KEEP_DAYS=$1
fi

# DELETE FILES OLDER THAN 7 days
for folder in "${folders[@]}"; do
	echo 'Deleting csv and log files older than '${KEEP_DAYS}' days'
	find $folder -type f -mtime +${KEEP_DAYS} -name '*.csv' -execdir rm -- {} \;
done

