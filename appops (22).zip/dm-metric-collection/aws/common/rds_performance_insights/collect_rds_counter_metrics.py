import boto3
import datetime
import json
import os, time
import pandas as pd
import platform

import pytz
import yaml
from vault_utility_v2 import vault_credentials

os.environ['TZ'] = 'UTC'
time.tzset()
pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)


def calc_time(interval):

    # Get day and hour now
    t = datetime.datetime.utcnow()
    day = [t.day, t.day]
    hour = [t.hour, t.hour]
    minute = [t.minute, t.minute]

    t2 = t - datetime.timedelta(minutes=interval)

    minute = [t.minute, t2.minute]
    hour = [t.hour, t2.hour]
    day = [t.day, t2.day]
    month = [t.month, t2.month]
    year = [t.year, t2.year]

    return minute, hour, day, month, year


def load_configuration(lconfig):
    """
    Read and load data from config.yaml file
    """
    cfg = {}  # Check if this is a dict
    try:
        with open(lconfig, 'r') as yamlfile:
            cfg = yaml.safe_load(yamlfile)
    except yaml.YAMLError as exc:
        pass
    except Exception as e:
        pass
    return cfg


def execute(**inputs):
    base_dir = inputs.get("BASE_HOME_DIR")

    config_path = inputs.get('CONFIG_PATH')

    config = load_configuration(config_path)
    # Get time
    minute, hour, day, month, year = calc_time(config['interval'])
    # Check platform
    if platform.system() == 'Windows':
        spacer = '\\'
    else:
        spacer = '/'
    # Connect to AWS
    if config.get('using_keys'):
        access_id = os.environ.get('AWS_ACCESS_KEY_ID')
        secret_key = os.environ.get('AWS_SECRET_ACCESS_KEY')
        if None in [access_id, secret_key]:
            secret_keys = vault_credentials.get_secret_from_vault(config['vault_path'],config['vault_keys'])
            access_id = secret_keys['accessKey']
            secret_key = secret_keys['secretKey']
        client = boto3.client('pi', aws_access_key_id=access_id, aws_secret_access_key=secret_key,
                              region_name=config['region'])
    else:
        client = boto3.client('pi', region_name=config['region'])
    # Create JSON list
    pwd = os.path.dirname(os.path.realpath(__file__))
    if base_dir:
        pwd = base_dir
    if platform.system() == 'Windows':
        csv_wd = pwd + config['csv_path'] + '\\csvs\\counter_metric'
    else:
        csv_wd = pwd + config['csv_path'] + '/csvs/counter_metric'
    # Set output time
    dt = datetime.datetime.utcnow() - datetime.timedelta(minutes=2)
    output_dt = str(dt.year) + '-' + str(dt.month) + '-' + str(dt.day).zfill(2)

    # Read in JSONs
    cm_json_path = config.get('counter_metric_jsons')
    db_load_json_path = config.get('db_load_jsons')
    json_paths = {}
    if cm_json_path or db_load_json_path:
        os_json_path = pwd + cm_json_path + 'os'
        db_json_path = pwd + cm_json_path + 'db'
        if cm_json_path:
            json_paths[db_json_path] = os.listdir(db_json_path)
            json_paths[os_json_path] = os.listdir(os_json_path)

        db_load_json_path = config.get('db_load_jsons')
        if db_load_json_path:
            json_paths[pwd + db_load_json_path] = os.listdir(pwd + db_load_json_path)

        for folder, files in json_paths.items():
            for file in files:
                with open(folder + '/' + file) as f:
                    metric_queries = json.load(f)

                output_df = pd.DataFrame(columns=['metric_date', 'instance', 'type', 'value'])
                # output_name = "/".join(file.split("/")[-2:]).split(".")[0]

                # Send request

                identifier_list = config['identifiers']
                for db_name, db_id in iter(identifier_list.items()):
                    response = client.get_resource_metrics(
                        ServiceType='RDS',
                        Identifier=db_id,
                        MetricQueries=metric_queries,
                        StartTime=str(year[0]) + '-' + str(month[0]) + '-' + str(day[1]) + 'T' + str(hour[1]) + ':' + str(minute[1]) + ':00UTC',
                        EndTime=str(year[0]) + '-' + str(month[0]) + '-' + str(day[0]) + 'T' + str(hour[0]) + ':' + str(minute[0]) + ':00UTC',
                        PeriodInSeconds=(config['interval']*60)
                    )
                    for set in response['MetricList']:
                        type = set['Key']['Metric']
                        for row in set['DataPoints']:
                            temp_time = row['Timestamp'].astimezone(pytz.UTC) - datetime.timedelta(seconds=300)
                            # print(temp_time)
                            time_value = str(temp_time).split('+')[0]  #str("{}-{}-{} {}:{}:00".format(year[1], month[1], "0"+day[1], hour[1], minute[1]))
                            try:
                                values = {'metric_date': time_value, 'instance': db_name, 'type': type, 'value': str(round(row['Value'],2))}
                            except KeyError as e:
                                values = {'metric_date': time_value, 'instance': db_name, 'type': type, 'value': 0}
                            output_df = output_df.append(values, ignore_index=True)
                temp_output = output_dt.split('-')
                output_file_name = temp_output[1]+temp_output[2]+temp_output[0]
                output_file_full_name = csv_wd + spacer + f"{config['csv_prefix']}_{config['service_name']}_metrics_" + output_file_name + '.csv'
                if not os.path.exists(csv_wd):
                    os.makedirs(csv_wd, exist_ok=True)

                if os.path.isfile(output_file_full_name):
                    df = pd.read_csv(output_file_full_name).append(output_df)
                    df.drop_duplicates(inplace=True)
                    df.to_csv(output_file_full_name, sep=',', index=False)
                else:
                    output_df.drop_duplicates(inplace=True)
                    output_df.to_csv(output_file_full_name, sep=',', index=False)


# if __name__ == '__main__':
#     execute(**{
#         'BASE_HOME_DIR': 'C:/Users/souma.datta/Documents/Projects/xOps/codebase/appops-main/appops/',
#         'CONFIG_PATH': 'C:/Users/souma.datta/Documents/Projects/xOps/codebase/appops-main/appops/tools/aws/rds/collection/sources/performance-insights/config.yaml'
#     })
