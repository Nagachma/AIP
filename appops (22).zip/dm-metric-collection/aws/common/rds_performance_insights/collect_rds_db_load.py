import boto3
import csv
import datetime
import json
import os, time
from os import path
import pandas as pd
import platform
import sys

os.environ['TZ'] = 'UTC'
time.tzset()
pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)


def calc_time():
	
	# Get day and hour now
	t = datetime.datetime.utcnow()
	day = [t.day, t.day]
	hour = [t.hour, t.hour]

	# Set collection times and return
	hour[1] += 1
	if hour[1] == 24:
		hour[1] = 0
		day[1] += 1
	return day, hour


if __name__ == '__main__':

	# Get time
        day, hour = calc_time()

	# Check platform
	if platform.system() == 'Windows':
                spacer = '\\'
        else:
                spacer = '/'

	# Connect to AWS
	client = boto3.client('pi', region_name='us-east-1')

	# Create JSON list
	pwd = os.path.dirname(os.path.realpath(__file__))
	if platform.system() == 'Windows':
		csv_wd = pwd + '\\csvs\\db_load'
	else:
		csv_wd = pwd + '/csvs/db_load'

	# Set output time
        dt = datetime.datetime.utcnow() - datetime.timedelta(minutes=2)
        output_dt = str(dt.year) + '-' + str(dt.month) + '-' + str(dt.day)

	# Set output dataframes
	output_df_dict = {'db_load_avg_host': pd.DataFrame(columns=['metric_date', 'instance', 'id', 'name', 'value']),
			'db_load_avg_sql': pd.DataFrame(columns=['metric_date','instance','db_id','id','statement','value']),
			'db_load_avg_user': pd.DataFrame(columns=['metric_date', 'instance', 'id', 'name', 'value']),
			'db_load_avg_wait': pd.DataFrame(columns=['metric_date', 'instance', 'name', 'type', 'value'])}

	# Set db list
	identifier_list = {'bcbueapoaipql03':'db-FGAYG2Y4OK4EXTT35GD3OZK3FI', 
			'bcbusbppaipql01':'db-S5NWSSTPUY6F74FK6KG6WMHRMI',
			'bcbueapoaipql02':'db-FXGUUSPLOQBV4PRGKP4MGZJTLY',
			'bcbueapoaipql01':'db-BWSZBGMKZEMQUJD32DI32YG4BY'}

	# Send request
	for db_name, db_id in identifier_list.iteritems():
		response = client.get_resource_metrics(
			ServiceType='RDS',
			Identifier=db_id,
			MetricQueries=[
				{
					"Metric": "db.load.avg",
					"GroupBy": { "Group": "db.host" }
				},{
				        "Metric": "db.load.avg",
				        "GroupBy": { "Group": "db.sql_tokenized" }
				},{
				        "Metric": "db.load.avg",
				        "GroupBy": { "Group": "db.user" }
				},{
				        "Metric": "db.load.avg",
				        "GroupBy": { "Group": "db.wait_event" }
				},
			],
			StartTime='2020-10-' + str(day[0]) + 'T' + str(hour[0]) + ':00:00UTC',
			EndTime='2020-10-' + str(day[1]) + 'T' + str(hour[1]) + ':00:00UTC',
			PeriodInSeconds=60
		)
		for set in response['MetricList']:
			if "Dimensions" in set['Key']:
				if 'db.host.id' in set['Key']['Dimensions']:
					id = set['Key']['Dimensions']['db.host.id']
       		                        name = set['Key']['Dimensions']['db.host.name']
                                        for row in set['DataPoints']:
                                                time_value = str(row['Timestamp']).split('+')[0]
                                                try:
                                                        values = {'metric_date': time_value, 'instance': db_name, 'id': id, 'name': name, 'value': str(row['Value'])}
                                                except KeyError as e:
                                                        values = {'metric_date': time_value, 'instance': db_name, 'id': id, 'name': name, 'value': 0}
                                                output_df_dict['db_load_avg_host'] = output_df_dict['db_load_avg_host'].append(values, ignore_index=True)
				elif 'db.sql_tokenized.db_id' in set['Key']['Dimensions']:
					db_id = set['Key']['Dimensions']['db.sql_tokenized.db_id']
                	                id = set['Key']['Dimensions']['db.sql_tokenized.id']
       		                        statement = set['Key']['Dimensions']['db.sql_tokenized.statement']
					for row in set['DataPoints']:
						time_value = str(row['Timestamp']).split('+')[0]
                                                try:
                                                        values = {'metric_date': time_value, 'instance': db_name, 'db_id': db_id, 'id': id, 'statement': statement, 'value': str(row['Value'])}
                                                except KeyError as e:
                                                        values = {'metric_date': time_value, 'instance': db_name, 'db_id': db_id, 'id': id, 'statement': statement, 'value': 0}
                                                output_df_dict['db_load_avg_sql'] = output_df_dict['db_load_avg_sql'].append(values, ignore_index=True)
				elif 'db.user.id' in set['Key']['Dimensions']:
					id = set['Key']['Dimensions']['db.user.id']
               	                        name = set['Key']['Dimensions']['db.user.name']
					for row in set['DataPoints']:
						time_value = str(row['Timestamp']).split('+')[0]
	                                        try:
	                                                values = {'metric_date': time_value, 'instance': db_name, 'id': id, 'name': name, 'value': str(row['Value'])}
	                                        except KeyError as e:
       		                                        values = {'metric_date': time_value, 'instance': db_name, 'id': id, 'name': name, 'value': 0}
	                                        output_df_dict['db_load_avg_user'] = output_df_dict['db_load_avg_user'].append(values, ignore_index=True)
				elif 'db.wait_event.name' in set['Key']['Dimensions']:
	                                name = set['Key']['Dimensions']['db.wait_event.name']
                                        type = set['Key']['Dimensions']['db.wait_event.type']
					for row in set['DataPoints']:
                                        	time_value = str(row['Timestamp']).split('+')[0]
                                                try:
                                                        values = {'metric_date': time_value, 'instance': db_name, 'name': name, 'type': type, 'value': str(row['Value'])}
                                                except KeyError as e:
                                                        values = {'metric_date': time_value, 'instance': db_name, 'name': name, 'type': type, 'value': 0}
                                                output_df_dict['db_load_avg_wait'] = output_df_dict['db_load_avg_wait'].append(values, ignore_index=True)

	# Write to CSV
	for output_name, output_df in output_df_dict.iteritems():
		if os.path.isfile(csv_wd + spacer + output_name + '_' + output_dt + '.csv'):
			output_df = output_df.replace('\n','', regex=True)
			try:
				df = pd.read_csv(csv_wd + spacer + output_name + '_' + output_dt + '.csv', lineterminator='\n').append(output_df)
				df.drop_duplicates(inplace=True)
	                        df.to_csv(csv_wd + spacer + output_name + '_' + output_dt + '.csv', sep=',', index=False)
			except ParserError as e:
				output_df.drop_duplicates(inplace=True)
        		        df.to_csv(csv_wd + spacer + output_name + '_' + output_dt + '.csv', sep=',', index=False, mode='a', header=False)
		else:
			output_df.drop_duplicates(inplace=True)
			output_df = output_df.replace('\n','', regex=True)
			output_df.to_csv(csv_wd + spacer + output_name + '_' + output_dt + '.csv', sep=',', index=False)
