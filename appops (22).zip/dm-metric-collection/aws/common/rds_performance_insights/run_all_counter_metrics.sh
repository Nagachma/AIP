# Collect all DB metrics
python /home/oauser/rds/collect_rds_counter_metrics.py /home/oauser/rds/jsons/counter_metric/db/Cache_metric.json
python /home/oauser/rds/collect_rds_counter_metrics.py /home/oauser/rds/jsons/counter_metric/db/Checkpoint_metric.json
python /home/oauser/rds/collect_rds_counter_metrics.py /home/oauser/rds/jsons/counter_metric/db/Concurrency_metric.json
python /home/oauser/rds/collect_rds_counter_metrics.py /home/oauser/rds/jsons/counter_metric/db/IO_metric.json
python /home/oauser/rds/collect_rds_counter_metrics.py /home/oauser/rds/jsons/counter_metric/db/SQL_metric.json
python /home/oauser/rds/collect_rds_counter_metrics.py /home/oauser/rds/jsons/counter_metric/db/state_metric.json
python /home/oauser/rds/collect_rds_counter_metrics.py /home/oauser/rds/jsons/counter_metric/db/Temp_metric.json
python /home/oauser/rds/collect_rds_counter_metrics.py /home/oauser/rds/jsons/counter_metric/db/Transactions_metric.json
python /home/oauser/rds/collect_rds_counter_metrics.py /home/oauser/rds/jsons/counter_metric/db/User_metric.json
python /home/oauser/rds/collect_rds_counter_metrics.py /home/oauser/rds/jsons/counter_metric/db/WAL_metric.json

# Collect all OS metrics
python /home/oauser/rds/collect_rds_counter_metrics.py /home/oauser/rds/jsons/counter_metric/os/cpuUtilization_metric.json
python /home/oauser/rds/collect_rds_counter_metrics.py /home/oauser/rds/jsons/counter_metric/os/diskIO_metric.json
python /home/oauser/rds/collect_rds_counter_metrics.py /home/oauser/rds/jsons/counter_metric/os/fileSys_metric.json
python /home/oauser/rds/collect_rds_counter_metrics.py /home/oauser/rds/jsons/counter_metric/os/general_metric.json
python /home/oauser/rds/collect_rds_counter_metrics.py /home/oauser/rds/jsons/counter_metric/os/loadAverageMinute_metric.json
python /home/oauser/rds/collect_rds_counter_metrics.py /home/oauser/rds/jsons/counter_metric/os/memory_1_metric.json
python /home/oauser/rds/collect_rds_counter_metrics.py /home/oauser/rds/jsons/counter_metric/os/memory_2_metric.json
python /home/oauser/rds/collect_rds_counter_metrics.py /home/oauser/rds/jsons/counter_metric/os/network_metric.json
python /home/oauser/rds/collect_rds_counter_metrics.py /home/oauser/rds/jsons/counter_metric/os/swap_metric.json
python /home/oauser/rds/collect_rds_counter_metrics.py /home/oauser/rds/jsons/counter_metric/os/tasks_metric.json

