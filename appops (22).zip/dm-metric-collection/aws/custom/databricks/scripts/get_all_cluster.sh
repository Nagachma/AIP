#!/bin/bash

# put current date as yyyy-mm-dd HH:MM:SS in $date
date=$(date '+%Y-%m-%d')
echo $date

# export DATABRICKS_TOKEN=dapi57da4bd851ccf18414f0099839c0993f
# url=https://bcbsm-prod-wsp-2.cloud.databricks.com/api/2.0/clusters/list

DATABRICKS_TOKEN=$1
url=$2

file=/data01/appops/dm-metric-collection/aws/custom/databricks/json/cluster_json.txt
#file="C:\\Users\\tushar.dua\\OneDrive - Accenture\\oai\\appops\\aws_databricks\\appops\\dm-metric-collection\\aws\\custom\\databricks\\json\\test.txt"

curl -X GET --header "Authorization: Bearer $DATABRICKS_TOKEN" $url > $file
