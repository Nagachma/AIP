#!/bin/bash

# put current date as yyyy-mm-dd HH:MM:SS in $date
date=$(date '+%Y-%m-%d %H:%M:%S')
# print variable on a screen
echo $date

# export DATABRICKS_TOKEN=dapi57da4bd851ccf18414f0099839c0993f
# url=https://bcbsm-prod-wsp-2.cloud.databricks.com/api/2.0/jobs/runs/list

file=/data01/appops/dm-metric-collection/aws/custom/databricks/json/jobs_json.txt

DATABRICKS_TOKEN=$1
url=$2

curl -X GET --header "Authorization: Bearer $DATABRICKS_TOKEN" $url > $file
