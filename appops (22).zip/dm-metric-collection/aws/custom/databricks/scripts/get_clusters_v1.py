import json
import pandas as pd
from pandas import DataFrame
import numpy as np
import os
import yaml
from datetime import datetime, timezone
pd.options.mode.chained_assignment = None
import time
from datetime import datetime
from pathlib import Path
from datetime import datetime
import logging
from vault_utility_v2 import vault_credentials

filedate = datetime.now().strftime('%d%m%Y')

logger = logging.getLogger('Collecting AWS DataBricks Metrics')
logger.setLevel(logging.INFO)

# create console handler and set level to debug
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.DEBUG)

# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# add formatter to console_handler
console_handler.setFormatter(formatter)

# add console_handler to logger
logger.addHandler(console_handler)

def load_configuration(lconfig):
    """Read and load data from config.yaml file"""
    cfg = {}
    try:
        with open(lconfig, 'r') as yaml_file:
            cfg = yaml.safe_load(yaml_file)
    except yaml.YAMLError as exc:
        print(exc)
        logger.exception(exc)
    except Exception as e:
        print(e)
        logger.exception(e)
    return cfg

def cluster_info(input_json, output_csv, TOKEN, URL):
    params = [TOKEN, URL]
    os.system("sh /data01/appops/dm-metric-collection/aws/custom/databricks/scripts/get_all_cluster.sh " + " ".join(params))
    # os.system("sh C:\\Users\\tushar.dua\\OneDrive - Accenture\\oai\\appops\\aws_databricks\\appops\\dm-metric-collection\\aws\\custom\\databricks\\scripts\\get_all_cluster.sh" + " ".join(params))
    time.sleep(5)
    columns = {'cluster_id' : [],'creator_user_name' : [],'start_timestamp' : [],'cluster_name' : [],'disk_count' : [],'disk_size' : [],'availability' : [],'cluster_memory_mb' : [],'cluster_cores' : [],'start_time' : [],'last_activity_time' : [],'last_restarted_time' : [],'state': [], 'JobId': [],'job_name' : [],'terminated_time' : [], 'termination_reason' : [], 'termination_status' : []}

    with open(input_json) as f:
        json_data = json.load(f)

    for clusters in json_data['clusters']:
        #print(clusters['cluster_id'])
        columns['cluster_id'].append(clusters['cluster_id'])
        columns['creator_user_name'].append(clusters['creator_user_name'])
        try:
            columns['start_timestamp'].append(clusters['driver']['start_timestamp'])
        except KeyError:
            columns['start_timestamp'].append(None)
        columns['cluster_name'].append(clusters['cluster_name'])
        columns['disk_count'].append(clusters['disk_spec']['disk_count'])
        try:
            columns['disk_size'].append(clusters['disk_spec']['disk_size'])
        except KeyError:
            columns['disk_size'].append(None)
        #columns['disk_size'].append(clusters['disk_spec']['disk_size'])
        try:
            columns['availability'].append(clusters['aws_attributes']['availability'])
        except KeyError:
            columns['availability'].append(None)
        try:
            columns['cluster_memory_mb' ].append(clusters['cluster_memory_mb'])
        except KeyError:
            columns['cluster_memory_mb' ].append(None)
        try:
            columns['cluster_cores' ].append(clusters['cluster_cores'])
        except KeyError:
            columns['cluster_cores' ].append(None)
        columns['start_time'].append(clusters['start_time'])
        columns['last_activity_time'].append(clusters['last_activity_time'])
        columns['last_restarted_time'].append(clusters['last_restarted_time'])
        columns['state'].append(clusters['state'])
        try:
            columns['terminated_time'].append(clusters['terminated_time'])
        except KeyError:
            columns['terminated_time'].append(None)
        try:
            columns['JobId'].append(clusters['default_tags']['JobId'])
        except KeyError:
            columns['JobId'].append(None)
        try:
            columns['job_name'].append(clusters['default_tags']['RunName'])
        except KeyError:
            columns['job_name'].append(None)
        try:
            columns['termination_reason'].append(clusters['termination_reason']['code'])
        except KeyError:
            columns['termination_reason'].append(None)
        try:
            columns['termination_status'].append(clusters['termination_reason']['type'])
        except KeyError:
            columns['termination_status'].append(None)
            
    for i in range(len(columns['start_timestamp'])):
        try:
            columns['start_timestamp'][i] = columns['start_timestamp'][i]/1000
            columns['start_timestamp'][i] = datetime.fromtimestamp(columns['start_timestamp'][i]).strftime('%Y-%m-%d %H:%M:%S')
        except:
            pass


    for i in range(len(columns['start_time'])):
        try:
            columns['start_time'][i] = columns['start_time'][i]/1000
            columns['start_time'][i] = datetime.fromtimestamp(columns['start_time'][i]).strftime('%Y-%m-%d %H:%M:%S')
            columns['start_time'][i] = datetime.strptime(columns['start_time'][i], "%Y-%m-%d %H:%M:%S")
        except:
            pass
    
    for i in range(len(columns['last_activity_time'])):
        try:
            columns['last_activity_time'][i] = columns['last_activity_time'][i]/1000
            columns['last_activity_time'][i] = datetime.fromtimestamp(columns['last_activity_time'][i]).strftime('%Y-%m-%d %H:%M:%S')
        except:
            pass

    for i in range(len(columns['last_restarted_time'])):
        try:
            columns['last_restarted_time'][i] = columns['last_restarted_time'][i]/1000
            columns['last_restarted_time'][i] = datetime.fromtimestamp(columns['last_restarted_time'][i]).strftime('%Y-%m-%d %H:%M:%S')
        except:
            pass

    for i in range(len(columns['terminated_time'])):
        try:
            columns['terminated_time'][i] = columns['terminated_time'][i]/1000
            columns['terminated_time'][i] = datetime.fromtimestamp(columns['terminated_time'][i]).strftime('%Y-%m-%d %H:%M:%S')
        except:
            pass
    
    df = DataFrame(columns)
    
    current_time = datetime.now(timezone.utc)
    current_time = current_time.strftime('%Y-%m-%d %H:%M:%S')
    current_time = datetime.strptime(current_time,'%Y-%m-%d %H:%M:%S')

    df['start_time'] = pd.to_datetime(df['start_time'])
    df['terminated_time'] = pd.to_datetime(df['terminated_time'])

    df['cluster_run_time'] = df.apply(lambda x: (current_time - x['start_time']) if pd.isnull(x['terminated_time']) else (x['terminated_time'] - x['start_time']), axis=1)

    df['cluster_run_time'] = df['cluster_run_time']/np.timedelta64(1,'h')
    df['cluster_run_time'] = round(df['cluster_run_time'],3)

    #print(f"{df['start_time']} , {df['terminated_time']} , {df['cluster_run_time']}")

    #file_path = Path(output_csv)
    file_path = Path(output_csv + "/cluster_awsdatabricks_metrics_"+ filedate +".csv")

    if file_path.exists():
        df.to_csv(file_path, header = False, mode = 'a',index = False)
    else:
        df.to_csv(file_path, header = True, mode = 'w', index = False)

def execute(**inputs):
    
    config = load_configuration(inputs.get('CONFIG_PATH'))
    #config = load_configuration('config.yaml')
    output_csv = config['CL_OUTPUT_CSV']
    input_json = config['CL_INPUT_JSON']

    #Creds from Vault
    cred = vault_credentials.get_secret_from_vault(config['vault_path'], config['vault_keys'])
    URL = cred['URL']
    TOKEN = cred['TOKEN']

    cluster_info(input_json, output_csv, TOKEN, URL)
