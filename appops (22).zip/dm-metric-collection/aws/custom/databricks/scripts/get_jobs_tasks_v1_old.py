import json
import pandas as pd
from pandas import DataFrame
import numpy as np
import yaml
from datetime import datetime, timedelta
pd.options.mode.chained_assignment = None
from datetime import datetime
from pathlib import Path
from datetime import datetime
import logging
from vault_utility_v2 import vault_credentials
import os
import time

filedate = datetime.now().strftime('%d%m%Y')

logger = logging.getLogger('Collecting AWS DataBricks Metrics')
logger.setLevel(logging.INFO)

# create console handler and set level to debug
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.DEBUG)

# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# add formatter to console_handler
console_handler.setFormatter(formatter)

# add console_handler to logger
logger.addHandler(console_handler)

def load_configuration(lconfig):
    """Read and load data from config.yaml file"""
    cfg = {}
    try:
        with open(lconfig, 'r') as yaml_file:
            cfg = yaml.safe_load(yaml_file)
    except yaml.YAMLError as exc:
        print(exc)
        logger.exception(exc)
    except Exception as e:
        print(e)
        logger.exception(e)
    return cfg

def job_info(input_json, output_csv, task_output_csv, URL, TOKEN):
    params = [TOKEN, URL]
    os.system("sh /data01/appops/dm-metric-collection/aws/custom/databricks/scripts/get_all_job_run_list.sh " + " ".join(params))
    time.sleep(5)

    columns = {'job_id' : [],'job_run_id' : [],'creator_user_name' : [],'life_cycle_state' : [],'result_state' : [],'state_message' : [],'ebs_volume_type' : [],'ebs_volume_count' : [],'ebs_volume_size' : [],'cluster_id' : [],'start_time' : [],'end_time' : [],'setup_duration': [], 'execution_duration': [],'cleanup_duration' : [], 'run_duration' : []}
    #'driver_node_type_id' : [],'job_clusters_min_workers' : [],'job_clusters_max_workers' : [],

    with open(input_json) as f:
        json_data = json.load(f)
  
    for run in json_data['runs']:

        columns['job_id'].append(run['job_id'])
        columns['job_run_id'].append(run['run_id'])
        columns['creator_user_name'].append(run['creator_user_name'])
        columns['life_cycle_state'].append(run['state']['life_cycle_state'])
        try:
            columns['result_state'].append(run['state']['result_state'])
        except KeyError:
            columns['result_state'].append(None)
        try:
            columns['state_message'].append(run['state']['state_message'])
        except KeyError:
            columns['state_message'].append(None)
        #columns['driver_node_type_id'].append(run['cluster_spec']['new_cluster']['driver_node_type_id'])
        #columns['job_clusters_min_workers'].append(run['cluster_spec']['new_cluster']['autoscale']['min_workers'])
        #columns['job_clusters_max_workers'].append(run['cluster_spec']['new_cluster']['autoscale']['max_workers'])
        columns['ebs_volume_type'].append(run['cluster_spec']['new_cluster']['aws_attributes']['ebs_volume_type'])
        columns['ebs_volume_count'].append(run['cluster_spec']['new_cluster']['aws_attributes']['ebs_volume_count'])
        columns['ebs_volume_size'].append(run['cluster_spec']['new_cluster']['aws_attributes']['ebs_volume_size'])
        try:
            columns['cluster_id'].append(run['cluster_instance']['cluster_id'])
        except KeyError:
            columns['cluster_id' ].append(None)
        columns['start_time'].append(run['start_time'])
        columns['end_time'].append(run['end_time'])
        columns['setup_duration'].append(run['setup_duration'])
        columns['execution_duration'].append(run['execution_duration'])
        try:
            columns['cleanup_duration'].append(run['cleanup_duration'])
        except KeyError:
            columns['cleanup_duration'].append(None)
        try:
            columns['run_duration'].append(run['run_duration'])
        except KeyError:
            columns['run_duration'].append(None)
            
    for i in range(len(columns['start_time'])):
        try:
            columns['start_time'][i] = columns['start_time'][i]/1000
            columns['start_time'][i] = datetime.fromtimestamp(columns['start_time'][i]).strftime('%Y-%m-%d %H:%M:%S')
            columns['start_time'][i] = datetime.strptime(columns['start_time'][i], "%Y-%m-%d %H:%M:%S")
        except:
            pass


    for i in range(len(columns['end_time'])):
        if columns['end_time'][i] != 0:
            try:
                columns['end_time'][i] = columns['end_time'][i]/1000
                columns['end_time'][i] = datetime.fromtimestamp(columns['end_time'][i]).strftime('%Y-%m-%d %H:%M:%S')
                columns['end_time'][i] = datetime.strptime(columns['end_time'][i], "%Y-%m-%d %H:%M:%S")
            except:
                pass
        else:
            columns['end_time'][i] = None
    
    df = DataFrame(columns)
    
    # current_time = datetime.now()

    # df['job_running_time'] = current_time - df['start_time']
    # df['job_running_time'] = df['job_running_time']/np.timedelta64(1,'m')
    # df['job_running_time'] = round(df['job_running_time'],3)
    
    file_path = Path(output_csv + "\\job_awsdatabricks_metrics_"+ filedate +".csv")
    #file_path = Path(output_csv + "/job_metrics_" + filedate +".csv")

    if file_path.exists():
        df.to_csv(file_path, header = False, mode = 'a',index = False)
    else:
        df.to_csv(file_path, header = True, mode = 'w', index = False)

    task_info(input_json, task_output_csv)

def task_info(input_json, task_output_csv):

    columns = {'job_id' : [],'job_run_id' : [],'task' : [],'task_details' : []}
    with open(input_json) as f:
        json_data = json.load(f)

    for run in json_data['runs']:
        columns['job_id'].append(run['job_id'])
        columns['job_run_id'].append(run['run_id'])
        for i in run['task']:
            columns['task'].append(i)
            if i == 'spark_python_task':
                name = 'python_file: '+run['task'][i]['python_file']
                columns['task_details'].append(name)
            elif i == 'spark_jar_task':
                name = 'main_class_name: '+run['task'][i]['main_class_name']
                columns['task_details'].append(name)
            elif i == 'notebook_task':
                name = 'notebook_path: '+run['task'][i]['notebook_path']
                columns['task_details'].append(name)
    
    df = DataFrame(columns)

    #file_path = Path(task_output_csv + "/task_metrics_" + filedate +".csv")
    file_path = Path(task_output_csv + "\\task_awsdatabricks_metrics_"+ filedate +".csv")

    if file_path.exists():
        df.to_csv(file_path, header = False, mode = 'a',index = False)
    else:
        df.to_csv(file_path, header = True, mode = 'w', index = False)

def execute(**inputs):
#if __name__ == '__main__':
    
    config = load_configuration(inputs.get('CONFIG_PATH'))
    #config = load_configuration('config_local.yaml')
    output_csv = config['JOB_OUTPUT_CSV']
    input_json = config['JOB_INPUT_JSON']
    task_output_csv = config['TASK_OUTPUT_CSV']

    #Creds from Vault
    cred = vault_credentials.get_secret_from_vault(config['vault_path'], config['vault_keys'])
    URL = cred['JOB_URL']
    TOKEN = cred['TOKEN']

    job_info(input_json, output_csv, task_output_csv, URL, TOKEN)
