'''This code will generate a master key to encrypt the (plain-text) symetric password that
is used for encrypting/decrypting yaml configuration file programmetically.
This is a 2-level security used by first using a master key to decrypt the password that is in turn used
for decrypting yaml configuration file.

The code also stores the master key and the encrypted password (required for yaml) as binary text in their respective files.
'''

from cryptography.fernet import Fernet


key = Fernet.generate_key()
#print(key)

cipher_suite = Fernet(key)
ciphered_text = cipher_suite.encrypt(b"Accenture@123")
#print(ciphered_text)


#write encrypted pass to file
with open('/home/aipuser/dm-cw-scripts/dm-glue-collection-master/keys/dm_fc_userguide.bin', 'wb') as file_object:
    file_object.write(ciphered_text)

#test decrypt - it will read the encrypted password and decrypt it to plain text
with open('/home/aipuser/dm-cw-scripts/dm-glue-collection-master/keys/dm_fc_userguide.bin', 'rb') as file_object:
    for line in file_object:
        encryptedpwd = line
uncipher_text = (cipher_suite.decrypt(encryptedpwd))
plain_text_pwd = bytes(uncipher_text).decode("utf-8") #convert to string and pass the key to safe_load(stream, key) in your code
#print(plain_text_pwd)

#store the master key in a file in some safe location in the server not easily tracable. This master key can be accessed from your code by open/read this key.
with open('/home/aipuser/dm-cw-scripts/dm-glue-collection-master/keys/dm_fc_userguide_mk.bin', 'wb') as file_object:
    file_object.write(key)
