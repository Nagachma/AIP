import boto3
import csv
import platform
import time
import os
from datetime import datetime
import xlwt
import sys
import re
import yaml
import EncryptedYAML as enyaml
from cryptography.fernet import Fernet


def getgluelistofjobs(**kwargs):
    """
            paginate through output data until it reach end of data point
        """
    if kwargs.get('NextToken') is None or kwargs.get('NextToken') == '':
        return kwargs.get('glue').list_jobs(MaxResults=100)
    else:
        return kwargs.get('glue').list_jobs(NextToken=kwargs.get("NextToken"), MaxResults=100)

def get_job_details(region, service_name, endpoint_url, aws_access_key_id, aws_secret_access_key):
        # Setup CSV
        pwd = os.path.dirname(os.path.realpath(__file__))
        filename = pwd + 'glue_job_metrics_' + \
               datetime.utcnow().strftime("%m%d%Y") + '.csv'
        if platform.system() == 'Windows':
            filename = pwd + '\\glue_job_metrics_' + \
                   datetime.utcnow().strftime("%m%d%Y%H%M%S") + '.csv'
        else:
            filename = pwd + '/glue_job_metrics_' + \
                   datetime.utcnow().strftime("%m%d%Y%H%M%S") + '.csv'

        if os.path.exists(filename):
            append_write = 'a'
        else:
            append_write = 'w'
        output = open(filename, append_write, newline='')
        csv_writer = csv.writer(output)
        count = 0
        # Writing headers of CSV file
        header = ['MetricDate', 'JobId', 'JobName', 'ExecutionTime', 'JobRunState', 'StartedOn',
                  'LastModifiedOn', 'CompletedOn', 'AllocatedCapacity', 'WorkerType', 'NumberOfWorkers',
                  'GlueVersion', 'ErrorMessage']
        if append_write == 'w' and count == 0:
            csv_writer.writerow(header)
            count += 1

        client = boto3.client(service_name=service_name, region_name=region,
                        endpoint_url=endpoint_url,
                        aws_access_key_id=aws_access_key_id,
                        aws_secret_access_key=aws_secret_access_key, verify=False)
        next_token = ''
        while next_token is not None:
            jobs_list = getgluelistofjobs(glue=client, NextToken=next_token)
            if jobs_list:
                #list_of_glue_jobs = listoutput['JobNames']
                for JobName in jobs_list['JobNames']:
                    response = client.get_job_runs(JobName=JobName)
                    # Parse response into csv
                    for JobRun in response["JobRuns"]:
                        try:
                            row = [datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S'), JobRun["Id"]]
                            for i in header[2:]:
                                if i in ['StartedOn', 'LastModifiedOn', 'CompletedOn']:
                                    row.append(
                                        datetime.strptime(JobRun[i].strftime("%Y-%m-%d %X"), '%Y-%m-%d %H:%M:%S'))
                                elif i in JobRun.keys():
                                    row.append(JobRun[i])
                                else:
                                    row.append("")
                        except KeyError as ex:
                            print(ex)
                        # Writing data of CSV file
                        finally:
                            csv_writer.writerow(row)
                # print(list_of_glue_jobs)
                if 'NextToken' in jobs_list:
                    next_token = jobs_list['NextToken']
                else:
                    next_token = None



def initialize():
    """
    Open config file using master key file
    """
    try:
		#First load/get the master-key; modify the path as per your key location
        with open(os.environ['MASTER_KEY'], 'r') as file_object:
            for line in file_object:
                str_mk = line
        c_suite = Fernet(str_mk)
		#Next, get the encrypted password that was used to encrypt YAML file; modify the path as per your key location
        with open(os.environ['ENCRYPTED_KEY'], 'rb') as file_object:
            for line in file_object:
                userguide = line
        byte_str = (c_suite.decrypt(userguide))   #This is where the master-key is used to decrypt your encrypted password
        plain_text = bytes(byte_str).decode("utf-8")   ## <--This is your decrypted plain-text password that will be used to decrypt YAML file
        return plain_text
    except Exception as e:
        print("Error in initialize() function: ",e)



def load_configuration(lconfig):
    """
    Read and load data from config.yaml file
    """
    cfg = {}
    try:
        if "encrypted" not in lconfig: 
            with open(lconfig, 'r') as yamlfile:
               cfg = yaml.load(yamlfile, Loader=yaml.FullLoader)
        else:
            with open(lconfig, 'rb') as stream:  #This hardcoded path needs to be replaced with relative path
               cfg = enyaml.safe_load(stream, initialize())        #Note here that safe_load function takes 2 params; the second being the key to open/decrypt YAMl file           
    except yaml.YAMLError as exc:
        print("YAMLError: cfg loading error: ",exc)
    except Exception as e:
        #log traceback for detailed error info
        print("YAML cfg loading error: ",e)
    return cfg


def execute(**inputs):
    print('fInputs'+inputs)
    starttime = datetime.now()
    os.environ['MASTER_KEY']='keys/dm_fc_userguide_mk.bin'
    os.environ['ENCRYPTED_KEY']='keys/dm_fc_userguide.bin'
    pwd = os.path.dirname(os.path.realpath(__file__))
    if platform.system() == 'Windows':
        config_wd = pwd + '\\config'
    else:
        config_wd = pwd + '/config'
    config_list = []
    for file in os.listdir(config_wd):
        if file.endswith(".yml"):
            if platform.system() == 'Windows':
                config_list.append(config_wd + '\\' + file)
            else:
                config_list.append(config_wd + '/' + file)

    for cfg in config_list:
        if "encrypted" not in cfg:   
            config = load_configuration(cfg)
            region = config['AWS']['region']
            service_name = config['AWS']['service_name']
            endpoint_url = config['AWS']['endpoint_url']
        else:
            config = load_configuration(cfg)
            aws_access_key_id = config['AWS']['aws_access_key_id']
            aws_secret_access_key = config['AWS']['aws_secret_access_key']
    get_job_details(region, service_name, endpoint_url, aws_access_key_id, aws_secret_access_key )



