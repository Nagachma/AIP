import boto3
import os
import csv
import re
import yaml
from datetime import datetime, timedelta
import arrow
import argparse
import hashlib
import platform


def load_configuration(cwdPath):
    """Read and load data from config.yaml file"""
    cfg = {}
    try:
        with open(cwdPath, 'r') as yamlfile:
            cfg = yaml.load(yamlfile, Loader=yaml.FullLoader)
    except yaml.YAMLError as exc:
        pass
    except Exception as e:
        pass
    return cfg


def save_csv(result, csvname):
    header = True
    try:
        with open(csvname, 'a', newline='') as f:
            writer = csv.writer(f)
            if header and os.stat(csvname).st_size == 0:
                writer.writerow(
                    ["Interval", "Start Time", "End Time", "Billed Duration (ms)",
                     "Memory Size (MB)", "Max Memory Used (MB)", "Function Name", "Unique ID"])
                header = False
            writer.writerows(result)
    except Exception as e:
        pass


def parse_log_event(log_event):
    """If the event type is START, records timestamp. If event type is REPORT, records metrics. Else returns none."""
    timestamp = log_event['timestamp'] / 1000  # convert to seconds
    date_time = arrow.get(timestamp).format('YYYY-MM-DD HH:mm:ss.SSSSSSZZ')

    message = log_event['message']
    if 'START' in message:
        return arrow.get(date_time)

    if 'REPORT' in message:
        metrics = message
#       duration_pattern = re.compile(r'[^Billed ]Duration: \d+\.\d+ \w+')
        billed_duration_pattern = re.compile(r'Billed Duration: \d+ \w+')
        memory_size_pattern = re.compile(r'Memory Size: \d+ \w+')
        max_memory_used_pattern = re.compile(r'Max Memory Used: \d+ \w+')
        numeric_match = re.compile(r'\d+')
#        duration_numeric_match = re.compile(r'\d+\.\d+')
        patterns = [billed_duration_pattern, memory_size_pattern, max_memory_used_pattern]
        row = []

        for pattern in patterns:
            full_match = pattern.findall(metrics)[0]
            metric = int(numeric_match.findall(full_match)[0])
            row.append(metric)
    else:
        return None

    billed_duration, memory_size, max_memory_used = row

    return [date_time, billed_duration, memory_size, max_memory_used]


def timestamp_intervals(start, end, interval):
    """Gives 5-minute increments from before first start time to after last end time in the form of list."""
#    start = datetime.strptime(start, '%b %d %Y %I:%M%p')
#    end = datetime.strptime(end, '%b %d %Y %I:%M%p')

    first = start - timedelta(minutes=start.minute % interval,
                              seconds=start.second)
#                             microseconds=start.microsecond
    last = end - timedelta(minutes=end.minute % interval,
                           seconds=end.second)
#                          microseconds=end.microsecond)

    first = arrow.get(first)
    last = arrow.get(last)

    intervals = [arrow.get((first + timedelta(hours=interval * i / 60))).format('YYYY-MM-DD HH:mm:ss.SSSSSSZZ')
                 for i in range(int((last - first).total_seconds() / 60.0 / interval) + 1)]

    return intervals  # list of time intervals.


def metrics_into_intervals(shift, intervals, events):
    """Iterates through intervals and checks which start times fit in each interval, inserts the metrics in each
    interval, taking the max of the metrics in each interval in case of multiple events."""
    results = []
    for i in range(len(intervals)):
        row = [intervals[i], None, None, 0, 0, 0, None]  # default value for each metric
        for j in range(len(events)):
            next_interval = arrow.get(intervals[i]).shift(minutes=+int(shift))
            if arrow.get(events[j][0]) >= arrow.get(intervals[i]) and arrow.get(events[j][0]) < next_interval:
                interval = [intervals[i]]
                interval.extend(events[j])
                row = interval
                if row[3:6] != [0, 0, 0]:
                    row_hash = hashlib.sha224(repr(row).encode('utf-8')).hexdigest()
                    row.append(row_hash)
                    results.append(row)
        if row[3:6] == [0, 0, 0]:
            row_hash = hashlib.sha224(repr(row).encode('utf-8')).hexdigest()
            row.append(row_hash)
            results.append(row)

    return results


def execute(**inputs):
    config = load_configuration(inputs.get('CONFIG_PATH'))

    region = config["REGION"]
    log_group_prefix = config["LOG_GROUP_PREFIX"]
    interval = config["INTERVAL"]
    start_date = config["START_DATE"]
    end_date = config["END_DATE"]
    historical = config["HISTORICAL"]
    csv_file_path = config["CSV_FILE_PATH"]


    # access aws
    access_id = os.environ['AWS_ACCESS_KEY_ID']
    secret_key = os.environ['AWS_SECRET_ACCESS_KEY']

    logs = boto3.client('logs', aws_access_key_id=access_id, aws_secret_access_key=secret_key, region_name=region)

    if historical:
        start_timestamp = int(arrow.get(start_date).timestamp()) * 1000
        end_timestamp = int(arrow.get(end_date).timestamp()) * 1000

    else:
        end = arrow.utcnow()
        start = end.shift(minutes=-int(interval))

        # Rounded to even 5 minutes on the clock.
        start = start - timedelta(minutes=start.minute % 5,
                                  seconds=start.second)
#                                  microseconds=start.microsecond)
        end = end - timedelta(minutes=end.minute % 5,
                              seconds=end.second)
#                              microseconds=end.microsecond)

        start_timestamp = int(start.timestamp()) * 1000
        end_timestamp = int(end.timestamp()) * 1000
        intervals = [start]
    log_groups = []
    events = []

    describe_log_groups_paginator = logs.get_paginator('describe_log_groups')

    for page in describe_log_groups_paginator.paginate(logGroupNamePrefix=log_group_prefix):
        log_groups.extend(page['logGroups'])

#    log_groups = [{'logGroupName': '/aws/lambda/thomas-young-hello-world'}]   # uncomment to test with hello-world only

    for log_group in log_groups:
        log_group_name = log_group['logGroupName']
        function_name = log_group_name[12:]  # log group name is function name prepended by 12 characters.
        filter_log_response = logs.filter_log_events(
            logGroupName=log_group_name,
            startTime=start_timestamp,
            endTime=end_timestamp,
        )
        log_events = filter_log_response['events']

        for log_event in log_events:
            data = parse_log_event(log_event)
            if data:
                if isinstance(data, arrow.Arrow):
                    start_time = data
                else:
                    metrics = data
                    start_time_formatted = start_time.format('YYYY-MM-DD HH:mm:ss.SSSSSSZZ')
                    metrics.insert(0, start_time_formatted)
                    metrics.append(function_name)
                    events.append(metrics)

    if historical:
        intervals = timestamp_intervals(start_date, end_date, interval)

    results = metrics_into_intervals(interval, intervals, events)

    if historical:
        a = arrow.get(start_date)
    else:
        a = arrow.utcnow()
    month = a.format("MM")
    year = a.format("YYYY")
    day = a.format("DD")
    output_file_name = csv_file_path + month + day + year + ".csv"

    save_csv(results, output_file_name)


if __name__ == "__main__":
    main()


