import os
import sys
from datetime import datetime, timedelta
from pathlib import Path

import boto3
import pandas as pd
import yaml

s3_client = boto3.client('s3')


def load_configuration(config_file_path):
    config = {}
    if config_file_path is None:
        config_file_path = 'sconfig.yaml'
    try:
        with open(config_file_path, 'r') as config_file:
            config = yaml.load(config_file, yaml.FullLoader)
    except yaml.YAMLError as e:
        print(repr(e))

    print(config)
    return config


def pre_setup(config, bucket_to_scan):
    prefix = bucket_to_scan['prefix']
    curr_date = datetime.now()
    prev_date = curr_date - timedelta(days=1, hours=-0)
    query_date = prev_date.strftime("%Y-%m-%d")
    if not config['historical']:
        prefix = bucket_to_scan['prefix'] + '/' + query_date

    list_of_objects = s3_client.list_objects_v2(
        Bucket=bucket_to_scan['bucket_name'],
        Prefix=prefix
    )

    # list of log file to be iterated
    list_of_files = []
    for key in list_of_objects['Contents']:
        # print(key['Key'])
        # print(key['LastModified'])
        list_of_files.append(key['Key'])

    query = config['query']

    metric_date = curr_date.strftime('%Y-%m-%d')
    curr_timestamp = curr_date.strftime('%Y%m%d%H%M%S')
    temp_csv_file = config['temp_csv_file_name'].format(curr_timestamp)

    inputs = {
        'bucket_name': bucket_to_scan['bucket_name'],
        'prefix': prefix,
        'query': query,
        'metric_date': metric_date,
        'query_date': query_date,
        'temp_csv_file': temp_csv_file,
        'list_of_files': list_of_files
    }
    return inputs


def read_data(inputs):
    with open(inputs['temp_csv_file'], 'w') as csv_file:
        # write header to file
        header_line = "bucketowner,bucket_name,requestdatetime,c4,remoteip,requester,requestid,operation,key," \
                      "request_uri," \
                      "httpstatus,errorcode,bytessent,objectsize,totaltime,turnaroundtime,referrer,useragent,versionid," \
                      "hostid,sigv,ciphersuite,authtype,endpoint,tlsversion,c26\n"

        csv_file.write(header_line)
        # loop over log files to get event metrics
        for file in inputs['list_of_files']:
            result = s3_client.select_object_content(
                Bucket=inputs['bucket_name'],
                Key=file,
                ExpressionType='SQL',
                Expression=inputs['query'],
                # InputSerialization={'CSV': {'FileHeaderInfo': 'NONE', 'RecordDelimiter': '\t'}},
                InputSerialization={
                    'CSV': {'FileHeaderInfo': 'NONE', 'RecordDelimiter': '\n', 'FieldDelimiter': ' ',
                            'QuoteCharacter': '"'}},
                OutputSerialization={'CSV': {}})

            payload = result['Payload']

            for event_stream in payload:
                if 'Records' in event_stream and ('Payload' in event_stream['Records']):
                    bytestr = event_stream['Records']['Payload']
                    if bytestr is not None:
                        lines = bytestr.decode('utf8')
                        # print("lines={"+lines+"}")
                        csv_file.write(lines)


def reformat_output_file(config, inputs):
    df = pd.read_csv(inputs['temp_csv_file'])
    # print(list(df.columns))
    df["requestdatetime"] = df['requestdatetime'].astype(str) + ' ' + df["c4"]
    # print(list(df.requestdatetime))
    # Remove column name 'c4' , 'c26'
    df.drop(['c4', 'c26'], axis=1, inplace=True)
    df.insert(0, 'metric_date', inputs['metric_date'])
    df['requestdatetime'] = df['requestdatetime'].apply(lambda x: str(x)[1:-1])

    # csv file path
    csv_file_path = config['csv_path'] + config['csv_file_name'].format(inputs['query_date'])

    # check if file path exists
    if not os.path.exists(config['csv_path']):
        # create directories if it doesn't exist
        os.makedirs(config['csv_path'], exist_ok=True)

    path_to_check = Path(csv_file_path)
    if (not path_to_check.is_file()) or (
            path_to_check.is_file() and os.stat(path_to_check).st_size == 0):
        print('adding header & creating file')
        df.to_csv(csv_file_path, index=False, header=True)
    else:
        print('not adding header and appending to file')
        df.to_csv(csv_file_path, index=False, mode='a', header=False)

    os.remove(inputs['temp_csv_file'])
    print('done')


def execute(**inputs):

    if not inputs.get('CONFIG_PATH'):
        print("Please provide config file path in args")
        sys.exit(1)
    config_dict = load_configuration(inputs.get('CONFIG_PATH'))
    for bucket_to_scan_dict in config_dict['buckets_to_scan']:
        inputs_to_process = pre_setup(config_dict, bucket_to_scan_dict)
        read_data(inputs_to_process)
        reformat_output_file(config_dict, inputs_to_process)

