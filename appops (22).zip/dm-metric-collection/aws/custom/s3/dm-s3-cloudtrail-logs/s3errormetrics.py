import boto3
import os
import csv
import re
import yaml
from datetime import datetime, timedelta
import arrow
import argparse
import hashlib
import platform
import json


def load_configuration(cwdPath):
    """Read and load data from config.yaml file"""
    cfg = {}
    try:
        with open(cwdPath, 'r') as yamlfile:
            cfg = yaml.load(yamlfile, Loader=yaml.FullLoader)
    except yaml.YAMLError as exc:
        print(exc)
    except Exception as e:
        print(e)
    return cfg


def save_csv(result,csvname):
    header = True
    try:
        with open(csvname, 'a', newline='') as f:
            writer = csv.writer(f)
            if header and os.stat(csvname).st_size == 0:
                writer.writerow(
                    ['metric_date', "eventTime", "eventSource", "eventName", "eventID" , "eventType" ,"awsRegion",
                     "sourceIPAddress", "errorCode", "errorMessage", "bucketName","key", "requestID"])
                header = False
            writer.writerows(result)
    except Exception as e:
        print(e)


def parse_log_event(log_event):
    """If the event type is START, records timestamp. If event type is REPORT, records metrics. Else returns none."""
    timestamp = log_event['timestamp'] / 1000  # convert to seconds
    date_time = arrow.get(timestamp).format('YYYY-MM-DD HH:mm:ss.SSSSSSZZ')

    message = log_event['message']

    if error_flag and 'errorCode' not in message:
        return None

    if 'eventTime' in message:

        data = json.loads(message)
        #print(data)
        event_time = data['eventTime']
        event_name = data['eventName']
        event_source = data['eventSource']
        eventID = data['eventID']
        eventType = data['eventType']
        awsRegion = data['awsRegion']
        sourceIPAddress = data['sourceIPAddress']
        if 'errorCode' in data:
            errorCode = data['errorCode']
        else:
            errorCode = ""
        if 'errorMessage' in data:
            errorMessage = data['errorMessage']
        else:
            errorMessage = ""
        requestParameters_bucketName = data['requestParameters']['bucketName']
        if 'key' in data['requestParameters']:
            requestParameters_Key = data['requestParameters']['key']
        else:
            requestParameters_Key = ""
        requestID = data['requestID']

        # print(event_name)
        # print(event_time)
        # print(requestParameters_bucketName)

    else:
        return None

    return [event_time, event_name, event_source, eventID, eventType, awsRegion, sourceIPAddress, errorCode, errorMessage, requestParameters_bucketName, requestParameters_Key, requestID ]


def timestamp_intervals(start, end, interval):
    """Gives 5-minute increments from before first start time to after last end time in the form of list."""
#    start = datetime.strptime(start, '%b %d %Y %I:%M%p')
#    end = datetime.strptime(end, '%b %d %Y %I:%M%p')

    first = start - timedelta(minutes=start.minute % interval,
                              seconds=start.second)
#                             microseconds=start.microsecond
    last = end - timedelta(minutes=end.minute % interval,
                           seconds=end.second)
#                          microseconds=end.microsecond)

    first = arrow.get(first)
    last = arrow.get(last)

    intervals = [arrow.get((first + timedelta(hours=interval * i / 60))).format('YYYY-MM-DD HH:mm:ss.SSSSSSZZ')
                 for i in range(int((last - first).total_seconds() / 60.0 / interval) + 1)]

    return intervals  # list of time intervals.


def metrics_into_intervals(shift, intervals, events):
    """Iterates through intervals and checks which start times fit in each interval, inserts the metrics in each
    interval, taking the max of the metrics in each interval in case of multiple events."""
    results = []
    for i in range(len(intervals)):
        row = [intervals[i], None, None, 0, 0, 0, None]  # default value for each metric
        for j in range(len(events)):
            next_interval = arrow.get(intervals[i]).shift(minutes=+int(shift))
            if arrow.get(events[j][0]) >= arrow.get(intervals[i]) and arrow.get(events[j][0]) < next_interval:
                interval = [intervals[i]]
                interval.extend(events[j])
                row = interval
                if row[3:6] != [0, 0, 0]:
                    row_hash = hashlib.sha224(repr(row).encode('utf-8')).hexdigest()
                    row.append(row_hash)
                    results.append(row)
        if row[3:6] == [0, 0, 0]:
            row_hash = hashlib.sha224(repr(row).encode('utf-8')).hexdigest()
            row.append(row_hash)
            results.append(row)

    return results


def execute(**inputs):
    config = load_configuration(inputs.get('CONFIG_PATH'))

    region = config["REGION"]
    log_group_prefix = config["LOG_GROUP_PREFIX"]
    interval = config["INTERVAL"]
    start_date = config["START_DATE"]
    end_date = config["END_DATE"]
    historical = config["HISTORICAL"]
    csv_file_path = config["CSV_FILE_PATH"]
    csv_file_name = config["CSV_FILE_NAME"] # "logs_s3_metrics_"
    global error_flag
    error_flag = config["ERROR_FLAG"]


    # access aws
    access_id = os.environ['AWS_ACCESS_KEY_ID']
    secret_key = os.environ['AWS_SECRET_ACCESS_KEY']

    logs = boto3.client('logs', aws_access_key_id=access_id, aws_secret_access_key=secret_key, region_name=region)

    if historical:
        start_timestamp = int(arrow.get(start_date).timestamp()) * 1000
        end_timestamp = int(arrow.get(end_date).timestamp()) * 1000

    else:
        end = arrow.utcnow()
        start = end.shift(minutes=-int(interval))

        # Rounded to even 5 minutes on the clock.
        start = start - timedelta(minutes=start.minute % 5,
                                  seconds=start.second)
#                                  microseconds=start.microsecond)
        end = end - timedelta(minutes=end.minute % 5,
                              seconds=end.second)
#                              microseconds=end.microsecond)

        start_timestamp = int(start.timestamp()) * 1000
        end_timestamp = int(end.timestamp()) * 1000
        intervals = [start]
    log_groups = []
    events = []

    print(log_group_prefix)

    log_groups = [{'logGroupName': log_group_prefix}]   # uncomment to test with hello-world only
    print(log_groups)
    for log_group in log_groups:
        log_group_name = log_group['logGroupName']

        filter_log_response = logs.filter_log_events(
            logGroupName=log_group_name,
            startTime=start_timestamp,
            endTime=end_timestamp,
        )
        log_events = filter_log_response['events']

        for log_event in log_events:
            data = parse_log_event(log_event)
            print(data)
            if data:
                metrics = data
                start_time_formatted = datetime.fromtimestamp(start_timestamp/1000.0).strftime("%Y-%m-%d %H:%M:%S%z")
                metrics.insert(0, start_time_formatted)
                events.append(metrics)
        print(events)

    # if historical:
    #     intervals = timestamp_intervals(start_date, end_date, interval)
    
    #results = metrics_into_intervals(interval, intervals, events)
    
    if historical:
        a = arrow.get(start_date)
    else:
        a = arrow.utcnow()
    month = a.format("MM")
    year = a.format("YYYY")
    day = a.format("DD")
    output_file_name = os.path.join(csv_file_path, csv_file_name) + month + day + year + ".csv"

    save_csv(events,output_file_name)



