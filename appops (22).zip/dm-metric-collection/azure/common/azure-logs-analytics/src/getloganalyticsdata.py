import logging
import os
from datetime import datetime, timedelta
from pathlib import Path

import arrow
import pandas as pd
import yaml
from azure.core.exceptions import ResourceExistsError
from azure.identity import ClientSecretCredential
from azure.monitor.query import LogsBatchQuery, LogsQueryClient, LogsQueryStatus
from azure.profiles import KnownProfiles
from azure.storage.blob import BlobServiceClient
from vault_utility_v2 import vault_credentials
from mysql_utility.config_parameters import ConfigParameters

# Logger configuration
logger = logging.getLogger(os.path.basename(__file__))
logger.setLevel(logging.INFO)
# create console handler and set level to debug
consoleHandler = logging.StreamHandler()
consoleHandler.setLevel(logging.DEBUG)
# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
# add formatter to ch
consoleHandler.setFormatter(formatter)
# add ch to logger
logger.addHandler(consoleHandler)

# By Default, use AzureStack supported profile
KnownProfiles.default.use(KnownProfiles.v2019_03_01_hybrid)


def load_configuration(lconfig):
    """
    Read and load data from config.yaml file
    """
    cfg = {}  # Check if this is a dict
    try:
        with open(lconfig, 'r') as config_file:
            cfg = yaml.load(config_file, Loader=yaml.FullLoader)
    except yaml.YAMLError as exc:
        logger.exception(exc)
    except Exception as e:
        logger.exception(e)
    return cfg


def set_credentials(azure_env_creds):
    secret_keys={}
    if azure_env_creds.get('client_id'):
        secret_keys['client_id'] = azure_env_creds.get('client_id')
    elif os.environ.get('AZURE_client_id'):
        logger.warning("client_id not found in config, fetching it from environment variable")
        secret_keys['client_id'] = os.environ['AZURE_client_id']
    else:
        logger.error("client_id not found in neither os env variable nor config.")
        raise
    if azure_env_creds.get('tenant_id'):
        secret_keys['tenant_id'] = azure_env_creds.get('tenant_id')
    elif os.environ.get('AZURE_TENANT_ID'):
        logger.warning("tenant_id not found in config, fetching it from environment variable")
        secret_keys['tenant_id'] = os.environ['AZURE_TENANT_ID']
    else:
        logger.error("tenant_id not found in neither os env variable nor config.")
        raise
    if azure_env_creds.get('client_secret'):
        secret_keys['client_secret'] = azure_env_creds.get('client_secret')
    elif os.environ.get('AZURE_CLIENT_SECRET'):
        logger.warning("client_secret not found in config, fetching it from environment variable")
        secret_keys['client_secret'] = os.environ['AZURE_CLIENT_SECRET']
    else:
        logger.error("client_id not found in neither os env variable nor config.")
        raise
    client_credentials = ClientSecretCredential(
        client_id=secret_keys['client_id'],
        tenant_id=secret_keys['tenant_id'],
        client_secret=secret_keys['client_secret']
     )
    return client_credentials


def call_batch_queries(query_requests, logs_query_client, logs_query_config, service_name, service_queries):
    """
    Execute log queries in batch requests for each service. Then save to csv files per query. Using UTC times only.
    LOGS_WORKSPACE_ID is required.
    """
    results = logs_query_client.query_batch(query_requests)
    count = 0
    for res in results:
        if res.status == LogsQueryStatus.FAILURE:
            # this will be a LogsQueryError
            logger.error("Log query status: Failure:{}".format(res.message))
        elif res.status == LogsQueryStatus.PARTIAL:
            # this will be a LogsQueryPartialResult
            logger.error("Log query status: Partial Result:{}".format(res.partial_error.message))
            for table in res.partial_data:
                df = pd.DataFrame(table.rows, columns=table.columns)
        elif res.status == LogsQueryStatus.SUCCESS:
            # this will be a LogsQueryResult
            logger.info("Log query status: Success")

            ts = datetime.utcnow().strftime("%m%d%Y")
            # # <query_name>_<service_name_lower>_metrics_<date(YYYYMMDD)>
            query_name = list(service_queries.keys())[count]
            csv_prefix = logs_query_config['SERVICES'][service_name]['CSV_PREFIX']
            output_file_name = "_".join([query_name, service_name.lower(), csv_prefix, ts]) + '.csv'

            # check if metric directory exists
            if not os.path.exists(logs_query_config['SERVICES'][service_name]['CSV_PATH'] + '/' + query_name):
                # if not then create it
                os.makedirs(logs_query_config['SERVICES'][service_name]['CSV_PATH'] + '/' + query_name, exist_ok=True)

            output_file_path = '/'.join(
                [logs_query_config['SERVICES'][service_name]['CSV_PATH'], query_name, output_file_name])

            for table in res.tables:
                df = pd.DataFrame(table.rows, columns=table.columns)
                path_to_check = Path(output_file_path)
                if (not path_to_check.is_file()) or (
                        path_to_check.is_file() and os.stat(output_file_path).st_size == 0):
                    df.to_csv(output_file_path, mode='a',
                              index=False, header=True)
                else:
                    df.to_csv(output_file_path, mode='a',
                              index=False, header=False)
            if logs_query_config['BLOB_UPLOAD']:
                logger.info(f"output file name = {output_file_name}")
                upload_file_to_blob(output_file_name, output_file_path, service_name)
            count = count + 1


def upload_file_to_blob(local_file_name, full_path_to_file, service_name):
    """
     upload csv file into blob storage
    :param local_file_name: only csv file name without path
    :param full_path_to_file: absolute path of csv
    :param service_name: azure managed service name
    :return: None
    """
    try:
        logger.info("calling upload csv file to blob storage")
        logger.debug("blob connection={}".format(os.environ['BLOB_CONNECTION']))
        # Create the BlobServiceClient object which will be used to create a container client
        blob_service_client = BlobServiceClient.from_connection_string(str(os.environ['BLOB_CONNECTION']))
        # blob_service_client = BlobServiceClient.from_connection_string(BLOB_CONNECTION)
        # Create a unique name for the container
        container_name = 'azure' + service_name.lower()
        # Create the container
        try:
            blob_service_client.create_container(container_name)
        # Catch exception and ignore it completely if already exist
        except ResourceExistsError:
            pass
        # Create a blob client using the local file name as the name for the blob
        blob_client = blob_service_client.get_blob_client(container=container_name, blob=local_file_name)

        logger.info("\nUploading to Azure Storage as blob:\n\t" + local_file_name)

        # Upload the created file
        with open(full_path_to_file, "rb") as data:
            blob_client.upload_blob(data, overwrite=True)
    except Exception as e:
        logger.error(str(e))


def execute(**inputs):

    # move validations to the main script
    #
    # check input
    # if not inputs.get('config_path') or inputs.get('config_path') == "":
    #     return "Specify config path."
    # else:
    #     config_path = inputs.get('config_path')


    azure_env_creds={}
    # reading from config file
    config = load_configuration(inputs.get('CONFIG_PATH'))
    azure_creds = vault_credentials.get_secret_from_vault(config['vault_path'], config['vault_keys'])
    xops_creds = vault_credentials.get_secret_from_vault(config['xops_vault_path'], config['xops_vault_keys'])
    # set log level to debug if debugging enabled
    if config.get('DEBUG'):
        logger.setLevel(logging.DEBUG)

    if azure_creds:
        azure_env_creds['client_id'] = azure_creds['clientID']
        azure_env_creds['client_secret'] = azure_creds['clientSecret']


    # Fetch azure account details from mysql db
    env_id = ''
    if azure_creds.get('env_id'):
        env_id = azure_creds.get('env_id')
    elif os.environ.get('AZURE_ENVIRONMENT_ID'):
        env_id = os.environ.get('AZURE_ENVIRONMENT_ID')
    azure_env_creds['env_id']= env_id
    cp = ConfigParameters(mysql_config=xops_creds)
    azure_config = cp.get_environment_parameter(['azure_tenant_id', 'azure_subscription_id'], azure_env_creds['env_id'])
    if azure_config:
        azure_env_creds['tenant_id'] = azure_config['azure_tenant_id']
        azure_env_creds['subscription_id'] = azure_config['azure_subscription_id']

    # create and set credentials
    credentials = set_credentials(azure_env_creds)

    interval_in_min = int(config['INTERVAL'])
    if config['HISTORICAL']:

        if inputs.get('START_DATE') and inputs.get('END_DATE'):
            config['START_DATE'] = inputs.get('START_DATE')
            config['END_DATE'] = inputs.get('END_DATE')

        start_date_from_config = config['START_DATE']
        start_time = datetime.strptime(start_date_from_config, '%Y-%m-%d %H:%M:%S')
        end_date_from_config = config['END_DATE']
        end_time = datetime.strptime(end_date_from_config, '%Y-%m-%d %H:%M:%S')

        start_day = config['START_DATE']
        end_day = config['END_DATE']
        shift_time = "00"
        timezone = config['TIMEZONE'].lower()
        if timezone.upper() == 'EDT':
            shift_time = "-240"
        if timezone.upper() == 'EST':
            shift_time = "-300"
        if timezone.upper() == 'IST':
            shift_time = "-330"
        utc_start_time = arrow.get(start_day).shift(minutes=int(shift_time)).to('utc').datetime
        start_time = arrow.get(start_day).shift(minutes=int(shift_time))
        utc_end_time = arrow.get(end_day).shift(minutes=int(shift_time)).to('utc').datetime
    else:
        utc_end_time = datetime.utcnow()
        logger.debug(f"end_time={utc_end_time}")
        utc_start_time = utc_end_time - timedelta(minutes=interval_in_min)
        logger.debug(f"start_time={utc_start_time}")

    requests = []
    queries = {}
    client = LogsQueryClient(credentials)
    for service in config['SERVICES'].keys():
        if service.startswith('.'):
            logger.info(f"Skipping service '{service[1:]}'")
        else:
            # csv folder base dir
            if inputs.get('BASE_HOME_DIR'):
                config['SERVICES'][service]['CSV_PATH'] = inputs.get('BASE_HOME_DIR') + config['SERVICES'][service]['CSV_PATH']
            service_config = config['SERVICES'][service]
            log_workspace_id = config['LOGS_WORKSPACE_ID']
            if service_config['LOGS_WORKSPACE_ID']:
                # override log workspace id if service specific workspace id given
                log_workspace_id = service_config['LOGS_WORKSPACE_ID']
            queries = service_config.get('QUERIES', {})
            for query in queries.keys():
                log_batch_query = LogsBatchQuery(query=queries[query], timespan=(utc_start_time, utc_end_time),
                                                 workspace_id=log_workspace_id)
                requests.append(log_batch_query)

            call_batch_queries(requests, client, config, service, queries)
