import getloganalyticsdata

if __name__ == '__main__':
    input_dict = {
        'CONFIG_PATH': 'config.yaml',
        'START_DATE': '2022-12-23 00:00:00',
        'END_DATE': '2022-12-23 23:00:00'
    }

    getloganalyticsdata.execute(**input_dict)
