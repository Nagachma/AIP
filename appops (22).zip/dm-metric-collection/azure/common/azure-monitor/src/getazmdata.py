"""Azure monitor metrics"""
# !/usr/bin/python
# pylint:disable=no-self-use,redefined-outer-name,logging-not-lazy,consider-iterating-dictionary,broad-except,too-many-nested-blocks,invalid-name,line-too-long,logging-format-interpolation,too-many-arguments,too-many-locals,no-else-continue,too-many-statements,too-many-branches,undefined-loop-variable,unused-variable,unnecessary-comprehension
import csv
import logging
import os
import platform
import sys
import traceback
from datetime import datetime, timedelta
from multiprocessing import Process

import arrow
import yaml
from azure.common.credentials import ServicePrincipalCredentials
from azure.core.exceptions import ResourceExistsError, HttpResponseError
from azure.identity import ClientSecretCredential
from azure.mgmt.compute import ComputeManagementClient
from azure.mgmt.containerservice import ContainerServiceClient
from azure.mgmt.datafactory import DataFactoryManagementClient
from azure.mgmt.datalake.store import DataLakeStoreAccountManagementClient  # ADLS1
from azure.mgmt.monitor import MonitorManagementClient
from azure.mgmt.sql import SqlManagementClient
from azure.mgmt.storage import StorageManagementClient
from azure.mgmt.synapse import SynapseManagementClient
from azure.profiles import KnownProfiles
from azure.storage.blob import BlobServiceClient
from azure.ai.ml import MLClient
from azure.mgmt.redis import RedisManagementClient
from vault_utility_v2 import vault_credentials
from mysql_utility.config_parameters import ConfigParameters

script_name = os.path.basename(os.path.realpath(__file__))
logger = logging.getLogger(script_name)
logger.setLevel(logging.INFO)

# create console handler and set level to debug
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)

# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# add formatter to ch
ch.setFormatter(formatter)

# add ch to logger
logger.addHandler(ch)

# By Default, use AzureStack supported profile
KnownProfiles.default.use(KnownProfiles.v2019_03_01_hybrid)


def collect_metrics(credentials, azure_env_creds, config, service, starttime, endtime):
    """
    Collect the metrics for any given resource list
    """
    logger.info("Collecting metrics for service '{}' and for start time '{}' to end time '{}'".format(service, starttime, endtime))
    # Get list of all vms in resource group
    subscription_id = azure_env_creds.get('subscription_id')
    resource_group_name = azure_env_creds.get('resource_group_name')
    resource_list = []
    adls2 = False

    if service == 'AZUREML':
        mlclient=MLClient(credentials, subscription_id,resource_group_name)
        resource_list=mlclient.workspaces.list()
    elif service == 'GEN1_ADLS':
        adls1_client = DataLakeStoreAccountManagementClient(set_credentials(azure_env_creds,credential_type=2 ), subscription_id)
        resource_list = adls1_client.accounts.list_by_resource_group(resource_group_name)
    elif service == 'GEN2_ADLS':
        adls2 = True
        adls2_client = StorageManagementClient(credentials, subscription_id,api_version='2022-05-01')
        storage_account_list = adls2_client.storage_accounts.list_by_resource_group(resource_group_name)
        adls2_list = []
        premium_list = []
        #       storage_account_names = {}
        for storage_account in storage_account_list:
            storage_account_properties = adls2_client.storage_accounts.get_properties(resource_group_name,
                                                                                      storage_account.name)
            # if storage_account_properties.is_hns_enabled:
                # Add blob_services instead of original storage account
            adls2_list.append(storage_account)
            if storage_account_properties.kind == 'BlockBlobStorage':
                premium_list.append(storage_account)

        #                storage_account_names[storage_account] = storage_account.name
        #                adls2_list.append(adls2_client.blob_services.get_service_properties(resource_group_name,
        #                                                                                    storage_account.name))
        #        storage_account_names[storage

        resource_list = adls2_list
    elif service == 'VM':
        vm_client = ComputeManagementClient(credentials, subscription_id)
        resource_list = vm_client.virtual_machines.list(resource_group_name)
    elif service == 'AKS':
        aks_client = ContainerServiceClient(credentials, subscription_id, api_version="2022-07-01")
        resource_list = aks_client.managed_clusters.list_by_resource_group(resource_group_name)
    elif service == 'DISKS':
        # Get list of all disks in resource group
        disk_client = ComputeManagementClient(credentials, subscription_id)
        resource_list = disk_client.disks.list_by_resource_group(resource_group_name)
    elif service == 'SQL_SERVER':
        # Get list of all sql servers in resource group
        sql_client = SqlManagementClient(credentials, subscription_id)
        resource_list = sql_client.servers.list_by_resource_group(resource_group_name)
    elif service == 'HYPERSCALE_SQL':
        # Get list of all sql servers in resource group
        sql_client = SqlManagementClient(credentials, subscription_id)
        resource_list = sql_client.servers.list_by_resource_group(resource_group_name)
    elif service == 'SQLDATABASES':
        # Get list of all sql servers in resource group
        sql_client = SqlManagementClient(credentials, subscription_id)
        sql_server_resource_list = sql_client.servers.list_by_resource_group(resource_group_name)
        for sql_server in sql_server_resource_list:
            logger.info('Collecting SQL DBs Metrics for ', sql_server.name)
            resource_list.extend(sql_client.databases.list_by_server(resource_group_name, sql_server.name))
    elif service == 'WORKSPACE_SYNAPSE':
        azure_synapse_workspace_client = SynapseManagementClient(credentials, subscription_id)
        resource_list = azure_synapse_workspace_client.workspaces.list_by_resource_group(resource_group_name)
    elif service == 'BIGDATAPOOLS_SYNAPSE':
        azure_synapse_workspace_client = SynapseManagementClient(credentials, subscription_id)
        resource_list12 = azure_synapse_workspace_client.workspaces.list_by_resource_group(resource_group_name)
        w_name = []
        resource_list = []
        for resource in resource_list12:
            w_name.append(resource.name)
        for workspace_name in w_name:
            azure_synapse_big_data_pools_client = SynapseManagementClient(credentials, subscription_id)
            resource_list1 = azure_synapse_big_data_pools_client.big_data_pools.list_by_workspace(resource_group_name, workspace_name)
            resource_list.extend(resource_list1)
    elif service == 'SQLPOOL_SYNAPSE':
        azure_synapse_workspace_client = SynapseManagementClient(credentials, subscription_id)
        resource_list12 = azure_synapse_workspace_client.workspaces.list_by_resource_group(resource_group_name)
        w_name = []
        resource_list = []
        for resource in resource_list12:
            w_name.append(resource.name)
        for workspace_name in w_name:
            azure_synapse_sql_pool_client = SynapseManagementClient(credentials, subscription_id)
            resource_list1 = azure_synapse_sql_pool_client.sql_pools.list_by_workspace(resource_group_name, workspace_name)
            resource_list.extend(resource_list1)
    elif service == 'DATAFACTORY':
        adf_client = DataFactoryManagementClient(credentials, subscription_id)
        resource_list = adf_client.factories.list_by_resource_group(resource_group_name)
    elif service == 'AZURECACHEREDIS':
        azureredis_client = RedisManagementClient(credentials, subscription_id)
        resource_list_temp = azureredis_client.redis.list_by_resource_group(resource_group_name)
        att_dict = {}
        cache_attributes_list = []
        for resource in resource_list_temp:
            att_dict["cache_name"]= resource.name
            att_dict['location']= resource.location
            att_dict['host_name']=resource.host_name
            att_dict['port']=resource.port
            att_dict['public_network_access']=resource.public_network_access
            att_dict['aof_backup_enabled']=resource.redis_configuration.aof_backup_enabled
            att_dict['maxclients']=resource.redis_configuration.maxclients
            att_dict['maxfragmentationmemory_reserved']=resource.redis_configuration.maxfragmentationmemory_reserved
            att_dict['maxmemory_delta']=resource.redis_configuration.maxmemory_delta
            att_dict['maxmemory_policy']=resource.redis_configuration.maxmemory_policy
            att_dict['maxmemory_reserved']=resource.redis_configuration.maxmemory_reserved
            att_dict['rdb_backup_enabled']=resource.redis_configuration.rdb_backup_enabled
            att_dict['rdb_backup_frequency']=resource.redis_configuration.rdb_backup_frequency
            # att_dict['rdb_backup_max_snapshot_count']=resource.redis_configuration.rdb_backup_max_snapshot_count
            att_dict['redis_version']=resource.redis_version
            att_dict['replicas_per_master']=resource.replicas_per_master
            att_dict['replicas_per_primary']=resource.replicas_per_primary
            att_dict['shard_count']=resource.shard_count
            att_dict['skuname']=resource.sku.name + "_" + resource.sku.family + str(resource.sku.capacity)
            att_dict['ssl_port']=resource.ssl_port
            cache_attributes_list.append(att_dict)
        resource_list = azureredis_client.redis.list_by_resource_group(resource_group_name)
    else:
        logger.warning(f"No service client configured for {service}")
        sys.exit(2)


    # Create monitoring client
    client = MonitorManagementClient(credentials, subscription_id)
    # for resource in resource_list:
    #     # You can get the available metrics of this specific resource
    #     for metric in client.metric_definitions.list(resource.id):
    #         # azure.monitor.models.MetricDefinition

    # Go through config and begin collecting metrics
    output = []
    list_of_metric = [elem for elem in config[service]['METRIC_LIST']]
    starttime = starttime.replace(tzinfo=None)
    endtime = endtime.replace(tzinfo=None)
    # Collect metrics according to resource ID
    logger.info(f'No of metrics = {len(list_of_metric)}')
    for resource in resource_list:
        metric_def_list = client.metric_definitions.list(resource_uri=resource.id)
        supported_metrics_list = []
        for item in metric_def_list:
            if logger.isEnabledFor(logging.DEBUG):
                logger.debug(str(item.name.localized_value))
                logger.debug(str(item.name.value))
            supported_metrics_list.append(str(item.name.value).casefold())

        # ***** ADLS Specific logic --- STARTS
        if adls2:
            adls2_name = resource.name
            if resource not in premium_list:
                if "BlobProvisionedSize" in list_of_metric:
                    list_of_metric.remove("BlobProvisionedSize")
            # else:
            #     if "BlobProvisionedSize" not in list_of_metric:
            #         list_of_metric.append("BlobProvisionedSize")

            resource = adls2_client.blob_services.get_service_properties(resource_group_name,
                                                                         adls2_name)
        # ****** ADLS Specific logic --- ENDS

        for metric in list_of_metric:
            if metric.casefold() not in supported_metrics_list:
                if logger.isEnabledFor(logging.DEBUG):
                    logger.debug(f"Metric {metric} not supported for resource {resource.name}")
                continue

            if 'statistical_aggregation' in config[service]['METRIC_LIST'][metric]:
                agg = config[service]['METRIC_LIST'][metric]['statistical_aggregation']
            else:
                agg = config[service]['aggregation']
            metric_namespace = config[service]['METRIC_LIST'][metric].get('namespace')
            per_metric_interval = config[service]['METRIC_LIST'][metric].get('interval')
            if not per_metric_interval:
                per_metric_interval = config.get('INTERVAL')
            delta = (endtime - starttime)
            interval_min = delta.total_seconds() / 60
            interval_count = interval_min / per_metric_interval
            if config.get('INTERVAL') < per_metric_interval:
                interval_count = 1
            # i= 1
            starttime1 = starttime
            # if adls2 and per_metric_interval!=60 and starttime1.minute=='00':
            for i in range(int(interval_count)):
                if adls2 and per_metric_interval % 60 == 0 and starttime1.strftime("%M") != '00':
                    continue
                else:
                    if per_metric_interval % 60 == 0 and starttime1.strftime("%M") == '00':
                        endtime1 = arrow.get(starttime1).shift(minutes=+int(config.get('INTERVAL'))).datetime.strftime(
                            "%Y-%m-%d %H:%M:%S")
                    else:
                        endtime1 = arrow.get(starttime1).shift(minutes=+int(per_metric_interval)).datetime.strftime(
                            "%Y-%m-%d %H:%M:%S")
                    endtime1 = datetime.strptime(endtime1, "%Y-%m-%d %H:%M:%S")
                    try:
                        if metric_namespace is not None:
                            metrics_data = client.metrics.list(
                                resource.id,
                                timespan="{}/{}".format(starttime1, endtime1),
                                interval='PT' + str(per_metric_interval) + 'M',
                                metricnames=metric,
                                aggregation=agg,
                                metricnamespace=metric_namespace
                            )
                        else:
                            metrics_data = client.metrics.list(
                                resource.id,
                                timespan="{}/{}".format(starttime1, endtime1),
                                interval='PT' + str(per_metric_interval) + 'M',
                                metricnames=metric,
                                aggregation=agg
                            )
                    except HttpResponseError as hre:
                        logger.warning(f"Error from AZ monitor Metrics API: {resource.id} :: {metric} : {repr(hre)}")
                        continue
                    datapoint = {}
                    for item in metrics_data.value:

                        for series in item.timeseries:
                            for data in series.data:
                                metrics = {
                                    'Average': data.average,
                                    'Minimum': data.minimum,
                                    'Maximum': data.maximum,
                                    'Total': data.total,
                                    'Count': data.count
                                }
                                # get resource_list from config file
                                input_list = config[service]['resource_list'].values()
                                # convert list of list to list
                                flat_list = [item for sublist in input_list for item in sublist]
                                # if resource_list is empty then collect for all
                                if not flat_list:
                                    start_time = data.time_stamp
                                    end_time = (data.time_stamp + timedelta(minutes=per_metric_interval))
                                    datapoint['start_time'] = start_time
                                    datapoint['end_time'] = end_time
                                    resource_header = service.lower() + 'name'
                                    if adls2:
                                        datapoint[resource_header] = adls2_name
                                    else:
                                        datapoint[resource_header] = resource.name
                                    if service == 'BIGDATAPOOLS_SYNAPSE' or service == 'SQLPOOL_SYNAPSE':
                                        ls = resource.id.split("/")
                                        datapoint['workspace_name'] = ls[len(ls) - 3]
                                        ls = []
                                    elif service == 'SQLDATABASES':
                                        ls = resource.id.split("/")
                                        datapoint['server_name'] = ls[len(ls) - 3]
                                    datapoint['metric_name'] = item.name.value
                                    datapoint['metric_value'] = metrics[agg]
                                    datapoint['statistic'] = agg
                                    datapoint['frequency'] = int(per_metric_interval)
                                    output.append(datapoint)
                                    datapoint = {}
                                else:
                                    # if resource_list have list item then check item is present in resource_list & capture
                                    # details
                                    if resource.name in flat_list:
                                        # start_time = (data.time_stamp - timedelta(minutes=per_metric_interval)).replace(
                                        #    tzinfo=None)
                                        # end_time = data.time_stamp.replace(tzinfo=None)
                                        end_time = (data.time_stamp + timedelta(
                                            minutes=per_metric_interval))  # .replace(
                                        #    tzinfo=None)
                                        start_time = data.time_stamp  # .replace(tzinfo=None)
                                        datapoint['start_time'] = start_time
                                        datapoint['end_time'] = end_time
                                        resource_header = service.lower() + 'name'
                                        if adls2:
                                            datapoint[resource_header] = adls2_name
                                        else:
                                            datapoint[resource_header] = resource.name
                                        if service == 'BIGDATAPOOLS_SYNAPSE' or service == 'SQLPOOL_SYNAPSE':
                                            ls = resource.id.split("/")
                                            datapoint['workspace_name'] = ls[len(ls) - 3]
                                            ls = []
                                        elif service == 'SQLDATABASES':
                                            ls = resource.id.split("/")
                                            datapoint['server_name'] = ls[len(ls) - 3]
                                        datapoint['metric_name'] = item.name.value
                                        datapoint['metric_value'] = metrics[agg]
                                        datapoint['statistic'] = agg
                                        datapoint['frequency'] = int(per_metric_interval)
                                        output.append(datapoint)
                                        datapoint = {}
                                    else:
                                        continue

                    starttime1 = endtime1
        #   AZURECACHEREDIS Specific logic --- STARTS
        if service == "AZURECACHEREDIS":
            att_datapoint = {}
            azurerediscache_name = resource.name
            for azureredis_dict in cache_attributes_list:
                if azureredis_dict['cache_name'] == azurerediscache_name:
                    for key,value in azureredis_dict.items():
                        att_datapoint['start_time'] = start_time
                        att_datapoint['end_time'] = end_time
                        att_datapoint[resource_header] = azurerediscache_name
                        att_datapoint['metric_name'] = key
                        att_datapoint['metric_value'] = value
                        att_datapoint['statistic'] = "attribute_metric"
                        att_datapoint['frequency'] = int(per_metric_interval)
                        output.append(att_datapoint)
                        att_datapoint = {}
        #   AZURECACHEREDIS Specific logic --- ENDS
    # Return finished metrics list
    return output


def azure_metric(service, config, azure_env_creds):
    """
        Collect service specified metrics
    """
    credentials = set_credentials(azure_env_creds)

    timezone = config['TIMEZONE'].lower()
    utc_start_time = ''
    utc_end_time = ''
    utc_five_min_interval = ''
    utc_five_min_interval_backup = ''
    interval_time_in_min = ''
    # get metric list from config file
    # metric_list = config[service]['METRIC_LIST']
    if not config['HISTORICAL']:
        # get frequency from config file
        interval_time_in_min = config['INTERVAL']
        # start time should be previous 5 min
        # start_time = datetime.now() - timedelta(minutes=(interval_time_in_min))
        start_time = arrow.utcnow().shift(minutes=-int(interval_time_in_min))
        end_time = arrow.utcnow()
        # replacing sec with 00 to make simple
        start_time = start_time.replace(year=start_time.year, month=start_time.month, day=start_time.day,
                                        hour=start_time.hour, minute=start_time.minute, second=00)
        start_time = start_time.strftime('%Y-%m-%d %H:%M:%S')

        end_time = end_time.replace(year=end_time.year, month=end_time.month, day=end_time.day, hour=end_time.hour,
                                    minute=end_time.minute, second=00)
        end_time = end_time.strftime('%Y-%m-%d %H:%M:%S')
        config['START_DATE'] = start_time
        config['END_DATE'] = end_time
        # utc_start_time = start_time
        # utc_end_time = end_time
    if config['START_DATE'] and config['END_DATE']:
        startday = config['START_DATE']
        endday = config['END_DATE']
        shift_time = "00"
        if timezone.upper() == 'EDT':
            shift_time = "-240"
        if timezone.upper() == 'EST':
            shift_time = "-300"
        if timezone.upper() == 'IST':
            shift_time = "-330"
        utc_start_time = arrow.get(startday).shift(minutes=int(shift_time)).to('utc').datetime
        start_time = arrow.get(startday).shift(minutes=int(shift_time))
        # endday = '2020-07-30 16:00:00'
        utc_end_time = arrow.get(endday).shift(minutes=int(shift_time)).to('utc').datetime
        end_time = arrow.get(endday).shift(minutes=int(shift_time))
        interval_time_in_min = config['INTERVAL']
        utc_five_min_interval_backup = start_time.shift(minutes=+int(interval_time_in_min))
        utc_five_min_interval = utc_five_min_interval_backup.to('utc').datetime
    output_file_name = ""
    output_file_path = ""
    while utc_start_time < utc_end_time:
        if utc_start_time.day != utc_end_time.day:
            utc_last_five_min_interval = utc_five_min_interval
            utc_last_five_min_interval = utc_last_five_min_interval.replace(year=utc_start_time.year,
                                                                            month=utc_start_time.month,
                                                                            day=utc_start_time.day,
                                                                            hour=utc_start_time.hour, minute=59,
                                                                            second=59)
            # Create output with VM list
            output = collect_metrics(credentials, azure_env_creds, config, service, utc_start_time, utc_last_five_min_interval)
        else:
            # Create output with VM list
            output = collect_metrics(credentials, azure_env_creds, config, service, utc_start_time, utc_five_min_interval)

        logger.info("Metrics collected for service '{}'".format(service))
        month = ''
        day = ''
        if len(str(utc_start_time.month)) == 1:
            month = '0' + str(utc_start_time.month)
        else:
            month = str(utc_start_time.month)
        if len(str(utc_start_time.day)) == 1:
            day = '0' + str(utc_start_time.day)
        else:
            day = str(utc_start_time.day)
        pwd = os.path.dirname(os.path.realpath(__file__))

        # if config[service]['csvname'] is not None and len(config[service]['csvname']) != 0:
        #     name_prefix = config[service]['csvname']
        # else:
        #     name_prefix = service.lower()

        if config[service]['csvpath'] != '':
            output_file_name = "azm_" + service.lower() + "_metrics_" + str(month) + str(day) + str(
                utc_start_time.year) + ".csv"
            if platform.system() == 'Windows':
                output_file_path = config[service]['csvpath'] + '\\' + output_file_name
            else:
                output_file_path = config[service]['csvpath'] + '/' + output_file_name
        else:
            output_file_name = "azm_" + service.lower() + "_metrics_" + str(month) + str(day) + str(
                utc_start_time.year) + ".csv"
            if platform.system() == 'Windows':
                output_file_path = "{0}{1}{2}".format(pwd, '\\', output_file_name)
            else:
                output_file_path = "{0}{1}{2}".format(pwd, '/', output_file_name)
        # Check output directory exists
        csv_path_from_config = config[service]['csvpath']
        if csv_path_from_config != '' and not os.path.exists(csv_path_from_config):
            logger.info("Creating csv path directory, as directory doesn't exist")
            os.makedirs(csv_path_from_config, exist_ok=True)
        save_csv(output, output_file_path, service)

        utc_start_time = utc_five_min_interval
        new_utc_five_min_interval = utc_five_min_interval_backup.shift(minutes=+int(interval_time_in_min))
        utc_five_min_interval_backup = new_utc_five_min_interval
        utc_five_min_interval = new_utc_five_min_interval.to('utc').datetime
    if config['BLOB_UPLOAD']:
        logger.info("file name ={}".format(output_file_name))
        uploadfiletoblob(output_file_name, output_file_path, service)


def load_configuration(lconfig):
    """
    Read and load data from config.yaml file
    """
    cfg = {}  # Check if this is a dict
    try:
        with open(lconfig, 'r') as yamlfile:
            cfg = yaml.load(yamlfile, Loader=yaml.FullLoader)
    except yaml.YAMLError as exc:
        logger.exception(exc)
    except Exception as e:
        logger.exception(e)
    return cfg


def set_credentials(azure_env_creds, credential_type=1):
    """
    Set credentials and account information
    """
    secret_keys = {}
    if azure_env_creds.get('client_id'):
        secret_keys['client_id'] = azure_env_creds.get('client_id')
    elif os.environ.get('AZURE_client_id'):
        logger.warning("client_id not found in config, fetching it from environment variable")
        secret_keys['client_id'] = os.environ['AZURE_client_id']
    else:
        logger.error("client_id not found in neither os env variable nor config.")
        raise
    if azure_env_creds.get('tenant_id'):
        secret_keys['tenant_id'] = azure_env_creds.get('tenant_id')
    elif os.environ.get('AZURE_TENANT_ID'):
        logger.warning("tenant_id not found in config, fetching it from environment variable")
        secret_keys['tenant_id'] = os.environ['AZURE_TENANT_ID']
    else:
        logger.error("tenant_id not found in neither os env variable nor config.")
        raise
    if azure_env_creds.get('client_secret'):
        secret_keys['client_secret'] = azure_env_creds.get('client_secret')
    elif os.environ.get('AZURE_CLIENT_SECRET'):
        logger.warning("client_secret not found in config, fetching it from environment variable")
        secret_keys['client_secret'] = os.environ['AZURE_CLIENT_SECRET']
    else:
        logger.error("client_id not found in neither os env variable nor config.")
        raise
    credentials = ''
    if credential_type == 1:
        credentials = ClientSecretCredential(
            client_id=secret_keys['client_id'],
            tenant_id=secret_keys['tenant_id'],
            client_secret=secret_keys['client_secret']
        )
    elif credential_type == 2:
        credentials = ServicePrincipalCredentials(
            client_id=secret_keys['client_id'],
            tenant=secret_keys['tenant_id'],
            secret=secret_keys['client_secret']
        )
    return credentials


def save_csv(result, output_filename, service):
    """
    Save a csv based on collected data
    """
    if result is not None:
        header = True
        try:
            with open(output_filename, 'a', newline='') as csvfile:
                writer = csv.writer(csvfile)
                for row in result:
                    if header and os.stat(output_filename).st_size == 0:
                        writer.writerow(row.keys())
                        header = False
                    writer.writerow(row.values())
            logger.info("Saved to csv for service '{}'".format(service))
        except Exception:
            logger.error("Error while saving to csv : {}".format(traceback.format_exc()))


def uploadfiletoblob(local_file_name, full_path_to_file, service):
    """
     upload csv file into blob storage
    :param local_file_name: only csv file name without path
    :param full_path_to_file: absolute path of csv
    :param service: azure managed service name
    :return:
    """
    try:
        logger.info("calling upload csv file to blob storage")
        # logger.info("blob connection={}".format(os.environ['BLOB_CONNECTION']))
        # Create the BlobServiceClient object which will be used to create a container client
        blob_service_client = BlobServiceClient.from_connection_string(str(os.environ['BLOB_CONNECTION']))
        # blob_service_client = BlobServiceClient.from_connection_string(BLOB_CONNECTION)
        # Create a unique name for the container
        container_name = 'azure' + service.lower()
        # Create the container
        try:
            container_client = blob_service_client.create_container(container_name)
        # Catch exception and ignore it completely if already exist
        except ResourceExistsError:
            pass
        # Create a blob client using the local file name as the name for the blob
        blob_client = blob_service_client.get_blob_client(container=container_name, blob=local_file_name)


        # Upload the created file
        with open(full_path_to_file, "rb") as data:
            blob_client.upload_blob(data, overwrite=True)
    except Exception as e:
        logger.info(str(e))


def execute(**inputs):
    # move the validation to the input main script
    # command_line_input = False
    #
    # # Error check input
    #
    # if not inputs.get('config_path') and inputs.get('config_path') == '':
    #     return "Specify config path"
    # else:
    #     pwd = inputs.get('config_path')
    #     command_line_input = True
    #
    # if inputs.get('start_date') is not None:
    #     if inputs.get('end_date') is None:
    #         return "Specify end date"
    # else:
    #     command_line_input = True
    #
    # if inputs.get('end_date') is not None:
    #     if inputs.get('start_date') is None:
    #         return "Specify start date"
    # else:
    #     command_line_input = True
    #
    # if inputs.get('start_date') == "":
    #     return "Specify start date value"
    # else:
    #     command_line_input = True
    # if inputs.get('end_date') == "":
    #     return "Specify end date value"
    # else:
    #     command_line_input = True


    # Establish directory and load config
    service_enable = {}
    starttime = datetime.now()
    logger.info(" --- calling Azure Monitor fetch metric function ---- ")
    azure_env_creds={}
    # reading from config file
    config = load_configuration(inputs.get('CONFIG_PATH'))
    azure_creds = vault_credentials.get_secret_from_vault(config['vault_path'], config['vault_keys'])
    xops_creds = vault_credentials.get_secret_from_vault(config['xops_vault_path'], config['xops_vault_keys'])
    # set log level to debug if debugging enabled
    if config.get('DEBUG'):
        logger.setLevel(logging.DEBUG)

    if azure_creds:
        azure_env_creds['client_id'] = azure_creds['clientID']
        azure_env_creds['client_secret'] = azure_creds['clientSecret']
        # azure_env_creds['resource_group_name'] = azure_creds['resource_group_name']

    # Set start and end dates
    if inputs.get('START_DATE') and inputs.get('END_DATE'):
        config['START_DATE'] = inputs.get('START_DATE')
        config['END_DATE'] = inputs.get('END_DATE')

    # Fetch azure account details from mysql db
    env_id = ''
    if config['vault_path']:
        env_id = str(config['vault_path'].split('/')[1])
    elif os.environ.get('AZURE_ENVIRONMENT_ID'):
        env_id = os.environ.get('AZURE_ENVIRONMENT_ID')
    azure_env_creds['env_id'] = env_id

    connection_str = xops_creds.get('jdbc-url')

    temp_1 = connection_str.split("/")[2:]
    temp_2 = temp_1[0].split(":")
    mysql_cred={
        "host": str(temp_2[0]),
        "port": str(temp_2[1]),
        "database": str(temp_1[1]),
        "user": str(xops_creds.get("username")),
        "password": str(xops_creds.get("password"))

    }

    cp = ConfigParameters(mysql_config=mysql_cred)
    azure_config = cp.get_environment_parameter(['azure_tenant_id', 'azure_subscription_id'], azure_env_creds['env_id'])
    if azure_config:
        azure_env_creds['tenant_id'] = azure_config['azure_tenant_id']
        azure_env_creds['subscription_id'] = azure_config['azure_subscription_id']

    if config['AZURE']['resource_group_name']:
        azure_env_creds['resource_group_name']=config['AZURE']['resource_group_name']
    # create and set credentials
    credentials = set_credentials(azure_env_creds)

    for service_name in config['SERVICES']['LIST']:
        service_found = False
        for service in config.keys():
            if service == '.' + service_name:
                tool_found = True  # service is found in data node though prefixed with (.)
                logger.warning(
                    "WARNING: Node <{}> is marked to exclude from processing [prefixed with dot (.)]. Skipping...".format(
                        service))
            else:
                if service == 'TOOLS':
                    # Skip as TOOLS is being processed in the beginning for iterating on list
                    continue
                elif service == service_name:  # This is to avoid hardcoding of service name in code
                    # csv folder base dir
                    if inputs.get('BASE_HOME_DIR'):
                        config[service]['csvpath'] = inputs.get('BASE_HOME_DIR') + config[service]['csvpath']
                    service_found = True
                    logger.debug('----------------Processing {} from {}----------------'.format(service, config))
                    service_enable[service] = 1

    # procs = []
    # for service in service_enable.keys():
    #     # Setup a list of processes that we want to run
    #     # azure_metric(service, config)
    #     processes = Process(target=azure_metric, args=(service, config))
    #     procs.append(processes)
    #     processes.start()
    #
    # for proc in procs:
    #     proc.join()
    for service in service_enable.keys():
        azure_metric(service, config, azure_env_creds)

    logger.info("---- End of logging ----")
    endtime = datetime.now()
    diff = endtime - starttime
    msg = "Total execution time ={0}".format(divmod(diff.total_seconds(), 60))
    logger.info(msg)
