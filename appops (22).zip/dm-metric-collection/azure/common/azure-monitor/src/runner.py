import getazmdata

if __name__ == '__main__':
    input_dict = {
        'CONFIG_PATH': '../../../../../tools/azure/hyperscale_sql/collection/sources/az-monitor/azconfig.yaml',
        'START_DATE': '2023-03-16 00:00:00',
        'END_DATE': '2022-03-16 23:00:00',
        'CREDENTIAL_FILE': '../../../../credentials.yaml'
    }

    getazmdata.execute(**input_dict)
