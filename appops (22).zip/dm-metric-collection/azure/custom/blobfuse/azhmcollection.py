import json
import datetime
import csv
import pandas as pd
import numpy as np
import glob

curDate = datetime.date.today()
curDate = datetime.date.strftime(curDate, '%m%d%Y')

def execute(**inputs):
    pd.set_option('display.max_rows', None)
    pd.set_option('display.max_columns', None)
    pd.set_option('display.width', None)
    pd.set_option('display.max_colwidth', None)
    file_pattern = 'azure/custom/blobfuse/*.json'
    file_list = glob.glob(file_pattern)
    for file in file_list:
        with open(file, "r") as f:
            data = json.load(f)
    arrData = []
    df = pd.DataFrame(data, columns=['Timestamp', 'CPUUsage', 'MemoryUsage'])
    df1 = pd.DataFrame(data, columns=['Timestamp', 'FileCache']).explode('FileCache')
    df2 = pd.DataFrame(data, columns=['BlobfuseStats']).explode('BlobfuseStats')
    df = pd.json_normalize(json.loads(df.to_json(orient="records")))
    df1 = pd.json_normalize(json.loads(df1.to_json(orient="records")))
    df2 = pd.json_normalize(json.loads(df2.to_json(orient="records")))
    # print(df)
    df['Timestamp'] = pd.to_datetime(df.Timestamp)
    df['Timestamp'] = df['Timestamp'].dt.strftime('%Y-%m-%d %H:%M:00')
    df.dropna(subset=['Timestamp'], inplace=True)
    df1['Timestamp'] = pd.to_datetime(df1.Timestamp)
    df1['Timestamp'] = df1['Timestamp'].dt.strftime('%Y-%m-%d %H:%M:00')
    df1.dropna(subset=['Timestamp'], inplace=True)
    df2['BlobfuseStats.timestamp'] = pd.to_datetime(df2['BlobfuseStats.timestamp'])
    df2['BlobfuseStats.timestamp'] = df2['BlobfuseStats.timestamp'].dt.strftime('%Y-%m-%d %H:%M:00')
    df2.dropna(subset=['BlobfuseStats.timestamp'], inplace=True)

    df = df.reset_index(drop=True)
    df = df.drop_duplicates(subset="Timestamp", keep='first')
    df.to_csv('../common-utility/mongoDB-ingestion/azure/blobfuse/metrics/azhmblobfuse/azhm_blobfuse_metrics_' + str(curDate) + '.csv', index=False)
    df1.to_csv('../common-utility/mongoDB-ingestion/azure/blobfuse/metrics/azhmfilecache/filecache_blobfuse_metrics_' + str(curDate) + '.csv', index=False)
    df2.to_csv('../common-utility/mongoDB-ingestion/azure/blobfuse/metrics/azhmblobfusestats/blobfusestats_blobfuse_metrics_' + str(curDate) + '.csv', index=False)
