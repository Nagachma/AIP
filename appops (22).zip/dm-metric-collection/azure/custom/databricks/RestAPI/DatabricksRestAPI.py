import calendar
import csv
import json
import logging
import os
import platform
import time
import traceback
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pandas as pd
import pandas.io.json
import requests
import yaml
import arrow

from mysql_utility.config_parameters import ConfigParameters
from vault_utility_v2 import vault_credentials

logger = logging.getLogger('get_api_metrics')
logger.setLevel(logging.INFO)
# create console handler and set level to debug
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)

# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# add formatter to ch
ch.setFormatter(formatter)

# add ch to logger
logger.addHandler(ch)


def set_credentials(azure_env_creds):
    secret_keys = {}
    if azure_env_creds.get('client_id'):
        secret_keys['client_id'] = azure_env_creds.get('client_id')
    elif os.environ.get('AZURE_client_id'):
        logger.warning("client_id not found in config, fetching it from environment variable")
        secret_keys['client_id'] = os.environ['AZURE_client_id']
    else:
        logger.error("client_id not found in neither os env variable nor config.")
        raise
    if azure_env_creds.get('tenant_id'):
        secret_keys['tenant_id'] = azure_env_creds.get('tenant_id')
    elif os.environ.get('AZURE_TENANT_ID'):
        logger.warning("tenant_id not found in config, fetching it from environment variable")
        secret_keys['tenant_id'] = os.environ['AZURE_TENANT_ID']
    else:
        logger.error("tenant_id not found in neither os env variable nor config.")
        raise
    if azure_env_creds.get('client_secret'):
        secret_keys['client_secret'] = azure_env_creds.get('client_secret')
    elif os.environ.get('AZURE_CLIENT_SECRET'):
        logger.warning("client_secret not found in config, fetching it from environment variable")
        secret_keys['client_secret'] = os.environ['AZURE_CLIENT_SECRET']
    else:
        logger.error("client_id not found in neither os env variable nor config.")
        raise
    client_credentials = {
        'client_id':secret_keys['client_id'],
        'tenant_id':secret_keys['tenant_id'],
        'client_secret':secret_keys['client_secret']
    }
    return client_credentials

# TODO : to be used when the api pricipal is enabled to access the databricks workspace


def get_token(credentials):
    client_id = credentials['client_id']
    client_secret = credentials['client_secret']
    tenant_id = credentials['tenant_id']
    # DBRKS_BEARER_TOKEN=None
    token_api_request_body = {
        'grant_type': 'client_credentials',
        'resource': '2ff814a6-3304-4ab8-85cb-cd0e6f879c1d',
        'client_id': client_id,
        'client_secret': client_secret
    }
    token_api_request_url = 'https://login.microsoftonline.com/' + tenant_id + '/oauth2/token'
    token_api_request_headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    response = requests.get(token_api_request_url, headers=token_api_request_headers, data=token_api_request_body)
    if response.status_code == 200:
        dbrks_bearer_token = response.json()['access_token']
        return dbrks_bearer_token


def job_runs(url, headers, starttime, endtime):
    results = []
    limit = 25
    offset = 0
    while True:
        response = requests.get(url=url, headers=headers,
                                params={'start_time_from': starttime, 'start_time_to': endtime,
                                        'expand_tasks': 'true', 'limit': limit, 'offset': offset})
        result = json.loads(response.text)
        results.append(result)
        offset = limit
        limit = limit + limit
        if result['has_more'] is False:
            break

    return results


def jobs(url, headers):
    logger.info(" --- calling Databricks Jobs Listing API ---- ")
    results = []
    limit = 25
    offset = 0
    while True:
        response = requests.get(url=url, headers=headers,
                                params={'expand_tasks': 'true', 'limit': limit, 'offset': offset})
        result = json.loads(response.text)
        results.append(result)
        offset = limit
        limit = limit + limit
        if result['has_more'] is False:
            break

    return results


def collect_metrics(api, config, start_time, end_time):
    """
        Collect the metrics for any given resource list
        """
    date_string = '%Y-%m-%d %H:%M:%S'
    date_string2 = '%Y-%m-%d %H:%M:00'
    starttime = calendar.timegm(time.strptime(start_time.strftime(date_string2), date_string))
    endtime = calendar.timegm(time.strptime(end_time.strftime(date_string2), date_string))
    starttime_ms = int(starttime) * 1000
    endtime_ms = int(endtime) * 1000

    logger.info(
        "Collecting metrics for api '{}' and for start time '{}' to end time '{}'".format(api, datetime.fromtimestamp(
            starttime, timezone.utc),
                                                                                          datetime.fromtimestamp(
                                                                                              endtime, timezone.utc)))
    # starttime11 = time.ctime(starttime)
    # endtime11 = time.ctime(endtime)
    data = []
    if api == 'JobRuns':
        runs = []
        version = config[api]['api_version']
        command = config[api]['api_command']
        host = config['DATABRICKS_HOST']
        url = f"{host}{version}{command}"
        azure_env_creds={}
        azure_creds = vault_credentials.get_secret_from_vault(config['vault_path'], config['vault_keys'])
        xops_creds = vault_credentials.get_secret_from_vault(config['xops_vault_path'], config['xops_vault_keys'])
        # set log level to debug if debugging enabled
        if config.get('DEBUG'):
            logger.setLevel(logging.DEBUG)

        if azure_creds:
            azure_env_creds['client_id'] = azure_creds['clientID']
            azure_env_creds['client_secret'] = azure_creds['clientSecret']

        # Fetch azure account details from mysql db
        env_id = ''
        if azure_creds.get('env_id'):
            env_id = azure_creds.get('env_id')
        elif os.environ.get('AZURE_ENVIRONMENT_ID'):
            env_id = os.environ.get('AZURE_ENVIRONMENT_ID')
        azure_env_creds['env_id'] = env_id
        cp = ConfigParameters(mysql_config=xops_creds)
        azure_config = cp.get_environment_parameter(['azure_tenant_id', 'azure_subscription_id'],
                                                    azure_env_creds['env_id'])
        if azure_config:
            azure_env_creds['tenant_id'] = azure_config['azure_tenant_id']
            azure_env_creds['subscription_id'] = azure_config['azure_subscription_id']
        credentials = set_credentials(azure_env_creds)  # to be taken from vault
        token = get_token(credentials)
        headers = {'Authorization': 'Bearer ' + token}

        # fetching job list
        job_api_path = config['Jobs']['api_path']
        job_url = f"{host}{version}{job_api_path}"
        job_results = jobs(job_url, headers)
        job_map = {}
        if job_results and len(job_results) > 0:
            for job_result in job_results:
                if job_result.get('jobs') and len(job_result.get('jobs')) > 0:
                    for job in job_result['jobs']:
                        job_map[job['job_id']] = job.get('settings', {}).get('name')

        results = job_runs(url, headers, starttime_ms, endtime_ms)

        for r in results:
            if not r.get('runs'):
                continue

            for job in r['runs']:
                run = {'metric_start_time': start_time, 'metric_end_time': end_time,
                       'workspace_name': config['DATABRICKS_WORKSPACE']}
                taskslist = []
                for key, value in job.items():
                    # if job_id in list, then put job_name in run dict
                    if key == 'job_id' and value in job_map.keys():
                        run['job_name'] = job_map[value]

                    if key and key.casefold() in ['schedule', 'overriding_parameters', 'git_source', 'cluster_instance',
                                                  'cluster_spec', 'job_clusters']:
                        continue

                    if type(value) is not list and type(value) is not dict:
                        if key in ['start_time','end_time']:
                            run[key]= time.strftime(date_string,time.gmtime(value/1000))
                        else:
                            run[key] = value

                    elif type(value) is not list and type(value) is dict:
                        for k, v in value.items():
                            run[k] = v
                    elif type(value) is list and key == 'tasks':
                        for tasks in value:
                            task = {}
                            task['task_run_id'] = tasks['run_id']
                            task['task_key'] = tasks['task_key']
                            task['cluster_id'] = tasks['cluster_instance']['cluster_id']
                            if tasks['start_time']!=0:
                                task['task_start_time'] = time.strftime(date_string,time.gmtime(tasks['start_time']/1000))
                            else:
                                task['task_start_time'] = tasks['start_time']
                            task['task_execution_duration'] = tasks['execution_duration']
                            if tasks['end_time']!=0:
                                task['task_end_time'] = time.strftime(date_string,time.gmtime(tasks['end_time']/1000))
                            else:
                                task['task_end_time'] = tasks['end_time']
                            # task[''] = tasks['']
                            if tasks['state']:
                                for k, v in tasks['state'].items():
                                    task['task_' + k] = v

                            taskslist.append(task)

                for t in taskslist:
                    run1 = run
                    # run1.update(t)
                    run3 = run1 | t
                    runs.append(run3)
        return runs


def api_metric(api, config):
    interval_in_min = int(config['INTERVAL'])
    utc_start_time = ''
    utc_end_time = ''
    if config['HISTORICAL']:
        start_day = config['START_DATE']
        end_day = config['END_DATE']
        shift_time = "00"
        timezone = config['TIMEZONE'].lower()
        if timezone.upper() == 'EDT':
            shift_time = "-240"
        if timezone.upper() == 'EST':
            shift_time = "-300"
        if timezone.upper() == 'IST':
            shift_time = "-330"
        utc_start_time = arrow.get(start_day).shift(minutes=int(shift_time)).to('utc').datetime
        utc_end_time = arrow.get(end_day).shift(minutes=int(shift_time)).to('utc').datetime
    else:
        utc_end_time = datetime.utcnow()
        logger.debug(f"end_time={utc_end_time}")
        utc_start_time = utc_end_time - timedelta(minutes=interval_in_min)
        logger.debug(f"start_time={utc_start_time}")

    output = collect_metrics(api, config, utc_start_time, utc_end_time)
    logger.info("Metrics collected for api '{}'".format(api))
    month = ''
    day = ''
    if len(str(utc_start_time.month)) == 1:
        month = '0' + str(utc_start_time.month)
    else:
        month = str(utc_start_time.month)
    if len(str(utc_start_time.day)) == 1:
        day = '0' + str(utc_start_time.day)
    else:
        day = str(utc_start_time.day)
    pwd = os.path.dirname(os.path.realpath(__file__))

    if config[api]['csvpath'] != '':
        output_file_name = api.lower() + '_databricks' + "_metrics_" + str(
            utc_start_time.year) + str(month) + str(day) + ".csv"
        if platform.system() == 'Windows':
            output_file_path = config[api]['csvpath'] + '\\' + output_file_name
        else:
            output_file_path = config[api]['csvpath'] + '/' + output_file_name
    else:
        output_file_name = api.lower() + '_databricks' + "_metrics_" + str(
            utc_start_time.year) + str(month) + str(day) + ".csv"
        if platform.system() == 'Windows':
            output_file_path = "{0}{1}{2}".format(pwd, '\\', output_file_name)
        else:
            output_file_path = "{0}{1}{2}".format(pwd, '/', output_file_name)

    # Check output directory exists
    csv_path_from_config = config[api]['csvpath']
    if csv_path_from_config != '' and not os.path.exists(csv_path_from_config):
        logger.info("Creating csv path directory, as directory doesn't exist")
        os.makedirs(csv_path_from_config, exist_ok=True)
    save_csv(output, output_file_path, config['Columns'])
    logger.info("Saved to csv for api '{}'".format(api))


def save_csv1(result, output_filename):
    """
    Save a csv based on collected data
    """
    if result is not None and len(result) > 0:
        header = True
        keys = result[0].keys()
        try:
            with open(output_filename, 'a', newline='') as csvfile:
                writer = csv.DictWriter(csvfile, keys)
                if header and os.stat(output_filename).st_size == 0:
                    writer.writeheader()
                    header = False
                writer.writerows(result)

        except Exception:
            # print(traceback.format_exc())
            logger.error("Error while saving to csv : {}".format(traceback.format_exc()))


def save_csv(result, output_filename, cols):
    data_frame = pd.DataFrame(result, columns=cols)
    # lst_concat_df_obj.to_csv(output_file_path_str, index=False)
    path_to_check = Path(output_filename)
    try:
        if (not path_to_check.is_file()) or (
                path_to_check.is_file() and os.stat(output_filename).st_size == 0):
            data_frame.to_csv(output_filename, mode='a', index=False, header=True)
        else:
            existing_df = pd.read_csv(output_filename)
            # existing_df.append(data_frame)
            new_df = pd.concat([existing_df, data_frame])
            new_df.to_csv(output_filename, mode='w', index=False, header=True)
            # data_frame.to_csv(output_filename, mode='a', index=False, header=False)
    except Exception as ex:
        logger.error("Error while saving CSV: ", ex)


def load_configuration(lconfig):
    """
        Read and load data from config.yaml file
        """
    cfg = {}  # Check if this is a dict
    try:
        with open(lconfig, 'r') as yamlfile:
            cfg = yaml.load(yamlfile, Loader=yaml.FullLoader)
    except yaml.YAMLError as exc:
        # print(exc)
        logger.exception(exc)
    except Exception as e:
        # print(e)
        logger.exception(e)
    return cfg


def execute(**inputs):
    # if __name__ == '__main__':
    # For VM testing only
    # starttime = datetime.now()
    # # Get input from command line
    # command_line_input = False
    # parser = argparse.ArgumentParser()
    # parser.add_argument('--start_date', dest="start_date", help='specify the start date to override config file ',
    #                     required=False)
    # parser.add_argument('--end_date', dest="end_date", help='specify the end date to override config file ',
    #                     required=False)
    # parser.add_argument('--config_path', dest="config_path", help='specify the config path to override default config '
    #                                                               'file ',
    #                     required=False)
    # args = parser.parse_args()
    #
    # # Error check input
    # if all(e is None for e in (args.start_date, args.end_date, args.config_path)):
    #     command_line_input = False
    # else:
    #     if args.start_date is not None:
    #         if args.end_date is None:
    #             parser.error("Specify end date")
    #     else:
    #         command_line_input = True
    #
    #     if args.end_date is not None:
    #         if args.start_date is None:
    #             parser.error("Specify start date")
    #     else:
    #         command_line_input = True
    #
    #     if args.start_date == "":
    #         parser.error("Specify start date value")
    #     else:
    #         command_line_input = True
    #     if args.end_date == "":
    #         parser.error("Specify end date value")
    #     else:
    #         command_line_input = True
    #
    #     if not args.config_path:
    #         parser.error("Specify config path")
    #     else:
    #         command_line_input = True

    # print(args.start_date)
    # print(args.end_date)

    # Establish directory and load config
    api_enable = {}
    starttime = datetime.now()
    logger.info(" --- calling Databricks RestAPI function ---- ")
    pwd = os.path.dirname(os.path.realpath(__file__))

    # if args.config_path is not None and args.config_path != "":
    #     pwd = args.config_path

    if platform.system() == 'Windows':
        cwd = "{0}{1}{2}".format(pwd, '\\', 'restconfig.yaml')
    else:
        cwd = "{0}{1}{2}".format(pwd, '/', 'restconfig.yaml')

    config = load_configuration(cwd)

    if inputs.get('BASE_HOME_DIR'):
        config['JobRuns']['csvpath'] = inputs['BASE_HOME_DIR'] + config['JobRuns']['csvpath']

    if config.get('DEBUG'):
        logger.setLevel(logging.DEBUG)

    logger.debug("Config path={0}".format(cwd))

    # Set start and end dates
    # if command_line_input and args.start_date and args.end_date:
    #     config['START_DATE'] = args.start_date
    #     config['END_DATE'] = args.end_date
    logger.info(" ---function ---- ")
    for api_name in config['APIS']['LIST']:
        api_found = False
        for api in config.keys():
            if api == '.' + api_name:
                tool_found = True  # api is found in data node though prefixed with (.)
                logger.warning(
                    "WARNING: Node <{}> is marked to exclude from processing [prefixed with dot (.)]. Skipping...".format(
                        api))
            else:
                if api == 'TOOLS':
                    # Skip as TOOLS is being processed in the beginning for iterating on list
                    continue
                elif api == api_name:  # This is to avoid hardcoding of api name in code
                    api_found = True
                    logger.debug('----------------Processing {} from {}----------------'.format(api, config))
                    api_enable[api] = 1

    # procs = []
    for api in api_enable.keys():
        # Setup a list of processes that we want to run
        # azure_metric(api, config)
        api_metric(api, config)
        # processes = Process(target=api_metric, args=(api, config))
        # procs.append(processes)
        # processes.start()

    # for proc in procs:
    #     proc.join()

    logger.info("---- End of logging ----")
    endtime = datetime.now()
    diff = endtime - starttime
    msg = "Total execution time ={0}".format(divmod(diff.total_seconds(), 60))
    logger.info(msg)
