import configparser
import json
import os
from collections import OrderedDict
from datetime import datetime, timedelta
import logging
import pandas as pd
import requests
import yaml
from json_flatten import flatten

from vault_utility_v2 import vault_credentials
from mysql_utility.config_parameters import ConfigParameters

logger = logging.getLogger('ADFMetrics.py')
logger.setLevel(logging.DEBUG)
# create console handler and set level to debug
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
# add formatter to ch
ch.setFormatter(formatter)
# add ch to logger
logger.addHandler(ch)

def get_token(tenantId, client_id, client_secret, resource, subscriptionId):
    service_url = 'https://login.microsoftonline.com/' + tenantId + '/oauth2/token'
    req_body = {"grant_type": "client_credentials", "client_id": client_id, "client_secret": client_secret,
                "resource": resource, "subscriptionId": subscriptionId}
    response = requests.get(url=service_url, data=req_body)
    # print (response.text)
    obj = json.loads(response.content)
    return obj["access_token"]
def load_configuration(lconfig):
    """
        Read and load data from config.yaml file
        """
    cfg = {}  # Check if this is a dict
    try:
        with open(lconfig, 'r') as yamlfile:
            cfg = yaml.load(yamlfile, Loader=yaml.FullLoader)
    except yaml.YAMLError as exc:
        logger.exception(exc)
    except Exception as e:
        logger.exception(e)
    return cfg

def execute(**inputs):

    # config = configparser.ConfigParser()
    # config_path = inputs.get('CONFIG_PATH')
    # config.read(config_path)
    config=load_configuration(inputs.get('CONFIG_PATH'))
    home_dir_path = config['DEFAULT'].get('home_dir_path')
    time_interval = config['DEFAULT'].get('time_interval')

    # create directories including the home directory
    home_dir_path = inputs.get('BASE_HOME_DIR') + home_dir_path
    if (not os.path.isdir(home_dir_path)) or (not os.path.isdir(home_dir_path + '/json_files/')):
        os.makedirs(home_dir_path, mode=0o777, exist_ok=True)
        os.makedirs(home_dir_path + '/json_files/', mode=0o777, exist_ok=True)

    from_time = datetime.utcnow() - timedelta(minutes=(int(time_interval)))
    from_time_tmp = from_time
    from_time = from_time.strftime('%Y-%m-%dT%H:%M:00.000000Z')
    to_time = datetime.utcnow().strftime('%Y-%m-%dT%H:%M:00.000000Z')
    timestamp = from_time_tmp.strftime('%Y-%m-%d %H:%M:00')
    azure_env_creds = {}
    azure_creds = vault_credentials.get_secret_from_vault(config['VAULT'].get('vault_path'),config['VAULT'].get('vault_keys'))
    xops_creds = vault_credentials.get_secret_from_vault(config['VAULT'].get('xops_vault_path'),config['VAULT'].get('xops_vault_keys'))

    if azure_creds:
        azure_env_creds['client_id'] = azure_creds['clientID']
        azure_env_creds['client_secret'] = azure_creds['clientSecret']
        # azure_env_creds['resource_group_name'] = azure_creds['resource_group_name']

    if config['AZURE_ACCOUNT_DETAILS']['resource_group_name']:
        azure_env_creds['resource_group_name']=config['AZURE']['resource_group_name']

    client_id = azure_env_creds['client_id']
    client_secret = azure_env_creds['client_secret']
    resource = config['AZURE_ACCOUNT_DETAILS'].get('resource')

    # Fetch azure account details from mysql db
    env_id = ''
    if azure_creds.get('env_id'):
        env_id = azure_creds.get('env_id')
    elif os.environ.get('AZURE_ENVIRONMENT_ID'):
        env_id = os.environ.get('AZURE_ENVIRONMENT_ID')
    azure_env_creds['env_id'] = env_id
    cp = ConfigParameters(mysql_config=xops_creds)
    azure_config = cp.get_environment_parameter(['azure_tenant_id', 'azure_subscription_id'], azure_env_creds['env_id'])
    if azure_config:
        azure_env_creds['tenant_id'] = azure_config['azure_tenant_id']
        azure_env_creds['subscription_id'] = azure_config['azure_subscription_id']
    else:
        azure_env_creds['tenant_id'] = config['AZURE_ACCOUNT_DETAILS'].get('tenantId')
        azure_env_creds['subscription_id'] = config['AZURE_ACCOUNT_DETAILS'].get('subscriptionId')
    resourceGroups = azure_env_creds['resource_group_name']
    apiVersion = config['AZURE_ACCOUNT_DETAILS'].get('apiVersion')
    interval = config['AZURE_ACCOUNT_DETAILS'].get('interval')

    filedate = datetime.utcnow().strftime('%m%d%Y')
    file_azmonitor_metrics_json = home_dir_path + '/json_files/azmonitor_metrics.json'
    file_azmonitor_metrics_csv = home_dir_path + '/csv_results/azmonitor_metrics_' + filedate + '.csv'
    file_pipeline_runs_json = home_dir_path + '/json_files/pipeline_runs.json'
    file_pipeline_runs_csv = home_dir_path + '/metrics/pipelineruns/pipeline_runs_datafactory_metrics_' + filedate + '.csv'
    file_activity_runs_json = home_dir_path + '/json_files/activity_runs.json'
    file_activity_runs_csv = home_dir_path + '/metrics/activityruns/activity_runs_datafactory_metrics_' + filedate + '.csv'

    bearerToken = get_token(azure_env_creds['tenant_id'], client_id, client_secret, resource, azure_env_creds['subscription_id'])
    # print (bearerToken)

    # Get List of Factories
    service_url = 'https://management.azure.com/subscriptions/' + azure_env_creds['subscription_id'] + '/resourceGroups/' \
                  + resourceGroups + '/providers/Microsoft.DataFactory/factories?api-version=' + apiVersion
    # print (service_url)
    headers = {"Authorization": "Bearer " + bearerToken}
    response = requests.get(url=service_url, headers=headers)
    obj = json.loads(response.content)
    for x in obj["value"]:
        factoryName = x.get("name")
        resourceUri = x.get("id")

        # Pipeline Runs - Query By Factory
        logger.info("**** PipelineRuns QueryByFactory ****")
        service_url = 'https://management.azure.com/subscriptions/' + azure_env_creds['subscription_id'] + '/resourceGroups/' \
                      + resourceGroups + '/providers/Microsoft.DataFactory/factories/' + factoryName \
                      + '/queryPipelineRuns?api-version=' + apiVersion
        headers = {"Authorization": "Bearer " + bearerToken, "content-type": "application/json"}
        req_body = {"lastUpdatedAfter": from_time, "lastUpdatedBefore": to_time}
        response = requests.post(url=service_url, data=json.dumps(req_body), headers=headers)
        pipeline_run_obj = json.loads(response.content)
        with open(file_pipeline_runs_json, 'w') as pipeline_runs:
            json.dump(pipeline_run_obj, pipeline_runs)
        # Convert Pipeline runs Json to csv
        with open(file_pipeline_runs_json) as file:
            data1 = json.load(file)
        columns_pipeline_run = ["id", "runId", "debugRunId", "runGroupId", "pipelineName", "parameters", "invokedBy_id",
                                "invokedBy_name", "invokedBy_invokedByType", "runStart", "runEnd", "durationInMs",
                                "status", "message", "lastUpdated", "annotations", "runDimension", "isLatest"]
        df = pd.DataFrame([flatten(record) for record in data1['value']], columns=columns_pipeline_run)
        if not data1["value"]:
            df = df.reindex(df.index.tolist() + list(range(0, 1)))
        df.insert(0, 'TimeStamp', timestamp)
        df.insert(1, 'factoryName', factoryName)
        if not os.path.exists('/'.join(file_pipeline_runs_csv.split('/')[:-1])):
            logger.info("Creating metric directory")
            os.makedirs('/'.join(file_pipeline_runs_csv.split('/')[:-1]), exist_ok=True)
        if not os.path.isfile(file_pipeline_runs_csv):
            df.to_csv(file_pipeline_runs_csv, header=True, index=False)
        else:
            df.to_csv(file_pipeline_runs_csv, mode='a', header=False, index=False)

        # Getting metrics for Activity runs
        columns_activity_run = ["activityRunEnd", "activityName", "activityRunStart", "activityType", "durationInMs",
                                "retryAttempt", "error_errorCode", "error_message", "error_failureType", "error_target",
                                "error_details", "activityRunId", "iterationHash", "input_source_type",
                                "input_sink_type", "linkedServiceName", "output_dataRead", "output_dataWritten",
                                "output_filesRead", "output_sourcePeakConnections", "output_sinkPeakConnections",
                                "output_rowsRead", "output_rowsCopied", "output_copyDuration", "output_throughput",
                                "output_errors", "output_effectiveIntegrationRuntime",
                                "output_usedDataIntegrationUnits", "output_usedParallelCopies", "pipelineName",
                                "pipelineRunId", "status"]
        df = pd.DataFrame(columns=columns_activity_run)
        # Check if pipeline data available, if not just write timestamp only
        if not pipeline_run_obj["value"]:
            # df = pd.DataFrame(columns=columns_activity_run)
            df = df.reindex(df.index.tolist() + list(range(0, 1)))
        else:
            for x in pipeline_run_obj["value"]:
                runId = x.get("runId")
                # print(runId)

                # Activity Runs - Query By Pipeline Run
                logger("**** Activity Runs - Query By Pipeline Run ****")
                service_url = 'https://management.azure.com/subscriptions/' + azure_env_creds['subscription_id'] + '/resourceGroups/' \
                              + resourceGroups + '/providers/Microsoft.DataFactory/factories/' + factoryName \
                              + '/pipelineruns/' + runId + '/queryActivityruns?api-version=' + apiVersion
                # print(service_url)
                headers = {"Authorization": "Bearer " + bearerToken, "content-type": "application/json"}
                req_body = {"lastUpdatedAfter": from_time, "lastUpdatedBefore": to_time}
                response = requests.post(url=service_url, headers=headers)
                # response = requests.post(url=service_url, data=req_body, headers=headers)
                activity_run_obj = json.loads(response.content)
                with open(file_activity_runs_json, 'w') as activity_runs:
                    json.dump(activity_run_obj, activity_runs)
                # Convert Activity runs Json to csv
                with open(file_activity_runs_json) as file:
                    data2 = json.load(file)

                for data in data2["value"]:
                    activity_metrics_od = OrderedDict()
                    activity_metrics_od["activityRunEnd"] = data.get("activityRunEnd")
                    activity_metrics_od["activityName"] = data.get("activityName")
                    activity_metrics_od["activityRunStart"] = data.get("activityRunStart")
                    activity_metrics_od["activityType"] = data.get("activityType")
                    activity_metrics_od["durationInMs"] = data.get("durationInMs")
                    activity_metrics_od["retryAttempt"] = data.get("retryAttempt")
                    if 'error' in data:
                        activity_metrics_od["error_errorCode"] = data["error"].get("errorCode")
                        activity_metrics_od["error_message"] = data["error"].get("message")
                        activity_metrics_od["error_failureType"] = data["error"].get("failureType")
                        activity_metrics_od["error_target"] = data["error"].get("target")
                        activity_metrics_od["error_details"] = data["error"].get("details")
                    activity_metrics_od["activityRunId"] = data.get("activityRunId")
                    activity_metrics_od["iterationHash"] = data.get("iterationHash")
                    if 'input' in data:
                        if 'source' in data["input"]:
                            activity_metrics_od["input_source_type"] = data["input"]["source"].get("type")
                        if 'sink' in data["input"]:
                            activity_metrics_od["input_sink_type"] = data["input"]["sink"].get("type")
                    activity_metrics_od["linkedServiceName"] = data.get("linkedServiceName")
                    if 'output' in data:
                        activity_metrics_od["output_dataRead"] = data["output"].get("dataRead")
                        activity_metrics_od["output_dataWritten"] = data["output"].get("dataWritten")
                        activity_metrics_od["output_filesRead"] = data["output"].get("filesRead")
                        activity_metrics_od["output_sourcePeakConnections"] = data["output"].get(
                            "sourcePeakConnections")
                        activity_metrics_od["output_sinkPeakConnections"] = data["output"].get("sinkPeakConnections")
                        activity_metrics_od["output_rowsRead"] = data["output"].get("rowsRead")
                        activity_metrics_od["output_rowsCopied"] = data["output"].get("rowsCopied")
                        activity_metrics_od["output_copyDuration"] = data["output"].get("copyDuration")
                        activity_metrics_od["output_throughput"] = data["output"].get("throughput")
                        activity_metrics_od["output_errors"] = data["output"].get("errors")
                        activity_metrics_od["output_effectiveIntegrationRuntime"] = data["output"].get(
                            "effectiveIntegrationRuntime")
                        activity_metrics_od["output_usedDataIntegrationUnits"] = data["output"].get(
                            "usedDataIntegrationUnits")
                        activity_metrics_od["output_usedParallelCopies"] = data["output"].get("usedParallelCopies")
                    activity_metrics_od["pipelineName"] = data.get("pipelineName")
                    activity_metrics_od["pipelineRunId"] = data.get("pipelineRunId")
                    activity_metrics_od["status"] = data.get("status")

                    df = df.append(activity_metrics_od, ignore_index=True)

        df.insert(0, 'TimeStamp', timestamp)
        df.insert(1, 'factoryName', factoryName)
        if not os.path.exists('/'.join(file_activity_runs_csv.split('/')[:-1])):
            os.makedirs('/'.join(file_activity_runs_csv.split('/')[:-1]), exist_ok=True)
        if not os.path.isfile(file_activity_runs_csv):
            df.to_csv(file_activity_runs_csv, header=True, index=False)
        else:
            df.to_csv(file_activity_runs_csv, mode='a', header=False, index=False)
