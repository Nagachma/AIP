import ADFMetrics

if __name__ == '__main__':
    input_dict = {
        'CONFIG_PATH': 'config.yaml'
    }

    ADFMetrics.execute(**input_dict)
