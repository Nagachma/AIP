import getloganalyticsdata_powerbi

if __name__ == '__main__':
    input_dict = {
        'CONFIG_PATH': 'config.yaml'
    }

    getloganalyticsdata_powerbi.execute(**input_dict)
