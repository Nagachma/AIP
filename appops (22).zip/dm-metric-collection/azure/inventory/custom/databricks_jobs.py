import datetime
import json

import requests


def get_token(tenant_id, client_id, client_secret, subscription_id) -> str:
    service_url = 'https://login.microsoftonline.com/' + tenant_id + '/oauth2/token'
    req_body = {"grant_type": "client_credentials", "client_id": client_id, "client_secret": client_secret,
                "resource": "https://management.azure.com/", "subscriptionId": subscription_id}
    response = requests.get(url=service_url, data=req_body)
    obj = json.loads(response.content)
    return obj.get("access_token")


def get_db_token(credentials):
    client_id = credentials['client_id']
    client_secret = credentials['client_secret']
    tenant_id = credentials['tenant_id']

    token_api_request_body = {
        'grant_type': 'client_credentials',
        'resource': '2ff814a6-3304-4ab8-85cb-cd0e6f879c1d',
        'client_id': client_id,
        'client_secret': client_secret
    }
    token_api_request_url = 'https://login.microsoftonline.com/' + tenant_id + '/oauth2/token'
    token_api_request_headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    response = requests.get(token_api_request_url, headers=token_api_request_headers, data=token_api_request_body)
    if response.status_code == 200:
        dbrks_bearer_token = response.json()['access_token']
        return dbrks_bearer_token


def execute(workspace_name: str, config: dict, azure_config: dict, secrets: dict) -> list:
    final_list = []
    bearer_token = get_token(azure_config['azure_tenant_id'], secrets['clientID'], secrets['clientSecret'],
                             azure_config['azure_subscription_id'])
    headers = {"Authorization": "Bearer " + bearer_token}
    for resource_group in config['RESOURCE_GROUPS']:
        url = f"https://management.azure.com/subscriptions/{azure_config['azure_subscription_id']}/resourceGroups/" \
              f"{resource_group}/providers/Microsoft.Databricks/workspaces/{workspace_name}?api-version=2018-04-01"

        response = requests.get(url=url, headers=headers)
        obj = json.loads(response.content)

        if obj.get("properties"):
            w_url = obj['properties']['workspaceUrl']
            job_url = f"https://{w_url}/api/2.1/jobs/list"
            db_token = get_db_token({'client_id': secrets['clientID'], 'client_secret': secrets['clientSecret'],
                                     'tenant_id': azure_config['azure_tenant_id']})
            # job_response = requests.get(url=job_url, headers={'Authorization': 'Bearer ' + db_token})
            # result = json.loads(job_response.text)

            results = []
            limit = 25
            offset = 0
            while True:
                job_response = requests.get(url=job_url, headers={'Authorization': 'Bearer ' + db_token},
                                        params={'expand_tasks': 'false', 'limit': limit, 'offset': offset})
                # print(job_response.text)
                result = json.loads(job_response.text)
                results.extend(result['jobs'])
                offset = limit
                limit = limit + limit
                if not result['has_more']:
                    break

            for j in results:
                # print(j)
                job = {
                    'name': f"{workspace_name}/{j.get('settings', {}).get('name')}",
                    config['COLLECTION_FIELDS']['CREATED_ON']: datetime.datetime.fromtimestamp(
                        j['created_time'] / 1000, datetime.timezone.utc),
                    'user': j['creator_user_name'],
                    config['COLLECTION_FIELDS']['LAST_MODIFIED_TIME']: None
                }
                final_list.append(job)
    return final_list
