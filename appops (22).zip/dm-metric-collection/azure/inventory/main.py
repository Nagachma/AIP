# Import the needed credential and management objects from the libraries.
import csv
import importlib.util
import logging
import os
import traceback
from datetime import datetime, timezone

import arrow
import pymongo
import yaml
from azure.core.exceptions import ResourceNotFoundError
from azure.identity import ClientSecretCredential
from azure.mgmt.monitor import MonitorManagementClient
from azure.mgmt.resource import ResourceManagementClient
from azure.mgmt.resource.resources.v2022_09_01.models import Resource
from dateutil import parser
from mysql_utility.config_parameters import ConfigParameters
from pymongo import MongoClient
from vault_utility import vault_credentials
from azure.inventory.subresources import get_sub_resources

logger = logging.getLogger('get_azure_inventory')
logger.setLevel(logging.INFO)

# create console handler and set level to debug
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)

# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# add formatter to ch
ch.setFormatter(formatter)

# add ch to logger
logger.addHandler(ch)


def load_configuration(lconfig):
    """
    Read and load data from config.yaml file
    """
    cfg = {}
    try:
        with open(lconfig, 'r') as yaml_file:
            cfg = yaml.safe_load(yaml_file)
    except yaml.YAMLError as exc:
        # logger.info(exc)
        logger.exception(exc)
    except Exception as e:
        # logger.info(e)
        logger.exception(e)
    return cfg


def save_csv(result, output_filename):
    """
    Save a csv based on collected data
    """
    if result is not None:
        header = True
        try:
            with open(output_filename, 'a', newline='') as csvfile:
                writer = csv.writer(csvfile)
                for row in result:
                    if header and os.stat(output_filename).st_size == 0:
                        # logger.info(row.keys())
                        writer.writerow(row.keys())
                        header = False
                    writer.writerow(row.values())
        except Exception:
            # logger.info(traceback.format_exc())
            logger.error("Error while saving to csv : {}".format(traceback.format_exc()))


def exec_custom_module(mod_conf, args, config, azure_config, secret_keys):
    module_name = mod_conf['MODULE']
    inputs = mod_conf['ARGS'].format(args)
    module = importlib.import_module(f"azure.inventory.custom.{module_name}")
    # spec = importlib.util.spec_from_file_location(module_name, file_path)
    # module = importlib.util.module_from_spec(spec)
    return module.execute(inputs, config, azure_config, secret_keys)


def execute(**inputs):
    logger.info(f"Start ----> {datetime.now(timezone.utc)}")
    # Acquire a credential object using CLI-based authentication.
    cp = ConfigParameters(credential_file=inputs.get('CREDENTIAL_FILE'))
    azure_config = cp.get_environment_parameter(['azure_tenant_id', 'azure_subscription_id'],
                                                os.environ['AZURE_ENVIRONMENT_ID'])
    # logger.info(f"{azure_config}")
    secret_keys = vault_credentials.get_secret_from_vault(['clientID', 'clientSecret'])
    credentials = ClientSecretCredential(
        client_id=secret_keys['clientID'],
        # tenant_id='8ce09ef1-d540-492e-9e4f-2b8869d6fe57',
        tenant_id=azure_config['azure_tenant_id'],  # '8ce09ef1-d540-492e-9e4f-2b8869d6fe57',
        client_secret=secret_keys['clientSecret']
    )

    # Retrieve subscription ID from environment variable.
    # subscription_id = '221ddaa9-f12f-4a5f-88ca-5fce9a69faa0'
    subscription_id = azure_config['azure_subscription_id']  # '221ddaa9-f12f-4a5f-88ca-5fce9a69faa0'

    # Read configuration from file
    config = load_configuration(inputs.get('CONFIG_PATH'))

    # Set up the mongo client
    mongo_config = config['MONGO']
    client = MongoClient(mongo_config['URL'])
    db = client.get_database(mongo_config['DATABASE'])
    collection = db.get_collection(mongo_config['COLLECTION'])

    # Retrieve existing data from mongo
    existing_list = collection.find().sort(config['COLLECTION_FIELDS']['INSERTED_TIME'], pymongo.DESCENDING)
    resources_dict = {}
    for item in existing_list:
        # logger.info(item)
        resources_dict = item
        break

    # Retrieve the resource group to use
    resource_groups = config['RESOURCE_GROUPS']  # 'PERF_ENG_RG'

    # Obtain the management object for resources.
    resource_client = ResourceManagementClient(credentials, subscription_id)
    monitor_mgmt_client = MonitorManagementClient(credentials, subscription_id)

    count = 1
    resource_groups_filter = '('
    for rg in resource_groups:
        if count == 1:
            resource_groups_filter += f"resourceGroup eq '{rg}'"
        else:
            resource_groups_filter += f" or resourceGroup eq '{rg}'"
    resource_groups_filter += ")"

    overall_dict = {}

    for service in config['SERVICES'].keys():

        service_dict = {'active': [], 'deleted': []}

        if '.' in service:
            continue
        resource_list = []
        # -----Fetching Sub resources ------ >>>>> #
        subresources = []
        if config['SERVICES'][service].get('REF') and not config['SERVICES'][service].get('CUSTOM'):
            logger.info('call sub-resource.py')
            active_parents = overall_dict[config['SERVICES'][service].get('REF')].get('active')
            for parent in active_parents:
                sub_list = get_sub_resources(parent, config['SERVICES'][service], config, azure_config, secret_keys)
                for r in sub_list:
                    # prepend parent name
                    r['name'] = parent['name'] + '/' + r['name']
                subresources.extend(sub_list)

        for subresource in subresources:
            # logger.info('subresource', str(subresource))
            # logger.info(str(subresource['id']))  # resource.id
            # logger.info(str(subresource['name']))
            # logger.info(str(subresource.get('properties', {}).get('displayName')))
            # logger.info(str(subresource.get('systemData', {}).get('createdAt')))
            # logger.info(str(subresource.get('systemData', {}).get('createdBy')))
            # logger.info('--------------------------------------------')
            resource_obj = Resource()
            resource_obj.name = subresource['name']
            resource_obj.id = subresource['id']
            resource_obj.type = subresource['type']
            resource_obj.provisioning_state = 'Succeeded'
            resource_obj.created_time = subresource.get('systemData', {}).get('createdAt')
            resource_obj.changed_time = None

            resource_list.append(resource_obj)
        # -----Fetching Sub resources ------ <<<<< #

        # Retrieve the list of resources in "myResourceGroup" (change to any name desired).
        # The expand argument includes additional properties in the output.
        if config['SERVICES'][service].get('REF'):
            pass
        else:
            resource_list = resource_client.resources.list(
                filter=F"resourceType eq '{config['SERVICES'][service]['TYPE']}' and "
                       + resource_groups_filter,
                expand="createdTime,"
                       "changedTime,provisioningState")

        custom_resource_list = []
        if config['SERVICES'][service].get('CUSTOM'):
            args = ''
            if config['SERVICES'][service].get('REF'):
                active_parents = overall_dict[config['SERVICES'][service].get('REF')].get('active')
                for parent in active_parents:
                    args = parent['name']
            script_config = config['SERVICES'][service].get('SCRIPT')
            custom_resource_list = exec_custom_module(script_config, args, config, azure_config, secret_keys)

        active_array = []
        deleted_list_existing = []
        if resources_dict.get(service):
            active_array = resources_dict[service]['active']
            deleted_list_existing = resources_dict[service]['deleted']
        active_list = []
        for resource in list(resource_list):
            # logger.info("prov state: ", resource.provisioning_state)
            if "Succeeded" not in resource.provisioning_state:
                continue
            resource_dict = {'name': resource.name, config['COLLECTION_FIELDS']['CREATED_ON']: None, 'user': None,
                             config['COLLECTION_FIELDS']['LAST_MODIFIED_TIME']: None}
            logger.info("-------------------------------------------")
            logger.info(f"resource name: {str(resource.name)}")
            logger.info(f"resource created time: {str(resource.created_time)}")
            logger.info(f"resource changed time: {str(resource.changed_time)}")
            logger.info(f"resource type: {str(resource.type)}")

            resource_dict[config['COLLECTION_FIELDS']['CREATED_ON']] = resource.created_time
            resource_dict[config['COLLECTION_FIELDS']['LAST_MODIFIED_TIME']] = resource.changed_time
            rlist = list(filter(lambda x: x['name'] == resource.name, active_array))
            resource_match = {}
            if len(rlist) > 0:
                resource_match = rlist[0]

            activity_log_list = []
            if resource_match and resource_match.get(config['COLLECTION_FIELDS']['CREATED_ON']) and resource_match['user']:
                logger.info(
                    f"Created-on field already exists------>{resource_match.get(config['COLLECTION_FIELDS']['CREATED_ON'])}")
                resource_dict['user'] = resource_match['user']
                resource_dict[config['COLLECTION_FIELDS']['CREATED_ON']] = resource_match[
                    config['COLLECTION_FIELDS']['CREATED_ON']]
            elif resource_dict[config['COLLECTION_FIELDS']['CREATED_ON']]:
                pivot_time = arrow.get(resource_dict[config['COLLECTION_FIELDS']['CREATED_ON']])
                start_time = pivot_time.shift(minutes=-15).to('utc').datetime
                end_time = pivot_time.shift(minutes=+45).to('utc').datetime
                logger.info(f"Fetching create activity logs from start_time = {start_time} to end_time = {end_time}")
                delta = datetime.now(timezone.utc) - start_time
                logger.info(f"delta days = {delta.days}")
                if delta.days <= 90:
                    activity_log_list = monitor_mgmt_client.activity_logs.list(
                        filter=f"eventTimestamp ge '{start_time}' and "
                               f"eventTimestamp le '{end_time}' and "
                               f"resourceUri eq '{resource.id}'")
                else:
                    logger.warning("delta days more than 90 days, unable to fetch create user")
            else:
                try:
                    logger.info("Fetching resource from get_by_id")
                    generic_resource = resource_client.resources.get_by_id(resource_id=resource.id,
                                                                           api_version=config['SERVICES'][service][
                                                                               'API_VERSION'])
                except ResourceNotFoundError:
                    logger.warning(f"Resource Not Found -->{resource.id}")
                    continue
                created_time_str = ''
                if generic_resource and generic_resource.properties:
                    for key in generic_resource.properties.keys():
                        if 'createdTime' in key or 'createTime' in key or 'creationTime' in key or 'creationDate' in key or 'createdDateTime' in key:
                            logger.info(f'creation time: {generic_resource.properties.get(key)}')
                            created_time_str = generic_resource.properties.get(key)
                            break
                activity_log_list = []

                if '' != created_time_str:
                    created_time = parser.parse(created_time_str)
                    resource_dict[config['COLLECTION_FIELDS']['CREATED_ON']] = created_time
                    pivot_time = arrow.get(created_time)
                    start_time = pivot_time.shift(minutes=-15).to('utc').datetime
                    end_time = pivot_time.shift(minutes=+45).to('utc').datetime
                    logger.info(f"Fetching create activity logs from start_time = {start_time} to end_time = {end_time}")
                    delta = datetime.now(timezone.utc) - start_time
                    logger.debug(f"delta days = {delta.days}")
                    if delta.days <= 90:
                        activity_log_list = monitor_mgmt_client.activity_logs.list(
                            filter=f"eventTimestamp ge '{start_time}' and "
                                   f"eventTimestamp le '{end_time}' and "
                                   f"resourceUri eq '{resource.id}'")
                    else:
                        logger.warning("delta days more than 90 days, unable to fetch create user")
                else:
                    pivot_time = arrow.utcnow()
                    start_time = pivot_time.shift(days=-90).to('utc').datetime
                    end_time = pivot_time.datetime
                    logger.info(f"created time not found, trying to find create activity log in past 90 days:: "
                                f"start_time = {start_time}, end_time = {end_time}")
                    activity_log_list = monitor_mgmt_client.activity_logs.list(
                        filter=f"eventTimestamp ge '{start_time}' and "
                               f"eventTimestamp le '{end_time}' and "
                               f"resourceUri eq '{resource.id}'")

            if not resource_dict['user']:
                # Create user detection ----- start
                create_event_list = []
                rtype_e = config['SERVICES'][service]['TYPE'] + '/write'
                if config['SERVICES'][service].get('REF'):
                    rtype_e = str(rtype_e).replace('/{}', '')
                for activity in activity_log_list:
                    event = {'timestamp': activity.event_timestamp,
                             'activity_ops_name': str(activity.operation_name.localized_value),
                             'activity_caller': str(activity.caller)}
                    if activity.operation_name.localized_value is not None and 'create' in str(
                            activity.operation_name.localized_value).casefold() \
                            and rtype_e in activity.operation_name.value \
                            and activity.status.value == 'Succeeded':
                        create_event_list.append(event)

                least_timestamp = ''
                max_timestamp = ''
                for event in create_event_list:
                    if '' == least_timestamp:
                        least_timestamp = event['timestamp']
                    if least_timestamp > event['timestamp']:
                        least_timestamp = event['timestamp']

                result = list(filter(lambda x: (x['timestamp'] == least_timestamp), create_event_list))
                if len(result) > 0:
                    event = result[0]
                    if not resource_dict[config['COLLECTION_FIELDS']['CREATED_ON']]:
                        resource_dict[config['COLLECTION_FIELDS']['CREATED_ON']] = event['timestamp']
                    resource_dict['user'] = str(event['activity_caller'])
                # Create user detection ----- end

            if not resource_dict[config['COLLECTION_FIELDS']['LAST_MODIFIED_TIME']]:
                # Update event detection ------- start
                if resource_match and resource_match.get(config['COLLECTION_FIELDS']['LAST_MODIFIED_TIME']):
                    start_time = resource_match[config['COLLECTION_FIELDS']['LAST_MODIFIED_TIME']]
                    resource_dict[config['COLLECTION_FIELDS']['LAST_MODIFIED_TIME']] = resource_match[
                        config['COLLECTION_FIELDS']['LAST_MODIFIED_TIME']]
                else:
                    start_time = resource_dict[config['COLLECTION_FIELDS']['CREATED_ON']]
                if start_time is None:
                    start_time = datetime.now(timezone.utc)
                pivot_time = arrow.get(start_time)
                start_time = pivot_time.to('utc').datetime
                delta = datetime.now(timezone.utc) - start_time
                if delta.days > 90:
                    start_time = arrow.utcnow().shift(days=-90).to('utc').datetime
                end_time = arrow.utcnow().datetime
                logger.info(f'fetching update activity logs from {start_time} to {end_time}')
                activity_log_list = monitor_mgmt_client.activity_logs.list(filter=f"eventTimestamp ge '{start_time}' and "
                                                                                  f"eventTimestamp le '{end_time}' and "
                                                                                  f"resourceUri eq '{resource.id}'")

                update_event_list = []
                rtype_e = config['SERVICES'][service]['TYPE']
                if config['SERVICES'][service].get('REF'):
                    rtype_e = str(rtype_e).replace('/{}', '')
                for activity in activity_log_list:
                    event = {'timestamp': activity.event_timestamp,
                             'activity_ops_name': str(activity.operation_name.localized_value),
                             'activity_caller': str(activity.caller)}
                    if activity.operation_name.localized_value is not None and 'update' in str(
                            activity.operation_name.localized_value).casefold() \
                            and rtype_e in activity.operation_name.value \
                            and activity.status.value == 'Succeeded':
                        update_event_list.append(event)

                max_timestamp = ''
                for event2 in update_event_list:
                    if '' == max_timestamp:
                        max_timestamp = event2['timestamp']
                    if max_timestamp < event2['timestamp']:
                        max_timestamp = event2['timestamp']

                result2 = list(filter(lambda x: (x['timestamp'] == max_timestamp), update_event_list))
                if len(result2) > 0:
                    event2 = result2[0]
                    resource_dict[config['COLLECTION_FIELDS']['LAST_MODIFIED_TIME']] = event2['timestamp']
                # Update event detection ------- end

            active_list.append(resource_dict)

        if not config['SERVICES'][service].get('CUSTOM'):
            service_dict['active'] = active_list
        else:
            service_dict['active'] = custom_resource_list
            active_list = custom_resource_list

        # Deleted resources
        deleted = []
        if active_array and active_list is not None:
            new_names = list(map(lambda x: x['name'], active_list))
            existing_names = list(map(lambda x: x['name'], active_array))
            deleted = [x for x in existing_names if x not in new_names]
        deleted.extend(deleted_list_existing)
        service_dict['deleted'] = deleted

        overall_dict[service] = service_dict

    overall_dict[config['COLLECTION_FIELDS']['INSERTED_TIME']] = datetime.utcnow()
    logger.info(overall_dict)

    collection.insert_one(overall_dict)
    # save_csv(active_list, './output.csv')
    logger.info(f"End time --------------->{datetime.now(timezone.utc)}")


# if __name__ == '__main__':
#     kwargs = {'CREDENTIAL_FILE': '../../credentials.yaml', 'CONFIG_PATH': './config.yaml'}
#     execute(**kwargs)
