import json

import requests


def get_token(tenant_id, client_id, client_secret, subscription_id) -> str:
    service_url = 'https://login.microsoftonline.com/' + tenant_id + '/oauth2/token'
    req_body = {"grant_type": "client_credentials", "client_id": client_id, "client_secret": client_secret,
                "resource": "https://management.azure.com/", "subscriptionId": subscription_id}
    response = requests.get(url=service_url, data=req_body)
    obj = json.loads(response.content)
    return obj.get("access_token")


def get_sub_resources(parent_dict: dict, child_dict: dict, config: dict, azure_config: dict, secrets: dict) -> list:
    obj_list = []
    subscription_id = azure_config['azure_subscription_id']
    resource_groups = config['RESOURCE_GROUPS']
    p_name = parent_dict['name']
    rtype = child_dict['TYPE'].format(p_name)
    api_version = child_dict['API_VERSION']
    bearer_token = get_token(azure_config['azure_tenant_id'], secrets['clientID'], secrets['clientSecret'],
                             subscription_id)
    headers = {"Authorization": "Bearer " + bearer_token}
    for rg in resource_groups:
        url = "https://management.azure.com/" \
              f"subscriptions/{subscription_id}/" \
              f"resourceGroups/{rg}/" \
              f"providers/{rtype}" \
              f"?api-version={api_version}"
        response = requests.get(url=url, headers=headers)
        obj = json.loads(response.content)
        if obj.get("value"):
            obj_list.extend(obj.get("value"))
    return obj_list
