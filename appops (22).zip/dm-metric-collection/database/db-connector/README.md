Requires Python 3.9.5 or higher

**Files and Directories:**

    configs - contains all database config files in yaml format
    imports.txt - lists every sqlalchemy and sqlalchemy related library that needs to be imported
    installs.txt - lists every sqlalchemy and sqlalchemy related library that needs to be installed
    universal_db_connector.py - python script that creates CSVs based on database information and queries retrieved from database config files


## STEPS to use DB_connector

* Make a config file with all the system table queries you need to collect the metrics and paste it inside active_configs folder.
* Make a yaml file having required credentials to connect to instance and paste it in active_configs folder.e.g: <br>
dbservice: mysql<br>
driver: pymysql<br>
username: <username><br> 
password: <password><br>
host: <endpoint> <br>
port: <port><br>
db: <databse><br>
* Use the file end_dec_text.py to encrypt username and password. (generate a master key using Fernet.generate_key() and use it in the script to encrypt username and password) 
* paste the generated master key in keys folder and the encrypted username and password in your credentials file. Crosscheck the location for both in main file.
* Run the db_connector.py file 


