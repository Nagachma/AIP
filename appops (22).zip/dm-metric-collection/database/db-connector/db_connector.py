#!/usr/bin/python
import csv
import os
import platform
import sys
from datetime import datetime, timedelta, timezone
from urllib.parse import quote_plus as urlquote
import logging
import sqlalchemy
import yaml
from cryptography.fernet import Fernet
from vault_utility_v2 import vault_credentials

logger = logging.getLogger('db_connector_script')
logger.setLevel(logging.DEBUG)
# create console handler and set level to debug
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
# add formatter to ch
ch.setFormatter(formatter)
# add ch to logger
logger.addHandler(ch)


def build_connection_string(configs):
    """
    Builds connection string from config data
    """
    # Check for all configs
    if 'dbservice' in configs:
        dbservice = str(configs['dbservice'])
    else:
        logger.error("No dbservice key found")
        raise Exception('No dbservice key found')

    if 'db_username' in configs:
        username = str(configs['db_username'])
    else:
        logger.error("No db_username key found")
        raise Exception('No db_username key found')

    if 'db_password' in configs:
        password = str(configs['db_password'])
        password = urlquote(password)

    else:
        logger.error("No db_password key found")
        raise Exception('No db_password key found')

    if 'db_host' in configs:
        host = str(configs['db_host'])
    else:
        logger.error("No db_host key found")
        raise Exception('No db_host key found')

    if 'db_port' in configs:
        port = str(configs['db_port'])
    else:
        logger.error("No db_port key found")
        raise Exception('No db_port key found')

    if 'db_name' in configs:
        dbname = str(configs['db_name'])
    else:
        logger.error("No db_name key found")
        raise Exception('No db_name key found')

    if str(configs['dbservice']).casefold() == 'oracle':
        if 'sid' in configs:
            sid = str(configs['sid'])
        else:
            logger.error("No sid key found")
            raise Exception('No sid key found')

    # Build connection string
    if 'driver' in configs:
        driver = str(configs['driver'])
        if 'database.windows.net' in str(configs['db_host']) or 'azuresynapse.net' in str(configs['db_host']) or 'mssql' in str(configs['dbservice']):
            return dbservice + '+' + driver + '://' + username + ':' + password + '@' + host + ':' + port + '/' + dbname + str(
                configs['additional_driver'])
        return dbservice + '+' + driver + '://' + username + ':' + password + '@' + host + ':' + port + '/' + dbname

    elif str(configs['dbservice']).casefold() == 'oracle' and 'sid' in configs:
        return dbservice + '://' + username + ':' + password + '@' + host + ':' + port + '/' + sid

    else:
        return dbservice + '://' + username + ':' + password + '@' + host + ':' + port + '/' + dbname


def collect_metrics(cfg, con, tools_dir, conf):
    """
    Collect metrics using config file
    """
    # Add necessary directories
    metrics_dir = tools_dir + "/" + cfg['metrics_dir']
    log_dir = tools_dir + "/" + cfg['log_dir']
    if not os.path.exists(metrics_dir):
        os.makedirs(metrics_dir)
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    # Set frequency
    if conf.get('timefilter_flag') == 1:
        query = cfg['query']
    else:
        freq = cfg['frequency']
        starttime = datetime.now(timezone.utc) - timedelta(minutes=(freq + 1))
        starttime = starttime.replace(second=0).replace(microsecond=0)
        endtime = datetime.now(timezone.utc) - timedelta(minutes=1)
        endtime = endtime.replace(second=0).replace(microsecond=0)

        # If query has a start time and end time, insert actual timestamps
        mod_query = cfg['query'].replace('starttime', "'" + str(starttime) + "'")
        query = mod_query.replace('endtime', "'" + str(endtime) + "'")

    # Prepare outfile and pull metrics
    csv_file = cfg['csv_file']

    #  Get data and save data to existing file
    outfile = metrics_dir + '/' + csv_file + '_' + str(datetime.now().strftime('%m%d%Y')) + '.csv'
    if cfg['operation_type'] == 'read':
        data = con.execute(query)
        # print(data)
        # print("data keys ", data.keys())
        if os.path.isfile(outfile):
            with open(outfile, 'a', newline='') as f:
                writer = csv.writer(f)
                if conf.get("db_info"):
                    values = data.fetchall()
                    for record in values:
                        writer.writerow(list(record) + list(conf['db_info'].values()))
                else:
                    writer.writerows(data.fetchall())
        else:
            with open(outfile, 'w', newline='') as f:
                writer = csv.writer(f)
                if conf.get("db_info"):
                    writer.writerow(list(data.keys()) + list(conf['db_info'].keys()))
                    values = data.fetchall()
                    for record in values:
                        # print("record", type(record))
                        writer.writerow(list(record) + list(conf['db_info'].values()))
                else:
                    writer.writerow(data.keys())
                    writer.writerows(data.fetchall())
        logger.info("Collected metrics data for: " + outfile)

    elif cfg['operation_type'] == 'create':
        con.execute(query)
        logger.info("Create statement executed successfully")



def load_configuration(lconfig):
    """
    Read and load data from config.yaml file
    """
    cfg = {}  # Check if this is a dict
    try:
        with open(lconfig, 'r') as yamlfile:
            cfg = yaml.safe_load(yamlfile)
    except yaml.YAMLError as exc:
        logger.info(exc)
    except Exception as e:
        logger.info(e)
    return cfg


def execute(**inputs):

    base_dir = inputs.get('BASE_HOME_DIR')

    config_path = inputs.get('CONFIG_PATH')

    # Load Query Config
    conf = load_configuration(config_path)

    #Loading creds from vault
    cred = vault_credentials.get_secret_from_vault(conf['vault_path'],conf['vault_keys'])

    # Adding extra details from config in cred dict
    if conf['connection_info'] is not None:
        cred = {**cred, **conf['connection_info']}
    
    # Create engine
    engine = sqlalchemy.create_engine(build_connection_string(cred), echo=True)
    with engine.connect() as con:

        # Execute scenarios
        for scenario in conf['live_scenarios']:
            if scenario.startswith("."):
                logger.info("Skipping " + scenario.split(".")[1])
                continue
            else:
                tools_dir = base_dir + conf['tools_dir']
                logger.info(" --- calling dbconnector collect metric function ---- ")
                collect_metrics(conf['live_scenarios'][scenario], con, tools_dir, conf)

        # Clean up connection
        con.close()
