from cryptography.fernet import Fernet

encdec=1

# generate a key for encryption and decryption
# You can use fernet to generate
# the key or use random key generator
# here I'm using fernet to generate key

#key = Fernet.generate_key()

# Once the key is generated put it in the variable below 
key = 'sxAbWonK0jCUNxaAEfKn6jJfoCyCIDCHuBlh7yxor64='
print("key: ",str(key))

# Instantiate the Fernet class with the key
fernet = Fernet(key)

if 1==encdec:

    # we will be encryting the below string.
    message = "dmuser123"
    
    # then use the Fernet class instance
    # to encrypt the string string must
    # be encoded to byte string before encryption
    encMessage = fernet.encrypt(message.encode())
    
    print("original string: ", message)
    print("encrypted string: ", encMessage)
else:
    # decrypt the encrypted string with the
    # Fernet instance of the key,
    # that was used for encrypting the string
    # encoded byte string is returned by decrypt method,
    # so decode it to string with decode methos
    
    encryptedString="gAAAAABjNrxGG-Kl3ja1VR-7anLdn1gEz2MSRnvnfi-hh_IZc5V6bv9fdgvQjP_5zqX1Y9YwAlR7_u7b7m1sErBNZF6KR1swzQ=="
    print("string to decrypt: ",encryptedString)
    encryptedString=bytes(encryptedString,'utf-8')
    decMessage = fernet.decrypt(encryptedString).decode()
    
    print("decrypted string: ", decMessage)
