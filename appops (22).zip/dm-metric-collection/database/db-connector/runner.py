import db_connector

if __name__ == '__main__':
    db_connector.execute()
