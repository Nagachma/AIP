import calendar
import json
import os
import platform
import time
from datetime import date, datetime
from pathlib import Path
import logging
import pandas as pd
import yaml
from google.cloud import monitoring_v3
from google.oauth2 import service_account
from vault_utility import vault_credentials

logger = logging.getLogger('get_gcp_monitoring_metric.py')
logger.setLevel(logging.DEBUG)
# create console handler and set level to debug
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
# add formatter to ch
ch.setFormatter(formatter)
# add ch to logger
logger.addHandler(ch)

def load_configuration(cwdPath):
    """Read and load data from config.yaml file"""
    cfg = {}  # Check if this is a dict
    try:
        with open(cwdPath, 'r') as yamlfile:
            cfg = yaml.load(yamlfile, Loader=yaml.FullLoader)
            print(cfg)
    except yaml.YAMLError as exc:
        logger.exception(exc)
    except Exception as e:
        logger.exception(e)
    return cfg


def get_credential(config):
    credential_obj = {}
    try:
        secret_keys = vault_credentials.get_secret_from_vault(['keyFileName', 'keyFile'])
        if not secret_keys.get('keyFileName'):
            logger.warning("KeyFileName not found in vault. hence fetching from os env variable/config")
            if os.environ.get('KEY_FILE_NAME'):
                secret_keys['keyFileName'] = os.environ['KEY_FILE_NAME']
            elif config.get('KEY_FILE_NAME'):
                secret_keys['keyFileName'] = config['KEY_FILE_NAME']
            else:
                logger.error("KeyFileName not found in neither os env variable nor config.")
                raise
        if not secret_keys.get('keyFile'):
            logger.error("keyFile not found")
            raise
        json_object = json.dumps(json.loads(secret_keys['keyFile']), indent=10)
        with open(secret_keys['keyFileName'], "w") as outfile:
            outfile.write(json_object)
        credential_obj = service_account.Credentials.from_service_account_file(secret_keys['keyFileName'])
        if os.path.exists(secret_keys['keyFileName']):
            os.remove(secret_keys['keyFileName'])
    except Exception as e:
        logger.error(e)
    return credential_obj


def create_client(dataType, credential):
    client_obj = {}
    if dataType == "timeSeries":  # create client according to the type of data getting fetched
        client_obj = monitoring_v3.MetricServiceClient(credentials=credential)

    return client_obj


def get_monitoring_metric_data(config, service, type, name, credential, service_name, service_group, datatype,
                               per_Series_aligner, cross_Series_Reducer, group, additional_filters):
    # print(service_group)
    dimension_list = service_group['resource_list']
    dimension_name = None
    for d in dimension_list:
        dimension_name = d
    resource_list = service_group['resource_list'].values()
    input_list = [item for sublist in resource_list for item in sublist]
    api_url = service + "{}".format('/') + type  # this is the api url which will be passed in filter
    filter_value = "metric.type = {}".format('"') + api_url + "{}".format('"')
    filter_value = filter_value if additional_filters is None else (filter_value + " " + " ".join(additional_filters))
    project_name = config['PROJECT_NAME']
    project_name_value = "projects/" + project_name
    frequency = config['INTERVAL']
    frequency_seconds = frequency * 60
    per_series_aligner = None
    if per_Series_aligner == 'sum':
        per_series_aligner = monitoring_v3.Aggregation.Aligner.ALIGN_SUM
    elif per_Series_aligner == 'mean':
        per_series_aligner = monitoring_v3.Aggregation.Aligner.ALIGN_MEAN
    elif per_Series_aligner == 'count':
        per_series_aligner = monitoring_v3.Aggregation.Aligner.ALIGN_COUNT
    else:
        per_series_aligner = monitoring_v3.Aggregation.Aligner.ALIGN_NONE
    cross_series_reducer = None
    if cross_Series_Reducer == 'sum':
        cross_series_reducer = monitoring_v3.Aggregation.Reducer.REDUCE_SUM
    elif cross_Series_Reducer == 'mean':
        cross_series_reducer = monitoring_v3.Aggregation.Reducer.REDUCE_MEAN
    elif cross_Series_Reducer=='count':
        cross_series_reducer = monitoring_v3.Aggregation.Reducer.REDUCE_COUNT
    elif cross_Series_Reducer=='none':
        cross_series_reducer = monitoring_v3.Aggregation.Reducer.REDUCE_NONE
    else:
        cross_series_reducer = monitoring_v3.Aggregation.Reducer.REDUCE_NONE
    group_by_fields = group
    aggregation = None
    aggregation = monitoring_v3.Aggregation(
        {
            "alignment_period": f"{frequency_seconds}s",  # {"seconds": frequency_seconds},  # 20 minutes
            "per_series_aligner": per_series_aligner,
            "cross_series_reducer": cross_series_reducer,
            "group_by_fields": group_by_fields,
        }
    )
    # calculating interval
    if not config['HISTORICAL']:
        time_interval = config[
            'INTERVAL']  # time frame within which metric will be collected, 5 mins , 10 mins , 20 mins any number
        time_interval_seconds = time_interval * 60
        now = time.time()  # present time in epoc format
        end_time_seconds = int(now)  # present time in no of seconds, end time will always be greater than start time
        start_time_seconds = end_time_seconds - time_interval_seconds - 60
        # nanos = int((now - end_time_seconds) * 10 ** 9)
        start_time_seconds = calendar.timegm(time.gmtime(start_time_seconds))
        end_time_seconds = calendar.timegm(time.gmtime(end_time_seconds))
        interval_value = monitoring_v3.TimeInterval(
            {
                "end_time": {"seconds": end_time_seconds},
                "start_time": {"seconds": start_time_seconds},
            }
        )

    else:
        start_date_time = config['START_DATE']
        end_date_time = config['END_DATE']
        date_string = '%Y-%m-%d %H:%M:%S'

        start_time_seconds = int(
            calendar.timegm(
                time.strptime(start_date_time, date_string)))  # this is the epoc time converted from date time (UTC)
        end_time_seconds = int(
            calendar.timegm(
                time.strptime(end_date_time, date_string)))  # this is the epoc time converted from date time (UTC)
        interval_value = monitoring_v3.TimeInterval(
            {
                "end_time": {"seconds": end_time_seconds},
                "start_time": {"seconds": start_time_seconds},
            }
        )

    data_type = service_group['data_type']  # metric data is time series
    client = create_client(data_type, credential)
    results = client.list_time_series(
        request={
            "name": project_name_value,
            "filter": filter_value,
            "interval": interval_value,
            "view": monitoring_v3.ListTimeSeriesRequest.TimeSeriesView.FULL,
            "aggregation": aggregation
        }
    )
    today = datetime.now()
    metricdata = []
    for result in results:
        output = result.points
        output2 = result.resource.labels
        # print("Output2")
        # print(output2)
        output3 = result.metric.labels
        for item in output:
            metricDict = {}
            if len(input_list) > 0:
                metricDict["start_time"] = item.interval.start_time
                metricDict["end_time"] = item.interval.end_time
                metricDict["project_id"] = project_name
                # for i in input_list:
                take = False
                take1 = False
                take2 = False
                # resource labels
                for key in output2.keys():
                    if key in dimension_list.keys() and (
                            (output2[key] in dimension_list[key]) or (len(dimension_list[key]) == 0)):
                        take1 = True
                        dim_value = output2[key]
                        metricDict[key] = dim_value
                # metric labels
                for key in output3.keys():
                    if key in dimension_list.keys() and (
                            (output3[key] in dimension_list[key]) or (len(dimension_list[key]) == 0)):
                        take2 = True
                        dim_value = output3[key]
                        metricDict[key] = dim_value
                take = take1 and take2
                if take:
                    metricDict["metric_type"] = type
                    metricDict["metric_name"] = name
                    if datatype == 'double':
                        metricDict['metric_value'] = item.value.double_value
                    elif datatype == 'int':
                        metricDict["metric_value"] = item.value.int64_value
                    elif datatype == 'string':
                        metricDict["metric_value"] = item.value.string_value
                    metricdata.append(metricDict)
                else:
                    continue
            elif len(input_list) == 0:
                # for key in output2.keys():
                #     if key == dimension_name:
                metricDict["start_time"] = item.interval.start_time
                metricDict["end_time"] = item.interval.end_time
                metricDict["project_id"] = project_name
                # metricDict[key] = output2[key]

                # resource labels
                for key in output2.keys():
                    if key in dimension_list.keys():
                        metricDict[key] = output2[key]

                # metric labels
                for key in output3.keys():
                    if key in dimension_list.keys():
                        metricDict[key] = output3[key]

                metricDict["metric_type"] = type
                metricDict["metric_name"] = name
                if datatype == 'double':
                    metricDict['metric_value'] = item.value.double_value
                elif datatype == 'int':
                    metricDict["metric_value"] = item.value.int64_value
                elif datatype == 'string':
                    metricDict["metric_value"] = item.value.string_value
                metricdata.append(metricDict)

    if metricdata and len(metricdata) > 0:
        df = pd.DataFrame(metricdata)
    else:
        df = pd.DataFrame()
    return df


def save_csv(lst_concat_df_obj, output_file_path_str):
    # dataFrame = pd.DataFrame(results)
    # lst_concat_df_obj.to_csv(output_file_path_str, index=False)
    path_to_check = Path(output_file_path_str)
    if (not path_to_check.is_file()) or (
            path_to_check.is_file() and os.stat(output_file_path_str).st_size == 0):
        lst_concat_df_obj.to_csv(output_file_path_str, mode='a',
                                 index=False, header=True)
    else:
        lst_concat_df_obj.to_csv(output_file_path_str, mode='a',
                                 index=False, header=False)


def execute(**inputs):
    pwd = os.path.dirname(os.path.realpath(__file__))
    # logger.info(str(pwd))
    config = {}
    if inputs.get('CONFIG_PATH'):
        config = load_configuration(inputs.get('CONFIG_PATH'))

    if inputs.get('START_DATE') and inputs.get('END_DATE'):
        config['START_DATE'] = inputs.get('START_DATE')
        config['END_DATE'] = inputs.get('END_DATE')

    credential = get_credential(config=config)
    # API call

    list_of_resouces = config['SERVICES']['LIST']
    for service_name in list_of_resouces:
        for service_group in config[service_name]:
            service_type = service_group['service_type']
            metrics_list = service_group['METRIC_LIST']
            final_result = []
            header = ['start_time', 'end_time', 'project_id'] + list(service_group['resource_list'].keys()) + [
                'metric_type', 'metric_name', 'metric_value']
            lst_concat_df = pd.DataFrame(final_result, columns=header)
            for metric_key, metric_record in metrics_list.items():
                service = metric_record['service']  # this field has the type of service whether big query or any other
                metric_type = metric_record['type']  # this field has the metric type of service which will be collected
                metric_name = metric_record[
                    'name']  # this field has the name of service which will be collected as per group by fields
                metric_datatype = metric_record['datatype']
                metric_per_series_aligner = metric_record['per_series_aligner']
                metric_cross_series_aligner = metric_record['cross_Series_Reducer']
                metric_group = metric_record['group_by']
                additional_filter = metric_record.get('additional_filter')
                results = get_monitoring_metric_data(config, service, metric_type, metric_name, credential,
                                                     service_name,
                                                     service_group, metric_datatype, metric_per_series_aligner,
                                                     metric_cross_series_aligner,
                                                     metric_group,
                                                     additional_filter)  # results is a dataframeprint(results)
                if not results.empty:
                    lst_concat_df = pd.concat([lst_concat_df, results])

            if not lst_concat_df.empty and 'start_time' in list(lst_concat_df.columns):
                lst_concat_df.sort_values(by=['start_time'], inplace=True)
            # creating and updating CSV
            # fetching current date
            today = date.today()
            year = today.year
            month = today.month
            day = today.day
            if len(str(month)) == 1:
                month = '0' + str(month)
            else:
                month = str(month)
            if len(str(day)) == 1:
                day = '0' + str(day)
            else:
                day = str(day)

            bsdir = ''
            if inputs.get('BASE_HOME_DIR'):
                bsdir = inputs['BASE_HOME_DIR']
            ts = str(year) + str(month) + str(day)

            output_file_name = "_".join([service_group['name'].lower(), service_name.lower(), "metrics", ts]) + '.csv'

            if service_group['csvpath'] != '':
                if not os.path.exists(bsdir + service_group['csvpath']):
                    # if not then create it
                    os.makedirs(bsdir + service_group['csvpath'], exist_ok=True)

                output_file_path = "{0}{1}{2}{3}".format(bsdir, service_group['csvpath'], '/', output_file_name)
            else:
                if platform.system() == 'Windows':
                    output_file_path = "{0}{1}{2}".format(pwd, '\\', output_file_name)
                else:
                    output_file_path = "{0}{1}{2}".format(pwd, '/', output_file_name)
            if lst_concat_df.empty:
                # Creating empty csv with header
                lst_concat_df = pd.DataFrame(columns=header)
                save_csv(lst_concat_df, output_file_path)
            else:
                save_csv(lst_concat_df, output_file_path)
