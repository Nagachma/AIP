import get_gcp_monitoring_metric

if __name__ == '__main__':
    input_dict = {
        'CONFIG_PATH': 'config.yaml',
        'BASE_HOME_DIR': ''
        # 'START_DATE': '2022-12-08 00:00:00',
        # 'END_DATE': '2022-12-08 17:15:00'
    }

    get_gcp_monitoring_metric.execute(**input_dict)
