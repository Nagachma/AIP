"""
Utility module to fetch GCP logs.
"""
from google.cloud import logging_v2 as cloud_logging


def fetch_logs_with_filter(custom_filter: str, credential):
    """
    Takes filter string as input and returns a generator that can be used to iterate over logs.
    """
    client = cloud_logging.Client(credentials=credential)
    return client.list_entries(filter_=custom_filter)
