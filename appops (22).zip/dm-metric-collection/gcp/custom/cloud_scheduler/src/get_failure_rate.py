"""
Custom script to fetch failure rate of GCP cloud scheduler.
"""
import logging
import os
from datetime import datetime as dt
from datetime import timezone, timedelta

import pandas as pd
import yaml
from gcp.common.gcp_logging import fetch_logs
from googleapiclient import discovery
from google.cloud import scheduler_v1
from google.oauth2 import service_account
from vault_utility import vault_credentials
import json

logger = logging.getLogger('get_failure_rate')
logger.setLevel(logging.INFO)

# create console handler and set level to debug
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.DEBUG)

# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# add formatter to console_handler
console_handler.setFormatter(formatter)

# add console_handler to logger
logger.addHandler(console_handler)


def get_credential(config):
    credential_obj = {}
    try:
        secret_keys = vault_credentials.get_secret_from_vault(['keyFileName', 'keyFile'])
        if not secret_keys.get('keyFileName'):
            logger.warning("KeyFileName not found in vault. hence fetching from os env variable/config")
            if os.environ.get('KEY_FILE_NAME'):
                secret_keys['keyFileName'] = os.environ['KEY_FILE_NAME']
            elif config.get('KEY_FILE_NAME'):
                secret_keys['keyFileName'] = config['KEY_FILE_NAME']
            else:
                logger.error("KeyFileName not found in neither os env variable nor config.")
                raise
        if not secret_keys.get('keyFile'):
            logger.error("keyFile not found")
            raise
        json_object = json.dumps(json.loads(secret_keys['keyFile']), indent=10)
        with open(secret_keys['keyFileName'], "w") as outfile:
            outfile.write(json_object)
        credential_obj = service_account.Credentials.from_service_account_file(secret_keys['keyFileName'])
        if os.path.exists(secret_keys['keyFileName']):
            os.remove(secret_keys['keyFileName'])
    except Exception as e:
        logger.error(e)
    return credential_obj


def load_configuration(lconfig):
    """Read and load data from config.yaml file"""
    cfg = {}
    try:
        with open(lconfig, 'r') as yaml_file:
            cfg = yaml.safe_load(yaml_file)
    except yaml.YAMLError as exc:
        logger.exception(exc)
    except Exception as e:
        logger.exception(e)
    return cfg


def save_df_to_csv(output, start_time, output_dir):
    """
    Method to save df to file
    """

    if output_dir != '' and not os.path.exists(output_dir):
        logger.info("Creating csv path directory, as directory doesn't exist")
        os.makedirs(output_dir, exist_ok=True)

    file_path = f"{output_dir}/jobsfailure_cloudscheduler_metrics_{start_time.strftime('%d%m%Y%H%M')}.csv"

    logger.info("Saving DF into csv file with length %d at path : %s", len(output), file_path)
    output.to_csv(file_path, index=False)


def get_locations(project_name, credential):
    service = discovery.build('cloudscheduler', 'v1', credentials=credential)

    location_array = []
    req = service.projects().locations().list(name=project_name)
    while True:
        res = req.execute()

        for location in res.get('locations', []):
            location_array.append(location['labels']['cloud.googleapis.com/region'])

        req = service.projects().locations().list_next(previous_request=req, previous_response=res)
        if req is None:
            break

    logger.info(f"Locations in project are : {location_array}")

    return location_array


def get_cloud_scheduler_jobs(project_name, location_list, credential):
    client = scheduler_v1.CloudSchedulerClient(credentials=credential)

    jobs = []
    for location in location_list:
        request = scheduler_v1.ListJobsRequest(parent=f"{project_name}/locations/{location}")

        result_page = client.list_jobs(request=request)
        for r in result_page:
            jobs.append(r.name)

    jobs = [job.split('/')[-1] for job in jobs]

    logger.info(f"Jobs associated with project are: {jobs}")

    return jobs


def count_logs(filter_str: str, credential):
    gen = fetch_logs.fetch_logs_with_filter(filter_str, credential)
    count = 0

    while True:
        try:
            next(gen)
            count += 1
        except StopIteration:
            gen.close()
            return count


def fetch_data_from_logs(jobs: list, config: dict, credential):
    count_started_list = []
    count_failure_list = []

    for job in jobs:
        count_started_list.append(count_logs(f""" resource.type="cloud_scheduler_job" AND
                                    resource.labels.job_id= "{job}" AND
                                    jsonPayload.@type =~ "AttemptStarted" AND
                                    timestamp >= "{config.get('START_DATE')}" AND
                                    timestamp <= "{config.get('END_DATE')}" """, credential))

        count_failure_list.append(count_logs(f""" resource.type="cloud_scheduler_job" AND
                                    resource.labels.job_id= "{job}" AND
                                    jsonPayload.@type =~ "AttemptFinished" AND
                                    jsonPayload.status != "SUCCESS" AND
                                    timestamp >= "{config.get('START_DATE')}" AND
                                    timestamp <= "{config.get('END_DATE')}" """, credential))

    return count_started_list, count_failure_list


def create_df(jobs, start_count_list, failure_count_list, start_date, end_date):
    return pd.DataFrame({'start_time': ([start_date] * len(jobs)),
                         'end_time': ([end_date] * len(jobs)),
                         'job_id': jobs,
                         'job_start_count': start_count_list,
                         'job_failure_count': failure_count_list,
                         'job_failure_rate': [
                             round(((failure_count / start_count) * 100), 2) if failure_count != 0 else 0.00
                             for start_count, failure_count in zip(start_count_list, failure_count_list)]})


def check_dates(inputs, config, start_time):
    env_start_date = os.getenv('START_DATE')
    env_end_date = os.getenv('END_DATE')
    if config.get('START_DATE') is not None and config.get('END_DATE') is not None:
        pass
    elif inputs.get('START_DATE') is not None and inputs.get('END_DATE') is not None:
        config['START_DATE'] = inputs.get('START_DATE')
        config['END_DATE'] = inputs.get('END_DATE')
    elif env_start_date is not None and env_end_date is not None:
        config['START_DATE'] = env_start_date
        config['END_DATE'] = env_end_date
    elif config.get('INTERVAL') is not None:
        config['START_DATE'] = (start_time - timedelta(minutes=config.get('INTERVAL'))).strftime('%Y-%m-%dT%H:%M:00Z')
        config['END_DATE'] = start_time.strftime('%Y-%m-%dT%H:%M:00Z')
    else:
        raise Exception('No Start Date, End Date or Interval')


def execute(**inputs):
    """
    Execution method to be called from the framework with relevant inputs.
    """

    start_time = dt.now(timezone.utc)

    logger.info(" --- calling GCP Cloud Scheduler Failure Rate Custom Script ---- ")

    config = load_configuration(inputs.get('CONFIG_PATH'))

    credential = {}
    if os.getenv("GOOGLE_APPLICATION_CREDENTIALS") is not None:
        credential = None
    elif inputs.get('CREDS_FILE') is not None and len(inputs.get('CREDS_FILE')) != 0:
        credential = service_account.Credentials.from_service_account_file(inputs.get('CREDS_FILE'))
        # os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = inputs.get('CREDS_FILE')
    else:
        credential = get_credential(config=config)

    check_dates(inputs, config, start_time)

    project = f"projects/{config.get('PROJECT_ID')}"

    logger.info("Listing all locations and cloud scheduler jobs of project id : %s ", config.get('PROJECT_ID'))

    jobs = get_cloud_scheduler_jobs(project, get_locations(project, credential), credential)

    logger.info("Fetching data from logs")

    start_count_list, failure_count_list = fetch_data_from_logs(jobs, config, credential)

    logger.info("Creating output df and writing to output file")

    save_df_to_csv(
        create_df(jobs, start_count_list, failure_count_list, config.get('START_DATE'), config.get('END_DATE')),
        start_time,
        config.get('OUTPUT_DIR', 'output'))

    logger.info("---- End of logging ----")
    logger.info(f"Total execution time ={divmod((dt.now(timezone.utc) - start_time).total_seconds(), 60)}")
