import get_failure_rate

if __name__ == '__main__':
    input_dict = {
        'CREDS_FILE': 'C:/Users/jatin.a.singh/Documents/gcp/acn-aip-nextgen-41a2abf1d3b8.json',
        'CONFIG_PATH': 'config.yaml'
    }
    get_failure_rate.execute(**input_dict)
