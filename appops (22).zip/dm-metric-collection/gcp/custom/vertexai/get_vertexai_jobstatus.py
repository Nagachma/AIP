import os
import csv
import datetime
import pandas as pd
from google.cloud import aiplatform_v1
from datetime import datetime,timezone

project_location = "us-central1"
project_id = "acn-aip-nextgen"
project_api_endpoint = "us-central1-aiplatform.googleapis.com"

def save_to_csv(final_data):
    current_date = datetime.now()
    pwd = os.path.dirname(os.path.realpath(__file__))
    path = pwd+"\\trainingjobstate_vertexai_metrics_"+str(current_date.year)+str("{:0>2d}".format(int(current_date.month)))+str("{:0>2d}".format(int(current_date.day)))+".csv"

    with open(path, 'w') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=final_data.keys())
        writer.writeheader()
        writer.writerows(final_data)

def sample_list_custom_jobs():
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = r'C:\Users\ross.charles.nitura\PycharmProjects\pythonProject_test\gcp\gcp\vertexai\collection\acn-aip-nextgen-41a2abf1d3b8.json'
    api_endpoint: str = project_api_endpoint
    client_options = {"api_endpoint": api_endpoint}
    location: str = project_location
    project: str = project_id
    client = aiplatform_v1.JobServiceClient(client_options=client_options)
    request = aiplatform_v1.ListCustomJobsRequest(parent=f"projects/{project}/locations/{location}")
    response = client.list_custom_jobs(request=request)

    final_data = {
        "start_time": [],
        "end_time": [],
        "project_id": [],
        "job_id": [],
        "job_status": [],
        "job_duration": []
    }

    metric_data_holder =[]
    previousValue = ""
    metric_response_counter = 0
    end_time_check = 0

    for job_id_list in str(response).split("\n"):
        if ("name: \"projects" in job_id_list):
            job_id = job_id_list.split(': ')[1].split('/')[5].replace("\"","")
            final_data["job_id"].append(job_id)
            final_data["project_id"].append(project)
            os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = r'C:\Users\ross.charles.nitura\PycharmProjects\pythonProject_test\gcp\gcp\vertexai\collection\acn-aip-nextgen-41a2abf1d3b8.json'
            client = aiplatform_v1.JobServiceClient(client_options=client_options)
            request = aiplatform_v1.GetCustomJobRequest(
                name=f"projects/{project}/locations/{location}/customJobs/{str(job_id)}",
            )
            response = client.get_custom_job(request=request)

            for j in str(response).split("\n"):
                metric_response_counter += 1
                if ("state:" in j):
                    print(j)
                    job_state = j.split(': ')[1]
                    final_data["job_status"].append(job_state)

                if ("start_time" in previousValue):
                    if ("seconds" in j):
                        epochTime = int(str(j.split(': ')[1]))
                        start_time = datetime.fromtimestamp(epochTime, timezone.utc)
                        print("start_time: " + str(start_time))
                        final_data["start_time"].append(str(start_time))
                        end_time_check = 1

                if ("end_time" in previousValue):
                    if ("seconds" in j):
                        epochTime = int(str(j.split(': ')[1]))
                        end_time = datetime.fromtimestamp(epochTime, timezone.utc)
                        print("end_time: " + str(str(end_time)))
                        final_data["end_time"].append(str(end_time))
                        job_duration = str((end_time - start_time).total_seconds())
                        final_data["job_duration"].append(str(job_duration))
                        end_time_check = 0
                        metric_response_counter = 0
                if(len(str(response).split("\n")) == metric_response_counter):
                    print("check")
                    if (end_time_check == 1):
                        print("none")
                        final_data["end_time"].append("NULL")
                        final_data["job_duration"].append("NULL")
                        end_time_check = 0
                        metric_response_counter =0

                previousValue = j
            #print("-----")

    current_date = datetime.now()
    pwd = os.path.dirname(os.path.realpath(__file__))
    path = pwd + "\\trainingjobstate_vertexai_metrics_" + str(current_date.year) + str(
        "{:0>2d}".format(int(current_date.month))) + str("{:0>2d}".format(int(current_date.day))) + ".csv"

    print(str(final_data))

    pd.DataFrame(final_data).to_csv(path, index=False)

if __name__ == '__main__':
    sample_list_custom_jobs()
