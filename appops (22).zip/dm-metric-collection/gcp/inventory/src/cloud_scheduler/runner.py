import get_from_cloud_scheduler_api

if __name__ == '__main__':
    input_dict = {
        'CREDS_FILE': 'C:/Users/jatin.a.singh/Documents/gcp/acn-aip-nextgen-41a2abf1d3b8.json',
        'CONFIG_PATH': 'config.yaml'
    }
    get_from_cloud_scheduler_api.execute(**input_dict)
