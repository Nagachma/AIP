"""
Module for Inventory of GCP based on the inputs received.
"""
import logging
import os
import pymongo
from datetime import datetime as dt
from datetime import timezone, timedelta

import pandas as pd
import yaml
from dateutil import parser as dt_parser
from google.cloud import asset_v1
from google.cloud import asset_v1p1beta1
from google.oauth2 import service_account
from vault_utility import vault_credentials
from gcp.common.gcp_logging import fetch_logs
import json
from gcp.inventory.src.cloud_scheduler import get_from_cloud_scheduler_api
from pymongo import MongoClient

logger = logging.getLogger('gcp_inventory')
logger.setLevel(logging.INFO)

# create console handler and set level to debug
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.DEBUG)

# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# add formatter to console_handler
console_handler.setFormatter(formatter)

# add console_handler to logger
logger.addHandler(console_handler)


def get_credential(config):
    credential_obj = {}
    try:
        secret_keys = vault_credentials.get_secret_from_vault(['keyFileName', 'keyFile'])
        if not secret_keys.get('keyFileName'):
            logger.warning("KeyFileName not found in vault. hence fetching from os env variable/config")
            if os.environ.get('KEY_FILE_NAME'):
                secret_keys['keyFileName'] = os.environ['KEY_FILE_NAME']
            elif config.get('KEY_FILE_NAME'):
                secret_keys['keyFileName'] = config['KEY_FILE_NAME']
            else:
                logger.error("KeyFileName not found in neither os env variable nor config.")
                raise
        if not secret_keys.get('keyFile'):
            logger.error("keyFile not found")
            raise
        json_object = json.dumps(json.loads(secret_keys['keyFile']), indent=10)
        with open(secret_keys['keyFileName'], "w") as outfile:
            outfile.write(json_object)
        credential_obj = service_account.Credentials.from_service_account_file(secret_keys['keyFileName'])
        if os.path.exists(secret_keys['keyFileName']):
            os.remove(secret_keys['keyFileName'])
    except Exception as e:
        print(repr(e))
        logger.error(e)
    return credential_obj


def load_configuration(lconfig):
    """Read and load data from config.yaml file"""
    cfg = {}
    try:
        with open(lconfig, 'r') as yaml_file:
            cfg = yaml.safe_load(yaml_file)
    except yaml.YAMLError as exc:
        print(exc)
        logger.exception(exc)
    except Exception as e:
        print(e)
        logger.exception(e)
    return cfg


def fetch_created_by_from_logs(resource_name: str, project_id: str, create_time: str, credential):
    """
    Method to fetch created by info from audit/activity logs.
    """

    logger.info("Fetching created by data from audit activity logs for : %s", resource_name)

    split_resource_name = list(filter(lambda x: len(x) > 0, resource_name.split('/')))

    entries = fetch_logs.fetch_logs_with_filter(
        f""" logName = "projects/{project_id}/logs/cloudaudit.googleapis.com%2Factivity" AND
                                (protoPayload.resourceName =~ "{split_resource_name[-1]}" OR
                                protoPayload.response.name =~ "{split_resource_name[-1]}" OR
                                protoPayload.request.job_id =~ "{split_resource_name[-1]}" OR
                                protoPayload.response.uri =~ "{split_resource_name[-1]}") AND
                                protoPayload.methodName =~ ("create" OR 
                                "Create" OR 
                                "InsertDataset" OR 
                                "InsertTable") AND
                                protoPayload.serviceName =~  "{split_resource_name[0]}" AND 
                                timestamp >= "{create_time}+00:03" AND
                                timestamp <= "{create_time}-00:01" """,
        credential)

    try:
        first_log = next(entries)
        logger.info('Created By User fetched successfully for %s.', resource_name)
        return dict(dict(first_log.payload).get('authenticationInfo')).get('principalEmail')
    except StopIteration:
        logger.info("No logs found for %s", resource_name)
        entries.close()
        return None


def fetch_relevant_data_from_inventory_api(inventory_data, credential, config) -> pd.DataFrame:
    """
    Method to organise data into pandas dataframe.
    """
    asset_name_list = []
    asset_type_list = []
    create_time_list = []
    update_time_list = []
    created_by_list = []
    parent_name_list = []

    logger.info("Creating pandas dataframe from information from assets API")

    for page in inventory_data:
        for assets in list(page):
            asset_data = asset_v1.types.assets.Asset(assets.asset)
            asset_name_list.append(asset_data.name.split('/')[-1])
            asset_type_list.append(asset_data.asset_type)
            asset_meta_data = dict(asset_data.resource.data)

            creation_time = None
            if asset_meta_data.get('timeCreated') is not None:
                creation_time = asset_meta_data.get('timeCreated')
            elif dict(asset_data.resource.data).get('createTime') is not None:
                creation_time = dict(asset_data.resource.data).get('createTime')
            elif dict(asset_data.resource.data).get('creationTime') is not None:
                # creation_time = str(dt.fromtimestamp(int(dict(asset_data.resource.data).get('creationTime')) / 1e3)
                #                     .astimezone(timezone.utc)).replace(' ', 'T')
                # creation_time[-6:] = "Z"
                creation_time = (dt.fromtimestamp(int(dict(asset_data.resource.data).get('creationTime')) / 1e3)
                                 .astimezone(timezone.utc)).strftime('%Y-%m-%dT%H:%M:%S.%fZ')

            create_time_list.append(creation_time)
            update_time_list.append((asset_data.update_time
                                     if asset_data.update_time is not None
                                     else asset_meta_data.get('updated')).strftime('%Y-%m-%dT%H:%M:%S.%fZ'))
            # update_time_list.append(asset_meta_data.get('updated'))
            # print('owner : {}'.format(asset_meta_data.get('owner')))
            created_by_list.append(None
                                   if creation_time is None or
                                      (dt.now(timezone.utc) - dt_parser.parse(creation_time))
                                   .days > 400 else
                                   fetch_created_by_from_logs(asset_data.name, config.get('PROJECT_ID'),
                                                              creation_time.split('.')[0],
                                                              credential))
            parent_name_list.append('/'.join(asset_data.resource.parent.split('/')[-2:]))

    return pd.DataFrame({
        'asset_name': asset_name_list,
        'asset_type': asset_type_list,
        'create_time': create_time_list,
        'update_time': update_time_list,
        'created_by': created_by_list,
        'parent': parent_name_list})


def save_df_to_csv(output, start_time, output_dir, file_name):
    """
    Method to save df to file
    """

    if output_dir != '' and not os.path.exists(output_dir):
        logger.info("Creating csv path directory, as directory doesn't exist")
        os.makedirs(output_dir, exist_ok=True)

    file_path = f"{output_dir}/{file_name}_{start_time.strftime('%d%m%Y%H%M')}.csv"

    logger.info("Saving DF into csv file with length %d at path : %s", len(output), file_path)
    output.to_csv(file_path, index=False)


def ingest_into_mongo(config, common_output_df, cloud_scheduler_df):
    logger.info('Retrieving last list from mongo db.')
    mongo_config = config['MONGO']
    client = MongoClient(mongo_config['URL'])
    db = client.get_database(mongo_config['DATABASE'])
    collection = db.get_collection(mongo_config['COLLECTION'])

    # Retrieve existing data from mongo
    existing_list = collection.find().sort(config['COLLECTION_FIELDS']['INSERTED_TIME'], pymongo.DESCENDING)
    resources_dict = {}
    for item in existing_list:
        # print(item)
        resources_dict = item
        break

    default_collection_field_names = {'INSERTED_TIME': 'insertedTime',
                                      'LAST_MODIFIED_TIME': 'lastModifiedOn',
                                      'CREATED_ON': 'createdOn',
                                      'CREATED_BY': 'createdBy',
                                      'PARENT': 'parent'}

    collection_fields = config.get('COLLECTION_FIELDS', default_collection_field_names)

    for key in default_collection_field_names:
        if key not in collection_fields.keys():
            collection_fields[key] = default_collection_field_names[key]

    doc_to_insert = {'projectId': config.get('PROJECT_ID')}

    asset_type_list = list(set(
        (config.get('ASSET_TYPES', []) if config.get('ASSET_TYPES') is not None else []) +
        (config.get('BETA_V1_ASSET_TYPE', []) if config.get('BETA_V1_ASSET_TYPE') is not None else [])))

    if cloud_scheduler_df is not None:
        asset_type_list.append('cloudscheduler.googleapis.com/Jobs')

    assets = list()

    for selected_asset_type in asset_type_list:
        active_list = []

        if selected_asset_type != 'cloudscheduler.googleapis.com/Jobs':

            for i, row in common_output_df[common_output_df['asset_type'] == selected_asset_type].iterrows():

                asset_dict = {
                    "name": row['asset_name']
                }

                if row['parent'] is not None:
                    asset_dict[collection_fields.get('PARENT')] = row['parent']
                if row['created_by'] is not None:
                    asset_dict[collection_fields.get('CREATED_BY')] = row['created_by']
                if row['update_time'] is not None:
                    asset_dict[collection_fields.get('LAST_MODIFIED_TIME')] = dt_parser.parse(row['update_time'])
                if row['create_time'] is not None:
                    asset_dict[collection_fields.get('CREATED_ON')] = dt_parser.parse(row['create_time'])

                active_list.append(asset_dict)

        else:

            for i, row in cloud_scheduler_df.iterrows():

                asset_dict = {
                    "name": row['job_id']
                }

                if row['user_update_time'] is not None:
                    asset_dict[collection_fields.get('LAST_MODIFIED_TIME')] = dt_parser.parse(row['user_update_time'])

                active_list.append(asset_dict)

        if selected_asset_type in resources_dict.keys():
            deleted_list = list(
                set([a['name'] for a in resources_dict[selected_asset_type]['active']])
                .difference([a['name'] for a in active_list]))
        else:
            deleted_list = []

        assets.append({selected_asset_type: {'active': active_list, 'deleted': deleted_list}})

    doc_to_insert["assets"] = assets
    doc_to_insert[collection_fields.get('INSERTED_TIME')] = dt.now(tz=timezone.utc)

    collection.insert_one(doc_to_insert)

    logger.info('Document inserted into mongo db collection.')


def execute(**inputs):
    """
    Execution method to be called from the framework with relevant inputs.
    """

    start_time = dt.now()

    logger.info(" --- calling GCP inventory ---- ")

    config = load_configuration(inputs.get('CONFIG_PATH'))

    credential = {}
    if os.getenv("GOOGLE_APPLICATION_CREDENTIALS") is not None:
        credential = None
    elif inputs.get('CREDS_FILE') is not None and len(inputs.get('CREDS_FILE')) != 0:
        credential = service_account.Credentials.from_service_account_file(inputs.get('CREDS_FILE'))
        # os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = inputs.get('CREDS_FILE')
    else:
        credential = get_credential(config=config)

    project_resource = f"projects/{config.get('PROJECT_ID')}"

    logger.info("Listing all assets of project id : %s and type : %s", config.get('PROJECT_ID'),
                config.get('ASSET_TYPES'))

    if config.get('ASSET_TYPES') is not None and len(config.get('ASSET_TYPES')) != 0:
        client = asset_v1.AssetServiceClient(credentials=credential)
        response = client.list_assets(
            request={
                "parent": project_resource,
                "read_time": None,
                "asset_types": config.get('ASSET_TYPES'),
                "page_size": 1000,
            }
        )
    else:
        response = []

    logger.info("Listing all assets of project id : %s and type : %s", config.get('PROJECT_ID'),
                config.get('BETA_V1_ASSET_TYPE'))

    if config.get('BETA_V1_ASSET_TYPE') is not None and len(config.get('BETA_V1_ASSET_TYPE')) != 0:
        beta_client = asset_v1p1beta1.AssetServiceClient(credentials=credential)
        beta_response = beta_client.search_all_resources(
            request={
                "scope": project_resource,
                "asset_types": config.get('BETA_V1_ASSET_TYPE'),
                "page_size": 500,
            }
        )
    else:
        beta_response = []

    asset_names_list = []

    inventory_data = []

    for asset in response:
        asset_names_list.append(asset.name)

    for asset in beta_response:
        asset_names_list.append(asset.name)

    for asset_names in [asset_names_list[x:x + 100] for x in range(0, len(asset_names_list), 100)]:
        logger.info("Getting asset history of assets, asset names: %s", asset_names)
        client = asset_v1.AssetServiceClient(credentials=credential)
        content_type = asset_v1.ContentType.RESOURCE
        read_time_window = asset_v1.TimeWindow()
        response = client.batch_get_assets_history(
            request={
                "parent": project_resource,
                "asset_names": asset_names,
                "content_type": content_type,
                "read_time_window": read_time_window,
            }
        )
        inventory_data.append(response.assets)

    common_output_df = fetch_relevant_data_from_inventory_api(inventory_data, credential, config)

    save_df_to_csv(common_output_df, start_time, config.get('OUTPUT_DIR', 'output'),
                   config.get('FILE_NAME', 'common_inventory_metrics'))

    if config.get('COLLECT_CLOUD_SCHEDULER'):
        cloud_scheduler_df = get_from_cloud_scheduler_api. \
            execute(CONFIG_PATH=config.get('JOB_SCHEDULER_CONFIG_PATH', 'cloud_scheduler/config.yaml'),
                    CREDENTIAL=credential)
    else:
        cloud_scheduler_df = None

    ingest_into_mongo(config, common_output_df, cloud_scheduler_df)

    logger.info("---- End of logging ----")
    logger.info(f"Total execution time ={divmod((dt.now() - start_time).total_seconds(), 60)}")
