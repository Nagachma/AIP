import argparse
import importlib.util
import logging
import multiprocessing
import os
import platform
from subprocess import Popen, PIPE

import yaml

logger = logging.getLogger('main.py')
logger.setLevel(logging.DEBUG)
# create console handler and set level to debug
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
# add formatter to ch
ch.setFormatter(formatter)
# add ch to logger
logger.addHandler(ch)


def load_configuration(lconfig):
    """Read and load data from config.yaml file"""
    cfg = {}
    try:
        with open(lconfig, 'r') as yaml_file:
            cfg = yaml.safe_load(yaml_file)
    except yaml.YAMLError as exc:
        logger.exception(exc)
    except Exception as e:
        logger.exception(e)
    return cfg


def line_separator():
    if platform.system() == 'Windows':
        sep = '\\'
    else:
        sep = '/'
    return sep


def module_from_file(module_name, file_path):
    spec = importlib.util.spec_from_file_location(module_name, file_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def exec_func(script_file, args_dict):
    module_ = module_from_file(f"{args_dict['source']}".replace("-", "").casefold(), script_file)
    module_.execute(**args_dict['inputs'])


if __name__ == '__main__':
    command_line_input = False
    parser = argparse.ArgumentParser()
    parser.add_argument('--platform', dest="platform", help='specify the platform for service ',
                        required=True)
    parser.add_argument('--start_date', dest="start_date", help='specify the start date to override config file ',
                        required=False)
    parser.add_argument('--end_date', dest="end_date", help='specify the end date to override config file ',
                        required=False)
    parser.add_argument('--service', dest="service_name", help='specify the service name to run ',
                        required=True)
    parser.add_argument('--config_path', dest="config_path", help='specify the config path for service ',
                        required=False)
    args = parser.parse_args()

    if None in (args.start_date, args.end_date):
        command_line_input = False
    else:
        if args.start_date is not None:
            if args.end_date is None:
                parser.error("Specify end date")
        else:
            command_line_input = True

        if args.end_date is not None:
            if args.start_date is None:
                parser.error("Specify start date")
        else:
            command_line_input = True

        if args.start_date == "":
            parser.error("Specify start date value")
        else:
            command_line_input = True
        if args.end_date == "":
            parser.error("Specify end date value")
        else:
            command_line_input = True

    # load configuration from config yaml
    pwd = os.path.dirname(os.path.realpath(__file__))
    config_file_path = "./config.yaml"
    if args.config_path:
        config_file_path = args.config_path
    else:
        config_file_path = "{0}{1}".format(pwd, line_separator() + 'config.yaml')
    config = load_configuration(config_file_path)

    # fetch Services list from config
    services_config = config['SERVICES']
    script_file_path = ''
    sources = []

    # iterate config to filter based on platform
    for key in services_config.keys():
        if key.casefold() == str(args.platform).casefold():
            # fetch the services of the platform from config
            services = services_config[key]
            for service in services.keys():
                if '.' in service:
                    # skip if the service is disabled for the platform
                    logger.info(f"Skipping Service: {service} , as its disabled by '.' in name")
                    continue
                # if service name matches from list of services in config, then fetch the service config
                if service.casefold().split('_')[0] == args.service_name.casefold():
                    logger.info(service + ' found')
                    logger.info(f'Sources: {str(services[service].keys())}')
                    # iterate each source and fetch its inputs from config
                    for source in services[service].keys():
                        dict1 = {}
                        if '.' in source:
                            # skip if the source is disabled for the service
                            logger.info(f"Skipping source: {source} , as its disabled by '.' in name")
                            pass
                        else:
                            inputs = services[service][source]

                            if inputs.get('CONFIG_PATH') is None:
                                logger.error("CONFIG PATH must be provided for the script to execute. If script "
                                             "doesn't require a config file then give '.' in config_path value")
                                raise Exception("CONFIG PATH must be provided for the script to execute. If script "
                                                "doesn't require a config file then give '.' in config_path value")
                            else:
                                config_path = inputs.get('CONFIG_PATH')
                                if '.' == config_path.strip():
                                    inputs.pop('CONFIG_PATH')
                                else:
                                    base_home_dir = config['BASE_HOME_DIR']
                                    config_path = base_home_dir + config_path
                                    inputs['CONFIG_PATH'] = config_path

                                script_file_path = config['SCRIPT_PATH'][source]

                                # if start_date & end_date passed in the arguments then override the config ones.
                                if args.start_date and args.end_date:
                                    inputs['START_DATE'] = args.start_date
                                    inputs['END_DATE'] = args.end_date

                                inputs['CREDENTIAL_FILE'] = pwd + line_separator() + config['MYSQL_CREDENTIAL_FILE']
                                inputs['BASE_HOME_DIR'] = config['BASE_HOME_DIR']
                                dict1['source'] = source
                                dict1['script_file_path'] = pwd + line_separator() + script_file_path
                                dict1['inputs'] = inputs
                                logger.debug(f"inputs = {str(inputs)}")

                                sources.append(dict1)

    # Set up a list of processes that we want to run
    processes = []
    for item in sources:
        process_obj = multiprocessing.Process(target=exec_func, args=(item['script_file_path'], item))
        processes.append(process_obj)
        process_obj.start()
        logger.info(f"Source '{item['source']}': execution started")

    # wait for all processes to end
    for proc in processes:
        proc.join()

    # check if all collection completed
    # if either of the processes returned non-zero exit code then skip ingestion.
    stop_flag = any(map(lambda p: p.exitcode != 0, processes))
    logger.info(f"stop_flag = {stop_flag}")
    logger.info("End of collection")
    if not stop_flag:
        services_enabled_for_ingestion = config['MONGO_INGESTION']['SERVICES']
        services_enabled_for_ingestion = list(map(lambda s: s.lower(), services_enabled_for_ingestion))
        python_interpreter = config.get('PYTHON_INTERPRETER', 'python')
        if args.service_name.casefold() in services_enabled_for_ingestion:
            ingestion_script_path = config['BASE_HOME_DIR'] + config['MONGO_INGESTION']['TRIGGER_SCRIPT']

            logger.info("Triggering ingestion")
            process = Popen([python_interpreter, ingestion_script_path, args.service_name.casefold()], stdout=PIPE, stderr=PIPE)
            stdout, stderr = process.communicate()
            logger.info(f"stdout: [{stdout.decode('utf-8')}]")
            logger.info(f"stderr: [{stderr.decode('utf-8')}]")

    logger.info("End of main.py")
