"""Custom Script to fetch metrics for a process in Linux CLI"""
import csv
import logging
import os
import platform
from datetime import datetime as dt
import pandas as pd
import yaml
from datetime import timezone, timedelta
import json
import paramiko
import time
import urllib3
from scp import SCPClient
from vault_utility_v2 import vault_credentials

logger = logging.getLogger('collect_from_cli')
logger.setLevel(logging.INFO)

# create console handler and set level to debug
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.DEBUG)

# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# add formatter to console_handler
console_handler.setFormatter(formatter)

# add console_handler to logger
logger.addHandler(console_handler)


def load_configuration(lconfig):
    """Read and load data from config.yaml file"""
    cfg = {}
    try:
        with open(lconfig, 'r') as yaml_file:
            cfg = yaml.safe_load(yaml_file)
    except yaml.YAMLError as exc:
        print(exc)
        logger.exception(exc)
    except Exception as e:
        print(e)
        logger.exception(e)
    return cfg


def save_file_per_day(df, file_path):
    if not os.path.isfile(file_path):
        df.to_csv(file_path, index=False)

    else:
        exist = pd.read_csv(file_path)
        df = pd.concat([exist, df], ignore_index=True)
        df.to_csv(file_path, index=False)


def process_from_cli(config, timestamp):
    create_dir(config.get('BASE_HOME_DIR') + config.get('TMP_DIR'))
    create_dir(config.get('BASE_HOME_DIR') + config.get('OUTPUT_DIR'))

    logger.info('Fetching data for service from ps, iostat and pidstat, and sadf')

    sadf_start_time = timestamp - timedelta(minutes=config.get('INTERVAL'))
    sadf_start_time = sadf_start_time - timedelta(minutes=(sadf_start_time.minute % config.get('INTERVAL')))

    if not config.get('REMOTE'):
        os.system(
            f""" echo "$(ps -C {config.get('PROCESS_NAME')} -o pid,%mem,etime,user | sed 's/\s\+/,/g;s/,/ /19g' | sed 's/^,//')" > {config.get('BASE_HOME_DIR') + config.get('TMP_DIR')}/ps_output.csv """)

        logger.info('Fetching data for service from pidstat')
        time.sleep(3)
        os.system(
            f""" echo "$(pidstat -p $(ps -C "{config.get('PROCESS_NAME')}" -o pid --no-headers | sed ':a;N;$!ba;s/\n/,/g' | sed 's/ //g') -urdhl | sed '1,3d' | sed 's/\s\+/,/g;s/,/ /21g' | sed 's/^.//;s/^,//;s/,$//')" > {config.get('BASE_HOME_DIR') + config.get('TMP_DIR')}/pid_stat_output.csv """)

        logger.info('Fetching data for service from iostat')
        time.sleep(3)

        os.system(
            f""" iostat > {config.get('BASE_HOME_DIR') + config.get('TMP_DIR')}/iostat_output.txt """)
        time.sleep(3)

        logger.info('Fetching data for service from sadf')

        os.system(
            f""" sadf -d -t -h -s {sadf_start_time.strftime('%H:%M:00')} -e {timestamp.strftime('%H:%M:00')} -- -u -w -W -B -b -r -S -v -q | sed 's/;/,/g' | sed 's/# //g' > {config.get('BASE_HOME_DIR') + config.get('TMP_DIR')}/sadf_output.csv """)
        time.sleep(3)

    else:
        try:
            ssh = paramiko.SSHClient()
            if config.get('SSH_CONFIG').get('PEM_FILE') is None or config.get('SSH_CONFIG').get('PEM_FILE') == '':
                cred = vault_credentials.get_secret_from_vault(config['vault_path'], config['vault_keys'])
                if cred.get('ipaddress') is not None:
                    IP = str(cred.get('ipaddress')).strip()
                else:
                    logger.error("No ipaddress found")
                    raise Exception('No ipaddress found')
                
                if cred.get('serviceusername') is not None:
                    username = cred.get('serviceusername')
                else:
                    logger.error("No serviceusername found")
                    raise Exception('No serviceusername found')
                
                if cred.get('servicepassword') is not None:
                    password = cred.get('servicepassword')
                else:
                    logger.error("No servicepassword found")
                    raise Exception('No servicepassword found')
                
                ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                ssh.connect(hostname=str(IP), username=str(username),
                            password=str(password))
            else:
                k = paramiko.RSAKey.from_private_key_file(config['SSH_CONFIG']['PEM_FILE'])
                ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                ssh.connect(hostname=str(IP), username=str(username), pkey=k)

            ssh.exec_command(f""" mkdir -p {config['SSH_CONFIG']['REMOTE_TMP']}""")
            time.sleep(3)
            ssh.exec_command(
                f""" echo "$(ps -C {config.get('PROCESS_NAME')} -o pid,%mem,etime,user | sed 's/\s\+/,/g;s/,/ /19g' | sed 's/^,//')" > {config['SSH_CONFIG']['REMOTE_TMP']}/ps_output.csv """)
            time.sleep(3)
            backslash = "\\"
            n = "n"
            pid_stat_command = f"echo \"$(pidstat -p $(ps -C {config.get('PROCESS_NAME')} -o pid --no-headers | sed ':a;N;$!ba;s/" + f"{backslash}{n}/,/g' | sed 's/ //g') -urdhl | sed '1,3d' | sed 's/\s\+/,/g;s/,/ /21g' | sed 's/^.//;s/^,//;s/,$//')\" > {config['SSH_CONFIG']['REMOTE_TMP']}/pid_stat_output.csv"
            ssh.exec_command(pid_stat_command)
            time.sleep(3)
            ssh.exec_command(f"""iostat > {config['SSH_CONFIG']['REMOTE_TMP']}/iostat_output.txt""")
            time.sleep(3)
            ssh.exec_command(
                f""" sadf -d -t -h -s {sadf_start_time.strftime('%H:%M:00')} -e {timestamp.strftime('%H:%M:00')} -- -u -w -W -B -b -r -S -v -q | sed 's/;/,/g' | sed 's/# //g' > {config['SSH_CONFIG']['REMOTE_TMP']}/sadf_output.csv """)

            # wait till all commands complete their execution
            time.sleep(3)
            with SCPClient(ssh.get_transport(), sanitize=lambda x: x) as scp:
                scp.get(remote_path=config['SSH_CONFIG']['REMOTE_TMP'] + "/ps_output.csv"
                        , local_path=config['SSH_CONFIG']['LOCAL_ABS_PATH'] + config['TMP_DIR'] + "/ps_output.csv")
                scp.get(remote_path=config['SSH_CONFIG']['REMOTE_TMP'] + "/pid_stat_output.csv"
                        , local_path=config['SSH_CONFIG']['LOCAL_ABS_PATH'] + config['TMP_DIR'] + "/pid_stat_output.csv")
                scp.get(remote_path=config['SSH_CONFIG']['REMOTE_TMP'] + f"/iostat_output.txt"
                        , local_path=config['SSH_CONFIG']['LOCAL_ABS_PATH'] + config['TMP_DIR'] + f"/iostat_output.txt")
                scp.get(remote_path=config['SSH_CONFIG']['REMOTE_TMP'] + f"/sadf_output.csv"
                        , local_path=config['SSH_CONFIG']['LOCAL_ABS_PATH'] + config['TMP_DIR'] + f"/sadf_output.csv")

            scp.close()
            ssh.close()
        except Exception as e:
            logger.error("Error in Command execution or VM connection. Please Check.")
            exit(0)

    logger.info('Preparing collected data')

    ps_output = pd.read_csv(f"{config.get('BASE_HOME_DIR') + config.get('TMP_DIR')}/ps_output.csv")
    pid_stat_output = pd.read_csv(f"{config.get('BASE_HOME_DIR') + config.get('TMP_DIR')}/pid_stat_output.csv",
                                  index_col=False, header=None,
                                  names=["# Time", "UID", "PID", "%usr", "%system", "%guest",
                                         "%wait", "%CPU", "CPU", "minflt/s", "majflt/s", "VSZ",
                                         "RSS", "%MEM", "kB_rd/s", "kB_wr/s", "kB_ccwr/s",
                                         "iodelay", "threads"])

    process_df = pd.merge(ps_output, pid_stat_output, how='left', on=['PID'])

    logger.info('Data collection from CLI completed. Data dumped to output files.')

    ts = timestamp.replace(second=0, microsecond=0)

    with open(f"{config['SSH_CONFIG']['LOCAL_ABS_PATH'] + config['TMP_DIR']}/iostat_output.txt", 'r') as iostat:
        line = iostat.readline()
        words = line.split()
        sysname = words[0]
        release = words[1]
        nodename = words[2].replace("(","").replace(")","")
        date = words[3]
        machine = words[4]
        number_of_cpus = words[5].replace("(","")

    with open(f"{config['SSH_CONFIG']['LOCAL_ABS_PATH'] + config['TMP_DIR']}/iostat_output.txt", 'r') as iostat:
        lines = iostat.readlines()
        cpu_words = lines[3].split()
        user = cpu_words[0]
        nice = cpu_words[1]
        system = cpu_words[2]
        iowait = cpu_words[3]
        steal = cpu_words[4]
        idle = cpu_words[5]

    header = ['timestamp','node_name','sys_name','release','machine','number_of_cpus','user','nice','system','iowait','steal','idle','disk_device','tps','kB_read_s','kB_wrtn_s','kB_dscd_s','kB_read','kB_wrtn','kB_dscd']

    with open(f"{config['SSH_CONFIG']['LOCAL_ABS_PATH'] + config['TMP_DIR']}/iostat_output.txt", 'r') as iostat:
        rows = []
        lines = iostat.readlines()
        count = 6
        while count < len(lines):
            row = []
            disk_words = lines[count].split()
            if disk_words is None or len(disk_words) == 0:
                count = count + 1
                continue
            row = [ts.strftime('%Y-%m-%d %H:%M:%S+00:00'),nodename,sysname,release,machine,number_of_cpus,user,nice,system,iowait,steal,idle,disk_words[0],disk_words[1],disk_words[2],disk_words[3],disk_words[4],disk_words[5],disk_words[6],disk_words[7]]
            rows.append(row)
            count = count + 1

    with open(f"{config['SSH_CONFIG']['LOCAL_ABS_PATH'] + config['TMP_DIR']}/iostat_output.csv", 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(header)
        for row in rows:
            writer.writerow(row)

    # iostat_df = iostat_data_to_df(config, ts)
    iostat_df = pd.read_csv(f"{config['SSH_CONFIG']['LOCAL_ABS_PATH'] + config['TMP_DIR']}/iostat_output.csv")

    process_df = pd.merge(iostat_df[['timestamp', 'node_name']].drop_duplicates(), process_df, how='cross')

    try:
        sadf_df = pd.read_csv(f"{config.get('BASE_HOME_DIR') + config.get('TMP_DIR')}/sadf_output.csv")
        sadf_df.timestamp = [ts] * len(sadf_df.timestamp)
    except pd.errors.EmptyDataError:
        sadf_df = pd.DataFrame(columns=["hostname","interval","timestamp","CPU","user","nice","system","iowait","steal","idle[...]","proc/s","cswch/s","pswpin/s","pswpout/s","pgpgin/s","pgpgout/s","fault/s","majflt/s","pgfree/s","pgscank/s","pgscand/s","pgsteal/s","vmeff","tps","rtps","wtps","dtps"])

    create_dir(f"{config.get('BASE_HOME_DIR') + config.get('OUTPUT_DIR')}/process")
    create_dir(f"{config.get('BASE_HOME_DIR') + config.get('OUTPUT_DIR')}/iostat")
    create_dir(f"{config.get('BASE_HOME_DIR') + config.get('OUTPUT_DIR')}/sadf")

    save_file_per_day(process_df,
                      f"{config.get('BASE_HOME_DIR') + config.get('OUTPUT_DIR')}/process/process_{config.get('SERVICE_NAME').lower()}_metrics_{timestamp.strftime('%d%m%Y')}.csv")

    save_file_per_day(iostat_df,
                      f"{config.get('BASE_HOME_DIR') + config.get('OUTPUT_DIR')}/iostat/iostat_{config.get('SERVICE_NAME').lower()}_metrics_{timestamp.strftime('%d%m%Y')}.csv")

    save_file_per_day(sadf_df,
                      f"{config.get('BASE_HOME_DIR') + config.get('OUTPUT_DIR')}/sadf/sadf_{config.get('SERVICE_NAME').lower()}_metrics_{timestamp.strftime('%d%m%Y')}.csv")

    return process_df, iostat_df, sadf_df


# def iostat_data_to_df(config, ts):
#
#     node_name = []
#     sys_name = []
#     release = []
#     machine = []
#     number_of_cpus = []
#     user = []
#     nice = []
#     system = []
#     iowait = []
#     steal = []
#     idle = []
#     disk_device = []
#     tps = []
#     kB_read_s = []
#     kB_wrtn_s = []
#     kB_dscd_s = []
#     kB_read = []
#     kB_wrtn = []
#     kB_dscd = []
#
#     data = json.load(open(f"{config.get('BASE_HOME_DIR') + config.get('TMP_DIR')}/iostat_output.json"))
#     for host in data.get("sysstat").get("hosts"):
#         for stat in host.get("statistics"):
#             for disk in stat.get("disk"):
#                 cpu = stat.get("avg-cpu")
#                 node_name.append(host.get("nodename"))
#                 sys_name.append(host.get("sysname"))
#                 release.append(host.get("release"))
#                 machine.append(host.get("machine"))
#                 number_of_cpus.append(host.get("number-of-cpus"))
#                 user.append(cpu.get("user"))
#                 nice.append(cpu.get("nice"))
#                 system.append(cpu.get("system"))
#                 iowait.append(cpu.get("iowait"))
#                 steal.append(cpu.get("steal"))
#                 idle.append(cpu.get("idle"))
#                 disk_device.append(disk.get("disk_device"))
#                 tps.append(disk.get("tps"))
#                 kB_read_s.append(disk.get("kB_read/s"))
#                 kB_wrtn_s.append(disk.get("kB_wrtn/s"))
#                 kB_dscd_s.append(disk.get("kB_dscd/s"))
#                 kB_read.append(disk.get("kB_read"))
#                 kB_wrtn.append(disk.get("kB_wrtn"))
#                 kB_dscd.append(disk.get("kB_dscd"))
#
#     return pd.DataFrame({
#         "timestamp": [ts] * len(node_name),
#         "node_name": node_name,
#         "sys_name": sys_name,
#         "release": release,
#         "machine": machine,
#         "number_of_cpus": number_of_cpus,
#         "user": user,
#         "nice": nice,
#         "system": system,
#         "iowait": iowait,
#         "steal": steal,
#         "idle": idle,
#         "disk_device": disk_device,
#         "tps": tps,
#         "kB_read_s": kB_read_s,
#         "kB_wrtn_s": kB_wrtn_s,
#         "kB_dscd_s": kB_dscd_s,
#         "kB_read": kB_read,
#         "kB_wrtn": kB_wrtn,
#         "kB_dscd": kB_dscd
#     })


def create_dir(dir_path):
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)


def fetch_metrics_from_cli(config, timestamp):
    if platform.system() == 'Windows' and not config.get('REMOTE'):
        logger.error('Can not execute on windows.')
        exit(0)
    else:
        return process_from_cli(config, timestamp)


def execute(**inputs):
    """
    Execution method to be called from the framework with relevant inputs.
    """
    start_time = dt.now(timezone.utc)

    logger.info(" --- calling CLI Custom Script ---- ")

    config = load_configuration(inputs.get('CONFIG_PATH'))
    config['BASE_HOME_DIR'] = inputs.get('BASE_HOME_DIR')

    process, iostat, sadf = fetch_metrics_from_cli(config, start_time)

    logger.info("---- End of logging ----")
    logger.info(f"Total execution time ={divmod((dt.now(timezone.utc) - start_time).total_seconds(), 60)}")
    return process, iostat, sadf
