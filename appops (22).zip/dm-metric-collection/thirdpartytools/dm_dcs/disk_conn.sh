#/bin/sh
curr_dir=$(dirname $0)
cd ${curr_dir}

if [ -f disk_info.txt ]; then
  rm -f disk_info.txt
fi

# Read the JSON file into a variable
json_file=${curr_dir}/disk_config.json
json_obj=$(cat "$json_file")
# Use jq to extract the parent key, subkey, and value for each key-value pair
pairs=$(jq -r 'path(..) as $p | select($p | length == 2) | [$p[0], $p[1], getpath($p)] | @tsv' disk_config.json)

# Print the parent key, subkey, and value for each key-value pair
echo "$pairs" | while IFS=$'\t' read -r parent subkey value; do
  echo "$parent,$subkey,$value" >> disk_info.txt
done
metrics_dir=${curr_dir}/metrics
[ ! -d ${metrics_dir} ] && mkdir ${metrics_dir}
lsblk | grep disk > disksList.txt
input=disksList.txt
echo "input iss  " $input
######################################
# $IFS removed to allow the trimming #
#####################################
echo "Timestamp,server_instance_name,server_ip,disk_name,disk_mount_path,disk_status" > ${metrics_dir}/conn_disk_metrics_$(date -u +"%d%m%Y").csv
while read -r line
do

  #echo " line iss.. " $line
  disk_path=$(echo $line | awk  '{print $(NF=7)}')
  if [ -z "$disk_path" ]
  then
    disk_path="root"
  else
    disk_path=$disk_path
  fi
  disk_name=$(echo $line | awk  '{print $(NF=1)}')
  Timestamp=$(date -u +"%Y-%m-%d %H:%M:%S")
  server_ip=$(hostname -I)

  server_instance_name=$(aws ec2 describe-instances --filter Name=private-ip-address,Values=$server_ip --query 'Reservations[].Instances[].InstanceId')
  str=$server_instance_name,$disk_name,$disk_path
  echo $str

  if grep -Fxq "$str" disk_info.txt
  then
    echo "PASSED"
    disk_status=0
  else
    echo "FAILED. Update disk_config.json"
    disk_status=1
  fi

  echo $Timestamp,$server_instance_name,$server_ip,$disk_name,$disk_path,$disk_status  >> ${metrics_dir}/conn_disk_metrics_$(date +"%d%m%Y").csv
done < "$input"