#/bin/sh
curr_dir=$(dirname $0)
cd ${curr_dir}

#chmod +x ${curr_dir}/*.sh

echo "Calling disk_conn.sh"
sh disk_conn.sh

echo "Calling disk_nfs_conn.sh"
sh disk_nfs_conn.sh