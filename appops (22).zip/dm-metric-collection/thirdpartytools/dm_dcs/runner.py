import collect_disk

if __name__ == '__main__':
    input_dict = {
        'CONFIG_PATH': 'config.yaml'
    }
    collect_disk.execute(**input_dict)
