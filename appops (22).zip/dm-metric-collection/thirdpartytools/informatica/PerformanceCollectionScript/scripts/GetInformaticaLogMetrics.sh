#!/bin/bash

# check whether start & end times are passed as arguments
if [ "$#" -ne 5 ]; then
    echo "Illegal number of parameters: Please provide START_TIME(MM-DD-YYYY hh:mi:ss) and END_TIME(MM-DD-YYYY hh:mi:ss)"
    exit 1
fi

# convert bin to text using infacmd
function convertBin2Text {
    echo "$(date +'%F %T') [INFO] Converting ${1} to text..."
    sudo ${InfaCMDPath} ConvertLogFile -in ${1} -fm text -lo ${2}
    [ $? -ne 0 ] && echo "$(date +'%F %T') [ERROR] Conversion failed for ${1}" && return 1
    sed -i -e "s/\r//g" ${2}
}

# similar to a thread pool
function pwait() {
    while [ $(jobs -p | wc -l) -ge $1 ]; do
        wait -n
    done
}

# similar to a thread pool
function createEmptyFile() {
	dt=$(date -u +'%d%m%Y')
	new_filename=${OutputDir}/infa_log_metrics_${dt}.csv
    echo "Start_Time,End_Time,Server_Name,Repository_Name,Folder_Name,Workflow_Name,Session_Name,Workflow_Execution_ID,Mapping_Name,Site_ID,pid,Hostname,AggIndexCacheSizeMB,AggDataCacheSizeMB,JnrIndexCacheSizeMB,JnrDataCacheSizeMB,Stale_Data,Log_File" > ${new_filename}
}

curr_dir=$(dirname $0)
source $curr_dir/../config/InfaLogParser.conf

chmod +x ${curr_dir}/*.sh
mkdir -p ${OutputDir}
mkdir -p ${ArchiveLogDir}

# clean output directory before collecting metrics
rm -rf ${OutputDir}/infa_log_metrics*

# get logs in provided time range
echo "$(date +'%F %T') [INFO] Fetching logs between $1 to $2..."
${curr_dir}/GetLogPath.sh "$1" "$2" "$3" "$4" "$5"
[ ! -f ${OutputDir}/logpaths.csv ] && createEmptyFile && exit 1
[ $(cat ${OutputDir}/logpaths.csv | wc -l) -le 1 ] && echo "$(date +'%F %T') [WARN] No logs found to process" && createEmptyFile && exit 1

# convert log files to text if it is in binary format
# Batch Convert the files parallelly
echo "$(date +'%F %T') [INFO] Converting log files to text..."
while read -r log; do
    convertBin2Text "${log}.bin" "${ArchiveLogDir}/$(basename ${log}).txt" &
    # run background jobs with max parallel processes, rather than running everything at once to avoid too much disk IO
    pwait ${MaxParallelConversions}
done <<< "$(sed 1d ${OutputDir}/logpaths.csv | grep -v 'Awaiting' | awk -F',' '{print $NF}')"
# wait for any unfinished jobs
wait
echo "$(date +'%F %T') [INFO] Conversion completed"

echo "$(date +'%F %T') [INFO] Starting log parser script..."

# parse the log files
sed 1d ${OutputDir}/logpaths.csv | grep -v 'Awaiting' | while IFS=',' read -r COLLECTION_START_TIME WORKFLOW_ID WORKFLOW_RUN_ID SERVER_NAME TASK_NAME START_TIME END_TIME LOG_FILE_PATH; do
    ${curr_dir}/InfaLogParser.sh "${ArchiveLogDir}/$(basename ${LOG_FILE_PATH}).txt" "${START_TIME}" "${END_TIME}"
done

echo "$(date +'%F %T') [INFO] Log parser completed"

