#!/bin/bash

curr_dir=$(dirname $0)
source $curr_dir/../config/InfaLogParser.conf

ORACLE_HOME=${OracleHome}
OUTPUT_DIR=${OutputDir}

export ORACLE_HOME

# DBPASS=`echo ${INFADBPASS} | openssl enc -aes-256-cbc -salt -k pass -a -d`
STARTTIME=$1
ENDTIME=$2

if [ "$#" -ne 5 ]; then
    echo "Illegal number of parameters: Please provide START_TIME(MM-DD-YYYY hh:mi:ss) and END_TIME(MM-DD-YYYY hh:mi:ss)"
    exit 1
fi

[ ! -d ${OUTPUT_DIR} ] && mkdir -p ${OUTPUT_DIR}
FILE=${OUTPUT_DIR}/logpaths.csv
echo "COLLECTION_START_TIME,WORKFLOW_ID,WORKFLOW_RUN_ID,SERVER_NAME,TASK_NAME,START_TIME,END_TIME,LOG_FILE_PATH" > $FILE

DBUSER="${3}"
DBPASS="${4}"
SchemaName="${5}"

var=`$ORACLE_HOME/bin/sqlplus -S $DBUSER/"$DBPASS"@INFAORCL << EOD
set pagesize 0
set linesize 32767
set numwidth 50
set feedback off
set headsep off
set colsep ,
set trim on
set trimspool on

spool ${OUTPUT_DIR}/logpaths.tmp

SELECT distinct ('$STARTTIME'),
OL.WORKFLOW_ID as WORKFLOW_ID,
OL.WORKFLOW_RUN_ID as WORKFLOW_RUN_ID,
T.SERVER_NAME as SERVER_NAME,
T.TASK_NAME as TASK_NAME,
TO_CHAR(T.START_TIME,'YYYY-MM-DD hh:mi:ss') as START_TIME,
CASE WHEN T.END_TIME IS NULL THEN 'Awaiting' ELSE TO_CHAR(T.END_TIME,'YYYY-MM-DD hh:mi:ss') END as END_TIME,
OL.log_file as log_file
FROM
${SchemaName}.OPB_TASK_INST_RUN T ,
${SchemaName}.OPB_SESS_TASK_LOG OL
WHERE
OL.WORKFLOW_ID = T.WORKFLOW_ID AND OL.WORKFLOW_RUN_ID = T.WORKFLOW_RUN_ID AND OL.INSTANCE_ID = T.INSTANCE_ID
AND (T.START_TIME BETWEEN TO_DATE('$STARTTIME','MM-DD-YYYY hh24:mi:ss') AND TO_DATE('$ENDTIME','MM-DD-YYYY hh24:mi:ss')
OR
T.END_TIME BETWEEN TO_DATE('$STARTTIME','MM-DD-YYYY hh24:mi:ss') AND TO_DATE('$ENDTIME','MM-DD-YYYY hh24:mi:ss'))
ORDER BY START_TIME;
spool off

exit;
EOD`

if [ $(grep -c 'ERROR' ${OUTPUT_DIR}/logpaths.tmp) -gt 0 ]; then
    echo "$(date +'%F %T') [ERROR] Failed to collect log paths with below error:"
    cat ${OUTPUT_DIR}/logpaths.tmp
    exit 1
fi

# remove any duplicates & trim columns before writing to file
cat ${OUTPUT_DIR}/logpaths.tmp | awk -F',' '!a[$NF]++' >> ${FILE}
rm -f ${OUTPUT_DIR}/logpaths.tmp

