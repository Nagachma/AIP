#!/bin/bash

curr_dir=$(dirname $0)

source $curr_dir/../config/InfaLogParser.conf

SESSION_LOG_DIR=$SessionLogDir
ARCHIVE_DIR=$ArchiveLogDir
METRICS_DIR=${OutputDir}
#STALE_DATA_PATTERN=${stale_data_pattern}
INFACMD=$InfaCMDPath

dt=$(date -u +'%d%m%Y')

# Getting the starttime and endtime from metadata db
start_time="${2}"
end_time="${3}"

# validate input log directories
if [ ! -d ${SESSION_LOG_DIR} ]; then
    echo "$(date +'%F %T') [ERROR] Session Log Directory [${SESSION_LOG_DIR}] does not exist or not accessible"
    exit 1
fi

# create output directory if not exists
[ ! -d ${METRICS_DIR} ] && mkdir -p ${METRICS_DIR}

# create archive directory if not exists
[ ! -d ${ARCHIVE_DIR} ] && mkdir -p ${ARCHIVE_DIR}

# convert bin to text using infacmd
function convertBin2Text {
    echo "$(date +'%F %T') [INFO] Converting ${1} to text..."
    sudo ${INFACMD} ConvertLogFile -in ${1} -fm text -lo ${2}
    sed -i -e "s/\r//g" ${2}
}

function get_log_metrics {
    # create output file if not exists
    local o_filename=${METRICS_DIR}/infa_log_metrics_${dt}.csv
    [ ! -f ${o_filename} ] && echo "Start_Time,End_Time,Server_Name,Repository_Name,Folder_Name,Workflow_Name,Session_Name,Workflow_Execution_ID,Mapping_Name,Site_ID,pid,Hostname,AggIndexCacheSizeMB,AggDataCacheSizeMB,JnrIndexCacheSizeMB,JnrDataCacheSizeMB,Stale_Data,Log_File" > ${o_filename}

    #start_time=$(head -n2 ${log_file_to_be_processed} | tail -n1 | awk -F"${delimiter}" '{print $1}')
    #end_time=$(tac ${log_file_to_be_processed} | grep "${delimiter}" -m1 | awk -F"${delimiter}" '{print $1}')

    # timezone=$(grep 'Current Timezone' ${log_file_to_be_processed} | awk -F'[' '{print $NF}' | cut -d']' -f1)

    start_time=$(date -d"${start_time}" +'%F %T')
    end_time=$(date -d"${end_time}" +'%F %T')

    Server_Name=$(grep 'Server Name' -m1 ${log_file_to_be_processed} | awk -F'[][]' '{print $2}')
    Repository_Name=$(grep 'Repository Name' -m1 ${log_file_to_be_processed} | awk -F'[][]' '{print $2}')
    Folder_Name=$(grep 'Folder' -m1 ${log_file_to_be_processed} | awk -F'[][]' '{print $2}')
    Workflow_Name=$(grep 'Workflow' -m1 ${log_file_to_be_processed} | awk -F'[][]' '{print $2}')
    Session_Name=$(grep 'Initializing session' -m1 ${log_file_to_be_processed} | awk -F'[][]' '{print $2}')
    Workflow_Execution_ID=$(grep 'Run Id' -m1 ${log_file_to_be_processed} | awk -F'[][]' '{print $6}')
    Mapping_Name=$(grep 'Mapping name' -m1 ${log_file_to_be_processed} | awk -F'Mapping name:' '{print $2}' | awk '{print $1}')
    Site_ID=$(grep 'Run Instance Name' -m1 ${log_file_to_be_processed} | awk -F'[][]' '{print $4}')
    PID=$(grep 'Current Process ID' -m1 ${log_file_to_be_processed} | awk -F'[][]' '{print $2}')
    Hostname=$(head -2 ${log_file_to_be_processed} | tail -1 | awk -F"${delimiter}" '{print $5}')

    AggIndexCacheSize=$(grep -F '[Index Cache] size for transformation' "${log_file_to_be_processed}" | awk -F'[][]' '{print $4,$8}' OFS=',' | grep '^agg' | cut -d, -f2 | paste -sd+ | bc -l)
    [ ! -z ${AggIndexCacheSize} ] && AggIndexCacheSizeMB=$(echo "${AggIndexCacheSize} * 0.000001" | bc -l)
    JnrIndexCacheSize=$(grep -F '[Index Cache] size for transformation' "${log_file_to_be_processed}" | awk -F'[][]' '{print $4,$8}' OFS=',' | grep '^jnr' | cut -d, -f2 | paste -sd+ | bc -l)
    [ ! -z ${JnrIndexCacheSize} ] && JnrIndexCacheSizeMB=$(echo "${JnrIndexCacheSize} * 0.000001" | bc -l)
    AggDataCacheSize=$(grep -F '[Data Cache] size for transformation' "${log_file_to_be_processed}" | awk -F'[][]' '{print $4,$8}' OFS=',' | grep '^agg' | cut -d, -f2 | paste -sd+ | bc -l)
    [ ! -z ${AggDataCacheSize} ] && AggDataCacheSizeMB=$(echo "${AggDataCacheSize} * 0.000001" | bc -l)
    JnrDataCacheSize=$(grep -F '[Data Cache] size for transformation' "${log_file_to_be_processed}" | awk -F'[][]' '{print $4,$8}' OFS=',' | grep '^jnr' | cut -d, -f2 | paste -sd+ | bc -l)
    [ ! -z ${JnrDataCacheSize} ] && JnrDataCacheSizeMB=$(echo "${JnrDataCacheSize} * 0.000001" | bc -l)

    Stale_Error_Count=$(grep -icE "Error setting/closing connection: Not Connected|Cannot COPY into nonexistent table" ${log_file_to_be_processed})
    [ ${Stale_Error_Count} -gt 0 ] && Stale_Data=1 || Stale_Data=0

    echo "${start_time},${end_time},${Server_Name},${Repository_Name},${Folder_Name},${Workflow_Name},${Session_Name},${Workflow_Execution_ID},${Mapping_Name},${Site_ID},${PID},${Hostname},${AggIndexCacheSizeMB},${AggDataCacheSizeMB},${JnrIndexCacheSizeMB},${JnrDataCacheSizeMB},${Stale_Data},${in_file}" >> ${o_filename}
}

function get_metadata_metrics {
    # create output file if not exists
    local o_filename=${METRICS_DIR}/infa_metadata_${dt}.csv
    [ ! -f ${o_filename} ] && echo "Start_Time,End_Time,Server_Name,Repository_Name,Folder_Name,Workflow_Name,Session_Name,Workflow_Execution_ID,Mapping_Name,Site_ID,PID,Hostname,Min_JVM_Heap,Max_JVM_Heap,Target_Tables,Warnings,Errors,Stale_Error_Count" > ${o_filename}

    jvm_params=$(grep 'JVM was created with the following JVM options' ${log_file_to_be_processed} | grep 'Xms.*.Xmx.*' -o | cut -d']' -f1)
    Min_JVM_Heap=$(echo "${jvm_params}" | awk '{print $1}' | sed 's/Xms//i')
    Max_JVM_Heap=$(echo "${jvm_params}" | awk '{print $2}' | sed 's/-Xmx//i')
    Target_Tables=$(grep 'WRT.*.Target:' ${log_file_to_be_processed} | awk -F': ' '{print $2}' | sort -u | awk '{print $1}' | tr '\n' ':' | sed 's/:$//')
    Warnings=$(grep "WARNING${delimiter}" -wc ${log_file_to_be_processed})
    Errors=$(grep "ERROR${delimiter}" -wc ${log_file_to_be_processed})

    echo "${start_time},${end_time},${Server_Name},${Repository_Name},${Folder_Name},${Workflow_Name},${Session_Name},${Workflow_Execution_ID},${Mapping_Name},${Site_ID},${PID},${Hostname},${Min_JVM_Heap},${Max_JVM_Heap},${Target_Tables},${Warnings},${Errors},${Stale_Error_Count}" >> ${o_filename}
}

function get_load_stats {
    # create output file if not exists
    local o_filename=${METRICS_DIR}/infa_load_stats_${dt}.csv
    [ ! -f ${o_filename} ] && echo "Workflow_Name,Workflow_Execution_ID,PID,Hostname,Partition_Name,Stage,Total_Run_Time(sec),Total_Idle_Time(sec),Busy_Percentage" > ${o_filename}
    cat ${log_file_to_be_processed} | grep 'Thread.*.created for.*.of partition point.*.has completed' | grep -v 'The total run time was insufficient for any meaningful statistics' | awk -F'[][]' '{print $4,$6}' OFS='@' | while IFS='@' read -r stg partitn; do
        stats=$(cat ${log_file_to_be_processed} | grep "Thread.*.created for \[${stg}\] of partition point \[${partitn}\] has completed" -A3 | grep '=' | awk -F'[][]' '{print $2}' | tr '\n' ',' | sed 's/,$//')
        partitn=$(echo "${partitn}" | sed 's/,/:/g')
        echo "${Workflow_Name},${Workflow_Execution_ID},${PID},${Hostname},${partitn},${stg},${stats}"
    done >> ${o_filename}
}

function get_transformation_stats {
    # create output file if not exists
    local o_filename=${METRICS_DIR}/infa_transformation_stats_${dt}.csv
    [ ! -f ${o_filename} ] && echo "Workflow_Name,Workflow_Execution_ID,PID,Hostname,Transformation_Name,Input_Rows,Index_Cache_Memory(Bytes),Data_Cache_Memory(Bytes),Index_Cache_Size(Bytes),Data_Cache_Size(Bytes)" > ${o_filename}
    cat ${log_file_to_be_processed} | grep -F '[Index Cache] size for transformation' | awk -F'[][]' '{print $4,$8}' OFS=',' | sort -t',' -k1 > .idx.tmp
    cat ${log_file_to_be_processed} | grep -F '[Data Cache] size for transformation' | awk -F'[][]' '{print $4,$8}' OFS=',' | sort -t',' -k1 > .dat.tmp
    cat ${log_file_to_be_processed} | grep -F 'The index cache size that would hold' | awk -F'[][]' '{print $4,$2,$6}' OFS=',' | sort -t',' -k1 > .idx.mem
    cat ${log_file_to_be_processed} | grep -F 'The data cache size that would hold' | awk -F'[][]' '{print $4,$6}' OFS=',' | sort -t',' -k1 > .dat.mem
    join -t',' -j 1 .idx.mem .dat.mem > .idx_dat.mem
    join -t',' -j 1 .idx.tmp .dat.tmp > .idx_dat.tmp
    join -t',' -j 1 .idx_dat.mem .idx_dat.tmp | sed "s/^/${Workflow_Name},${Workflow_Execution_ID},${PID},${Hostname},/g" >> ${o_filename}
    rm -f .*.tmp .*.mem
}

function get_warnings {
    # create output file if not exists
    local o_filename=${METRICS_DIR}/infa_warnings_${dt}.csv
    [ ! -f ${o_filename} ] && echo "Workflow_Name,Workflow_Execution_ID,PID,Hostname,Warning_Message,Occurrences" > ${o_filename}
    grep 'WARNING' ${log_file_to_be_processed} | awk -F"${delimiter}" '{if($2 == "WARNING") print $7}' | awk '!a[$0]++' | while read -r msg; do
        cnt=$(grep "${msg}" -cF ${log_file_to_be_processed})
        # replace any commas with semi-columns
        msg=$(echo "${msg}" | sed 's/,/;/g')
        echo "${Workflow_Name},${Workflow_Execution_ID},${PID},${Hostname},${msg},${cnt}"
    done >> ${o_filename}
}

function get_errors {
    # create output file if not exists
    local o_filename=${METRICS_DIR}/infa_errors_${dt}.csv
    [ ! -f ${o_filename} ] && echo "Workflow_Name,Workflow_Execution_ID,PID,Hostname,Error_Message,Occurrences" > ${o_filename}
    grep 'ERROR' ${log_file_to_be_processed} | awk -F"${delimiter}" '{if($2 == "ERROR") print $7}' | awk '!a[$0]++' | while read -r msg; do
        cnt=$(grep "${msg}" -cF ${log_file_to_be_processed})
        # replace any commas with semi-columns
        msg=$(echo "${msg}" | sed 's/,/;/g')
        echo "${Workflow_Name},${Workflow_Execution_ID},${PID},${Hostname},${msg},${cnt}"
    done >> ${o_filename}
}

# get a log file name as an argument
[ ! -z "$1" ] && in_file="$1" || { echo "$(date +'%F %T') [ERROR] Provide log file name as an argument" && exit 1; }

# use provided path if absolute path is provided, else use path from config file
if [ $(echo "${in_file}" | grep '^/' -c) -ge 1 ]; then
    SESSION_LOG_DIR=$(dirname ${in_file})
    in_file=$(basename ${in_file})
fi

echo "$(date +'%F %T') [INFO] Processing ${in_file}..."

# check if provided session file exists or not
if [ ! -f ${SESSION_LOG_DIR}/${in_file} ]; then
    echo "$(date +'%F %T') [ERROR] Session Log File [${in_file}] does not exist under [${SESSION_LOG_DIR}]"
    exit 1
elif [ "${SESSION_LOG_DIR}" != "${ARCHIVE_DIR}" ]; then
    # do not copy if provided file is in archive
    cp -f ${SESSION_LOG_DIR}/${in_file} ${ARCHIVE_DIR}
fi

# convert log file to text if it is in binary format
if [ $(echo "${in_file}" | grep '.bin$' -c) -ge 1 ]; then
    log_file_to_be_processed="${ARCHIVE_DIR}/$(basename -s '.bin' ${in_file}).txt"
    convertBin2Text "${ARCHIVE_DIR}/${in_file}" "${log_file_to_be_processed}"
else
    log_file_to_be_processed="${ARCHIVE_DIR}/${in_file}"
fi

# start parsing
echo "$(date +'%F %T') [INFO] Collecting log metrics..."
get_log_metrics

if [ ${CollectMetadataStats} = 'Y' ]; then
    get_metadata_metrics
fi

if [ ${CollectLoadStats} = 'Y' ]; then
    echo "$(date +'%F %T') [INFO] Collecting load stats..."
    get_load_stats
fi

if [ ${CollectTransformationStats} = 'Y' ]; then
    echo "$(date +'%F %T') [INFO] Collecting Transformation stats..."
    get_transformation_stats
fi

if [ ${CollectWarnings} = 'Y' ]; then
    echo "$(date +'%F %T') [INFO] Collecting Warnings..."
    get_warnings
fi

if [ ${CollectErrors} = 'Y' ]; then
    echo "$(date +'%F %T') [INFO] Collecting Errors..."
    get_errors
fi

if [ ${SaveToArchive} = 'N' ]; then
    echo "$(date +'%F %T') [INFO] Removing log files from archive..."
    rm -rf $(echo ${log_file_to_be_processed} | awk -F'.' '{NF--; print}' OFS='.')*
fi

