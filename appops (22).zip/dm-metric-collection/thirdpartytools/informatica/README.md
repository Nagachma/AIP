# Informatica metrics collection - Log Parser & Metadata metrics

Refer this [wiki link](https://dev.azure.com/aipplus/Performance%20Engineering/_wiki/wikis/Performance-Engineering.wiki/7128/Informatica-Log-Parser)
