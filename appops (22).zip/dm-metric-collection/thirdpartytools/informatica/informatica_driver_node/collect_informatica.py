"""Custom Script to fetch Informatica metrics"""
from encodings import utf_8
import logging
import os
import platform
from datetime import datetime as dt
import pandas as pd
from sqlalchemy import true
import yaml
from datetime import timezone
import json
import paramiko
import time
from scp import SCPClient
from multiprocessing.pool import ThreadPool as Pool
import shutil
from vault_utility_v2 import vault_credentials

"""
__author__ = "Arunabha Das"
__copyright__ = "Copyright 2023, The OrchastrAI Project"
__license__ = "GPL"
__version__ = "1.0.0"
__email__ = "arunabha.a.das@accenture.com"
"""

logger = logging.getLogger('Collecting Informatica Log Parser and Infa DB Metrics')
logger.setLevel(logging.INFO)

# create console handler and set level to debug
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.DEBUG)

# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# add formatter to console_handler
console_handler.setFormatter(formatter)

# add console_handler to logger
logger.addHandler(console_handler)


def load_configuration(lconfig):
    """Read and load data from config.yaml file"""
    cfg = {}
    try:
        with open(lconfig, 'r') as yaml_file:
            cfg = yaml.safe_load(yaml_file)
    except yaml.YAMLError as exc:
        logger.exception(exc)
    except Exception as e:
        logger.exception(e)
    return cfg

def create_dir(dir_path):
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)

def remove_dir(dir_path):
    if os.path.exists(dir_path):
        shutil.rmtree(dir_path)

def execute_commands(url,config,cred):
    """ Execute commands on Remote Machine.
  
    Parameters:
    url (str): Host IP
    config (dict): Config.yml
    cred: Credentials for the IP Login
  
    Returns: None
    """
    
    try:
        if cred.get('serviceusername') is not None:
            username=cred.get('serviceusername')
        else:
            logger.error("No serviceusername found")
            raise Exception('No serviceusername found')
        
        if cred.get('servicepassword') is not None:
            password=cred.get('servicepassword')
        else:
            logger.error("No servicepassword found")
            raise Exception('No servicepassword found')
        
        if cred.get('dbusername') is not None:
            infdbusername=cred.get('dbusername')
        else:
            logger.error("No dbusername found")
            raise Exception('No dbusername found')
        
        if cred.get('dbpassword') is not None:
            infdbpassword=cred.get('dbpassword')
        else:
            logger.error("No dbpassword found")
            raise Exception('No dbpassword found')
        
        if cred.get('dbschema') is not None:
            infdbschema=cred.get('dbschema')
        else:
            logger.error("No dbschema found")
            raise Exception('No dbschema found')
        

        # SSH Connection 
        ssh = paramiko.SSHClient()   
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        
        try:
            if config.get('SSH_CONFIG').get('PPK_FILE') is None or config.get('SSH_CONFIG').get('PPK_FILE') == '':
                ssh.connect(hostname=url, username=str(username),password=str(password), timeout= 20)               # WITH PASSWORD
            else:
                k = paramiko.RSAKey.from_private_key_file(config.get('SSH_CONFIG').get('PPK_FILE'))
                ssh.connect(hostname=url, username=str(username), pkey=k,timeout=20)                                # WITH PPK

            # Copy Files to Remote server on condition
            local_script_path=config.get('BASE_HOME_DIR')+config.get('LOCAL_SCRIPTS_PATH')
            remote_script_path=config.get('SSH_CONFIG').get('REMOTE_SCRIPT_PATH')
            
            if config.get('IS_COPY_SCRIPT') is True:        #Overides the files
                with SCPClient(ssh.get_transport(), sanitize=lambda x: x) as scp:
                    scp.put(local_script_path,remote_path=remote_script_path, recursive=True)
                logger.info("Scipts copied sucessfully to remote path : {} ".format(remote_script_path))
            else:
                logger.info("Copy of scripts is disabled --- Passing")
            
            # Command to run
            logparser_cmd=f""" sh {config['SSH_CONFIG']['MAIN_WRAPPER_FILE_PATH']} '{str(infdbusername)}' '{str(infdbpassword)}' '{str(infdbschema)}' """

            logger.info("Running command in node : {} ".format(url))
            
            stdin, stdout, stderr = ssh.exec_command(logparser_cmd,get_pty=True)

            logger.info("Command Output : ---------")
            for line in iter(stdout.readline, ""):
                logger.info(line)

            # wait till commands complete their execution
            time.sleep(3)

            csv_date=dt.now()
            csv_date=csv_date.strftime("%d%m%Y")

            # SCP FILES FROM REMOTE
            logger.info("Copying CSVs from Remote to Local from {} ".format(url))
            with SCPClient(ssh.get_transport(), sanitize=lambda x: x) as scp:
                scp.get(remote_path=config['SSH_CONFIG']['REMOTE_TMP_MAIN'] + "/infa_log_metrics_{}.csv".format(csv_date), local_path=config['SSH_CONFIG']['LOCAL_ABS_PATH'] + config['LOG_PARSER_TMP_DIR'] + "/{}_logparser_informatica_metrics_{}.csv".format(url,csv_date))
                scp.get(remote_path=config['SSH_CONFIG']['REMOTE_TMP_MAIN'] + "/infadboutput_{}.csv".format(csv_date), local_path=config['SSH_CONFIG']['LOCAL_ABS_PATH'] + config['INFA_DB_TMP_DIR'] + "/{}_infadb_informatica_metrics_{}.csv".format(url,csv_date))
            
            ssh.close()


        except Exception as e:
                logger.error("---- Connection Refused to node : {} ----".format(url))
                logger.error("Error : {}".format(e))
    except Exception as e:
        logger.error("Error : {}".format(e))



def process_from_cli(config):
    
    try:
        #Removing Temp Directory
        remove_dir(config.get('BASE_HOME_DIR') + config.get('LOG_PARSER_TMP_DIR'))
        remove_dir(config.get('BASE_HOME_DIR') + config.get('INFA_DB_TMP_DIR'))
        remove_dir(config.get('BASE_HOME_DIR') + config.get('LOG_PARSER_DIR'))
        remove_dir(config.get('BASE_HOME_DIR') + config.get('INFA_DB_DIR'))
        
        #Creating Directories
        create_dir(config.get('BASE_HOME_DIR') + config.get('LOG_PARSER_TMP_DIR'))
        create_dir(config.get('BASE_HOME_DIR') + config.get('INFA_DB_TMP_DIR'))
        create_dir(config.get('BASE_HOME_DIR') + config.get('LOG_PARSER_DIR'))
        create_dir(config.get('BASE_HOME_DIR') + config.get('INFA_DB_DIR'))

        logger.info('Fetching data')

        #Loading creds from vault
        cred = vault_credentials.get_secret_from_vault(config['vault_path'],config['vault_keys'])
        ip_addresses=cred.get('ipaddress').split(',')

        if not config.get('REMOTE'):
            logger.info('Remote is not set to true, please write the code further to execute if required')
        else:
            # Multiprocess - Provide POOL SIZE as number of grids in config
            with Pool(processes=len(ip_addresses)) as pool:
                args = [(str(url.strip()), config, cred) for url in ip_addresses]
                pool.starmap(execute_commands, args)
                pool.close()
                pool.join()
            
            logger.info("End of collection of metrics from all nodes")
            logger.info("Merging CSV from all nodes")
            
            infa_file_list = os.listdir(config.get('BASE_HOME_DIR') + config.get('INFA_DB_TMP_DIR'))
            logparser_file_list = os.listdir(config.get('BASE_HOME_DIR') + config.get('LOG_PARSER_TMP_DIR'))
            
            csv_date=dt.now()
            csv_date=csv_date.strftime("%d%m%Y")

            #For InfaDB CSVs
            infa_df = pd.DataFrame()
            for file in infa_file_list:
                filepath=config.get('BASE_HOME_DIR') + config.get('INFA_DB_TMP_DIR')+"/"+file
                data = pd.read_csv(filepath)
                infa_df = pd.concat([infa_df, data], axis=0)
                break
            final_path=config.get('BASE_HOME_DIR') + config.get('INFA_DB_DIR')+"/infadb_informatica_metrics_{}.csv".format(csv_date)
            infa_df.to_csv(final_path, index=False)   
            
            #For LogParser CSVs
            log_parser_df = pd.DataFrame()
            for file in logparser_file_list:
                filepath=config.get('BASE_HOME_DIR') + config.get('LOG_PARSER_TMP_DIR')+"/"+file
                data = pd.read_csv(filepath)
                log_parser_df = pd.concat([log_parser_df, data], axis=0)
                break
            final_path=config.get('BASE_HOME_DIR') + config.get('LOG_PARSER_DIR')+"/logparser_informatica_metrics_{}.csv".format(csv_date)
            log_parser_df.to_csv(final_path, index=False)
        
        logger.info('Done collecting the data')
    except Exception as e:
        logger.error("Error Hence exiting: {}".format(e))
        exit(1)


def fetch_metrics(config):
    if platform.system() == 'Windows' and not config.get('REMOTE'):
        logger.error('Can not execute on windows.')
        exit(1)
    else:
        return process_from_cli(config)


def execute(**inputs):
    """
    Execution method to be called from the framework with relevant inputs.
    """
    start_time = dt.now(timezone.utc)

    logger.info(" --- calling Log Parser and Infadb Script ---- ")

    #Loading of Config file
    config = load_configuration(inputs.get('CONFIG_PATH'))
    config['BASE_HOME_DIR'] = inputs.get('BASE_HOME_DIR')
    
    #Call function to fetch metrics
    fetch_metrics(config)

    logger.info("---- End of logging ----")
    logger.info(f"Total execution time ={divmod((dt.now(timezone.utc) - start_time).total_seconds(), 60)}")
