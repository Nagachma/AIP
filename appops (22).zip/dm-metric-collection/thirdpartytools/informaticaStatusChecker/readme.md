Informatica-Service_Status-Connector

1. Create connector directory on VM node and move all files to connectory directory
2. Provide/Add mongodb credentials in config.yaml file i.e. InfaCMDPath, OutputDir, SecurityDomain etc
3. Run InfaServiceStatusChecker.sh from VM node using sh InfaServiceStatusChecker.sh
4. Collected output metrics will be generated in output directory

# Informatica-Service_Status Metrics Collection Scripts for Operational Analytics

## Introduction:
- These scripts collect Informatica service status metrics from Informatica server and put it into a CSV file. There is 1 metrics collection script:
- 1. `Informatica-Service_Status`: This script collects data based at realtime. Example: If user wants to collect data with 60 mins interval then user needs to configure crontab with appropriate command.

## Set up:
- Copy the parent folder i.e. informaticaStatusChecker to the driver node /data path.

## Configuration:
- Update `config.yaml`,Provide/Add informatica configurations in config.yaml file i.e. InfaCMDPath, OutputDir, SecurityDomain etc, sample config file is having self explanatory contents.

## Execution:

### Informatica-Service_Status Metrics Collection:

#### Step1: Execute python script from main:
```sh InfaServiceStatusChecker.sh ```

### Live Metrics Collection:

#### Step1: configure the crontab with following command:
```*/5 * * * * /bin/su -c "sh /data/informaticaStatusChecker/InfaServiceStatusChecker.sh > /data/informaticaStatusChecker/logs/InfaServiceStatusChecker.log 2>&1" - dmuser```

## For validation:

### Metrics files should be generated under following path:

	informaticaStatusChecker Metrics: ```/data/informaticaStatusChecker/outputs/*```

## Referance: Please refer this link for all the query details:
https://confluence.dev.accentureanalytics.com/display/PERFENG/

## License and Authors:

### Authors: sachin.maurya
