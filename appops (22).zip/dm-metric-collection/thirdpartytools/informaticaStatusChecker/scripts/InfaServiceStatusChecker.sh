#!/bin/bash

# author: prudhvi.l.chelluri
# Email: prudhvi.l.chelluri@accenture.com
# License: GPL
# Version: 1.0.0
# Copyright: Copyright 2023, The OrchastrAI Project


curr_dir=$(dirname $0)

# load config
source $curr_dir/../config/infaServiceStatusChecker.conf

function create_out_file {
    # create output directory if not exists
    [ ! -d ${OutputDir} ] && mkdir -p ${OutputDir}

    out_file=${OutputDir}/infa_service_status.csv
    prev_file=${OutputDir}/prev_infa_service_status.csv

    echo 'collection_time,domain_name,service_name,node_name,service_status,message' > ${out_file}
    collection_time="$(date +'%F %T')"
}

function list_services {
    local domain=$1
    if [ -z ${ServiceTypes} ]; then
        ${InfaCMDPath} listServices -dn ${domain} -un ${UserName} -pd ${Password} -sdn ${SecurityDomain}
    else
        for st in ${ServiceTypes//,/ }; do
            ${InfaCMDPath} listServices -dn ${domain} -un ${UserName} -pd ${Password} -sdn ${SecurityDomain} -st ${st}
        done
    fi | grep -iv 'successfully' | grep -v 'failed with error' > .services.list
}

function list_service_nodes {
    local domain=$1
    local service=$2
    ${InfaCMDPath} listServiceNodes -dn ${domain} -un ${UserName} -pd ${Password} -sdn ${SecurityDomain} -sn ${service} | grep -iv 'successfully' | grep -v 'failed with error' > .nodes.list
}

function check_service_status {
    local domain=$1
    local service=$2
    local node=$3
    # msg=$(${InfaCMDPath} ping -dn ${domain} -sn ${service} -nn ${node})
    msg="$(${InfaCMDPath} getServiceProcessStatus -dn ${domain} -un ${UserName} -pd ${Password} -sdn ${SecurityDomain} -sn ${service} -nn ${node})"
    status=$?
    msg=$(echo "${msg}" | grep -v 'successfully')
    [ ${status} -ne 0 ] && status=1

    return ${status}
}

function swap_out_files {
    # rename current file as previous and previous as current
    if [ -f ${prev_file} ]; then
        mv ${out_file} .status.out
        mv ${prev_file} ${out_file}
        mv .status.out ${prev_file}
    else
        mv ${out_file} ${prev_file} 
    fi
}

function cleanup {
    rm -f .*.list
}

# create output file
create_out_file

for domain in ${DomainNames//,/ }; do
    # list services in a domain
    list_services ${domain}
    cat .services.list | while read -r service; do
        # list nodes on which a service is running
        list_service_nodes ${domain} ${service}
        cat .nodes.list | while read -r node; do
            # check the status of a service on a node
            check_service_status ${domain} ${service} ${node}
            echo "${collection_time},${domain},${service},${node},${status},${msg}" >> ${out_file}
        done
    done
done

# post collection activities
swap_out_files
cleanup
