# Author: Santhosh Prabakaran
# Version: 0.0.1
# Last modified: 28/08/2023

# Get the date and time from 5 minutes ago
$start = (Get-Date).AddMinutes(-5).ToUniversalTime().ToString("MM-dd-yyyy HH:mm:ss")
# Get the current UTC time
$end = (Get-Date).ToUniversalTime().ToString("MM-dd-yyyy HH:mm:ss")

# Function to convert the bin to text
$ConvertBinToText = {
    param(
        [string]$arg1,
        [string]$arg2,
        [string]$arg3
    )
    $timestamp = (Get-Date).ToUniversalTime().ToString("yyyy-MM-dd HH:mm:ss")
    write-output "$timestamp [INFO] Converting $arg1 to text..."
    # Informatica command to use infacmd file to convert the file	
    $process = (Start-Process -FilePath $arg3 -ArgumentList "ConvertLogFile", "-InputFile", $arg1, "-fm", "text", "-lo", $arg2 -PassThru -Wait)
	Start-Sleep -Seconds 5
	Write-output "Process exit code should be here: " $process.ExitCode

    if ($process.ExitCode -ne 0){
        $failed_timestamp = (Get-Date).ToUniversalTime().ToString("yyyy-MM-dd HH:mm:ss")
        Write-Error "$failed_timestamp Error Converting the bin file to Txt"
        Exit 1
    }

    # Read the content of the file
    $content = Get-Content -Path $ArchiveLogDir

    # Perform the replacement on each line
    $modifiedContent = $content -replace "\r", ""

    # Write the modified content back to the file
    $modifiedContent | Set-Content -Path $ArchiveLogDir

}

function createEmptyFile() {
    $dt = (Get-Date).ToUniversalTime().ToString("ddMMyyyy")
    $new_filename = "${OutputDir}/infa_log_metrics_${dt}.csv"
    "Start_Time,End_Time,Server_Name,Repository_Name,Folder_Name,Workflow_Name,Session_Name,Workflow_Execution_ID,Mapping_Name,Site_ID,pid,Hostname,AggIndexCacheSizeMB,AggDataCacheSizeMB,JnrIndexCacheSizeMB,JnrDataCacheSizeMB,Stale_Data,Log_File" | Out-File $new_filename -Encoding utf8
}

$curr_dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$InfaLogParserConf = Join-Path $curr_dir "..\config\InfaLogParser.conf"

# Read the contents of the configuration file
$confContents = Get-Content -Path $InfaLogParserConf

# Initialize an empty dictionary to store key-value pairs
$confData = @{}

# Loop through each line in the configuration file
foreach ($line in $confContents) {
    # Skip empty lines and comments
    if ($line -match '^\s*#') { continue }
    if ($line -match '^\s*$') { continue }

    # Split the line into key and value using the delimiter
    $key, $value = $line -split '=', 2

    # Trim whitespace from keys and values
    $key = $key.Trim()
    $value = $value.Trim()

    # Add key-value pair to the dictionary
    $confData[$key] = $value
}

# Display the contents of the configuration dictionary
$confData
$OutputDir = $confData['OutputDir']
$ARCHIVE_DIR = $confData['ArchiveLogDir']
$SESSION_LOG_DIR = $confData['SessionLogDir']
$METRICS_DIR = $confData['OutputDir']
$InfaCMDPath = $confData['InfaCMDPath']
$delimiter = $confData['delimiter']
$MaxParallelConversions = $confData['MaxParallelConversions']
$dbhost = $args[0]
$dbusername = $args[1]
$dbpassword = $args[2]
$dbschema = $args[3]
$ipaddress = $args[4]
$serviceusername = $args[5]
$servicepassword = $args[6]

# Clean Archive directory before collecting metrics
Remove-Item -Path $ARCHIVE_DIR -Recurse
New-Item -ItemType Directory -Path $OutputDir -Force
New-Item -ItemType Directory -Path $ARCHIVE_DIR -Force

# clean output directory before collecting metrics
Remove-Item -Path "${OutputDir}\infa_log_metrics*" -Force -Recurse

# get logs in provided time range
write-output "[INFO] Fetching logs between $start to $end..."

& "$curr_dir\GetLogPath.ps1"  $start  $end  $dbusername  $dbpassword  $dbhost $dbschema

(Get-Content -Raw "${OutputDir}\logpaths.csv") -replace "(?m)[\r\n]+$" | Set-Content "${OutputDir}\logpaths.csv"
if ((Get-Content "${OutputDir}\logpaths.csv" | Measure-Object -Line).Lines -le 1) {
    write-output "$((Get-Date).ToUniversalTime().ToString("yyyy-MM-dd HH:mm:ss")) [WARN] No logs found to process"
    createEmptyFile
    exit 1
}

# Filter the CSV with required condition
write-output "$((Get-Date).ToUniversalTime().ToString("yyyy-MM-dd HH:mm:ss")) [INFO] Converting log files to text..."

$LogPaths = Get-Content -Path "${OutputDir}\logpaths.csv" | Select-Object -Skip 1 | Where-Object { $_ -notlike "*Awaiting*" } | Where-Object { $_ -notlike "*NULL*" }

foreach ($log in $LogPaths) {
    # Your processing code for each log here
    $logColumns = $log -split ','
    $last = $logColumns[-1]
    write-output "Processing log: $last"
    
    # Call the function to convert bin to text
    write-output "${last}.bin" "${ArchiveLogDir}\${last}.txt"
	$filename = Split-Path -Path $last -leaf
	$binfile = "${last}.bin"
    $Archive = "${ARCHIVE_DIR}\${filename}.txt"
    Start-Job -ScriptBlock $ConvertBinToText -ArgumentList $binfile, $Archive, $InfaCMDPath
    Start-Sleep 1
    while(@(Get-Job -State "Running").Count -gt $MaxParallelConversions){
        Start-Sleep 1
    }
    write-output "conversion completed"
}

# Wait for all background jobs to complete
Get-Job | Wait-Job | Receive-Job

# Clean up background jobs
Get-Job | Remove-Job

write-output "$((Get-Date).ToUniversalTime().ToString("yyyy-MM-dd HH:mm:ss")) [INFO] Conversion completed" 

# parse the log files
$LogPaths2 = Get-Content -Path "${OutputDir}\logpaths.csv" | Select-Object -Skip 1 | Where-Object { $_ -notlike "*Awaiting*" } | Where-Object { $_ -notlike "*NULL*" } | Where-Object { $_.LOG_FILE_PATH -ne "" }

foreach ($log in $LogPaths2) {
    # Your processing code for each log here
    $logColumns = $log -split ','
    $last = $logColumns[-1]
    if ($last -eq ''){
        continue
    }
	$START_TIME = $logColumns[-3]
    $END_TIME = $logColumns[-2]
	write-output "log_file_path:$last"
	& "$curr_dir\InfaLogParser.ps1" "${ARCHIVE_DIR}\$(Split-Path -Leaf $last).txt" $START_TIME $END_TIME
}

write-output "[INFO] Log parser completed"