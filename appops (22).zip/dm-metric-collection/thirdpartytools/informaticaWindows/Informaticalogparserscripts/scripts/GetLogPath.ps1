#PowerShell
$curr_dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$InfaLogParserConf = Join-Path $curr_dir "../config/InfaLogParser.conf"
# Read the contents of the configuration file
$confContents = Get-Content -Path $InfaLogParserConf
# Initialize an empty dictionary to store key-value pairs
$confData = @{}

# Loop through each line in the configuration file
foreach ($line in $confContents) {
    # Skip empty lines and comments
    if ($line -match '^\s*#') { continue }
    if ($line -match '^\s*$') { continue }

    # Split the line into key and value using the delimiter
    $key, $value = $line -split '=', 2

    # Trim whitespace from keys and values
    $key = $key.Trim()
    $value = $value.Trim()

    # Add key-value pair to the dictionary
    $confData[$key] = $value
}

# Display the contents of the configuration dictionary
$confData
$OutputDir = $confData['OutputDir']
$ARCHIVE_DIR = $confData['ArchiveLogDir']
$SESSION_LOG_DIR = $confData['SessionLogDir']
$METRICS_DIR = $confData['OutputDir']
$InfaCMDPath = $confData['InfaCMDPath']


$STARTTIME = $args[0]
$ENDTIME = $args[1]

if ($args.Count -ne 6) {
    Write-error "Illegal number of parameters: Please provide START_TIME(MM-DD-YYYY hh:mi:ss) and END_TIME(MM-DD-YYYY hh:mi:ss)"
    exit 1
}

if (!(Test-Path -Path $OutputDir)) {
    New-Item -ItemType Directory -Path $OutputDir | Out-Null
}

$FILE = Join-Path $OutputDir "logpaths.csv"
"COLLECTION_START_TIME,WORKFLOW_ID,WORKFLOW_RUN_ID,SERVER_NAME,TASK_NAME,START_TIME,END_TIME,LOG_FILE_PATH" | Out-File -FilePath $FILE

$DBUSER = $args[2]
$DBPASS = $args[3]
$ServerName = $args[4]
$Schema_name = $args[5]

$csvData = Invoke-Sqlcmd -ServerInstance $ServerName -Username $DBUSER -Password $DBPASS -Query "SELECT ('$STARTTIME') AS DATE_CONSTANT,
OL.WORKFLOW_ID as WORKFLOW_ID,
OL.WORKFLOW_RUN_ID as WORKFLOW_RUN_ID,
T.SERVER_NAME as SERVER_NAME,
T.TASK_NAME as TASK_NAME,
CONVERT(VARCHAR, T.START_TIME, 120) as START_TIME,
CASE WHEN T.END_TIME IS NULL THEN 'Awaiting' ELSE CONVERT(VARCHAR, T.END_TIME, 120) END as END_TIME,
OL.log_file as log_file
FROM
$Schema_name.dbo.OPB_TASK_INST_RUN T ,
$Schema_name.dbo.OPB_SESS_TASK_LOG OL
WHERE
OL.WORKFLOW_ID = T.WORKFLOW_ID AND OL.WORKFLOW_RUN_ID = T.WORKFLOW_RUN_ID AND OL.INSTANCE_ID = T.INSTANCE_ID
AND (T.START_TIME BETWEEN CONVERT(DATETIME, '$STARTTIME', 101) AND CONVERT(DATETIME, '$ENDTIME', 101)
OR
T.END_TIME BETWEEN CONVERT(DATETIME, '$STARTTIME', 101) AND CONVERT(DATETIME, '$ENDTIME', 101))
ORDER BY START_TIME;" -TrustServerCertificate | ConvertTo-Csv

# Create CSV lines without quotes
$csvDataLines = $csvData -split "`r`n" | Select-Object -Skip 2
# Write the CSV data to the output file
$csvDataLines | Out-File -FilePath "$OutputDir/logpaths.tmp" -Encoding UTF8

(Get-Content -Path "$OutputDir/logpaths.tmp") -replace '"', '' | Set-Content -Path "$OutputDir/logpaths.tmp"

if ((Select-String -Path "$OutputDir/logpaths.tmp" -Pattern 'ERROR').Count -gt 0) {
    Write-output "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') [ERROR] Failed to collect log paths with below error:"
    Get-Content "$OutputDir/logpaths.tmp"
    exit 1
}

(Get-Content "$OutputDir/logpaths.tmp" | Select-Object -Unique) | Add-Content -Path $FILE
Remove-Item -Path "$OutputDir/logpaths.tmp" -Force