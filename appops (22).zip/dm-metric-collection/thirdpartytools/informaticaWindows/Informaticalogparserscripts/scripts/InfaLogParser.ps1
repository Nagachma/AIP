#PowerShell
$curr_dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$InfaLogParserConf = Join-Path $curr_dir "..\config\InfaLogParser.conf"

# Read the contents of the configuration file
$confContents = Get-Content -Path $InfaLogParserConf

# Initialize an empty dictionary to store key-value pairs
$confData = @{}

# Loop through each line in the configuration file
foreach ($line in $confContents) {
    # Skip empty lines and comments
    if ($line -match '^\s*#') { continue }
    if ($line -match '^\s*$') { continue }

    # Split the line into key and value using the delimiter
    $key, $value = $line -split '=', 2

    # Trim whitespace from keys and values
    $key = $key.Trim()
    $value = $value.Trim()

    # Add key-value pair to the dictionary
    $confData[$key] = $value
}

# Display the contents of the configuration dictionary
$confData
$OutputDir = $confData['OutputDir']
$ARCHIVE_DIR = $confData['ArchiveLogDir']
$SESSION_LOG_DIR = $confData['SessionLogDir']
$METRICS_DIR = $confData['OutputDir']
$InfaCMDPath = $confData['InfaCMDPath']
$delimiter = $confData['delimiter']
$SaveToArchive = $confData['SaveToArchive']
$dt = (Get-Date).ToUniversalTime().ToString("ddMMyyyy")
$start_time = $args[1]
$end_time = $args[2]

<#if (-not (Test-Path $SESSION_LOG_DIR -PathType Container)) {
    Write-Output "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') [ERROR] Session Log Directory [$SESSION_LOG_DIR] does not exist or not accessible"
    exit 1
} #>

if (-not (Test-Path $METRICS_DIR -PathType Container)) {
    New-Item -ItemType Directory -Path $METRICS_DIR | Out-Null
}

if (-not (Test-Path $ARCHIVE_DIR -PathType Container)) {
    New-Item -ItemType Directory -Path $ARCHIVE_DIR | Out-Null
}

function ConvertBin2Text {
    param (
        [Parameter(Mandatory=$true)]
        [string]$inputFile,
        [Parameter(Mandatory=$true)]
        [string]$outputFile
    )

    Write-Output "$((Get-Date).ToUniversalTime().ToString("yyyy-MM-dd HH:mm:ss")) [INFO] Converting $inputFile to text..."
	if ($inputfile -ne "") {
	Start-Process -FilePath $InfaCMDPath -ArgumentList "ConvertLogFile", "-InputFile", $inputFile, "-fm", "text", "-lo", $outputFile
	}
    (Get-Content $outputFile) -replace "\r" | Set-Content $outputFile
}

function Get-LogMetrics {
    # create output file if not exists
    $o_filename = "${METRICS_DIR}/infa_log_metrics_${dt}.csv"
    if (-not (Test-Path $o_filename)) {
        "Start_Time,End_Time,Server_Name,Repository_Name,Folder_Name,Workflow_Name,Session_Name,Workflow_Execution_ID,Mapping_Name,Site_ID,pid,Hostname,AggIndexCacheSizeMB,AggDataCacheSizeMB,JnrIndexCacheSizeMB,JnrDataCacheSizeMB,Stale_Data,Log_File" | Out-File -FilePath $o_filename -Encoding utf8
    }


    $start_time = Get-Date -Date $start_time -Format 'yyyy-MM-dd HH:mm:ss'
    $end_time = Get-Date -Date $end_time -Format 'yyyy-MM-dd HH:mm:ss'
	
	$file_content = Get-Content -Path $log_file_to_be_processed

	$keywords = @("Server Name: \[(.*?)\]","Repository Name: \[(.*?)\]","Folder: \[(.*?)\]","Workflow: \[(.*?)\]","Initializing session \[(.*?)\]","Run Id: \[(.*?)\]","Mapping name: (.*)","Current Process ID: \[(.*?)\]")
	#Loop through each line and look for the line with metrics_name
	foreach ($line in $file_content) {
	#write-host $line
		foreach ($keyword in $keywords){
			if ($line -match $keyword){
				$pattern = $matches[0].Trim()
				if ($pattern -like "Server Name:*") {
					$Server_name = $matches[1]
					}
				elseif ($pattern -like "Repository Name:*") {
					$Repository_name = $matches[1]
					}
				elseif ($pattern -like "Folder:*") {
					$Folder_Name = $matches[1]
					}
				elseif ($pattern -like "Workflow:*") {
					$Workflow_Name = $matches[1]
					}
				elseif ($pattern -like "Initializing session*")  {
					$Session_Name = $matches[1]
					}
				elseif ($pattern -like "Run Id:*") {
					$Workflow_Execution_ID = $matches[1]
					}
				elseif ($pattern -like "Mapping name:*") {
					$Mapping_Name = $matches[1]
				$Mapping_Name = $Mapping_Name.Trim(".")
					}
				elseif ($pattern -like "Run Instance Name:*") {
					$Site_ID = $matches[1]
					}
				elseif ($pattern -like "Current Process ID:*") {
					$P_ID = $matches[1]
					}
				}
		}
	}

	#Hostname
	$lines = Get-Content -Path $log_file_to_be_processed -TotalCount 2
	$secondLine = $lines[1]
	$splitLine = $secondLine -split $delimiter
	$Hostname = $splitLine[6].Trim()

	#function call to get AggIndexCacheSizeMB,JnrIndexCacheSizeMB,AggDataCacheSizeMB,JnrDataCacheSizeMB
	$AggIndexCacheSizeMB = Log_Metrics -arg1 '\[Index Cache\] size for transformation' -arg2 'agg*'
	$JnrIndexCacheSizeMB = Log_Metrics -arg1 '\[Index Cache\] size for transformation' -arg2 'jnr*'
	$AggDataCacheSizeMB = Log_Metrics -arg1 '\[Data Cache\] size for transformation' -arg2 'agg*'
	$JnrDataCacheSizeMB = Log_Metrics -arg1 '\[Data Cache\] size for transformation' -arg2 'jnr*'

    $Stale_Error_Count = (Select-String -Pattern "Error setting/closing connection: Not Connected|Cannot COPY into nonexistent table" -Path $log_file_to_be_processed -AllMatches).Matches.Count
    if ($Stale_Error_Count -gt 0) {
        $Stale_Data = 1
    } else {
        $Stale_Data = 0
    }
    "${start_time},${end_time},${Server_Name},${Repository_Name},${Folder_Name},${Workflow_Name},${Session_Name},${Workflow_Execution_ID},${Mapping_Name},${Site_ID},${P_ID},${Hostname},${AggIndexCacheSizeMB},${AggDataCacheSizeMB},${JnrIndexCacheSizeMB},${JnrDataCacheSizeMB},${Stale_Data},${in_file}" | Out-File -FilePath $o_filename -Append -Encoding utf8
}
function Log_Metrics{
	param (
        [string]$arg1,
        [string]$arg2
    )
	$lines = Get-Content -Path $log_file_to_be_processed | Where-Object { $_ -match $arg1 }
    # Process each line
	foreach ($line in $lines) {
    # Split the line into fields
	$fields = $line -split '\[|\]'
    # Extract the 4th and 8th fields
    $field4 = $fields[3]
    $field8 = $fields[7]
	
    if ($field4 -like $arg2) {
		$field8 = [int]$field8
		$Metric += $field8
		#write-host $JnrIndexCacheSize
	}
	}
	$MetricMB = $Metric / 1000000
	return $MetricMB
}
function Get-MetadataMetrics {
    param(
        [string]$logFileToBeProcessed,
        [string]$dt,
        [string]$start_time,
        [string]$end_time,
        [string]$Server_Name,
        [string]$Repository_Name,
        [string]$Folder_Name,
        [string]$Workflow_Name,
        [string]$Session_Name,
        [string]$Workflow_Execution_ID,
        [string]$Mapping_Name,
        [string]$Site_ID,
        [string]$PID,
        [string]$Hostname
    )

    # Create output file if not exists
    $o_filename = Join-Path $METRICS_DIR "infa_metadata_${dt}.csv"
    if (-not (Test-Path $o_filename)) {
        "Start_Time,End_Time,Server_Name,Repository_Name,Folder_Name,Workflow_Name,Session_Name,Workflow_Execution_ID,Mapping_Name,Site_ID,PID,Hostname,Min_JVM_Heap,Max_JVM_Heap,Target_Tables,Warnings,Errors,Stale_Error_Count" | Out-File $o_filename -Encoding utf8
    }

    $jvm_params = Select-String -Path $logFileToBeProcessed -Pattern 'JVM was created with the following JVM options' | ForEach-Object {
        $_.Line -match 'Xms.*.Xmx.*'
    } | ForEach-Object {
        $_ -replace '].*',''
    }

    $Min_JVM_Heap = ($jvm_params -split ' ')[0] -replace 'Xms',''
    $Max_JVM_Heap = ($jvm_params -split ' ')[1] -replace '-Xmx',''

    $Target_Tables = Select-String -Path $logFileToBeProcessed -Pattern 'WRT.*.Target:' | ForEach-Object {
        $_.Line -split (': ')[1]
    } | Sort-Object -Unique | ForEach-Object {
        $_.Split(' ')[0]
    } -join ':'

    $Warnings = (Select-String -Path $logFileToBeProcessed -Pattern "WARNING$delimiter" | Measure-Object).Count
    $Errors = (Select-String -Path $logFileToBeProcessed -Pattern "ERROR$delimiter" | Measure-Object).Count

    "$start_time,$end_time,$Server_Name,$Repository_Name,$Folder_Name,$Workflow_Name,$Session_Name,$Workflow_Execution_ID,$Mapping_Name,$Site_ID,$PID,$Hostname,$Min_JVM_Heap,$Max_JVM_Heap,$Target_Tables,$Warnings,$Errors,$Stale_Error_Count" | Out-File $o_filename -Append -Encoding utf8
}


function Get-LoadStats {
    param(
        [string]$logFileToBeProcessed,
        [string]$dt,
        [string]$Workflow_Name,
        [string]$Workflow_Execution_ID,
        [string]$PID,
        [string]$Hostname
    )

    # Create output file if not exists
    $o_filename = Join-Path $METRICS_DIR "infa_load_stats_${dt}.csv"
    if (-not (Test-Path $o_filename)) {
        "Workflow_Name,Workflow_Execution_ID,PID,Hostname,Partition_Name,Stage,Total_Run_Time(sec),Total_Idle_Time(sec),Busy_Percentage" | Out-File $o_filename -Encoding utf8
    }

    $logContent = Get-Content -Path $logFileToBeProcessed

    $logContent | Select-String -Pattern 'Thread.*.created for.*.of partition point.*.has completed' | ForEach-Object {
        $_.Line -match 'Thread.*.created for (.*) of partition point (.*) has completed'
        $stg = $Matches[1]
        $partitn = $Matches[2]
        if ($_ -notmatch 'The total run time was insufficient for any meaningful statistics') {
            $stats = ($logContent | Select-String -Pattern ("Thread.*.created for \[${[regex]::Escape($stg)}\] of partition point \[${[regex]::Escape($partitn)}\] has completed") -Context 0, 3 | Select-String -Pattern '=').Line -replace '\[.*?\]'
            $partitn = $partitn -replace ',', ':'
            "$Workflow_Name,$Workflow_Execution_ID,$PID,$Hostname,$partitn,$stg,$stats" | Out-File $o_filename -Append -Encoding utf8
        }
    }
}


function Get-TransformationStats {
    param(
        [string]$logFileToBeProcessed,
        [string]$dt,
        [string]$Workflow_Name,
        [string]$Workflow_Execution_ID,
        [string]$PID,
        [string]$Hostname
    )

    # Create output file if not exists
    $o_filename = Join-Path $METRICS_DIR "infa_transformation_stats_${dt}.csv"
    if (-not (Test-Path $o_filename)) {
        "Workflow_Name,Workflow_Execution_ID,PID,Hostname,Transformation_Name,Input_Rows,Index_Cache_Memory(Bytes),Data_Cache_Memory(Bytes),Index_Cache_Size(Bytes),Data_Cache_Size(Bytes)" | Out-File $o_filename -Encoding utf8
    }

    Select-String -Path $logFileToBeProcessed -Pattern '[Index Cache] size for transformation' | ForEach-Object {
        $_.Line -match '\[([^]]+)\] size for transformation ([^,]+)' | Out-File .idx.tmp -Append -Encoding utf8
    }
    Select-String -Path $logFileToBeProcessed -Pattern '[Data Cache] size for transformation' | ForEach-Object {
        $_.Line -match '\[([^]]+)\] size for transformation ([^,]+)' | Out-File .dat.tmp -Append -Encoding utf8
    }
    Select-String -Path $logFileToBeProcessed -Pattern 'The index cache size that would hold' | ForEach-Object {
        $_.Line -match '\[([^]]+)\] (.+?) size that would hold ([^,]+)' | Select-Object @{Name='Name';Expression={$Matches[1]}}, @{Name='Index_Cache_Memory(Bytes)';Expression={$Matches[3]}}, @{Name='Data_Cache_Memory(Bytes)';Expression={$Matches[3]}} | Out-File .idx.mem -Append -Encoding utf8
    }
    Select-String -Path $logFileToBeProcessed -Pattern 'The data cache size that would hold' | ForEach-Object {
        $_.Line -match '\[([^]]+)\] (.+?) size that would hold ([^,]+)' | Select-Object @{Name='Name';Expression={$Matches[1]}}, @{Name='Data_Cache_Memory(Bytes)';Expression={$Matches[3]}} | Out-File .dat.mem -Append -Encoding utf8
    }

    $idxDatMem = Compare-Object (Get-Content .idx.mem) (Get-Content .dat.mem) -Property Name -PassThru | Where-Object { $_.SideIndicator -eq '==' }
    $idxDatMem | ForEach-Object {
        $line = $_.Name + ',' + $_.'Index_Cache_Memory(Bytes)' + ',' + $_.'Data_Cache_Memory(Bytes)'
        $line | Out-File .idx_dat.mem -Append -Encoding utf8
    }

    $idxTmp = Import-Csv .idx.tmp -Header 'Transformation_Name', 'Index_Cache_Size(Bytes)'
    $datTmp = Import-Csv .dat.tmp -Header 'Transformation_Name', 'Data_Cache_Size(Bytes)'

    $result = $idxTmp | Join-Object -Right $datTmp -RightProperty 'Transformation_Name' -Type Inner -On 'Transformation_Name'
    $result | ForEach-Object {
        $line = $_.Transformation_Name + ',' + $_.Input_Rows + ',' + $_.'Index_Cache_Memory(Bytes)' + ',' + $_.'Data_Cache_Memory(Bytes)' + ',' + $_.'Index_Cache_Size(Bytes)' + ',' + $_.'Data_Cache_Size(Bytes)'
        $line | Out-File $o_filename -Append -Encoding utf8
    }

    Remove-Item .*.tmp, .*.mem -Force
}


function get_warnings {
    param(
        [string]$logFileToBeProcessed,
        [string]$dt,
        [string]$Workflow_Name,
        [string]$Workflow_Execution_ID,
        [string]$PID,
        [string]$Hostname
    )

    $o_filename = Join-Path $METRICS_DIR "infa_warnings_${dt}.csv"
    if (-not (Test-Path $o_filename)) {
        "Workflow_Name,Workflow_Execution_ID,PID,Hostname,Warning_Message,Occurrences" | Out-File $o_filename -Encoding utf8
    }

    Select-String -Path $logFileToBeProcessed -Pattern 'WARNING' | ForEach-Object {
        $message = ($_ -split $delimiter)[6]
        $occurrences = Select-String -Path $logFileToBeProcessed -Pattern $message | Measure-Object | Select-Object -ExpandProperty Count
        $message = $message -replace ',', ';'
        "$Workflow_Name,$Workflow_Execution_ID,$PID,$Hostname,$message,$occurrences" | Out-File $o_filename -Append -Encoding utf8
    }
}

function get_errors {
    param(
        [string]$logFileToBeProcessed,
        [string]$dt,
        [string]$Workflow_Name,
        [string]$Workflow_Execution_ID,
        [string]$PID,
        [string]$Hostname
    )

    $o_filename = Join-Path $METRICS_DIR "infa_errors_${dt}.csv"
    if (-not (Test-Path $o_filename)) {
        "Workflow_Name,Workflow_Execution_ID,PID,Hostname,Error_Message,Occurrences" | Out-File $o_filename -Encoding utf8
    }

    Select-String -Path $logFileToBeProcessed -Pattern 'ERROR' | ForEach-Object {
        $message = ($_ -split $delimiter)[6]
        $occurrences = Select-String -Path $logFileToBeProcessed -Pattern $message | Measure-Object | Select-Object -ExpandProperty Count
        $message = $message -replace ',', ';'
        "$Workflow_Name,$Workflow_Execution_ID,$PID,$Hostname,$message,$occurrences" | Out-File $o_filename -Append -Encoding utf8
    }
}


# Get a log file name as an argument
if ($args.Length -gt 0) {
    $in_file = $args[0]
} else {
    Write-Error "$((Get-Date).ToUniversalTime().ToString("yyyy-MM-dd HH:mm:ss")) [ERROR] Provide log file name as an argument"
    exit 1
}
# Use provided path if an absolute path is provided, else use path from config file
<#if ($in_file -match '^\') {
    $SESSION_LOG_DIR = Split-Path $in_file
	write-host "inside infile"
    $in_file = [System.IO.Path]::GetFileName($in_file)
} 
#>
Add-Type -AssemblyName System.IO
$in_file = [System.IO.Path]::GetFileName($in_file)

Write-output "$((Get-Date).ToUniversalTime().ToString("yyyy-MM-dd HH:mm:ss")) [INFO] Processing $in_file..."

# Check if the provided session file exists or not
<#if (-not (Test-Path (Join-Path $SESSION_LOG_DIR $in_file))) {
    Write-Host "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') [ERROR] Session Log File [$in_file] does not exist under [$SESSION_LOG_DIR]"
    exit 1
} elseif ($SESSION_LOG_DIR -ne $ARCHIVE_DIR) {
    # Do not copy if the provided file is in the archive
    Copy-Item -Force (Join-Path $SESSION_LOG_DIR $in_file) $ARCHIVE_DIR
} #>

# Convert the log file to text if it is in binary format
if ($in_file -match '\.bin$' ) {
    $log_file_to_be_processed = Join-Path $ARCHIVE_DIR ([System.IO.Path]::GetFileNameWithoutExtension($in_file) + '.txt')
    ConvertBin2Text "$ARCHIVE_DIR\$in_file" "$log_file_to_be_processed"  # Replace this with the actual convertBin2Text function or logic
} else {
    $log_file_to_be_processed = Join-Path $ARCHIVE_DIR $in_file
}

# Start parsing
Write-output "$((Get-Date).ToUniversalTime().ToString("yyyy-MM-dd HH:mm:ss")) [INFO] Collecting log metrics..."
# Call the get_log_metrics function or execute its logic here
Get-LogMetrics

if ($CollectMetadataStats -eq 'Y') {
    # Call the get_metadata_metrics function or execute its logic here
}

if ($CollectLoadStats -eq 'Y') {
    write-output "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') [INFO] Collecting load stats..."
    # Call the get_load_stats function or execute its logic here
}

if ($CollectTransformationStats -eq 'Y') {
    write-output "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') [INFO] Collecting Transformation stats..."
    # Call the get_transformation_stats function or execute its logic here
}

if ($CollectWarnings -eq 'Y') {
    write-output "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') [INFO] Collecting Warnings..."
    # Call the get_warnings function or execute its logic here
}

if ($CollectErrors -eq 'Y') {
    write-output "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') [INFO] Collecting Errors..."
    # Call the get_errors function or execute its logic here
}

if ($SaveToArchive -eq 'Y') {
    write-output "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') [INFO] Removing log files from archive..."
    $filenameWithoutExtension = $in_file.Replace(".txt", "")
	Remove-Item -Path "$ARCHIVE_DIR\$filenameWithoutExtension*" -Force -Recurse
}