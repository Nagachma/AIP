import vault_credentials
import yaml
import subprocess, sys, os
import logging

logger = logging.getLogger('wrapper.py')
logger.setLevel(logging.DEBUG)
# create console handler and set level to debug
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
# add formatter to ch
ch.setFormatter(formatter)
# add ch to logger
logger.addHandler(ch)

def load_configuration(cwdPath):
    """Read and load data from config.yaml file"""
    cfg = {}  # Check if this is a dict
    try:
        with open(cwdPath, 'r') as yamlfile:
            cfg = yaml.safe_load(yamlfile)
    except yaml.YAMLError as exc:
        logger.exception(exc)
    except Exception as e:
        logger.exception(e)
    return cfg
# Get the directory where the current script is located
script_dir = os.path.dirname(os.path.abspath(__file__))
# Navigate one step back to the parent directory
parent_dir = os.path.dirname(script_dir)
# Construct the path to the "config" folder
config_dir = os.path.join(parent_dir, 'config')
# Construct the full path to the configuration file
config_file_path = os.path.join(config_dir, 'config.yaml')
cfg = load_configuration(config_file_path)
cred = vault_credentials.get_secret_from_vault(cfg['vault_path'], cfg['vault_keys'])
db_host=cred['db_host']
db_username=cred['db_username']
db_password=cred['db_password']
db_schema=cred['db_schema']
ipaddress=cred['ipaddress']
serviceusername=cred['serviceusername']
servicepassword=cred['servicepassword']

# Define the PowerShell script file and arguments
powershell_script = "GetInformaticaLogMetrics.ps1"

# Use subprocess to run the PowerShell script with arguments
command = ["C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe", "-File", powershell_script, db_host, db_username, db_password, db_schema, ipaddress, serviceusername, servicepassword]

# Run the PowerShell script and capture the output
try:
    output = subprocess.check_output(command, stderr=subprocess.STDOUT)
    logger.info("PowerShell Script Output:")
    logger.info(output)
except subprocess.CalledProcessError as e:
    logger.info('PowerShell Script Error:')
    logger.info(e.output)
