#!/bin/bash
# author: sachin.maurya
# Email: sachin.maurya@accenture.com
# License: GPL
# Version: 1.0.0
# Copyright: Copyright 2023, The OrchastrAI Project

curr_dir=$(dirname $0)
echo "$curr_dir"

STARTTIME=$(date --date='5 minutes ago' +"%m-%d-%Y %H:%M:%S")
ENDTIME=$(date +"%m-%d-%Y %H:%M:%S")
DBUSER=$1
DBPASS=$2
infdbhost=$3
Schema_Name=$4

if [ "$#" -ne 4 ]
then
echo "Illegal number of parameters: Please provide START_TIME(MM-DD-YYYY hh:mi:ss) and END_TIME(MM-DD-YYYY hh:mi:ss)"
exit
fi

# Output file path
output_file=$curr_dir/../temp/output_temp.csv

# Remove the output file if it already exists
if [ -f "$output_file" ]; then
  rm "$output_file"
fi

# Run the SQL query and append the output to the output file
sqlcmd -S $infdbhost -U $DBUSER -P $DBPASS -Q "WITH WORKFLOW_AND_TASK_ALL AS (
       SELECT DISTINCT
        '$ENDTIME' AS CTIME,
        CONVERT(VARCHAR, T.START_TIME, 120) AS START_TIME,
        CASE 
            WHEN CONVERT(VARCHAR, T.END_TIME, 120) LIKE '%1753-01-01%' THEN CONVERT(VARCHAR, GETDATE(), 120)
            ELSE CONVERT(VARCHAR, T.END_TIME, 120)
        END AS END_TIME,
        S.SUBJ_NAME AS FOLDER_NAME,
        SRV.SERVER_NAME AS INTEGRATION_SERVICE,
        W.WORKFLOW_NAME AS WORKFLOW_NAME,
        T.WORKFLOW_RUN_ID AS WORKFLOW_RUN_ID,
        T.TASK_NAME AS TASK_NAME,
        W.WORKFLOW_ID AS WORKFLOW_ID,
        CASE
            WHEN W.RUN_STATUS_CODE = 1 THEN 0
            WHEN W.RUN_STATUS_CODE = 2 THEN 3
            WHEN W.RUN_STATUS_CODE = 3 THEN 1
            WHEN W.RUN_STATUS_CODE = 4 THEN 3
            WHEN W.RUN_STATUS_CODE = 5 THEN 3
            WHEN W.RUN_STATUS_CODE = 6 THEN 2
            WHEN W.RUN_STATUS_CODE = 7 THEN 3
            WHEN W.RUN_STATUS_CODE = 8 THEN 3
            WHEN W.RUN_STATUS_CODE = 9 THEN 3
            WHEN W.RUN_STATUS_CODE = 10 THEN 3
            WHEN W.RUN_STATUS_CODE = 11 THEN 3
            WHEN W.RUN_STATUS_CODE = 12 THEN 3
            WHEN W.RUN_STATUS_CODE = 13 THEN 3
            WHEN W.RUN_STATUS_CODE = 14 THEN 3
            WHEN W.RUN_STATUS_CODE = 15 THEN 3
        END AS STATUS,
        CASE
            WHEN CONVERT(VARCHAR, T.END_TIME, 120) LIKE '%1753-01-01%' THEN ROUND((DATEDIFF(SECOND, T.START_TIME, GETDATE())), 0)
            ELSE ROUND((DATEDIFF(SECOND, T.START_TIME, T.END_TIME)), 0)
        END AS TOTAL_TIME,
        CASE
            WHEN CONVERT(VARCHAR, W.END_TIME, 120) LIKE '%1753-01-01%' THEN ROUND((DATEDIFF(SECOND, W.START_TIME, GETDATE())), 0)
            ELSE ROUND((DATEDIFF(SECOND, W.START_TIME, W.END_TIME)), 0)
        END AS WORFLOW_EXECUTION_TIME,
        CONVERT(VARCHAR, GETDATE(), 120) AS DB_TPS,
        -- Replace REGEXP_SUBSTR with SUBSTRING and CHARINDEX
        --SUBSTRING(W.log_file, CHARINDEX('log.', W.log_file) + 4, CHARINDEX('.', W.log_file) - CHARINDEX('log.', W.log_file) - 4) AS site_no,
        REPLACE(CONVERT(varchar(max), W.RUN_ERR_MSG), ',', ' ') AS RUN_ERR_MSG,
        T.INSTANCE_ID AS INSTANCE_ID
    FROM
        ${Schema_Name}.dbo.OPB_WFLOW_RUN W
        JOIN ${Schema_Name}.dbo.OPB_TASK_INST_RUN T ON W.SUBJECT_ID = T.SUBJECT_ID AND W.WORKFLOW_RUN_ID = T.WORKFLOW_RUN_ID AND W.WORKFLOW_ID = T.WORKFLOW_ID
        JOIN ${Schema_Name}.dbo.OPB_SUBJECT S ON S.SUBJ_ID = W.SUBJECT_ID
        JOIN ${Schema_Name}.dbo.OPB_SERVER_INFO SRV ON SRV.SERVER_ID = W.SERVER_ID
    WHERE
        (T.TASK_TYPE = 68 OR T.TASK_TYPE = 58)
        AND (W.START_TIME BETWEEN CONVERT(DATETIME, '$STARTTIME', 101) AND CONVERT(DATETIME, '$ENDTIME', 101)
            OR W.END_TIME BETWEEN CONVERT(DATETIME, '$STARTTIME', 101) AND CONVERT(DATETIME, '$ENDTIME', 101))

)
SELECT
    CTIME,
    START_TIME,
    END_TIME,
    FOLDER_NAME,
    INTEGRATION_SERVICE,
    WORKFLOW_NAME,
    WTA.WORKFLOW_RUN_ID,
    TASK_NAME,
    STATUS,
    COALESCE(OL.SRC_SUCCESS_ROWS, 0) AS SUCCESSFUL_SOURCE_ROWS,
    COALESCE(OL.SRC_FAILED_ROWS, 0) AS FAILED_SOURCE_ROWS,
    COALESCE(OL.TARG_SUCCESS_ROWS, 0) AS SUCCESSFUL_TARGET_ROWS,
    COALESCE(OL.TARG_FAILED_ROWS, 0) AS FAILED_TARGET_ROWS,
    TOTAL_TIME,WORFLOW_EXECUTION_TIME,DB_TPS,RUN_ERR_MSG
FROM
    WORKFLOW_AND_TASK_ALL WTA
	LEFT OUTER JOIN ${Schema_Name}.DBO.OPB_SESS_TASK_LOG OL ON OL.INSTANCE_ID = WTA.INSTANCE_ID AND OL.WORKFLOW_ID = WTA.WORKFLOW_ID AND OL.WORKFLOW_RUN_ID = WTA.WORKFLOW_RUN_ID;" -s "," -o "$output_file" -h-1 -W

# Remove the second line (dashed line) from the CSV
sed '2d' "$output_file" 

FILE=/data01/appops/tools/thirdpartytools/informaticawindows/collection/metrics/infadb/infadb_informaticawindows_metrics$(date -u +"_%d%m%Y").csv

if test -f "$FILE"
then
rm -rf /data01/appops/tools/thirdpartytools/informaticawindows/collection/metrics/infadb/infadb_informaticawindows_metrics_*
touch $FILE
else
touch $FILE
fi

echo 'file: '$FILE

lc=`wc -l $FILE | cut -d ' ' -f1`

echo 'line count: '$lc

if [ $lc -eq 0 ]
then
echo 'inside line 0'
echo "COLLECTION_START_TIME,START_TIME,END_TIME,FOLDER_NAME,INTEGRATION_SERVICE,WORKFLOW_NAME,WORKFLOW_EXECUTION_ID,TASK_NAME,STATUS,SUCCESSFUL_SOURCE_ROWS,FAILED_SOURCE_ROWS,SUCCESSFUL_TARGET_ROWS,FAILED_TARGET_ROWS,EXECUTION_TIME,WORFLOW_EXECUTION_TIME,DB_TIMESTAMP,RUN_ERR_MSG" > $FILE
cat $curr_dir/../temp/output_temp.csv | grep -v "rows affected" $curr_dir/../temp/output_temp.csv >>$FILE
else
cat $curr_dir/../temp/output_temp.csv | grep -v "rows affected" $curr_dir/../temp/output_temp.csv >>$FILE
fi