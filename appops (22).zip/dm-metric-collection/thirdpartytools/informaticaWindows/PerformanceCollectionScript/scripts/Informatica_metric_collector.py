# import multiprocessing
import os
import logging
import subprocess
import platform
import yaml
import sys
from vault_utility_v2 import vault_credentials

logger = logging.getLogger('Informatica_metric_collector.py')
logger.setLevel(logging.INFO)
# create console handler and set level to debug
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
# add formatter to ch
ch.setFormatter(formatter)
# add ch to logger
logger.addHandler(ch)

def load_configuration(cwdPath):
    """Read and load data from config.yaml file"""
    cfg = {}  # Check if this is a dict
    try:
        with open(cwdPath, 'r') as yamlfile:
            cfg = yaml.safe_load(yamlfile)
    except yaml.YAMLError as exc:
        logger.exception(exc)
    except Exception as e:
        logger.exception(e)
    return cfg

if __name__ == '__main__':
    pwd = os.path.dirname(os.path.realpath(__file__))
    # logger.info(str(pwd))
    if len(sys.argv) == 3:
        inputs={'BASE_HOME_DIR': sys.argv[1],'CONFIG_PATH': sys.argv[2] }
    else:
        logger.error("Check the arguments passed")
    
    bsdir = ''
    if inputs.get('BASE_HOME_DIR'):
        bsdir = inputs['BASE_HOME_DIR']

    config = {}
    config_file_path=''
    if inputs.get('CONFIG_PATH'):
        if platform.system() == 'Windows':
            config_file_path = str(inputs.get('CONFIG_PATH')).replace("/","\\")
        else:
            config_file_path=str(inputs.get('CONFIG_PATH'))
        config = load_configuration(config_file_path)

        # Loading creds from vault
    cred = vault_credentials.get_secret_from_vault(config['vault_path'], config['vault_keys'])
    REMOTE_SERVER_IP=cred['ipaddress']
    USERNAME =f"{cred['serviceusername']}"
    logger.info(USERNAME)
    PASSWORD=cred['servicepassword']
    METRICS_DIR1 =config['METRICS_DIR1']
    DATA_DIR1 = bsdir +config['DATA_DIR1']
    # TIME_DELTA =config['TIME_DELTA']
    TOOL_NAME =config['TOOL_NAME']
    script_path= config['BASH_SCRIPT_PATH']
    ruby_script_path= config['RUBY_SCRIPT_PATH']
    #bash='sh'
    # if inputs.get('BASH'):
    #     bash=inputs.get('BASH')


    bash_script_path=bsdir+script_path #relative path after base home dir
    ruby_path =bsdir+ruby_script_path
    bash_command = ['sh', bash_script_path, REMOTE_SERVER_IP, f"{USERNAME}", f"{PASSWORD}", f"{METRICS_DIR1}", f"{DATA_DIR1}", TOOL_NAME, ruby_path]
    logger.info("command:{}".format(bash_command))


    process1= subprocess.Popen(bash_command, stderr=subprocess.PIPE, stdout=subprocess.PIPE, shell=False)
    stdout, stderr = process1.communicate()
    logger.info(f"stdout: [{stdout.decode('utf-8')}]")
    logger.info(f"stderr: [{stderr.decode('utf-8')}]")
    # exit_code = subprocess.call(bash_script_path)

    logger.info('Running the bash script')