#! /bin/bash

TIME_DELTA=`date -u +%d%m%Y`
TIME_DELTA2=`date -u +%d%m%Y`
REMOTE_SERVER_IP=$1
USERNAME=${2}
PASSWORD=$3
METRICS_DIR1=$4
DATA_DIR1=$5
TOOL_NAME=$6
RUBY_SCRIPT_PATH=$7

#sleep 120
mkdir -p $DATA_DIR1
echo "Collecting metrics from all nodes for entire date i.e. $day!"
for host in $(echo $REMOTE_SERVER_IP |sed "s/,/ /g")
do
    echo "Collecting metrics from server: $host ..."
    if [ "$TOOL_NAME" = "INFORMATICAWINDOWS" ]
    then
        echo "Copying file for $i ..."
        middle="infa_log_metrics"
        tsm_status="tsm_status"
        remote_path1=${METRICS_DIR1}\\${middle}_${TIME_DELTA}.csv
        echo $remote_path1
        local_path1="${DATA_DIR1}/logparser_informaticawindows_metrics_${TIME_DELTA2}.csv"
        echo $local_path1
        /usr/local/rvm/rubies/ruby-2.6.6/bin/ruby $RUBY_SCRIPT_PATH $host ${USERNAME} ${PASSWORD} ${remote_path1} ${local_path1}
    fi
    echo "copied all csv files from $host server!!";
done
echo "Done copying all remote metrics CSV files to local server"