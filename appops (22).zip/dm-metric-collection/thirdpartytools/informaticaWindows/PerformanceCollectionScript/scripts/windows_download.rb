##!/usr/bin/ruby
require 'winrm-fs'

if ARGV.length < 5
        puts "Error : Please pass ip,userid,password,input_file,target_file as argument"
        exit 1
end

ip = ARGV[0]
user_id = ARGV[1]
passwd = ARGV[2]
src = ARGV[3]
dest = ARGV[4]
puts ip
endpoint = 'http://' + ip +':5985/wsman'
auth_method = "negotiate"
begin 
        opts = { endpoint: endpoint,transport: auth_method,user: user_id,password: passwd,operation_timeout: 300}
        conn = WinRM::Connection.new(opts)
        file_manager = WinRM::FS::FileManager.new(conn)
        # upload file.txt from the current working directory
        #file_manager.upload(input_file, target_file)
        #download file from windows host
        ret = file_manager.download(src,dest)
        puts "#{ret}"
        if ret
            puts "#{src} File downloaded successfully from #{ip}"
        else
            puts "Error downloading #{src} file from #{ip}"
        end

rescue
    puts "Error : #{src} File is not downloaded from #{ip}"
end
