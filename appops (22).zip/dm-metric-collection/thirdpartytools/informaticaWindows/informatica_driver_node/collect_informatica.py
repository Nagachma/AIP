"""Custom Script to fetch Informatica metrics"""
from encodings import utf_8
import logging
import os
import subprocess
import platform
from datetime import datetime as dt
#import pandas as pd
import yaml
from datetime import timezone
from multiprocessing.pool import ThreadPool as Pool
import shutil
from vault_utility_v2 import vault_credentials

"""
__author__ = "Arunabha Das"
__copyright__ = "Copyright 2023, The OrchastrAI Project"
__license__ = "GPL"
__version__ = "1.0.0"
__email__ = "arunabha.a.das@accenture.com"
"""

logger = logging.getLogger('Collecting Informatica Log Parser and Infa DB Metrics')
logger.setLevel(logging.INFO)

# create console handler and set level to debug
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.DEBUG)

# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# add formatter to console_handler
console_handler.setFormatter(formatter)

# add console_handler to logger
logger.addHandler(console_handler)


def load_configuration(lconfig):
    """Read and load data from config.yaml file"""
    cfg = {}
    try:
        with open(lconfig, 'r') as yaml_file:
            cfg = yaml.safe_load(yaml_file)
    except yaml.YAMLError as exc:
        logger.exception(exc)
    except Exception as e:
        logger.exception(e)
    return cfg

def create_dir(dir_path):
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)

def remove_dir(dir_path):
    if os.path.exists(dir_path):
        shutil.rmtree(dir_path)

def execute_commands(command,cred):
    """ Execute commands on Remote Machine.
  
    Parameters:
    command: Command to run in shell
    Returns: None
    """
    
    try:
        # Running Command
        process1 = subprocess.Popen(command, stderr=subprocess.PIPE, stdout=subprocess.PIPE, shell=False)
        stdout, stderr = process1.communicate()
        logger.info(f"stdout: [{stdout.decode('utf-8')}]")
        logger.info(f"stderr: [{stderr.decode('utf-8')}]")
        logger.info('Running the bash script')

    except Exception as e:
        logger.error("Error : {}".format(e))
        exit(1)


def process_from_cli(config):
    create_dir(config.get('BASE_HOME_DIR') + config.get('INFA_DB_DIR'))
    
    try:
        #Loading creds from vault
        cred = vault_credentials.get_secret_from_vault(config['vault_path'],config['vault_keys'])

        if cred.get('db_username') is not None:
            infdbusername=cred.get('db_username')
        else:
            logger.error("No db_username found")
            raise Exception('No db_username found')
        
        if cred.get('db_password') is not None:
            infdbpassword=cred.get('db_password')
        else:
            logger.error("No db_password found")
            raise Exception('No db_password found')
        
        if cred.get('db_schema') is not None:
            infdbschema=cred.get('db_schema')
        else:
            logger.error("No db_schema found")
            raise Exception('No db_schema found')

        if cred.get('db_host') is not None:
            infdbhost = cred.get('db_host')
        else:
            logger.error("No db_host found")
            raise Exception('No db_host found')
        
        # Command Creation
        interpreter=config['SSH_CONFIG']['PYTHON_INTERPRETER']
        logparser_script_path=config['SSH_CONFIG']['LOGPARSESR_COLLECTION_SCRIPT_PATH']
        logparser_cmd= [interpreter, logparser_script_path, f"{config['BASE_HOME_DIR']}", f"{config['CONFIG_PATH']}"]
        
        infa_db_path=config['SSH_CONFIG']['INFA_DB_SCRIPT_PATH']
        infadb_cmd = ['sh', infa_db_path, f"{infdbusername}", f"{infdbpassword}", f"{infdbhost}", f"{infdbschema}"]
        
        commands_to_run=[]
        commands_to_run.append(logparser_cmd)
        commands_to_run.append(infadb_cmd)
        
        # Multiprocess for different commands
        with Pool(processes=len(commands_to_run)) as pool:
                args = [(command,cred) for command in commands_to_run]
                pool.starmap(execute_commands, args)
                pool.close()
                pool.join()
        
        logger.info('Done collecting the data')
    
    except Exception as e:
        logger.error("Error Hence exiting: {}".format(e))
        exit(1)


def fetch_metrics(config):
    if platform.system() == 'Windows' and not config.get('REMOTE'):
        logger.error('Can not execute on windows.')
        exit(1)
    else:
        return process_from_cli(config)


def execute(**inputs):
    """
    Execution method to be called from the framework with relevant inputs.
    """
    start_time = dt.now(timezone.utc)

    logger.info(" --- calling Log Parser and Infadb Script ---- ")

    #Loading of Config file
    config = load_configuration(inputs.get('CONFIG_PATH'))
    config['BASE_HOME_DIR'] = inputs.get('BASE_HOME_DIR')
    config['CONFIG_PATH'] = inputs.get('CONFIG_PATH')
    
    #Call function to fetch metrics
    fetch_metrics(config)

    logger.info("---- End of logging ----")
    logger.info(f"Total execution time ={divmod((dt.now(timezone.utc) - start_time).total_seconds(), 60)}")
