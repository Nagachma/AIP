#!/bin/bash

# author: sachin.maurya
# Email: sachin.maurya@accenture.com
# License: GPL
# Version: 1.0.0
# Copyright: Copyright 2023, The OrchastrAI Project


curr_dir=$(dirname $0)
source $curr_dir/../config/config.conf

ORACLE_HOME=${OracleHome}
export ORACLE_HOME

STARTTIME=$1
ENDTIME=$2
DBUSER=$3
DBPASS=$4
SchemaName=$5

if [ "$#" -ne 5 ]
then
echo "Illegal number of parameters: Please provide START_TIME(MM-DD-YYYY hh:mi:ss) and END_TIME(MM-DD-YYYY hh:mi:ss)"
exit
fi

var=`$ORACLE_HOME/bin/sqlplus -S $DBUSER/"$DBPASS"@INFAORCL << EOD
set pagesize 0
set linesize 32767
set numwidth 50
set feedback off
set headsep off
set colsep ,
set trim on
set trimspool on

spool $curr_dir/../temp/outputtemp.csv

with WORKFLOW_AND_TASK_ALL as (SELECT distinct ('$ENDTIME')  as CTIME,
TO_CHAR(T.START_TIME,'YYYY-MM-DD hh24:mi:ss') as START_TIME,CASE WHEN TO_CHAR(T.END_TIME,'YYYY-MM-DD hh24:mi:ss') like '%1753-01-01%' THEN TO_CHAR(CURRENT_DATE,'YYYY-MM-DD hh24:mi:ss')
ELSE TO_CHAR(T.END_TIME,'YYYY-MM-DD hh24:mi:ss')
END AS END_TIME,
S.SUBJ_NAME AS FOLDER_NAME,
SRV.SERVER_NAME AS INTEGRATION_SERVICE ,
W.WORKFLOW_NAME as WORKFLOW_NAME,
T.WORKFLOW_RUN_ID as WORKFLOW_RUN_ID,
T.TASK_NAME AS TASK_NAME , W.WORKFLOW_ID as WORKFLOW_ID,
DECODE (W.RUN_STATUS_CODE,1,0,2,3,3,1,4,3,5,3,6,2,7,3,8,3,9,3,10,3,11,3,12,3,13,3,14,3,15,3) AS STATUS,
CASE WHEN TO_CHAR(T.END_TIME,'YYYY-MM-DD hh:mi:ss') like '%1753-01-01%' THEN ROUND((CURRENT_DATE-T.START_TIME)*24*60*60)
ELSE ROUND((T.END_TIME-T.START_TIME)*24*60*60)
END AS TOTAL_TIME,
TO_CHAR(SYSDATE,'YYYY-MM-DD hh:mi:ss') as DB_TPS , T.INSTANCE_ID as INSTANCE_ID, REGEXP_SUBSTR(W.log_file, 'log\.([^.]+)\.', 1, 1, NULL, 1) as site_no
FROM
${SchemaName}.OPB_WFLOW_RUN W ,
${SchemaName}.OPB_TASK_INST_RUN T ,
${SchemaName}.OPB_SUBJECT S ,
${SchemaName}.OPB_SERVER_INFO SRV
WHERE
W.SUBJECT_ID=T.SUBJECT_ID AND W.WORKFLOW_RUN_ID=T.WORKFLOW_RUN_ID AND W.WORKFLOW_ID=T.WORKFLOW_ID
and SRV.SERVER_ID = W.SERVER_ID
and S.SUBJ_ID = W.SUBJECT_ID
AND (T.TASK_TYPE=68 OR T.TASK_TYPE = 58)
AND (T.START_TIME  BETWEEN TO_DATE('$STARTTIME','MM-DD-YYYY hh24:mi:ss') and TO_DATE('$ENDTIME','MM-DD-YYYY hh24:mi:ss')
        OR
    T.END_TIME  BETWEEN TO_DATE('$STARTTIME','MM-DD-YYYY hh24:mi:ss') and TO_DATE('$ENDTIME','MM-DD-YYYY hh24:mi:ss')))
select distinct CTIME, START_TIME, END_TIME, FOLDER_NAME,INTEGRATION_SERVICE,WORKFLOW_NAME , WTA.WORKFLOW_RUN_ID, TASK_NAME, STATUS,
COALESCE(OL.SRC_SUCCESS_ROWS,0), COALESCE(OL.SRC_FAILED_ROWS,0),
COALESCE(OL.TARG_SUCCESS_ROWS,0) AS SUCCESSFUL_TARGET_ROWS,
COALESCE(OL.TARG_FAILED_ROWS,0) AS FAILED_TARGET_ROWS,TOTAL_TIME,
DB_TPS,WTA.site_no
from WORKFLOW_AND_TASK_ALL WTA left outer join  ${SchemaName}.OPB_SESS_TASK_LOG OL on OL.INSTANCE_ID = WTA.INSTANCE_ID
AND OL.WORKFLOW_ID = WTA.WORKFLOW_ID and OL.WORKFLOW_RUN_ID = WTA.WORKFLOW_RUN_ID;
spool off

exit;
EOD`

cat '$curr_dir/../temp/outputtemp.csv'

FILE=$curr_dir/../outputs/infadboutput$(date -u +"_%d%m%Y").csv

if test -f "$FILE"
then
rm -rf $curr_dir/../outputs/infadboutput*
touch $FILE
else
touch $FILE
fi

lc=`wc -l $FILE | cut -d ' ' -f1`
if [ $lc -eq 0 ]
then
echo 'inside line 0'
echo "COLLECTION_START_TIME,START_TIME,END_TIME,FOLDER_NAME,INTEGRATION_SERVICE,WORKFLOW_NAME,WORKFLOW_EXECUTION_ID,TASK_NAME,STATUS,SUCCESSFUL_SOURCE_ROWS,FAILED_SOURCE_ROWS,SUCCESSFUL_TARGET_ROWS,FAILED_TARGET_ROWS,EXECUTION_TIME,DB_TIMESTAMP,SITE_NO" > $FILE
cat $curr_dir/../temp/outputtemp.csv >>$FILE
else
cat $curr_dir/../temp/outputtemp.csv >> $FILE
fi

