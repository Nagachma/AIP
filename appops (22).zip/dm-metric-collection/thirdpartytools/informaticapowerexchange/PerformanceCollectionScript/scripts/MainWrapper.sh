#!/bin/bash

# author: sachin.maurya
# Email: sachin.maurya@accenture.com
# License: GPL
# Version: 1.0.0
# Copyright: Copyright 2023, The OrchastrAI Project

username="${1}"
password="${2}"
dbschema="${3}"


if [ "$#" -ne 3 ]
then
echo "Please provide username and password"
exit
else
username="${1}"
password="${2}"
dbschema="${3}"
fi


start=$(date --date='5 minutes ago' +"%m-%d-%Y %H:%M:%S")
end=$(date +"%m-%d-%Y %H:%M:%S")

echo "START_TIME : ${start}"
echo "END_TIME : ${end}"

curr_dir=$(dirname $0)
chmod +x ${curr_dir}/*.sh

source $curr_dir/../config/config.conf

cd $curr_dir/../scripts

sh GetInfaDbMetrcis.sh "${start}" "${end}" "${username}" "${password}" "${dbschema}"



