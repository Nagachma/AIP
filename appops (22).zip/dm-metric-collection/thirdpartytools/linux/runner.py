from thirdpartytools.common_sources import collect_from_cli

if __name__ == '__main__':
    input_dict = {
        'CONFIG_PATH': 'config.yaml'
    }
    collect_from_cli.execute(**input_dict)
