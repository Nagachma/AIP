import csv
import os
from datetime import datetime
from sys import argv
import logging
import pymongo
from sys import exit as exit_python
import yaml

"""
__author__ = "Sachin Maurya"
__copyright__ = "Copyright 2023, The OrchastrAI Project"
__license__ = "GPL"
__version__ = "1.0.0"
__email__ = "sachin.maurya@accenture.com"
"""


logger = logging.getLogger(__name__)
# set default logging level to INFO
logger.setLevel(logging.INFO)

# Codes for exit function
OK_CODE = 0
WARNING_CODE = 1
ERROR_CODE = 2


def exit_handler(error_code=OK_CODE):
    # check to see if logger has file handler attached
    if len(logger.handlers) == 1 and isinstance(logger.handlers[0], logging.FileHandler):
        if error_code == ERROR_CODE:
            logger.error("Program failed due to Error. See Above Error for more details.")
        elif error_code == WARNING_CODE:
            logger.warning("Program finished with Warning(s). See Above Warning(s) for more details.")
        else:
            logger.info("Program finished successfully.")
        # get filename
        log_filename = logger.handlers[0].baseFilename
        # close the file
        logger.handlers[0].close()
        # remove the handler, as no use to us closed
        logger.removeHandler(logger.handlers[0])
    else:
        log_filename = ""

    if log_filename != "":
        if error_code == ERROR_CODE:
            logger.error("Program failed due to Error. Please check logs (" + log_filename + ") for more details.")
        elif error_code == WARNING_CODE:
            logger.warning("Program finished with Warnings. Please check logs (" + log_filename + ") for more details.")
        else:
            logger.info("Program finished successfully.")
    else:
        if error_code == ERROR_CODE:
            logger.error("\nProgram failed due to Error.")
        elif error_code == WARNING_CODE:
            logger.warning("\nProgram finished with Warnings.")
        else:
            logger.info("\nProgram finished successfully.")

    exit_python()


def pre_error_handling(config_filename):
    if len(argv) - 1 < 1:
        logger.error("To run this program you need to pass in a name of a single cloud service as an argument.")
        logger.error("You did not pass any arguments. Please add one and try again.\n")
        exit_handler(ERROR_CODE)
    elif len(argv) - 1 > 1:
        logger.error("To run this program you need to pass in a name of a single cloud service as an argument.")
        logger.error("You passed in more than 1 argument. Please remove any extra and try again.\n")
        exit_handler(ERROR_CODE)

def load_configuration(lconfig):
    """Read and load data from config.yaml file"""
    cfg = {}
    try:
        with open(lconfig, 'r') as yaml_file:
            cfg = yaml.safe_load(yaml_file)
    except yaml.YAMLError as exc:
        logger.exception(exc)
    except Exception as e:
        logger.exception(e)
    return cfg


def execute(**inputs):
    basedir = inputs.get('BASE_HOME_DIR')
    config = load_configuration(inputs.get('CONFIG_PATH'))

    client1 = pymongo.MongoClient('mongodb://' + config['username'] + ':' + config['password'] + '@' + config['mongo_host'] + ':' + str(config['mongo_port']) + '/')
    db1 = client1.admin
    dbs = client1.list_database_names()

    collstats = list()
    dbStats = list()

    for db in dbs:
        if str(db).casefold() in ['config', 'local', 'admin']:
            continue
        con = client1[db]
        colls = con.collection_names()
        for coll in colls:
            try:
                collstats.append(con.command("collstats", coll))
            except:
                pass
        dbStats.append(con.command("dbstats"))

    # dbStats = db1.command("dbstats")  # prints database stats for "test_db"
    serverStatus = db1.command("serverStatus")  # prints collection-level stats for "test_collection" under "test_db".
    # collstats = db1.command("collstats",
    #                         "test_collection")  # prints collection-level stats for "test_collection" under "test_db".
    # replSetGetStatus = db1.command(
    #     "replSetGetStatus")  # prints collection-level stats for "test_collection" under "test_db".
    currentOp = db1.command("top")  # prints collection-level stats for "test_collection" under "test_db".

    for dbStats_dict in dbStats:
        for keys in dbStats_dict:
            dbStats_dict[keys] = str(dbStats_dict[keys])
        for k, v in dbStats_dict.items():
            if "{" in str(v):
                dbStats_dict[k] = str(v).replace("'", "#").replace(",", "%").replace("\\", "@").replace(
                    "datetime.datetime", "").replace("ObjectId", "").replace("Timestamp", "")

    for keys in serverStatus:
        serverStatus[keys] = str(serverStatus[keys])
    for k, v in serverStatus.items():
        if "{" in str(v):
            serverStatus[k] = str(v).replace("'", "#").replace(",", "%").replace("\\", "@").replace("datetime.datetime",
                                                                                                    "").replace(
                "ObjectId", "").replace("Timestamp", "")

    for collstats_dict in collstats:
        for keys in collstats_dict:
            collstats_dict[keys] = str(collstats_dict[keys])
        for k, v in collstats_dict.items():
            if "{" in str(v):
                collstats_dict[k] = str(v).replace("'", "#").replace(",", "%").replace("\\", "@").replace(
                    "datetime.datetime", "").replace("ObjectId", "").replace("Timestamp", "")
    #
    # for keys in replSetGetStatus:
    #     replSetGetStatus[keys] = str(replSetGetStatus[keys])
    # for k,v in replSetGetStatus.items():
    #     if "{" in str(v):
    #         replSetGetStatus[k] = str(v).replace("'","#").replace(",","%").replace("\\","@").replace("datetime.datetime","").replace("ObjectId","").replace("Timestamp","")

    for keys in currentOp:
        currentOp[keys] = str(currentOp[keys])
    for k, v in currentOp.items():
        if "{" in str(v):
            tmp_str = str(v)
            tmp_str = str(tmp_str).replace("'", "#").replace(",", "%").replace("\\", "@").replace("datetime.datetime",
                                                                                                  "").replace(
                "ObjectId", "").replace("Timestamp", "")
            currentOp[k] = tmp_str

    current_time = datetime.now().strftime("%Y%m%d")
    csv_dir_path = basedir+config.get('csv_path')+'metrics/'
    if not os.path.exists(csv_dir_path):
        os.makedirs(csv_dir_path, exist_ok=True)
    keys = dbStats[0].keys()
    with open(csv_dir_path + 'dbstats_mongodb_metrics_' + current_time + '.csv', 'w', newline='') as output_file:
        dict_writer = csv.DictWriter(output_file, keys)
        dict_writer.writeheader()
        dict_writer.writerows(dbStats)

    for dicts in collstats:
        if len(dicts) == 18:
            keys_col = collstats[2]
            break
    with open(csv_dir_path + 'collstats_mongodb_metrics_' + current_time + '.csv', 'w', newline='') as output_file:
        dict_writer = csv.DictWriter(output_file, keys_col)
        dict_writer.writeheader()
        for coll_dict in collstats:
            if len(coll_dict) == 18 and 'count' not in coll_dict:
                dict_writer.writerow(coll_dict)

    with open(csv_dir_path + 'serverstatus_mongodb_metrics_' + current_time + '.csv',
              'w') as f:  # You will need 'wb' mode in Python 2.x
        w = csv.DictWriter(f, serverStatus.keys())
        w.writeheader()
        w.writerow(serverStatus)

    #
    # with open(csv_dir_path + 'replsetgetstatus_mongodb_metrics_' + current_time + '.csv',
    #             'w') as f:  # You will need 'wb' mode in Python 2.x
    #     w = csv.DictWriter(f, replSetGetStatus.keys())
    #     w.writeheader()
    #     w.writerow(replSetGetStatus)

    with open(csv_dir_path + 'currentop_mongodb_metrics_' + current_time + '.csv',
              'w') as f:  # You will need 'wb' mode in Python 2.x
        w = csv.DictWriter(f, currentOp.keys())
        w.writeheader()
        w.writerow(currentOp)

