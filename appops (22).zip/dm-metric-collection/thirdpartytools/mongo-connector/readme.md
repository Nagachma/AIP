MongoDB-Connector

1. Provide/Add mongodb credentials in config.yaml file i.e. username, password, mongodb url, mongodb port
2. Run get_mongo_metric.py from main.py by enabling service in parent config.yaml
3. Collected output metrics will be generated in metrics directory

# Mongo Metrics Collection Scripts for Operational Analytics

## Introduction:
- These scripts collect Mongo metrics from Mongo DB and put it into a CSV file. There is 1 metrics collection script:
- 1. `get_mongo_metric.py`: These script collects data based at realtime. Example: If user wants to collect data with 60 mins interval then user needs to configure crontab with appropriate command.

## Set up:
- Copy the parent folder i.e. mongo-connector to the driver node /data path.

## Assumption:
- python 2.7 with pip is installed
- python package `pymongo` should be installed

## Configuration:
- Update `config.yaml`,Provide/Add mongodb credentials in config.yaml file i.e. username, password, mongodb url, mongodb port, sample config file is having self explanatory contents.

## Execution:

### Mongo Metrics Collection:

#### Step1: Execute python script from main:
```python main.py ```

### Live Metrics Collection:

#### Step1: configure the crontab with following command:
```*/5 * * * * /bin/su -c "/bin/python /data/mongo-coonector/get_mongo_metric.py > /data/mongo/logs/get_mongo_metric.log 2>&1" - dmuser```

## For validation:

### Metrics files should be generated under following path:

	Mongo Metrics: ```/data/mongo/metrics/*```

## Referance: Please refer this link for all the query details:
https://confluence.dev.accentureanalytics.com/display/PERFENG/

## License and Authors:

### Authors: sachin.maurya
