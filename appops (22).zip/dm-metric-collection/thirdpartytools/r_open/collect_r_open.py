"""Custom Script to fetch metrics for R Open"""
import logging
import yaml
from datetime import datetime as dt
from datetime import timezone
from thirdpartytools.common_sources import collect_from_cli
from pymongo import MongoClient

logger = logging.getLogger('collect_r_open_metrices')
logger.setLevel(logging.INFO)

# create console handler and set level to debug
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.DEBUG)

# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# add formatter to console_handler
console_handler.setFormatter(formatter)

# add console_handler to logger
logger.addHandler(console_handler)


# def ingest_data(config, process_df, iostat_json, timestamp):
#     mongo_config = config['MONGO']
#     client = MongoClient(mongo_config['URL'])
#     db = client.get_database(mongo_config['DATABASE'])
#     collection = db.get_collection(mongo_config['COLLECTION'])

#     final_output = {'source': config['SOURCE'], 'ts': timestamp}

#     instances = iostat_json.get('sysstat').get('hosts')

#     processes = []

#     for i, row in process_df.iterrows():
#         processes.append({
#             'pid': row['PID'],
#             'Command': row['Command'],
#             'elapsed': row['ELAPSED'],
#             'user': row['USER'],
#             'per_usr': row['%usr'],
#             'per_system': row['%system'],
#             'per_guest': row['%guest'],
#             'per_cpu': row['%CPU'],
#             'cpu': row['CPU'],
#             'minflt_s': row['minflt/s'],
#             'majflt_s': row['majflt/s'],
#             'vsz': row['VSZ'],
#             'rss': row['RSS'],
#             'per_mem': row['%MEM_y'],
#             'kB_rd_s': row['kB_rd/s'],
#             'kB_wr_s': row['kB_wr/s'],
#             'kB_ccwr_s': row['kB_ccwr/s'],
#             'iodelay': row['iodelay']
#         })

#     instances[0]['processes'] = processes

#     final_output['instances'] = instances

#     collection.insert_one(final_output)


def load_configuration(lconfig):
    """Read and load data from config.yaml file"""
    
    cfg = {}
    try:
        with open(lconfig, 'r') as yaml_file:
            cfg = yaml.safe_load(yaml_file)
    except yaml.YAMLError as exc:
        logger.exception(exc)
    except Exception as e:
        logger.exception(e)
    return cfg


def execute(**inputs):
    """
        Execution method to be called from the framework with relevant inputs.
    """
    start_time = dt.now(timezone.utc)
    ingestion_timestamp = start_time.strftime('%Y-%m-%d %H:%M')
    ingestion_timestamp = dt.strptime(ingestion_timestamp, '%Y-%m-%d %H:%M')

    logger.info(" --- calling R Open Script ---- ")

    collect_from_cli.execute(**inputs)

    logger.info('End of Collection.')

    logger.info("---- End of logging ----")
    logger.info(f"Total execution time ={divmod((dt.now(timezone.utc) - start_time).total_seconds(), 60)}")
