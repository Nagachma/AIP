import collect_r_open

if __name__ == '__main__':
    input_dict = {
        'CONFIG_PATH': 'config.yaml'
    }
    collect_r_open.execute(**input_dict)
