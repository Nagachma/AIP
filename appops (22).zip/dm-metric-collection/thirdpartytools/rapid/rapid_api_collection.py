import sys
import logging
import requests
import yaml
from datetime import datetime
from pymongo import MongoClient
from vault_utility_v2 import vault_credentials

logger = logging.getLogger('rapid_api_collection')
logger.setLevel(logging.INFO)

# create console handler and set level to debug
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.DEBUG)

# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# add formatter to console_handler
console_handler.setFormatter(formatter)

# add console_handler to logger
logger.addHandler(console_handler)

metric_list = {
    'base_classloader_loadedClasses_total': 'baseClassloaderLoadedClassesTotal',
    'base_classloader_loadedClasses_count': 'baseClassloaderLoadedClassesCount',
    'base_classloader_unloadedClasses_total': 'baseClassloaderUnloadedClassesTotal',
    'base_cpu_availableProcessors': 'baseCpuAvailableProcessors',
    'base_cpu_processCpuLoad': 'baseCpuProcessCpuLoad',
    'base_cpu_processCpuTime_seconds': 'baseCpuProcessCpuTimeSeconds',
    'base_cpu_systemLoadAverage': 'baseCpuSystemLoadAverage',
    'base_gc_total{name="PS MarkSweep"}': 'baseGcTotalNamePsMarkSweep',
    'base_gc_total{name="PS Scavenge"}': 'baseGcTotalNamePsScavenge',
    'base_gc_time_total_seconds{name="PS MarkSweep"}': 'baseGcTimeTotalSecondsNamePsMarkSweep',
    'base_gc_time_total_seconds{name="PS Scavenge"}': 'baseGcTimeTotalSecondsNamePsScavenge',
    'base_jvm_uptime_seconds': 'baseJvmUptimeSeconds',
    'base_memory_committedHeap_bytes': 'baseMemoryCommittedHeapBytes',
    'base_memory_committedNonHeap_bytes': 'baseMemoryCommittedNonHeapBytes',
    'base_memory_maxHeap_bytes': 'baseMemoryMaxHeapBytes',
    'base_memory_maxNonHeap_bytes': 'baseMemoryMaxNonHeapBytes',
    'base_memory_usedHeap_bytes': 'baseMemoryUsedHeapBytes',
    'base_memory_usedNonHeap_bytes': 'baseMemoryUsedNonHeapBytes',
    'base_thread_count': 'baseThreadCount',
    'base_thread_daemon_count': 'baseThreadDaemonCount',
    'base_thread_max_count': 'baseThreadMaxCount',
    'vendor_BufferPool_used_memory_bytes{name="direct"}': 'vendorBufferPoolUsedMemoryBytesNameDirect',
    'vendor_BufferPool_used_memory_bytes{name="mapped"}': 'vendorBufferPoolUsedMemoryBytesNameMapped',
    'vendor_memoryPool_usage_bytes{name="Code Cache"}': 'vendorMemoryPoolUsageBytesNameCodeCache',
    'vendor_memoryPool_usage_bytes{name="Compressed Class Space"}': 'vendorMemoryPoolUsageBytesNameCompressedClassSpace',
    'vendor_memoryPool_usage_bytes{name="Metaspace"}': 'vendorMemoryPoolUsageBytesNameMetaspace',
    'vendor_memoryPool_usage_bytes{name="PS Old Gen"}': 'vendorMemoryPoolUsageBytesNamePsOldGen',
    'vendor_memoryPool_usage_bytes{name="PS Survivor Space"}': 'vendorMemoryPoolUsageBytesNamePsSurvivorSpace',
    'vendor_memoryPool_usage_max_bytes{name="Code Cache"}': 'vendorMemoryPoolUsageMaxBytesNameCodeCache',
    'vendor_memoryPool_usage_max_bytes{name="Compressed Class Space"}': 'vendorMemoryPoolUsageMaxBytesNameCompressedClassSpace',
    'vendor_memoryPool_usage_max_bytes{name="Metaspace"}': 'vendorMemoryPoolUsageMaxBytesNameMetaspace',
    'vendor_memoryPool_usage_max_bytes{name="PS Eden Space"}': 'vendorMemoryPoolUsageMaxBytesNamePsEdenSpace',
    'vendor_memoryPool_usage_max_bytes{name="PS Old Gen"}': 'vendorMemoryPoolUsageMaxBytesNamePsOldGen',
    'vendor_memoryPool_usage_max_bytes{name="PS Survivor Space"}': 'vendorMemoryPoolUsageMaxBytesNamePsSurvivorSpace',
    # 'wildfly_batch_jberet_active_count{thread_pool="batch"}': 'wildflyBatchJberetActiveCountThreadPoolBatch',
    # 'wildfly_batch_jberet_completed_task_count{thread_pool="batch"}': 'wildflyBatchJberetCompletedTaskCountThreadPoolBatch',
    # 'wildfly_batch_jberet_current_thread_count{thread_pool="batch"}': 'wildflyBatchJberetCurrentThreadCountThreadPoolBatch',
    # 'wildfly_batch_jberet_largest_thread_count{thread_pool="batch"}': 'wildflyBatchJberetLargestThreadCountThreadPoolBatch',
    # 'wildfly_batch_jberet_queue_size{thread_pool="batch"}': 'wildflyBatchJberetQueueSizeThreadPoolBatch',
    # 'wildfly_batch_jberet_rejected_count{thread_pool="batch"}': 'wildflyBatchJberetRejectedCountThreadPoolBatch',
    # 'wildfly_batch_jberet_task_count{thread_pool="batch"}': 'wildflyBatchJberetTaskCountThreadPoolBatch',
    # 'wildfly_ee_active_thread_count{managed_executor_service="default"}': 'wildflyEeActiveThreadCountManagedExecutorServiceDefault',
    # 'wildfly_ee_active_thread_count{managed_scheduled_executor_service="default"}': 'wildflyEeActiveThreadCountManagedScheduledExecutorServiceDefault',
    # 'wildfly_ee_completed_task_count{managed_executor_service="default"}': 'wildflyEeCompletedTaskCountManagedExecutorServiceDefault',
    # 'wildfly_ee_completed_task_count{managed_scheduled_executor_service="default"}': 'wildflyEeCompletedTaskCountManagedScheduledExecutorServiceDefault',
    # 'wildfly_ee_current_queue_size{managed_executor_service="default"}': 'wildflyEeCurrentQueueSizeManagedExecutorServiceDefault',
    # 'wildfly_ee_current_queue_size{managed_scheduled_executor_service="default"}': 'wildflyEeCurrentQueueSizeManagedScheduledExecutorServiceDefault',
    # 'wildfly_ee_hung_thread_count{managed_executor_service="default"}': 'wildflyEeHungThreadCountManagedExecutorServiceDefault',
    # 'wildfly_ee_hung_thread_count{managed_scheduled_executor_service="default"}': 'wildflyEeHungThreadCountManagedScheduledExecutorServiceDefault',
    # 'wildfly_ee_max_thread_count{managed_executor_service="default"}': 'wildflyEeMaxThreadCountManagedExecutorServiceDefault',
    # 'wildfly_ee_max_thread_count{managed_scheduled_executor_service="default"}': 'wildflyEeMaxThreadCountManagedScheduledExecutorServiceDefault',
    # 'wildfly_ee_task_count{managed_executor_service="default"}': 'wildflyEeTaskCountManagedExecutorServiceDefault',
    # 'wildfly_ee_task_count{managed_scheduled_executor_service="default"}': 'wildflyEeTaskCountManagedScheduledExecutorServiceDefault',
    # 'wildfly_ee_thread_count{managed_executor_service="default"}': 'wildflyEeThreadCountManagedExecutorServiceDefault',
    # 'wildfly_ee_thread_count{managed_scheduled_executor_service="default"}': 'wildflyEeThreadCountManagedScheduledExecutorServiceDefault',
    # 'wildfly_ejb3_active_count{thread_pool="async_pool"}': 'wildflyEjb3ActiveCountThreadPoolAsyncPool',
    # 'wildfly_ejb3_active_count{thread_pool="default"}': 'wildflyEjb3ActiveCountThreadPoolDefault',
    # 'wildfly_ejb3_completed_task_count{thread_pool="async_pool"}': 'wildflyEjb3CompletedTaskCountThreadPoolAsyncPool',
    # 'wildfly_ejb3_completed_task_count{thread_pool="default"}': 'wildflyEjb3CompletedTaskCountThreadPoolDefault',
    # 'wildfly_ejb3_current_thread_count{thread_pool="async_pool"}': 'wildflyEjb3CurrentThreadCountThreadPoolAsyncPool',
    # 'wildfly_ejb3_current_thread_count{thread_pool="default"}': 'wildflyEjb3CurrentThreadCountThreadPoolDefault',
}

def execute(**inputs):
    try:
        logger.info('Reading config file, config.yml, to fetch parameters required for this script...')
        with open(inputs.get('CONFIG_PATH'), 'r') as ymlfile:
            cfg = yaml.safe_load(ymlfile)
    except:
        logger.error("Unable to read/parse config file, config.yml.")
        sys.exit(1)

    cred = vault_credentials.get_secret_from_vault(cfg['vault_path'], cfg['vault_keys'])
    
    t = datetime.now()

    # details = cfg['details']
    inst_name = cfg['inst_name']

    final_output = {}
    instances = []

    for inst, inst_data in cred.items():

        # Make a GET request to the Rapid instance URL
        response = requests.get(inst_data, timeout=60)

        # Check the status code of the response
        if response.status_code == 200:

            data = response.text
            # with open("log.txt", "w") as writer:
            #     writer.write(data)

            data = data.split("\n")

            inst_map = {'instance_name': inst_name, 'URL': inst_data}

            # st = datetime.strftime(t, '%Y-%m-%d %H:%M:%S')
            # dict['start_time'] = st

            for line in data:
                if '#' not in line:
                    # print(line)
                    arr = line.split(" ")
                    metric_name = " ".join(arr[:-1])
                    if metric_name in metric_list.keys() and 'wildfly' not in metric_name.lower():
                        k = metric_list[metric_name]
                        inst_map[k] = arr[-1]

                    # if len(arr) == 2:
                    #     if arr[0] in metric_list.keys():
                    #         k = metric_list[arr[0]]
                    #         dict[k] = arr[1]
                    # elif len(arr) == 4:
                    #     key = arr[0] + " " + arr[1] + " " + arr[2]
                    #     if key in metric_list.keys():
                    #         k = metric_list[key]
                    #         dict[k] = arr[3]

            instances.append(inst_map)

        else:
            # Show an error message if the request failed
            logger.error("Failed to retrieve the data from Rapid API. Response code:", response.status_code)
            sys.exit(1)

    # Mongo Ingestion
    t = datetime.strftime(t, '%Y-%m-%d %H:%M')
    t = datetime.strptime(t, '%Y-%m-%d %H:%M')

    final_output["source"] = cfg['SOURCE']
    final_output['ts'] = t
    final_output['instances'] = instances

    

    logger.info("Data Collected, Ingesting data to mongo")

    cred = vault_credentials.get_secret_from_vault(cfg['mongo_vault_path'], cfg['mongo_vault_keys'])

    client = MongoClient(cred['mongo_url'])
    db = client.get_database(cfg['mongo_db'])
    collection = db.get_collection(cfg['mongo_collection'])

    collection.insert_one(final_output)

    logger.info("Data Ingested Successfully")
