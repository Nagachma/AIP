import logging
import sys
import requests
import yaml
from datetime import datetime, timezone
from prometheus_client.parser import text_string_to_metric_families
from random import randint
from pymongo import MongoClient
from vault_utility_v2 import vault_credentials

logger = logging.getLogger('rapid_dynamic_api_collection')
logger.setLevel(logging.INFO)

# create console handler and set level to debug
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.DEBUG)

# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# add formatter to console_handler
console_handler.setFormatter(formatter)

# add console_handler to logger
logger.addHandler(console_handler)


def load_config(inputs):
    try:
        logger.info('Reading config file, config.yml, to fetch parameters required for this script...')
        with open(inputs.get('CONFIG_PATH'), 'r') as yaml_file:
            cfg = yaml.safe_load(yaml_file)
    except:
        logger.error("Unable to read/parse config file, config.yml.")
        sys.exit(1)
    return cfg


def parse_metrics(response):
    metrics_data = response.content.decode('utf-8')
    metrics = text_string_to_metric_families(metrics_data)
    metrics_out = []
    for metric in metrics:
        for sample in metric.samples:
            metrics_out.append({'name': sample.name, 'value': sample.value, 'labels': sample.labels})
    return metrics_out


def convert_to_ascii(page_id_string):
    return ''.join(str(ord(c)) for c in page_id_string)


def create_page_obj(metric, page_metrics):
    if metric['labels']['pageId'] not in page_metrics.keys():
        page_metrics[metric['labels']['pageId']] = {
            'page_id': metric['labels']['pageId'],
            'page_id_ascii': convert_to_ascii(metric['labels']['pageId'])
        }
        if metric['labels'].get('appId'):
            page_metrics[metric['labels']['pageId']]['app_id'] = metric['labels']['appId']


def execute(**inputs):
    cfg = load_config(inputs)

    t = datetime.now(timezone.utc)

    inst_name = cfg['inst_name']

    final_output = {}
    instances = []

    cred = vault_credentials.get_secret_from_vault(cfg['vault_path'], cfg['vault_keys'])
    mongo_cred = vault_credentials.get_secret_from_vault(cfg['mongo_vault_path'], cfg['mongo_vault_keys'])
    
    for inst, inst_data in cred.items():

        # Make a GET request to the Rapid instance URL
        response = requests.get(inst_data, timeout=60)

        # Check the status code of the response
        inst_map = {'instance_name': inst_name, 'URL': inst_data, 'unique_run_id': randint(1000000000, 9999999999)}
        if response.status_code == 200:

            metrics_out = parse_metrics(response)
            page_metrics = {}
            for metric in metrics_out:
                if not metric['labels']:
                    metric_name=metric['name']
                    if 'wildfly' in str(metric_name).lower():
                        pass
                    else:
                        inst_map[metric['name']] = metric['value']

                elif set(metric['labels'].keys()).issubset({'pageId', 'appId', 'quantile'}):
                    create_page_obj(metric, page_metrics)
                    if not metric['labels'].get('quantile'):
                        page_metrics[metric['labels']['pageId']][metric['name']] = metric['value']
                    else:
                        page_metrics[metric['labels']['pageId']][
                            '_'.join(
                                [metric['name'], 'quantile', str(int(float(metric['labels']['quantile']) * 1000))])] = \
                            metric['value']

                else:
                    metric_name_array = [metric['name']]
                    metric_name_array.extend(
                        ['_'.join([k, '_'.join(map(lambda x: x.lower(), str(v).split(' ')))]) for k, v in
                         metric['labels'].items()])
                    inst_map['_'.join(metric_name_array)] = metric['value']
            if len(page_metrics)==0:
                pass
            else:
                inst_map['pages'] = list(page_metrics.values())

        else:
            logger.error("Failed to retrieve the data from Rapid API. Response code:", response.status_code)
        instances.append(inst_map)

    # Mongo Ingestion
    t = datetime.strftime(t, '%Y-%m-%d %H:%M')
    t = datetime.strptime(t, '%Y-%m-%d %H:%M')

    final_output["source"] = cfg['SOURCE']
    final_output['ts'] = t
    final_output['instances'] = instances

    logger.info("Data Collected, Ingesting data to mongo")

    client = MongoClient(mongo_cred['mongo_url'])
    db = client.get_database(cfg['mongo_db'])
    collection = db.get_collection(cfg['mongo_collection'])

    collection.insert_one(final_output)

    logger.info("Data Ingested Successfully")
