"""Custom Script to fetch metrics for a process in Linux CLI"""
import json
import logging
import os
import platform
import time
from datetime import datetime as dt
from datetime import timezone

import pandas as pd
import paramiko
import yaml
from scp import SCPClient

from vault_utility_v2 import vault_credentials

logger = logging.getLogger('collect_from_redis')
logger.setLevel(logging.INFO)

# create console handler and set level to debug
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.DEBUG)

# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# add formatter to console_handler
console_handler.setFormatter(formatter)

# add console_handler to logger
logger.addHandler(console_handler)


def load_configuration(lconfig):
    """Read and load data from config.yaml file"""
    cfg = {}
    try:
        with open(lconfig, 'r') as yaml_file:
            cfg = yaml.safe_load(yaml_file)
    except yaml.YAMLError as exc:
        logger.exception(exc)
    except Exception as e:
        logger.exception(e)
    return cfg


def save_file_per_day(df, file_path):
    if not os.path.isfile(file_path):
        df.to_csv(file_path, index=False)

    else:
        exist = pd.read_csv(file_path)
        df = pd.concat([exist, df], ignore_index=True)
        df.to_csv(file_path, index=False)


def process_from_cli(config, timestamp):
    create_dir(config.get('BASE_HOME_DIR') + config.get('TMP_DIR'))
    create_dir(config.get('BASE_HOME_DIR') + config.get('OUTPUT_DIR'))

    logger.info('Fetching data for service from redis')

    if not config.get('REMOTE'):
        os.system(
            f""" redis-cli info > {config.get('BASE_HOME_DIR') + config.get('TMP_DIR')}/redis_info.txt """)
        os.system(
            f""" redis-cli info latencystats > {config.get('BASE_HOME_DIR') + config.get('TMP_DIR')}/redis_latency.txt """)

    else:
        ssh = paramiko.SSHClient()
        creds = vault_credentials.get_secret_from_vault(config['vault_path'], config['vault_keys'])

        if config.get('SSH_CONFIG').get('PEM_FILE') is None or config.get('SSH_CONFIG').get('PEM_FILE') == '':
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect(config['SSH_CONFIG']['URL'], username=str(creds.get("username")),
                        password=str(creds.get("password")))

        else:
            k = paramiko.RSAKey.from_private_key_file(config['SSH_CONFIG']['PEM_FILE'])
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect(hostname=config['SSH_CONFIG']['URL'], username=creds.get("username"),
                        pkey=k)

        ssh.exec_command(f""" mkdir -p {config['SSH_CONFIG']['REMOTE_TMP']}""")

        ssh.exec_command(f""" redis-cli info > /tmp/redis/redis_info.txt """)
        ssh.exec_command(f""" redis-cli info latencystats > /tmp/redis/redis_latency.txt """)

        # wait till all commands complete their execution
        time.sleep(3)
        with SCPClient(ssh.get_transport(), sanitize=lambda x: x) as scp:
            scp.get(remote_path=config['SSH_CONFIG']['REMOTE_TMP'] + "/redis_info.txt"
                    , local_path=config['SSH_CONFIG']['LOCAL_ABS_PATH'] + config['TMP_DIR'] + "/redis_info.txt")
            scp.get(remote_path=config['SSH_CONFIG']['REMOTE_TMP'] + "/redis_latency.txt"
                    , local_path=config['SSH_CONFIG']['LOCAL_ABS_PATH'] + config['TMP_DIR'] + "/redis_latency.txt")
        scp.close()
        ssh.close()

    logger.info('Preparing collected data')

    redis_info_dic = {}
    redis_latency_dic = {}
    with open(config['SSH_CONFIG']['LOCAL_ABS_PATH'] + config['TMP_DIR'] + "/redis_info.txt",
              'r') as file:
        for line in file.readlines():
            if ':' in line:
                file_split = line.split(":")
                if file_split[0] in config['METRICS']:
                    redis_info_dic[file_split[0]] = file_split[1][:-1]

            else:
                continue

        file.close()

    with open(config['SSH_CONFIG']['LOCAL_ABS_PATH'] + config['TMP_DIR'] + "/redis_latency.txt",
              'r') as file:
        for line in file.readlines():
            if ':' in line:
                file_split = line.split(":")
                value_split = file_split[1].split(",")
                for value in value_split:
                    val = value.split("=")
                    redis_latency_dic[file_split[0] + "_" + val[0]] = val[1][:-1]
            else:
                continue
        file.close()

    redis_info_df = pd.DataFrame([redis_info_dic])
    redis_latency_df = pd.DataFrame([redis_latency_dic])

    logger.info('Data collection from redis completed. Data dumped to output files.')

    ts = timestamp.replace(second=0, microsecond=0)
    ip = config['SSH_CONFIG']['URL']

    redis_info_df.insert(0, 'timestamp', [ts] * len(redis_info_df.redis_version))
    redis_info_df.insert(1, 'ip', [ip] * len(redis_info_df.redis_version))

    redis_latency_df.insert(0, 'timestamp',
                            [ts] * len(redis_latency_df.get("latency_percentiles_usec_command|docs_p50")))
    redis_latency_df.insert(1, 'ip', [ip] * len(redis_latency_df.get("latency_percentiles_usec_command|docs_p50")))

    create_dir(f"{config.get('BASE_HOME_DIR') + config.get('OUTPUT_DIR')}/info")
    create_dir(f"{config.get('BASE_HOME_DIR') + config.get('OUTPUT_DIR')}/latency")

    save_file_per_day(redis_info_df,
                      f"{config.get('BASE_HOME_DIR') + config.get('OUTPUT_DIR')}/info/info_{config.get('SERVICE_NAME').lower()}_metrics_{timestamp.strftime('%d%m%Y')}.csv")
    save_file_per_day(redis_latency_df,
                      f"{config.get('BASE_HOME_DIR') + config.get('OUTPUT_DIR')}/latency/latency_{config.get('SERVICE_NAME').lower()}_metrics_{timestamp.strftime('%d%m%Y')}.csv")

    return redis_info_df, redis_latency_df


def iostat_data_to_df(config, ts):
    node_name = []
    sys_name = []
    release = []
    machine = []
    number_of_cpus = []
    user = []
    nice = []
    system = []
    iowait = []
    steal = []
    idle = []
    disk_device = []
    tps = []
    kB_read_s = []
    kB_wrtn_s = []
    kB_dscd_s = []
    kB_read = []
    kB_wrtn = []
    kB_dscd = []

    data = json.load(open(f"{config.get('BASE_HOME_DIR') + config.get('TMP_DIR')}/iostat_output.json"))
    for host in data.get("sysstat").get("hosts"):
        for stat in host.get("statistics"):
            for disk in stat.get("disk"):
                cpu = stat.get("avg-cpu")
                node_name.append(host.get("nodename"))
                sys_name.append(host.get("sysname"))
                release.append(host.get("release"))
                machine.append(host.get("machine"))
                number_of_cpus.append(host.get("number-of-cpus"))
                user.append(cpu.get("user"))
                nice.append(cpu.get("nice"))
                system.append(cpu.get("system"))
                iowait.append(cpu.get("iowait"))
                steal.append(cpu.get("steal"))
                idle.append(cpu.get("idle"))
                disk_device.append(disk.get("disk_device"))
                tps.append(disk.get("tps"))
                kB_read_s.append(disk.get("kB_read/s"))
                kB_wrtn_s.append(disk.get("kB_wrtn/s"))
                kB_dscd_s.append(disk.get("kB_dscd/s"))
                kB_read.append(disk.get("kB_read"))
                kB_wrtn.append(disk.get("kB_wrtn"))
                kB_dscd.append(disk.get("kB_dscd"))

    return pd.DataFrame({
        "timestamp": [ts] * len(node_name),
        "node_name": node_name,
        "sys_name": sys_name,
        "release": release,
        "machine": machine,
        "number_of_cpus": number_of_cpus,
        "user": user,
        "nice": nice,
        "system": system,
        "iowait": iowait,
        "steal": steal,
        "idle": idle,
        "disk_device": disk_device,
        "tps": tps,
        "kB_read_s": kB_read_s,
        "kB_wrtn_s": kB_wrtn_s,
        "kB_dscd_s": kB_dscd_s,
        "kB_read": kB_read,
        "kB_wrtn": kB_wrtn,
        "kB_dscd": kB_dscd
    })


def create_dir(dir_path):
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)


def fetch_metrics_from_cli(config, timestamp):
    if platform.system() == 'Windows' and not config.get('REMOTE'):
        logger.error('Can not execute on windows.')
        exit(0)
    else:
        return process_from_cli(config, timestamp)


def execute(**inputs):
    """
    Execution method to be called from the framework with relevant inputs.
    """
    start_time = dt.now(timezone.utc)

    logger.info(" --- calling CLI Custom Script ---- ")

    config = load_configuration(inputs.get('CONFIG_PATH'))
    config['BASE_HOME_DIR'] = inputs.get('BASE_HOME_DIR')

    redis_info, redis_latency = fetch_metrics_from_cli(config, start_time)

    logger.info("---- End of logging ----")
    logger.info(f"Total execution time ={divmod((dt.now(timezone.utc) - start_time).total_seconds(), 60)}")

    return redis_info, redis_latency
