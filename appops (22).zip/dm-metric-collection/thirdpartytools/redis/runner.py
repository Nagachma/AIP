import collect_from_redis

if __name__ == '__main__':
    input_dict = {
        'CONFIG_PATH': 'config.yaml',
        'BASE_HOME_DIR': "/Applications/Projects/appops/"

    }
    collect_from_redis.execute(**input_dict)
