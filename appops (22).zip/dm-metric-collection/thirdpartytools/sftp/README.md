## Pre-enablement

### Access Requirement and Enablement: 
 * SCP/SSH access to all the nodes

## SCRIPTS REQUIRED : 
 * Collect metrics for SFTP Connection - https://dev.azure.com/aipplus/xOps/_git/appops?path=/tools/thirdpartytools/sftp/collection/sftp_conn.py&version=GBsftp&_a=contents (sftp_conn.py)
 * Scheduler script - https://dev.azure.com/aipplus/xOps/_git/appops?path=/tools/thirdpartytools/sftp/collection/scheduler.py&version=GBsftp&_a=contents (scheduler.py)
 * Mongo Ingestion - https://dev.azure.com/aipplus/xOps/_git/appops?version=GBmain&path=/common-utility/mongoDB-ingestion (main.py)

 ## METRIC COLLECTION :
For SFTP connection script.
* Check values are correct in the config.yaml .
* Input and Output path are correctly configured.
* SSH Keys are present and functional.


## METRIC INGESTION:
Create the directories (if not existing) : `common-utility/mongoDB-ingestion/thirdpartytools/sftp/ingestion`
* Create the time series collection in the mongoDB as 'sftp'
* Add the sftp csv location details in the `common-utility/mongoDB-ingestion/config.yaml` under 'sftp_metrics_info' and verify the paths (absoulte paths).
* Provide the mongo url in the 'mongo_url' variable in `common-utility/mongoDB-ingestion/config.yaml` for mongo connection.

## CONNECTOR FRAMEWORK EXECUTION: 
Collection and ingestion are part of the connector framework kept under : `appops/dm-metric-collection` folder
* Provide the config paths for sftp connection under sftp under THIRDPARTYTOOLS. For e.g- `tools/thirdpartytools/sftp/collection`
* Please follow the execution process as mentioned in the [readme.md](https://dev.azure.com/aipplus/xOps/_git/appops?version=GBmain&_a=contents&path=/dm-metric-collection/README.md) under 'appops/dm-metric-collection' folder.
