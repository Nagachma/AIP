from sftp_conn import check_connectivity
from apscheduler.schedulers.blocking import BlockingScheduler


if __name__ == '__main__':
    scheduler = BlockingScheduler()
    scheduler.add_job(check_connectivity, 'interval', minutes=5)
    scheduler.start()