import csv
import datetime
import subprocess
import traceback
import paramiko
import os
import platform
from datetime import timezone
import yaml
import logging
from vault_utility_v2 import vault_credentials
from datetime import datetime as dt

logger = logging.getLogger('SFTP')
logger.setLevel(logging.INFO)

# create console handler and set level to debug
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.DEBUG)

# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# add formatter to console_handler
console_handler.setFormatter(formatter)

# add console_handler to logger
logger.addHandler(console_handler)


def check_connectivity(config):
    pwd = os.path.dirname(os.path.realpath(__file__))
    # if platform.system() == 'Windows':
    #     cwd = "{0}{1}{2}".format(pwd, '\\', 'config.yaml')
    # else:
    #     cwd = "{0}{1}{2}".format(pwd, '/', 'config.yaml')
    # config = load_configuration(cwd)

    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    timestamp = datetime.datetime.now(timezone.utc)
    reachability = 1
    connectivity = 1
    ip_usernames = []
    servers = config.get('servers')
    if servers:
        for server in servers:
            ip_address = server.get('ip_address')
            username = server.get('username')
            if ip_address and username:
                ip_usernames.append((ip_address,username))
    for ip, username in ip_usernames:
        try:
            logger.info(f"Trying to connect to {ip}")
            if config.get('SSH_CONFIG').get('PEM_FILE') is None or config.get('SSH_CONFIG').get('PEM_FILE') == '':
                creds = vault_credentials.get_secret_from_vault(config["SSH_CONFIG"]["vault_path"],
                                                                [config["SSH_CONFIG"]["password_key"]+f"_{ip}"])
                ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                ssh.connect(ip, username=username,
                            password=creds.get(config["SSH_CONFIG"]["password_key"]))
            else:
                k = paramiko.RSAKey.from_private_key_file(config['SSH_CONFIG']['PEM_FILE'])
                ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                ssh.connect(hostname=ip, username=username, pkey=k)
            logger.info("Connection successful")
            connectivity = 0
            try:
                url = config['SSH_CONFIG']['URL']
                stdin, stdout, stderr = ssh.exec_command(f'ping -c 1 {url}')
                reachability = 0
            except paramiko.SSHException as ssh_ex:
                reachability = 1
            sftp_client = ssh.open_sftp()
            files = sftp_client.listdir(config['CONNECTION_DIR'])
            sftp_client.chdir(config['CONNECTION_DIR'])
            output = []
            datapoint = {}
            datapoint["Timestamp"] = timestamp
            datapoint["host"] = config['SSH_CONFIG']['URL']
            datapoint["username"] = config['SSH_CONFIG']['USER']
            datapoint["server_reachability"] = reachability
            datapoint["server_connectivity"] = connectivity
            datapoint["conn_directory"] = config['CONNECTION_DIR']
            datapoint["list_of_files"] = files
            output.append(datapoint)
        except:
            print(config['ERROR_MESSAGE'])
            output = []
            files = []
            datapoint = {}
            datapoint["Timestamp"] = timestamp
            datapoint["host"] = config['SSH_CONFIG']['URL']
            datapoint["username"] = config['SSH_CONFIG']['USER']
            datapoint["server_reachability"] = reachability
            datapoint["server_connectivity"] = connectivity
            datapoint["conn_directory"] = config['CONNECTION_DIR']
            datapoint["list_of_files"] = files
            output.append(datapoint)
        output_file_name = config['FILE_NAME'] + timestamp.strftime('%d%m%Y') + ".csv"
        path1 = config['BASE_HOME_DIR'] + config['CSV_PATH']
        path2 = config['BASE_HOME_DIR'] + config['OUTPUT_DIR']
        output_file_path1 = path1 + output_file_name
        output_file_path2 = path2 + output_file_name
        save_csv(output, output_file_path1)
        save_csv(output, output_file_path2)
    return output

def save_csv(output, output_file_path):
    if not output:
        pass
    else:
        header = True
        try:
            with open(output_file_path, 'a', newline='') as csvfile:
                writer = csv.writer(csvfile)
                for row in output:
                    if header and os.stat(output_file_path).st_size == 0:
                        #print(row.keys())
                        writer.writerow(row.keys())
                        header = False
                    writer.writerow(row.values())
        except Exception:
            print(traceback.format_exc())
            # logger.error(traceback.format_exc())

def load_configuration(lconfig):
    """
    Read and load data from config.yaml file
    """
    cfg = {}  # Check if this is a dict
    try:
        with open(lconfig, 'r') as yamlfile:
            cfg = yaml.safe_load(yamlfile)
    except yaml.YAMLError as exc:
        print(exc)
        # logger.exception(exc)
    except Exception as e:
        print(e)
        # logger.exception(e)
    return cfg

def execute(**inputs):
    """
    Execution method to be called from the framework with relevant inputs.
    """

    start_time = dt.now(timezone.utc)

    config = load_configuration(inputs.get('CONFIG_PATH'))
    config['BASE_HOME_DIR'] = inputs.get('BASE_HOME_DIR')

    check_connectivity(config)

    logger.info("---- End of logging ----")
    logger.info(f"Total execution time ={divmod((dt.now(timezone.utc) - start_time).total_seconds(), 60)}")
