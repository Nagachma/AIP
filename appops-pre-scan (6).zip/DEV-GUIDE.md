# Developer Guide

Guidelines to be followed by developers who are contributing to this repo

# Guidelines

## Naming Conventions
- For a new serivce, create a folder under root of this repository
- Folder should contain name of the service in lowercase and use hyphen (-) as a separator
- The versioning of a service follows semantic system and should start with 0.0.1. Mention the version in the main script
- File names (scripts & configurations) should be in lowercase and use underscore (_) as a separator
- Variables should follow snake-casing (_ex: name_of_variable_) and use appropriate names (not ambiguous like x, y, etc)

## Coding Guidelines
- Once folder structure is created, use the template file located under: `./dummy/base_template.py`
- Make sure to add following details after taking copy from base template:
  - description of the scriptscript
  - author, email, version of the script
  - service-name in the script
- Proper comments for every function and in the script
- Close any connections or files in the finally block of your script
- Maintain a requirements.txt file per version per service
- Maintain a README.md & RELEASE-NOTES.md file per service showing the details about script and changes across all versions respectively.

# TODO
- Add requirements for vault Utility
- Create build script to package every service
