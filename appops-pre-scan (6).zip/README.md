# AppOps Pre-Scan

This repo contains the scripts to perform a pre-scan on a service. The purpose of pre-scan is to collect metadata about a service like list of active workflows in Informatica Power Center.

# Available Services

- Dummy: a sample demo service
- Informatica
  - Power Center
  - Power Exchange
- Redshift
- Tableau
