import requests
import json
import pandas as pd
from pandas import DataFrame
import numpy as np
import yaml
from datetime import datetime, timezone
pd.options.mode.chained_assignment = None
import time
from datetime import datetime
from pathlib import Path
from datetime import datetime
import logging
import os, sys
import argparse
import pandas as pd

# Add common utilities path for importing
helper_path = os.path.abspath(os.path.join( '..', 'common-utilities'))
sys.path.append(helper_path)
mongo_util_path = os.path.abspath(os.path.join( '..', 'common-utilities', 'mongo-util'))
sys.path.append(mongo_util_path)

# custom imports
from helpers import load_yaml, create_logger , get_from_vault
from MongoUtil import UpdateInventory

# def load_configuration(lconfig):
#     """Read and load data from config.yaml file"""
#     cfg = {}
#     try:
#         with open(lconfig, 'r') as yaml_file:
#             cfg = yaml.safe_load(yaml_file)
#     except yaml.YAMLError as exc:
#         #print(exc)
#         logger.exception(exc)
#     except Exception as e:
#         #print(e)
#         logger.exception(e)
#     return cfg

def get_response(api_url, api_token):
    # Set up the headers with the token
    headers = {
        'Authorization': f'Bearer {api_token}',
        'Content-Type': 'application/json'
    }

    try:
        response = requests.get(api_url, headers=headers, verify=False)

        if response.status_code == 200:
            data = response.json()
            #print('API Response:', data)
        else:
            logger.error(f'API Request failed with status code {response.status_code}')
            logger.error('Response Content:', response.text)
            # print(f'API Request failed with status code {response.status_code}')
            # print('Response Content:', response.text)

    except requests.exceptions.RequestException as e:
        logger.exception(e)

    return data

def get_info(URL, TOKEN):
    result_cluster = get_response(URL, TOKEN)

    columns = {'creator_user_name' : [],'cluster_name' : [], 'job_id' : []}

    for clusters in result_cluster['clusters']:
        columns['cluster_name'].append(clusters['cluster_name'])
        columns['creator_user_name'].append(clusters['creator_user_name'])
        try:
            columns['job_id'].append(clusters['default_tags']['JobId'])
        except KeyError:
            columns['job_id'].append(None)

    df = DataFrame(columns)

    df['cluster_name'] = df['cluster_name'].fillna('').astype(str)
    df['job_id'] = df['job_id'].fillna('').astype(str)

    df['cluster_name'] = df['cluster_name'].astype(str)
    df['job_id'] = df['job_id'].astype(str)

    df['name'] = df['cluster_name'] + ': ' + df['job_id']
    df['LastModifiedOn'] = ''
    df['user'] = df['creator_user_name']
    df['Created_On'] = ''
    df = df.drop('cluster_name', axis=1)
    df = df.drop('job_id', axis=1)
    df = df.drop('creator_user_name', axis=1)

    df = df.to_dict(orient='records')

    return df

if __name__ == '__main__':

    # get cli arguments
    parser = argparse.ArgumentParser(description='pre-scanner of AWS DataBricks service')
    parser.add_argument('-c', '--config', type=str, default='aws_db_pre_scanner.yaml', help='configuration file')
    parser.add_argument('-v', '--version', action='version', version=f'{os.path.basename(__file__)} v{__version__}')

    args = parser.parse_args()
    config_file = args.config

    config = load_yaml(config_file)
    logger = create_logger(**config['LOGGING'])

    try:
        logger.info(f'Starting pre-scanner for service [AWS DataBricks]')
        logger.info(f'Fetching Credentials form vault')
        creds = get_from_vault(config['AWS_DB_CONFIG']['vault_path'],config['AWS_DB_CONFIG']['vault_key'])

        logger.info(f'Checking Credentials form vault')
        api_url=''
        api_token=''
        if creds.get('databricks_cluster_api') is not None:
            api_url = creds['databricks_cluster_api']
        else:
            logger.error("No URL found")
            raise Exception('No URL found')
        if creds.get('access_token') is not None:
            api_token = creds['access_token']
        else:
            logger.error("No TOKEN found")
            raise Exception('No TOKEN found')

        result = get_info(api_url, api_token)
        #print(result)

        active_objects = result
        deleted_objects = []

        logger.info(f'Collection Completed.')

        # ingestion of metadata into inventory
        UpdateInventory(active_objects, deleted_objects, **config['INVENTORY_CONFIG'])
        logger.info(f'Ingestion Completed.')

    except Exception as e:
        logger.error(f"Error occured: {e}")

    
