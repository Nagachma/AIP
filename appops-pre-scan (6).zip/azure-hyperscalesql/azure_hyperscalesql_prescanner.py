'''
This script is used to collect metadata information (pre-scan) from azure hyperscaleSQL.
'''
__author__ = 'Amitha K S'
__email__ = 'amitha.k.s@accenture.com'
__version__ = '0.0.1'   # 2023-10-17

# module imports
# from datetime import datetime, timedelta
import os, sys
import argparse
import pyodbc
# import boto3
# import pandas as pd

# Add common utilities path for importing
helper_path = os.path.abspath(os.path.join('..', 'common-utilities'))
sys.path.append(helper_path)
mongo_util_path = os.path.abspath(os.path.join('..', 'common-utilities', 'mongo-util'))
sys.path.append(mongo_util_path)
db_util_path = os.path.abspath(os.path.join('..', 'common-utilities', 'db-util'))
sys.path.append(db_util_path)

# custom imports
from helpers import load_yaml, create_logger
from MongoUtil import UpdateInventory
from db_connect import db_connect_util


if __name__ == '__main__':
    # get cli arguments
    parser = argparse.ArgumentParser(description='pre-scanner of Azure HyperscaleSQL')
    parser.add_argument('-c', '--config', type=str, default='azure_hyperscalesql_prescanner.yaml', help='configuration file')
    # parser.add_argument('-s', '--service-name', type=str, default='azure hyperscale')
    parser.add_argument('-v', '--version', action='version', version=f'{os.path.basename(__file__)} v{__version__}')

    args = parser.parse_args()
    config_file = args.config
    # service = args.service_name

    config = load_yaml(config_file)
    logger = create_logger(**config['LOGGING'])
    metadb_client = None
    query = config['scan_query']

    try:
        logger.info(f'Starting pre-scanner for service [Azure HyperscaleSQL]')
        # collection of metadata using service-specific logic
        metadb_client = db_connect_util(config['CONNECTION_INFO'], **config['AZURE_HYPERSCALESQL_CONFIG'])
        print(metadb_client)
        data = metadb_client.execute_query(query)
        print("fetched data")
        # convert list of lists (table) to list of dicts (inventory format)
        active_objects = [
            {
                'name': row[0],
                'LastModifiedOn': '',
                'user': '',
                'Created_On': ''
            } for row in data if row
        ]
        deleted_objects = []

        # ingestion of metadata into inventory
        UpdateInventory(active_objects, deleted_objects, **config['INVENTORY_CONFIG'])

    except Exception as e:
        logger.error(f"Error occured: {e}")

    finally:
        # handle closing of connections here
        if metadb_client: metadb_client.close_connection()
