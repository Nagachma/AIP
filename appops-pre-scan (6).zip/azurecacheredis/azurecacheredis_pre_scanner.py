'''
This Script is used to collect metadata for Azure Cache Redis from Azure
'''
__author__ = 'Aditya Joshi'
__email__ = 'aditya.bharat.joshi@accenture.com'
__version__ = '0.0.1'   # 2023-10-30

# module imports
import os, sys
import argparse
import pandas as pd
from azure.identity import ClientSecretCredential
from azure.mgmt.redis import RedisManagementClient
import json
# Add common utilities path for importing
helper_path = os.path.abspath(os.path.join( '..', 'common-utilities'))
sys.path.append(helper_path)
mongo_util_path = os.path.abspath(os.path.join( '..', 'common-utilities', 'mongo-util'))
sys.path.append(mongo_util_path)

# custom imports
from helpers import load_yaml, create_logger , get_from_vault
from MongoUtil import UpdateInventory

if __name__ == '__main__':
    # get cli arguments
    parser = argparse.ArgumentParser(description='pre-scanner of azurecacheredis service')
    parser.add_argument('-c', '--config', type=str, default='azurecacheredis_pre_scanner.yaml', help='configuration file')
    parser.add_argument('-v', '--version', action='version', version=f'{os.path.basename(__file__)} v{__version__}')

    args = parser.parse_args()
    config_file = args.config

    config = load_yaml(config_file)
    logger = create_logger(**config['LOGGING'])

    try:
        logger.info(f'Starting pre-scanner for service [Azure Cache Redis]')
        
        logger.info(f'Fetching Credentials form vault')
        creds = get_from_vault(config['AZURECACHEREDIS_CONFIG']['vault_path'],config['AZURECACHEREDIS_CONFIG']['vault_key'])
        region = config['AZURECACHEREDIS_CONFIG']['region']

        logger.info(f'Fetching cache_name from vault')
        azurecache_vault_path = "environment/1/azurerediscache"
        azurecache_vault_keys = ["cache_name"]
        redis_name = get_from_vault(azurecache_vault_path, azurecache_vault_keys)

        logger.info(f'Checking Credentials form vault')
        secret_keys = {}

        if creds.get('client_id') is not None:
            secret_keys['client_id'] = creds.get('client_id')
        else:
            logger.error("No client_id found")
            raise Exception('No client_id found')

        if creds.get('tenant_id') is not None:
            secret_keys['tenant_id'] = creds.get('tenant_id')
        else:
            logger.error("No tenant_id found")
            raise Exception('No tenant_id found')

        if creds.get('client_secret') is not None:
            secret_keys['client_secret'] = creds.get('client_secret')
        else:
            logger.error("No client_secret found")
            raise Exception('No client_secret found')

        if creds.get('subscription_id') is not None:
            secret_keys['subscription_id'] = creds.get('subscription_id')
        else:
            logger.error("No subscription_id found")
            raise Exception('No subscription_id found')

        if creds.get('resource_group_name') is not None:
            secret_keys['resource_group_name'] = creds.get('resource_group_name')
        else:
            logger.error("No resource_group_name found")
            raise Exception('No resource_group_name found')

        if redis_name.get('cache_name') is not None:
            secret_keys['cache_name'] = redis_name.get('cache_name')
        else:
            logger.error("No cache_name found")
            raise Exception('No cache_name found')

        
        credentials = ''
        credentials = ClientSecretCredential(
            client_id=secret_keys['client_id'],
            tenant_id=secret_keys['tenant_id'],
            client_secret=secret_keys['client_secret']
        )
        logger.info(f'Connecting to Azure.....')
        client = RedisManagementClient(credentials, secret_keys['subscription_id'])


        logger.info(f'Fetching Response')


        response = client.redis.get(
            resource_group_name=secret_keys['resource_group_name'],
            name=secret_keys['cache_name']
        )



        active_objects = [
            {
                'name': response['name'],
                'LastModifiedOn': '',
                'user': '',
                'Created_On': '',
            }
        ]
        deleted_objects = []
        logger.info(f'Collection Completed.')

        # ingestion of metadata into inventory
        UpdateInventory(active_objects, deleted_objects, **config['INVENTORY_CONFIG'])
        logger.info(f'Ingestion Completed.')
    
    
    except Exception as e:
        logger.error(f"Error occured: {e}")

    finally:
        # handle closing of connections here
        if client:
            client.close()
            # close() -> None
