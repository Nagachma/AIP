import logging
import os

from sqlalchemy import create_engine, text
from sqlalchemy.exc import SQLAlchemyError
# from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import create_engine

from helpers import get_from_vault, load_yaml

Base = declarative_base()


class db_connect_util:
    def __init__(self, connection_info, **connection_dict):
        self.logger = connection_dict.get('logger', self._get_logger_())
        # get default connection details
        self.connection_details = self._get_defaults_('db_connect.yaml')
        # update provided connection details in default settings
        self.connection_details.update(connection_dict)
        self.connection_details.update(connection_info)

        # get connection uri from vault
        if self.connection_details['use_vault']:
            self.logger.debug('Loading DB credentials from Vault')
            vault_keys_to_fetch = { key:value for key, value in self.connection_details.items()
                                   if (key.startswith('db_') or key == 'connection_uri') and value is not None }
            conf_from_vault = self._get_db_uri_from_vault_(
                self.connection_details['vault_path'],
                **vault_keys_to_fetch
            )
            self.connection_details.update(conf_from_vault)

        if self.connection_details.get('connection_uri'):
            self.connection_uri = self.connection_details.get('connection_uri')
        else:
            self.db_name = self.connection_details.get('db_name')
            self.db_username = self.connection_details.get('db_username')
            self.db_password = self.connection_details.get('db_password')
            self.db_host = self.connection_details.get('db_host')
            self.db_port = self.connection_details.get('db_port')
            self.dbservice = self.connection_details.get('dbservice')
            self.driver = self.connection_details.get('driver')
            self.additional_driver = self.connection_details.get('additional_driver')
            #self.build_connection_uri()

        #self.connect_with_uri()
        # self.Session = sessionmaker(bind=self.engine)

    def _get_defaults_(self, default_config_file) -> dict:
        '''load the default connection details from default config file'''
        default_connection_details = {}
        self.logger.debug(f'Loading default connection details from {default_config_file}')

        # get default configuration for db
        default_config_file = os.path.join(os.path.dirname(__file__), default_config_file)
        default_config = load_yaml(default_config_file)
        default_connection_details.update(default_config['DB_CONFIG'])
        default_connection_details.update(default_config['CONNECTION_INFO'])

        return default_connection_details

    def _get_logger_(self):
        '''get root logger instance if none provided'''
        return logging.getLogger()

    def _get_db_uri_from_vault_(self, vault_path: str, **vault_key_dict) -> str:
        '''Retrieve the database connection uri from the vault'''
        vault_keys = [ value for value in vault_key_dict.values() if value is not None ]
        vault_conf = get_from_vault(vault_path, vault_keys)
        updated_vault_conf = {}
        for key, value in vault_key_dict.items():
            if vault_conf[value] is not None:
                updated_vault_conf[key] = vault_conf[value]

        return updated_vault_conf

    def connect_with_uri(self):
        try:
            self.logger.debug(f'Creating connection engine')
            self.engine = create_engine(self.connection_uri)
            # Session = sessionmaker(bind=self.engine)
            # self.session = Session()
            self.logger.debug('Engine created')
        except Exception as e:
            self.logger.error(f"Error: {e}")
            exit(1)

    def build_connection_uri(self):
        """
        Builds connection string from config data
        """
        # Check for all configs
        if not self.dbservice:
            self.logger.error("No dbservice found")
            raise Exception('No dbservice found')

        if not self.db_username:
            self.logger.error("No db_username found")
            raise Exception('No db_username found')

        if not self.db_password:
            self.logger.error("No db_password found")
            raise Exception('No db_password found')

        if not self.db_host:
            self.logger.error("No db_host found")
            raise Exception('No db_host found')

        if not self.db_port:
            self.logger.error("No db_port found")
            raise Exception('No db_port found')

        if not self.db_name:
            if self.dbservice.lower() == 'oracle':
                self.db_name = 'ORCL'     # set SID name if DBName is not provided
            else:
                self.logger.error("No db_name found")
                raise Exception('No db_name found')

        # Build connection string
        if self.driver:
            self.connection_uri = f'{self.dbservice}+{self.driver}://{self.db_username}:{self.db_password}@{self.db_host}:{self.db_port}/{self.db_name}'
            # add additional driver for certain databases
            if 'database.windows.net' in self.db_host or 'azuresynapse.net' in self.db_host or 'mssql' in self.dbservice:
                self.connection_uri += f'{self.additional_driver}'

        else:
            self.connection_uri = f'{self.dbservice}://{self.db_username}:{self.db_password}@{self.db_host}:{self.db_port}/{self.db_name}'

    def execute_query(self, query):
        try:
            self.build_connection_uri()
            self.connect_with_uri()

            self.logger.debug("Executing the query on the database")
            with self.engine.connect() as con:
                result = con.execute(text(query)).fetchall()
            self.logger.debug("Query executed successfully")

            return result

        except SQLAlchemyError as e:
            self.logger.error(f"Error: {e}")
            raise e

    def close_connection(self):
        if self.engine:
            self.logger.debug("Disposing the connection engine")
            self.engine.dispose()

# Example usage
if __name__ == "__main__":
    db_config = {
        "db_name": "your_db_name",
        "db_username": "your_username",
        "db_password": "your_password",
        "db_host": "localhost",
        "db_port": "5432"

    }
    conn_config ={
        "dbservice": "postgresql",
        "driver": "psycopg2",
        "additional_driver": "?driver = ODBC+Driver+17+for+SQL+Server"
    }

    util = db_connect_util(conn_config, **db_config)
    util.connect_with_uri()

    # Execute a query
    # Fetch data
    select_query = "SELECT * FROM test_table;"
    data = util.execute_query(select_query)
    if data:
        for row in data:
            util.logger.debug(row)

    util.close_connection()
