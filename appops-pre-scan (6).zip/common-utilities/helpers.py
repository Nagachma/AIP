'''
This script contains common functions to avoid duplication of code blocks and facilitate developer-friendly code :)
'''
__author__ = 'Prudhvi Chelluri'
__email__ = 'prudhvi.l.chelluri@accenture.com'
__version__ = '0.0.1'  # 2023-08-08

import logging
from logging.handlers import RotatingFileHandler
import os, sys
import yaml
import json
import requests
import traceback


def load_yaml(config_file) -> dict:
    '''Load yaml configuration

    Args: configuration file
    Returns: yaml file as dict
    '''
    # check if config file exists
    if not os.path.isfile(config_file):
        print(f'Configuration file not found [{config_file}]')
        exit(1)

    config = {}
    with open(config_file, 'r') as conf:
        try:
            config = yaml.safe_load(conf)
        except yaml.YAMLError as ye:
            print(f'Error loading config file: {ye}')
            exit(1)

    return config


def create_logger(**logger_config):
    '''Create a logging handler

    Args: logging configuration as a dictionary [Allowed keys: log_level, log_to_console, log_dir, log_filename, max_log_size_in_kb, log_backup_count]
    Returns: a logging handler'''
    # human-readable log-level to logging.* mapping
    log_levels = {
        'DEBUG': logging.DEBUG,
        'INFO': logging.INFO,
        'WARNING': logging.WARNING,
        'ERROR': logging.ERROR
    }

    # set default logging configuration
    default_logging_config = {
        'log_level': 'INFO',
        'log_to_console': False,
        'log_dir': 'log',
        'log_filename': 'service_pre_scan.log',
        'max_log_size_in_kb': 5000,
        'log_backup_count': 5
    }

    # update missing logging configuration with defaults
    for key in default_logging_config.keys():
        if key not in logger_config:
            logger_config[key] = default_logging_config[key]

    # format the log entries
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    # get root logger
    logger = logging.getLogger()
    # set logging level
    logger.setLevel(log_levels.get(logger_config['log_level'].upper()))

    # create logging handler
    if logger_config.get('log_to_console'):
        handler = logging.StreamHandler(sys.stdout)
    else:
        # create logging directory
        if logger_config['log_dir']: os.makedirs(logger_config['log_dir'], exist_ok=True)
        # add rotating file handler to rotate log file when size crosses a threshold
        handler = RotatingFileHandler(
            os.path.join(logger_config['log_dir'], logger_config['log_filename']),
            maxBytes=logger_config['max_log_size_in_kb'] * 1000,  # KB to Bytes
            backupCount=logger_config['log_backup_count']
        )

    handler.setFormatter(formatter)
    logger.addHandler(handler)

    return logger


def get_from_vault(vault_path: str, keys: list) -> dict:
    '''Wrapper to read secrets from vault

    Args:
        vault_path (str): path to vault
        keys (list): keys to read from vault
    Returns:
        configuration from vault as dict'''

    from vault_utility_v2 import vault_credentials

    # retrieve details from vault
    vault_conf = vault_credentials.get_secret_from_vault(vault_path, keys)

    return vault_conf


def push_db(converted_dict, service_name, metric_ts,load_url):
    try:
        converted_dict = json.loads(converted_dict)
        data = {'dataframe_dict': converted_dict, 'service': service_name, 'env': 'AWS North Virginia',
                'metric_timestamp': str(metric_ts)}
        data_json = json.dumps(data)
        print("data", data_json)
        headers = {'Content-Type': 'application/json'}
        response = requests.post(str(load_url), data=data_json)
        print("finished")
    except:
        print(traceback.print_exc())

