'''
This script contains functions related to MongoDB
'''
__author__ = 'Prudhvi Chelluri'
__email__ = 'prudhvi.l.chelluri@accenture.com'
__version__ = '0.0.1'   # 2023-08-08

import csv
import logging
import os, sys
from pymongo import MongoClient
from typing import List

# Add common utilities path for importing
helper_path = os.path.abspath(os.path.join('..'))
sys.path.append(helper_path)

# custom imports
from helpers import load_yaml, get_from_vault


class MongoUtil():
    '''
    Utility class for MongoDB transactions. Initialize by passing MongoDB details as a dictionary.
    '''
    def __init__(self, **connection_dict):
        # get logger first
        self.logger = connection_dict.get('logger', self._get_logger_())
        # get default connection details
        connection_details = self._get_defaults_('mongodb_defaults.yaml')
        # update provided connection details in default settings
        connection_details.update(connection_dict)

        # get connection uri from vault
        if connection_details['use_vault']:
            self.logger.debug('Loading MongoDB URI from Vault')
            connection_details_vault = self._get_db_uri_from_vault_(
                connection_details['vault_path'],
                connection_details['vault_keys']
            )
            connection_details.update(connection_details_vault)

        self.connection_uri = connection_details['connection_uri']
        self.database = connection_details['database']
        self.collection_name = connection_details['collection']
        self.create_connection()

    def _get_defaults_(self, default_config_file) -> dict:
        '''load the default connection details from default config file'''
        default_connection_details = {}
        self.logger.debug(f'Loading default mongo connection details from {default_config_file}')

        # get default configuration for db
        default_config_file = os.path.join(os.path.dirname(__file__), default_config_file)
        default_config = load_yaml(default_config_file)
        default_connection_details.update(default_config['DB_CONFIG'])
        default_connection_details.update(default_config['VAULT_CONFIG'])

        return default_connection_details

    def _get_logger_(self):
        '''get root logger instance if none provided'''
        return logging.getLogger()

    def _get_db_uri_from_vault_(self, vault_path: str, keys: list) -> str:
        '''Retrieve the database connection uri from the vault'''
        vault_conf = get_from_vault(vault_path, keys)
        connection_config ={}
        connection_config['connection_uri']=vault_conf['mongo_url']
        connection_config['database']=vault_conf['mongo_db']


        return connection_config

    def create_connection(self):
        '''Create a new database connection'''
        try:
            self.mongo_client = MongoClient(self.connection_uri, tz_aware=True)
            self.db = self.mongo_client.get_database(self.database)
            self.collection = self.db.get_collection(self.collection_name)
            self.logger.debug(f'MongoDB connection created for collection [{self.database}.{self.collection_name}]')
        except Exception as e:
            # add specific connection errors related to the database for more granular error messages
            self.logger.error(f'Failed to create MongoDB connection for collection [{self.database}.{self.collection_name}] with error: {e}')
            exit(1)

    def count(self, query={}) -> int:
        '''Return count of documents based on the query'''
        self.logger.debug(f'Getting count of documents using query [{query}]')
        return self.collection.count_documents(query)

    def read(self, query={}):
        '''Return latest one record from database'''
        self.logger.debug(f'Fetching data from [{self.database}.{self.collection_name}]')
        #docs = self.collection.find(query).sort('_id', DESCENDING).limit(1)
        #result = [ doc for doc in docs ]
        # since the inventory contains only one record, we can simply query the collection without any filters
        result = self.collection.find_one(query)

        return result

    def insert(self, records):
        '''Insert records into database'''
        self.logger.debug(f'Inserting {len(records)} records into [{self.database}.{self.collection_name}]')
        if isinstance(records, list):
            self.collection.insert_many(records)
        else:
            self.collection.insert_one(records)

    def upsert(self, filter, update_expression):
        '''Upsert a record into database (update the record if exists, else insert)'''
        self.logger.debug(f'Upserting record in [{self.database}.{self.collection_name}]')
        self.collection.update_one(filter, update_expression, upsert=True)

    def close_connection(self):
        '''Close database connection'''
        if self.mongo_client:
            self.logger.debug(f'Closing mongo connection for [{self.database}.{self.collection_name}]')
            self.mongo_client.close()

def save_to_file(data: List[dict], filename: str) -> str:
    '''Save the data to a file. This overwrites the file if exists'''
    try:
        with open(filename, 'w') as csvfile:
            fieldnames = ['name', 'LastModifiedOn', 'user', 'Created_On']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(data)

        return 'success'

    except Exception as e:
        return str(e)

# TODO: optimize this function to handle bulk data. 
# 1. use chunking or GridFS while ingesting to mongo
# 2. use pandas to load data instead of list of dictionaries
def UpdateInventory(active_objects: List[dict], deleted_objects: List[dict], **config):
    '''
    Update inventory collection. Overwrites existing data for a service if exists.

    Args:
        active_objects: list of active workflows / jobs
        deleted_objects: list of deleted workflows / jobs
        config: dict of configuration containing inventory mongodb configuration
    `Note`: This function will create and close a new connection to the mongodb
    '''
    service_alias = config['service_alias_name']
    if not active_objects and not deleted_objects:
        logging.getLogger().info(f'No data found to update inventory for service [{service_alias}]')
        return

    # create mongo connection
    mongo_util = MongoUtil(**config)
    try:
        mongo_util.logger.info(f'Ingesting inventory data for service [{service_alias}]')
        formatted_data = {
            service_alias: {
                'Active': active_objects,
                'Deleted': deleted_objects
            }
        }
        if mongo_util.count() > 0:
            # upsert service data if collection is not empty. use $set to overwrite data if exists.
            mongo_util.logger.debug(f'Updating inventory for service [{service_alias}]')
            mongo_util.upsert({}, {'$set': formatted_data})
        else:
            # insert data as collection is empty
            mongo_util.logger.debug(f'Collection does not exist or empty. Inserting inventory for service [{service_alias}]')
            mongo_util.insert(formatted_data)
        mongo_util.logger.info(f'Updated {len(active_objects)} active and {len(deleted_objects)} deleted objects in inventory for service [{service_alias}]')

    except Exception as e:
        mongo_util.logger.error(f'Failed to update inventory for service [{service_alias}] with error: {e}')
        if config['save_on_failure']:
            # save collected data to csv on ingestion failure
            active_obj_file_name = f'{service_alias}_active.csv'
            deleted_obj_file_name = f'{service_alias}_deleted.csv'
            mongo_util.logger.info(f'Saving collected inventory data for service [{service_alias}] to: [{active_obj_file_name}, {deleted_obj_file_name}]')
            # save active objects data
            status = save_to_file(active_objects, active_obj_file_name)
            if status != 'success':
                mongo_util.logger.error(f'Failed to save active inventory data with error: {status}')
            # save deleted objects data
            status = save_to_file(deleted_objects, deleted_obj_file_name)
            if status != 'success':
                mongo_util.logger.error(f'Failed to save active inventory data with error: {status}')

    finally:
        mongo_util.close_connection()

if __name__ == '__main__':
    connection_details = {
        'connection_uri': 'mongo_uri',
        'database': 'appops_dev',
        'collection': 'dummy'
    }
    mongo_util = MongoUtil(**connection_details)
    print(mongo_util.read())

    mongo_util.close_connection()
