'''
This Script is used to collect metadata from Informatica Power Exchange metadata DB
'''
__author__ = 'Prudhvi Chelluri'
__email__ = 'prudhvi.l.chelluri@accenture.com'
__version__ = '0.0.1'   # 2023-08-29

# module imports
import os, sys
import argparse

# Add common utilities path for importing
helper_path = os.path.abspath(os.path.join('..', '..', 'common-utilities'))
sys.path.append(helper_path)
mongo_util_path = os.path.abspath(os.path.join('..', '..', 'common-utilities', 'mongo-util'))
sys.path.append(mongo_util_path)
db_util_path = os.path.abspath(os.path.join('..', '..', 'common-utilities', 'db-util'))
sys.path.append(db_util_path)

# custom imports
from helpers import load_yaml, create_logger
from MongoUtil import UpdateInventory
from db_connect import db_connect_util

if __name__ == '__main__':
    # get cli arguments
    parser = argparse.ArgumentParser(description='pre-scanner of Informatica Power Exchange service')
    parser.add_argument('-c', '--config', type=str, default='infa_pwx_pre_scanner.yaml', help='configuration file')
    parser.add_argument('-v', '--version', action='version', version=f'{os.path.basename(__file__)} v{__version__}')

    args = parser.parse_args()
    config_file = args.config

    config = load_yaml(config_file)
    logger = create_logger(**config['LOGGING'])
    metadb_client = None
    query = config['scan_query']

    try:
        logger.info(f'Starting pre-scanner for service [Informatica Power Exchange]')
        # collection of metadata using service-specific logic
        logger.info(f'Creating Oracle connection to Informatica Power Exchange')
        metadb_client = db_connect_util(config['CONNECTION_INFO'], **config['METADB_CONFIG'])
        data = metadb_client.execute_query(query)
        # convert list of lists (table) to list of dicts (inventory format)
        active_objects = [
            {
                'name': row[0],
                'LastModifiedOn': '',
                'user': row[1],
                'Created_On': ''
            } for row in data if row
        ]
        deleted_objects = []

        # ingestion of metadata into inventory
        UpdateInventory(active_objects, deleted_objects, **config['INVENTORY_CONFIG'])

    except Exception as e:
        logger.error(f"Error occured: {e}")

    finally:
        # handle closing of connections here
        if metadb_client: metadb_client.close_connection()
