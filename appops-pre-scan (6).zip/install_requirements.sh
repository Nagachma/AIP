#!/bin/bash

echo 'Installing pip packages for AppOps-Pre-Scan...'
find . -name 'requirements.txt' | while read -r file; do
    echo "Installing packages from ${file}..."
    pip install -r ${file}
done
echo 'Installation of pip packages is complete!'
