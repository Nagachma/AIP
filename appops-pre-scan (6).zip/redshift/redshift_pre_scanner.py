'''
This Script is used to collect metadata for Redshift from AWS
'''
__author__ = 'Arunabha Das'
__email__ = 'arunabha.a.das@accenture.com'
__version__ = '0.0.1'   # 2023-08-28

# module imports
import os, sys
import argparse
import boto3
import pandas as pd

# Add common utilities path for importing
helper_path = os.path.abspath(os.path.join( '..', 'common-utilities'))
sys.path.append(helper_path)
mongo_util_path = os.path.abspath(os.path.join( '..', 'common-utilities', 'mongo-util'))
sys.path.append(mongo_util_path)

# custom imports
from helpers import load_yaml, create_logger , get_from_vault
from MongoUtil import UpdateInventory

if __name__ == '__main__':
    # get cli arguments
    parser = argparse.ArgumentParser(description='pre-scanner of Redshift service')
    parser.add_argument('-c', '--config', type=str, default='redshift_pre_scanner.yaml', help='configuration file')
    parser.add_argument('-v', '--version', action='version', version=f'{os.path.basename(__file__)} v{__version__}')

    args = parser.parse_args()
    config_file = args.config

    config = load_yaml(config_file)
    logger = create_logger(**config['LOGGING'])

    try:
        logger.info(f'Starting pre-scanner for service [Redshift]')
        
        logger.info(f'Fetching Credentials form vault')
        creds = get_from_vault(config['REDSHIFT_CONFIG']['vault_path'],config['REDSHIFT_CONFIG']['vault_key'])
        region = config['REDSHIFT_CONFIG']['region']

        logger.info(f'Checking Credentials form vault')
        access_id=''
        secret_key=''
        if creds.get('accessKey') is not None:
            access_id = creds['accessKey']
        else:
            logger.error("No access key found")
            raise Exception('No access key found')
        if creds.get('secretKey') is not None:
            secret_key = creds['secretKey']
        else:
            logger.error("No secret key found")
            raise Exception('No secret key found')
        
        logger.info(f'Connecting to AWS.....')
        client = boto3.client('redshift',aws_access_key_id=access_id, aws_secret_access_key=secret_key,
                                  region_name=region)
        
        logger.info(f'Fetching Response')
        # Get all cluster details in response
        response = client.describe_clusters()

        # List of clusters
        cluster_list=response.get("Clusters")
        data=pd.DataFrame()
        
        for cluster in cluster_list:
            tags=cluster.get('Tags')
            created_by=''
            if tags:
                for i in tags:
                    if i.get('Key') == 'createdBy':
                        created_by=i.get('Value')
                        
            df_dictionary = pd.DataFrame([{
                        'cluster_name': str(cluster.get("ClusterIdentifier")),
                        'create_time': str(cluster.get("ClusterCreateTime")),
                        'created_by': created_by 
                    }])
            data = pd.concat([data, df_dictionary], ignore_index=True)
        
        # convert list of lists (table) to list of dicts (inventory format)
        active_objects = [
            {
                'name': row['cluster_name'],
                'LastModifiedOn': '',
                'user': row['created_by'],
                'Created_On': row['create_time']
            } for index,row in data.iterrows()
        ]
        deleted_objects = []
        logger.info(f'Collection Completed.')

        # ingestion of metadata into inventory
        UpdateInventory(active_objects, deleted_objects, **config['INVENTORY_CONFIG'])
        logger.info(f'Ingestion Completed.')
    
    
    except Exception as e:
        logger.error(f"Error occured: {e}")

    finally:
        # handle closing of connections here
        if client: client.close()
