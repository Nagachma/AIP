import logging
import snowflake.connector as sf
import os
import sys

db_util_path = os.path.abspath(os.path.join('..', '..', 'common-utilities', 'db-util'))
sys.path.append(db_util_path)

from snowflake.connector.errors import DatabaseError, ProgrammingError
from datetime import datetime, timedelta, timezone
from db_connect import db_connect_util


class snow_db_connect_util(db_connect_util):
    def __init__(self, connection_info, **connection_dict):
        super().__init__(connection_info, **connection_dict)

        self.account = self.connection_details.get('account')
        self.warehouse = self.connection_details.get('warehouse')
        self.schema = self.connection_details.get('schema')
        self.frequency = 5
        self.build_snow_connection_uri()
        print("in snow_db_connect_util",self.connection_details)
        self.connect_snow_with_uri()
        # self.Session = sessionmaker(bind=self.engine)


    def connect_snow_with_uri(self):
        try:
            self.logger.debug(f'Creating connection engine')
            self.engine = sf.connect(user=self.db_username, password=self.db_password, account=self.account,
                                     warehouse=self.warehouse, database=self.db_name, schema=self.schema)
            # self.engine = create_engine(self.connection_uri)
            self.logger.debug("engine created", self.engine)
        except DatabaseError as db_ex:
            if db_ex.errno == 250001:
                self.logger.debug(f"ERROR: Invalid username/password, please re-enter username and password...")
                # code for user to re-enter username & pass
            else:
                raise
        except Exception as ex:
            # Log this
            self.logger.error(f"ERROR: Unhandled snowflake error occurred {ex}")
            raise


    def build_snow_connection_uri(self):
        """
        Builds connection string from config data
        """
        # Check for all configs

        if not self.account:
            self.logger.error("No account found")
            raise Exception('No account found')

        if not self.db_username:
            self.logger.error("No db_username found")
            raise Exception('No db_username found')

        if not self.db_password:
            self.logger.error("No db_password found")
            raise Exception('No db_password found')

        if not self.schema:
            self.logger.error("No schema found")
            raise Exception('No schema found')

        if not self.warehouse:
            self.logger.error("No warehouse found")
            raise Exception('No warehouse found')

        if not self.db_name:
            self.logger.error("No db_name found")
            raise Exception('No db_name found')

        # Build connection string

        #self.connection_uri = f'{self.dbservice}://{self.db_username}:{self.db_password}@{self.db_host}:{self.db_port}/{self.db_name}'
        self.connection_uri = f'snowflake://{self.db_username}:{self.db_password}@{self.account}/{self.db_name}/{self.schema}?warehouse={self.warehouse}'

    def snow_execute_query(self, query):
        try:
            self.logger.debug("inside try")
            freq = self.frequency
            starttime = datetime.now(timezone.utc) - timedelta(minutes=(freq + 1))
            starttime = starttime.replace(second=0).replace(microsecond=0)
            endtime = datetime.now(timezone.utc) - timedelta(minutes=1)
            endtime = endtime.replace(second=0).replace(microsecond=0)

            # If query has a start time and end time, insert actual timestamps
            mod_query = query['query'].replace('starttime', "'" + str(starttime) + "'")
            query = mod_query.replace('endtime', "'" + str(endtime) + "'")
            # with self.engine.connect() as con:
            # data = con.execute(text(query)).fetchall()
            self.logger.debug("Query executed successfully")
            # self.engine = sf.connect(user='naga', password='Newproject@1431', account='pnb46339.us-east-1', warehouse='compute_wh',
            #        database='SNOWFLAKE_SAMPLE_DATA', schema='TPCH_SF1')
            engine = self.engine.cursor()
            data = engine.execute(query)
            # res_values = data.fetch_pandas_all()

            # self.logger.debug("data is",res_values)
            return data
        except ProgrammingError as db_ex:
            self.logger.error(f"ERROR: Programming error: {db_ex}")
            raise db_ex

    def close_connection(self):
        """closing database connection."""
        self.engine.close()
        self.logger.debug("Disposing the connection engine")
