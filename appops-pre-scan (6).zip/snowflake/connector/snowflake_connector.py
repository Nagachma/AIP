'''
This Script is used to collect the metrics from snowflake
'''
# module imports
import argparse
import os
import sys
import boto3
import traceback
import hashlib
import random
import json
import numpy as np
import pandas as pd
from abc import ABC, abstractmethod

helper_path = os.path.abspath(os.path.join('..', '..', 'common-utilities'))
sys.path.append(helper_path)

# custom imports
from helpers import load_yaml, create_logger, get_from_vault, push_db
from snow_db_connect import snow_db_connect_util


class BaseMetricsCollector(ABC):
    """base class to define collect metrics for all services and
    will be implemented by subclass """

    @abstractmethod
    def collect_metrics(self):
        raise NotImplementedError


class DatabaseMetricsCollector(BaseMetricsCollector):
    def __init__(self):
        """
        initializing all the required variables.
        """
        # get cli arguments
        self.parser = argparse.ArgumentParser(description='snowflake service metrics for xops ')
        self.parser.add_argument('-c', '--config', type=str, default='snowflake_connector.yaml',
                                 help='configuration file')
        self.args = self.parser.parse_args()
        self.config_file = self.args.config

        self.config = load_yaml(self.config_file)
        # self.logger.debug("self config is",self.config)
        self.logger = create_logger(**self.config['logging'])
        self.logger.debug("self config is", self.config)
        # query = config['scan_query']

    def collect_metrics(self):
        """this method is used to collect the metrics from DB"""
        try:
            self.logger.debug("inside collect metrics")
            self.snowflake_client = None
            self.snowflake_client = snow_db_connect_util(self.config['connection_info'],
                                                         **self.config['snowflake_config'])
            self.logger.debug(f"connection is: {self.snowflake_client}")

            self.col_metrics = []
            for scenario in self.config['live_scenarios']:
                self.logger.debug("inside ", self.config['live_scenarios'])
                if scenario.startswith("."):
                    self.logger.debug("Skipping " + scenario.split(".")[1])
                    continue
                else:
                    self.logger.debug(" --- calling dbconnector collect metric function ---- ")
                    res_data = self.snowflake_client.snow_execute_query(self.config['live_scenarios'][scenario])
                    # data.to_csv(f'appendeddd+{str(i)}.csv')

                    all_rows = res_data.fetchall()
                    # num_fields = len(res_data.description)
                    field_names = [i[0] for i in res_data.description]
                    df = pd.DataFrame(all_rows)
                    df.columns = field_names

                    self.col_metrics.append(df)
            converted_dict = self.flattening_data()
            ts = str(converted_dict.iloc[0]["START_TIME"])
            # ts = str(converted_dict["START_TIME"]).strip()

            converted_dict = converted_dict.to_json()
            load_url = self.config['snowflake_config']['load_url']

            # converted_dict = json.loads(converted_dict)

            push_db(converted_dict, self.config['connection_info']['dbservice'], ts, load_url)
            return converted_dict

        except Exception as e:
            self.logger.error(f"Error occurred: {str(e)}")

        finally:
            # handle closing of connections here
            if self.snowflake_client:
                self.snowflake_client.close_connection()

    def flattening_data(self):
        cluster_df = self.col_metrics[0]
        filter_df2 = self.col_metrics[1]
        col = self.config.get('snowflake_config')
        col_list = col['col_list']
        filter_df1 = cluster_df[col_list]
        result = pd.concat([filter_df1, filter_df2], axis=1, join='inner')

        result.insert(0, "cluster_unique_id", hashlib.sha3_256(
            repr(filter_df1["name"] + str(random.randint(0, 999999))).encode('utf-8')).hexdigest())

        if ['START_TIME']:
            result['START_TIME'] = result['START_TIME'].dt.strftime('%Y-%m-%d %H:%M:%S')
        if ['END_TIME']:
            result['END_TIME'] = result['END_TIME'].dt.strftime('%Y-%m-%d %H:%M:%S')
        if ['CREDITS_USED_CLOUD_SERVICES']:
            result['CREDITS_USED_CLOUD_SERVICES'] = result['CREDITS_USED_CLOUD_SERVICES'].apply(lambda x: str(x))
        if ['RELEASE_VERSION']:
            result['RELEASE_VERSION'] = result['RELEASE_VERSION'].apply(lambda x: str(x))

        if ["IS_CLIENT_GENERATED_STATEMENT"]:
            result["IS_CLIENT_GENERATED_STATEMENT"] = result['IS_CLIENT_GENERATED_STATEMENT'].apply(lambda x: str(x))

        result.rename(columns={'name': 'cluster_name'}, inplace=True)
        # time.strptime(timestamp[:19], "%Y-%m-%dT%H:%M:%S")
        # result["START_TIME"] = result['START_TIME'].apply(lambda timestamp: time.strftime("%Y-%m-%d %H:%M:%S",time.strptime(timestamp[:19], "%Y-%m-%dT%H:%M:%S")))

        result.replace(np.nan, 'None', inplace=True)
        # converted_dict = result.to_json()
        # converted_dict = json.loads(converted_dict)

        # push_db(converted_dict,self.config['connection_info']['dbservice'],converted_dict["START_TIME"]["0"])
        return result


class CloudwatchMetricsCollector(BaseMetricsCollector):
    def __init__(self):
        """
        initializing all the required variables.
        """

        # get cli arguments
        self.parser = argparse.ArgumentParser(description='snowflake service metrics for xops ')
        self.parser.add_argument('-c', '--config', type=str, default='snowflake_connector.yaml',
                                 help='configuration file')
        self.args = self.parser.parse_args()
        self.config_file = self.args.config

        self.config = load_yaml(self.config_file)
        self.logger.debug("self config is", self.config)
        self.logger = create_logger(**self.config['logging'])
        # query = config['scan_query']

    def collect_metrics(self):
        """
        this method is used to collect the metrics from AWS Cloudwatch
        """
        access_id = ''
        secret_key = ''
        region = self.config['AWS']['region']
        secret_keys = vault_credentials.get_secret_from_vault(self.config['vault_path'], self.config['vault_keys'])
        if secret_keys.get('accessKey') is not None:
            access_id = secret_keys['accessKey']
        else:
            self.logger.error("No access key found")
            raise Exception('No access key found')
        if secret_keys.get('secretKey') is not None:
            secret_key = secret_keys['secretKey']
        else:
            self.logger.error("No secret key found")
            raise Exception('No secret key found')

        cloudwatch = ''
        try:
            # AWS CloudWatch connection
            cloudwatch = boto3.client('cloudwatch', aws_access_key_id=access_id, aws_secret_access_key=secret_key,
                                      region_name=region)
        except Exception as e:
            self.logger.error(traceback.format_exc())


class LogsMetricsCollector(BaseMetricsCollector):
    def collect_metrics(self):
        pass


class MetricsCollector:
    def __init__(self, source_collector):
        self.source_collector = source_collector

    def collect_all_metrics(self):
        metrics = {}
        re = self.source_collector.collect_metrics()
        # self.logger.debug("re is",re)
        # metrics.update(self.source_collector.collect_metrics())
        return re


# initializing object
database_collector = DatabaseMetricsCollector()
# cloudwatch_collector = CloudwatchMetricsCollector()

# passing object as a parameter for collecting metrics
metric_collector = MetricsCollector(database_collector)
metrics = metric_collector.collect_all_metrics()

print("metrics are ", metrics)
