import pytest
from commonutilities.dbutil.db_connect import db_connect_util
from commonutilities.helpers import load_yaml
from snowflake.connector.snowflake_connector import DatabaseMetricsCollector


@pytest.fixture
def load_yaml_file():
    config = load_yaml("snowflake_connector.yaml")
    return config


@pytest.fixture
def setup_teardown(load_yaml_file):
    obj = db_connect_util(load_yaml_file["snowflake_config"], **load_yaml_file["connection_info"])
    obj.connect_with_uri()
    yield
    obj.close_connection()


# testing service name in yaml
def test__get_defaults_(load_yaml_file):
    obj = db_connect_util(load_yaml_file["snowflake_config"], **load_yaml_file["connection_info"])
    res = obj._get_defaults_("db_connect.yaml")
    assert "Snowflake" in res.values()


# testing result of collected metrics
def test_collect_metrics():
    obj = DatabaseMetricsCollector()
    res = obj.collect_metrics()
    assert  res is not None


# testing start time
def test_start_time(setup_teardown, load_yaml_file):
    obj = db_connect_util(load_yaml_file["snowflake_config"], **load_yaml_file["connection_info"])
    res = obj.execute_query(load_yaml_file['live_scenarios']['cluster_details'])
    assert res["name"].tolist() is not None


# testing cluster size
def test_cluster_size(setup_teardown, load_yaml_file):
    obj = db_connect_util(load_yaml_file["snowflake_config"], **load_yaml_file["connection_info"])
    res = obj.execute_query(load_yaml_file['live_scenarios']['cluster_details'])
    assert res["size"].tolist()[0] == "X-Small"


# testing cluster name
def test_cluster_name(setup_teardown, load_yaml_file):
    obj = db_connect_util(load_yaml_file["snowflake_config"], **load_yaml_file["connection_info"])
    res = obj.execute_query(load_yaml_file['live_scenarios']['cluster_details'])
    assert res["name"].tolist()[0] == "COMPUTE_WH"


# testing cluster status
def test_cluster_status(setup_teardown, load_yaml_file):
    obj = db_connect_util(load_yaml_file["snowflake_config"], **load_yaml_file["connection_info"])
    res = obj.execute_query(load_yaml_file['live_scenarios']['cluster_details'])
    assert res["failed"].tolist()[0] == 0


# testing cluster active status
def test_cluster_active_status(setup_teardown, load_yaml_file):
    obj = db_connect_util(load_yaml_file["snowflake_config"], **load_yaml_file["connection_info"])
    res = obj.execute_query(load_yaml_file['live_scenarios']['cluster_details'])
    assert res["actives"].tolist()[0] == 1

