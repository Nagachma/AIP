import argparse
import base64
import json
import logging
import os
import re
import sys
from datetime import datetime, timedelta

import requests
import yaml
from pymongo import MongoClient



helper_path = os.path.abspath(os.path.join('..','..', 'common-utilities'))
sys.path.append(helper_path)
from helpers import get_from_vault, load_yaml, create_logger
logger = logging.getLogger('Stonebranch_connector')
logger.setLevel(logging.INFO)
# create console handler and set level to debug
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)

# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# add formatter to ch
ch.setFormatter(formatter)

# add ch to logger
logger.addHandler(ch)


def extract_log_information(log_content):
    # Define regular expression patterns to match the desired information
    api_return_code_pattern = r"DataBricks API Return code: (\d+)"
    run_id_pattern = r"Run ID of this execution : (\d+)"
    result_state_pattern = r"job execution completed with status: (\w+)"
    job_id_pattern = r'"job_id":(\d+)'
    life_cycle_state_pattern = r'"life_cycle_state":"(\w+)"'

    # Search for the patterns in the log content
    api_return_code_match = re.search(api_return_code_pattern, log_content)
    run_id_match = re.search(run_id_pattern, log_content)
    result_state_match = re.search(result_state_pattern, log_content)
    job_id_match = re.search(job_id_pattern, log_content)
    life_cycle_state_match = re.search(life_cycle_state_pattern, log_content)

    # Initialize variables to store the extracted values
    db_api_return_code = None
    db_job_run_id = None
    db_result_state = None
    db_job_id = None
    db_life_cycle_state = None
    SB_DBricks_conn_fail = None

    if api_return_code_match:
        db_api_return_code = api_return_code_match.group(1)
        if db_api_return_code == '200':
            SB_DBricks_conn_fail = False
        else:
            SB_DBricks_conn_fail = True
    if run_id_match:
        db_job_run_id = run_id_match.group(1)

    if result_state_match:
        db_result_state = result_state_match.group(1)

    if job_id_match:
        db_job_id = job_id_match.group(1)

    if life_cycle_state_match:
        db_life_cycle_state = life_cycle_state_match.group(1)

    return {
        "db_api_return_code": db_api_return_code,
        "SB_DBricks_conn_fail": SB_DBricks_conn_fail,
        "db_job_run_id": db_job_run_id,
        "db_result_state": db_result_state,
        "db_job_id": db_job_id,
        "db_life_cycle_state": db_life_cycle_state
    }


def calculate_duration(start_time_str, end_time_str):
    # Convert the timestamp strings to datetime objects
    if (start_time_str is not None and start_time_str != '') and (end_time_str is not None and end_time_str != ''):
        start_time = datetime.strptime(start_time_str, "%Y-%m-%d %H:%M:%S %z")
        end_time = datetime.strptime(end_time_str, "%Y-%m-%d %H:%M:%S %z")

        # Calculate the duration

        duration = end_time - start_time
        duration = int(duration.total_seconds() * 1000)
    else:
        duration = 0
    return duration


def map_status_to_numeric(status):
    if status == 'SUCCESS':
        return 0
    elif status == 'FAILED':
        return 1
    else:
        return 2

def fetch_resource_metrics(env,api_name, api, username, password, frequency):
    auth_string = f"{username}:{password}"
    base64_auth = base64.b64encode(auth_string.encode()).decode()
    api_url = env + api.get('endpoint')
    api_method = api.get('method')
    request_parameter = api.get('request_parameter')
    request_parameter['updatedTime'] = f'-{frequency}mn'
    query_parameter = api.get('query_parameter')
    headers = api.get('headers')
    headers.update({"Authorization": f"Basic {base64_auth}"})
    # Create a session
    session = requests.Session()
    #
    # # Set up basic authentication (if required)
    session.auth = (username, password)
    # if api_method == 'GET':
    #     # Send the GET request with query parameters, headers, and authentication
    #     try:
    #         if query_parameter is not None:
    #             response = session.get(url=api_url, params=query_parameter, headers=headers, verify=False)
    #         else:
    #             response = session.get(url=api_url, headers=headers, verify=False)
    #         # Check for a successful response (status code 200)
    #         if response.status_code == 200 and api_name == 'status':
    #             logger.debug("GET request was successful!")
    #             try:
    #                 json_response = json.loads(response.text)
    #                 return json_response
    #             except Exception as exc:
    #                 logger.exception(exc)
    #
    #         else:
    #             logger.error(f"GET request failed with status code {response.status_code}:")
    #
    #     except requests.exceptions.RequestException as e:
    #         logger.exception(f"An error occurred: {e}")
    #
    #     finally:
    #         session.close()

    if api_method == 'POST':
        try:
            response = session.post(url=api_url, headers=headers, json=request_parameter, verify=False)
            # Check for a successful response (status code 200)
            if response.status_code == 200 and api_name == 'taskinstance':
                # if True:
                logger.debug("POST request was successful!")
                try:
                    taskInstances = []
                    json_response = json.loads(response.text)
                    taskInstanceList = json_response
                    if type(taskInstanceList) == dict:
                        taskInstances = list(taskInstanceList.items())
                    elif type(taskInstanceList) == list:
                        taskInstances = taskInstanceList
                    workflow_list = []
                    task_list = []
                    for inst in taskInstances:
                        taskInstanceDict = {}
                        workflow = {}
                        if inst["type"] == 'Workflow':
                            workflow["workflow_instanceNumber"] = inst["instanceNumber"]
                            workflow["workflow_instanceName"] = inst["taskName"]
                            workflow["workflow_definitionId"] = inst["taskId"]
                            workflow["workflow_instanceId"] = inst["sysId"]
                            workflow["workflow_startTime"] = inst["startTime"]
                            workflow["workflow_endTime"] = inst["endTime"]
                            workflow["workflow_businessService"] = inst["businessServices"][0]
                            workflow["workflow_executionUser"] = inst["executionUser"]
                            workflow["workflow_status"] = map_status_to_numeric(inst["status"])
                            workflow["workflow_statusDescription"] = inst["statusDescription"]
                            workflow["workflow_progress_percent"] = inst["progress"]
                            workflow["workflow_duration_ms"] = calculate_duration(inst["startTime"], inst["endTime"])

                            workflow_list.append(workflow)
                        else:
                            taskInstanceDict["task_instanceNumber"] = inst["instanceNumber"]
                            taskInstanceDict["task_businessService"] = inst["businessServices"][0]
                            taskInstanceDict["task_taskName"] = inst["taskName"]
                            taskInstanceDict["task_executionUser"] = inst["executionUser"]
                            taskInstanceDict["task_status"] = map_status_to_numeric(inst["status"])
                            taskInstanceDict["task_exitCode"] = inst["exitCode"]
                            taskInstanceDict["task_statusDescription"] = inst["statusDescription"]
                            taskInstanceDict["task_progress_percent"] = inst["progress"]
                            taskInstanceDict["task_startTime"] = inst["startTime"]
                            taskInstanceDict["task_endTime"] = inst["endTime"]
                            taskInstanceDict["task_duration_ms"] = calculate_duration(inst["startTime"], inst["endTime"])
                            taskInstanceDict["task_agent"] = inst["agent"]
                            taskInstanceDict["task_taskId"] = inst["taskId"]
                            taskInstanceDict["task_triggerTime"] = inst["triggerTime"]
                            taskInstanceDict["task_triggeredBy"] = inst["triggeredBy"]
                            taskInstanceDict["task_type"] = inst["type"]
                            if inst["outputs"] is not None and len(inst['outputs']) > 0:
                                dbList = inst["outputs"]
                                # Filter dictionaries with output data size > 20 and not only containing 'run_id'
                                filtered_data = [d for d in dbList if len(d.get('outputData', '')) > 100]

                                # Sort the filtered data by attemptCount in descending order to get the latest attempt
                                filtered_data.sort(key=lambda x: int(x['attemptCount']), reverse=True)

                                # Fetch the outputData from the latest attempt
                                if len(filtered_data) > 0:
                                    latest_attempt_output = filtered_data[0].get('outputData', '')
                                else:
                                    latest_attempt_output = ''
                                # logContent = dbList[1]['outputData']
                                # result = extract_log_information(logContent)
                                result = extract_log_information(latest_attempt_output)
                                taskInstanceDict["databricks_api_return_code"] = result["db_api_return_code"]
                                # taskInstanceDict["stonebranch_databricks_connection_failure"] = result["SB_DBricks_conn_fail"]
                                taskInstanceDict["databricks_run_id"] = result["db_job_run_id"]
                                taskInstanceDict["databricks_result_state"] = map_status_to_numeric(result["db_result_state"])
                                taskInstanceDict["databricks_job_id"] = result["db_job_id"]
                                taskInstanceDict["databricks_lifecycle_state"] = map_status_to_numeric(result["db_life_cycle_state"])
                                if result["db_result_state"] is not None and ((inst["status"] == 'SUCCESS' and result["db_result_state"] == 'SUCCESS') or (
                                        inst["status"] == 'FAILED' and result["db_result_state"] == 'FAILED')):
                                    # or (inst["status"]=='CANCELLED' and result["db_result_state"]=='CANCELED'):
                                    taskInstanceDict["SB_DBricks_conn_fail"] = 0
                                elif result["db_result_state"] is not None and ((inst["status"] == 'SUCCESS' and result["db_result_state"] != 'SUCCESS') or (
                                        inst["status"] == 'FAILED' and result["db_result_state"] != 'FAILED') or (
                                        inst["status"] != 'SUCCESS' and result["db_result_state"] == 'SUCCESS') or (
                                        inst["status"] != 'FAILED' and result["db_result_state"] == 'FAILED')):
                                    taskInstanceDict["SB_DBricks_conn_fail"] = 1
                                elif result["db_result_state"] is None:
                                    taskInstanceDict["SB_DBricks_conn_fail"] = None

                            taskInstanceDict["workflow_instanceName"] = inst["workflowInstanceName"]
                            taskInstanceDict["workflow_definitionId"] = inst["workflowDefinitionId"]
                            taskInstanceDict["workflow_instanceId"] = inst["workflowInstanceId"]
                            task_list.append(taskInstanceDict)

                    new_task_list = []
                    logger.info(f'Number of tasks {len(task_list)}')
                    for t in task_list:
                        new_task = t.copy()
                        for wf in workflow_list:
                            new_workflow = {}
                            triggered_by = t['task_triggeredBy'] if 'workflow' in t['task_triggeredBy'] else None
                            if triggered_by is not None and wf['workflow_instanceName'] == triggered_by.split(':')[
                                1].strip() \
                                    and wf['workflow_instanceName'] == t["workflow_instanceName"] and wf[
                                "workflow_definitionId"] == t["workflow_definitionId"] \
                                    and wf["workflow_instanceId"] == t["workflow_instanceId"]:
                                new_task.update(wf)
                        new_task_list.append(new_task)

                    # new_workflow_list=[]
                    # unparented_tasks=[]
                    # for wf in workflow_list:
                    #     tasks=[]
                    #
                    #     for item in task_list:
                    #         task={}
                    #         triggered_by=item['task_triggeredBy'] if 'workflow' in item['task_triggeredBy'] else None
                    #         if triggered_by is not None and wf['workflow_instanceName'] == triggered_by.split(':')[1].strip():
                    #             task=item
                    #             tasks.append(task)
                    #         elif triggered_by is None:
                    #             task=item
                    #             unparented_tasks.append(task)
                    #     filterd_tasks =[]
                    #     for d in tasks:
                    #         filtered_dict = {key: value for key, value in d.items() if value is not None and value!=''}
                    #         filterd_tasks.append(filtered_dict)
                    #     if len(filterd_tasks)>0:
                    #         wf['tasks']= filterd_tasks
                    #     new_workflow_list.append(wf)
                    # filtered_unparented_tasks=[]
                    # for d in unparented_tasks:
                    #     filtered_dict = {key: value for key, value in d.items() if value is not None and value!=''}
                    #     filtered_unparented_tasks.append(filtered_dict)
                    # new_workflow_list.append({'workflow_instanceName': 'Unparented_tasks', 'tasks': filtered_unparented_tasks})
                    # # Create a new list with key-value pairs where the value is not None
                    # filtered_list = []
                    # for d in new_workflow_list:
                    #     filtered_dict = {key: value for key, value in d.items() if value is not None and value!=''}
                    #     filtered_list.append(filtered_dict)
                    # print(filtered_list)
                    # return filtered_list

                    filterd_tasks = []
                    for nt in new_task_list:
                        filtered_dict = {key: value for key, value in nt.items() if value is not None and value != ''}
                        filterd_tasks.append(filtered_dict)
                    return filterd_tasks
                except Exception as exc:
                    logger.exception(exc)

            else:
                logger.error(f"POST request failed with status code {response.status_code}:")

        except requests.exceptions.RequestException as e:
            logger.exception(f"An error occurred: {e}")

        finally:
            session.close()  # Close the session when done


def get_credentials_from_vault(vault_path, vault_keys):
    vault_conf = get_from_vault(vault_path, vault_keys)

    return vault_conf


if __name__ == '__main__':
    logger.info('Executing Stonebranch connector')
    pwd = os.path.dirname(os.path.realpath(__file__))

    # get cli arguments
    parser = argparse.ArgumentParser(description='pre-scanner of a service-name service from a MongoDB')
    parser.add_argument('-c', '--config', type=str, default='stonebranch_connector.yaml', help='configuration file')
    args = parser.parse_args()
    config_file = args.config

    config = load_yaml(config_file)
    logger = create_logger(**config['logging'])

    # get default connection details
    connection_details = config.get('connection_info')

    # get connection uri from vault
    if connection_details['use_vault']:
        logger.debug('Loading credentials from Vault')
        conf_from_vault = get_credentials_from_vault(
            connection_details['vault_path'],
            connection_details['vault_keys']
        )
        connection_details.update(conf_from_vault)
    stonebranch_env = connection_details['stonebranchapi']
    api_username = connection_details['serviceusername']
    api_password = connection_details['servicepassword']
    frequency = config['frequency']
    # Get the current UTC timestamp
    current_utc_time = datetime.utcnow()
    # Calculate a timedelta of 5 minutes
    five_minutes_ago = current_utc_time - timedelta(minutes=frequency)
    # Format the result in UTC format (ISO 8601)
    utc_timestamp = datetime.strptime(five_minutes_ago.strftime("%Y-%m-%d %H:%M"), '%Y-%m-%d %H:%M')
    output_list = []
    node = {}
    node['ts'] = utc_timestamp
    source = {'region': connection_details['region'],'env': connection_details['env'], 'service_provider': connection_details['service_provider']}
    node['source'] = source
    for api in config['apis']:
        output = fetch_resource_metrics(stonebranch_env, api, config['apis'][api], api_username, api_password, frequency)
        # if 'status' == api and output is not None:
        #     node['status'] = output
        if 'taskinstance' == api and output is not None:
            # node['workflows'] = output
            node['tasks'] = output

    if len(node) > 2:
        output_list.append(node)

    # get default connection details
    mongo_details = config.get('mongo_details')

    # get connection uri from vault
    if mongo_details['use_vault']:
        logger.debug('Loading credentials from Vault')
        conf_from_vault = get_credentials_from_vault(
            mongo_details['vault_path'],
            mongo_details['vault_keys']
        )
        mongo_details.update(conf_from_vault)
    if len(output_list) > 0:
        client = MongoClient(mongo_details['mongo_url'])
        db = client.get_database(mongo_details['mongo_db'])
        collection = db.get_collection(mongo_details['collection_name'])
        try:
            collection.insert_many(output_list)
            logger.info(f" {len(output_list)} documents are ingested to mongo for Stonebranch   ")
        except Exception as e:
            logger.exception(f"Error occured while trying to insert to mongo {e}")
    else:
        logger.warning("Zero new entries inserted to mongodb for Stonebranch")
