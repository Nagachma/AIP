import argparse
import base64
import json
import logging
import os
import sys

import pandas as pd
import requests
import yaml


# Add common utilities path for importing
helper_path = os.path.abspath(os.path.join('..','..', 'common-utilities'))
sys.path.append(helper_path)
mongo_util_path = os.path.abspath(os.path.join( '..','..', 'common-utilities', 'mongo-util'))
sys.path.append(mongo_util_path)

from MongoUtil import UpdateInventory
from helpers import load_yaml, create_logger, get_from_vault

logger = logging.getLogger('Stonebranch_prescan')
logger.setLevel(logging.INFO)
# create console handler and set level to debug
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)

# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# add formatter to ch
ch.setFormatter(formatter)

# add ch to logger
logger.addHandler(ch)



def fetch_tasks(env, api, username, password):
    auth_string = f"{username}:{password}"
    base64_auth = base64.b64encode(auth_string.encode()).decode()
    api_url = env + api.get('endpoint')
    api_method=api.get('method')
    # request_parameter=json.dumps(api.get('request_parameter'))
    request_parameter=api.get('request_parameter')
    query_parameter=api.get('query_parameter')
    headers=api.get('headers')
    headers.update({"Authorization": f"Basic {base64_auth}"})
    # Create a session
    session = requests.Session()
    # Set up basic authentication (if required)
    session.auth = (username, password)

    try:
        response = session.get(url=api_url, headers=headers, json=request_parameter, verify=False,
                               params=query_parameter)
        # Check for a successful response (status code 200)
        if response.status_code == 200:
            logger.debug("POST request was successful!")
            try:
                json_response = json.loads(response.text)
                return json_response
            except Exception as exc:
                logger.exception(exc)

        else:
            logger.error(f"POST request failed with status code {response.status_code}:")

    except requests.exceptions.RequestException as e:
        logger.exception(f"An error occurred: {e}")

    finally:
        session.close()  # Close the session when done



def load_configuration(cwdPath):
    """Read and load data from config.yaml file"""
    cfg = {}  # Check if this is a dict
    try:
        with open(cwdPath, 'r') as yamlfile:
            cfg = yaml.load(yamlfile, Loader=yaml.FullLoader)
    except yaml.YAMLError as exc:
        logger.exception(exc)
    except Exception as e:
        logger.exception(e)
    return cfg



# def execute(**inputs):
def get_credentials_from_vault(vault_path, vault_keys):
    vault_conf = get_from_vault(vault_path, vault_keys)

    return vault_conf


if __name__ == '__main__':
    logger.info('Executing Stonebranch prescan')
    pwd = os.path.dirname(os.path.realpath(__file__))

    # get cli arguments
    parser = argparse.ArgumentParser(description='pre-scanner of a service-name service from a MongoDB')
    parser.add_argument('-c', '--config', type=str, default='stonebranch_prescanner.yaml', help='configuration file')
    args = parser.parse_args()
    config_file = args.config

    config = load_yaml(config_file)
    logger = create_logger(**config['logging'])

    # get default connection details
    connection_details = config.get('connection_info')

    # get connection uri from vault
    if connection_details['use_vault']:
        logger.debug('Loading credentials from Vault')
        conf_from_vault = get_credentials_from_vault(
            connection_details['vault_path'],
            connection_details['vault_keys']
        )
        connection_details.update(conf_from_vault)
    stonebranch_env=connection_details['stonebranchapi']
    api_username=connection_details['serviceusername']
    api_password=connection_details['servicepassword']
    try:
        logger.info(f'Starting pre-scanner for service [Stonebranch]')
        # collection of metadata using service-specific logic
        tasks =fetch_tasks(stonebranch_env, config['tasks'], api_username, api_password)
        data = pd.DataFrame()
        for task in tasks:

            df_dictionary = pd.DataFrame([{
                'task_name': task['name'],
                'firstRun': task['firstRun'],
                'lastRun': task['lastRun']
            }])
            data = pd.concat([data, df_dictionary], ignore_index=True)
        active_objects = [
            {
                'name': row['task_name'],
                'LastModifiedOn': row['lastRun'],
                'user': '',
                'Created_On': row['firstRun']
            } for index, row in data.iterrows()
        ]
        deleted_objects = []
        logger.info(f'Collection Completed.')
        # ingestion of metadata into inventory
        UpdateInventory(active_objects, deleted_objects, **config['inventory_config'])

    except Exception as e:
        logger.error(f"Error occured: {e}")


