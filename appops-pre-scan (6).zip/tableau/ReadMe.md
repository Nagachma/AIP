# TABLEAU PRE-SCAN EXECUTION GUIDE

## 1. Pass scanning range of the tableau metadata db from the console
###    `python3.9 tableau_prescanner.py --config=tableau_prescanner.yaml --start_date="2023-08-20 00:00:59" --end_date="2023-08-30 23:59:59"`

## 2. Pass the scanning range in the config in minutes from start_time to the current_time:
###   If you want to scan for last 2hrs or 120 minutes, update the `scan_range_in_minutes:` property in `tableau_prescaner.yaml` config file

### `scan_range_in_minutes: 120`