'''
Short description about what this script does
'''
__author__ = 'souvik.c.roy'
__email__ = 'souvik.c.roy@accenture.com'

# module imports
import os, sys
import argparse
from datetime import datetime, timezone, timedelta
# Add common utilities path for importing
helper_path = os.path.abspath(os.path.join('', '..', 'common-utilities'))
sys.path.append(helper_path)
mongo_util_path = os.path.abspath(os.path.join('', '..', 'common-utilities', 'mongo-util'))
sys.path.append(mongo_util_path)
db_util_path = os.path.abspath(os.path.join('', '..', 'common-utilities', 'db-util'))
sys.path.append(db_util_path)

# custom imports
from helpers import load_yaml, create_logger
from MongoUtil import UpdateInventory
from db_connect import db_connect_util

if __name__ == '__main__':
    # get cli arguments
    parser = argparse.ArgumentParser(description='pre-scanner of a service-name service from a MongoDB')
    parser.add_argument('-c', '--config', type=str, default='tableau_prescanner.yaml', help='configuration file')
    parser.add_argument('--start_date', type=str, dest="start_date", help='specify the start date to scan in the format YYYY-MM-DD HH:MM:SS',
                        required=False)
    parser.add_argument('--end_date', type=str, dest="end_date", help='specify the end date to scan in the format YYYY-MM-DD HH:MM:SS',
                        required=False)
    # parser.add_argument('-v', '--version', action='version', version=f'{os.path.basename(__file__)} v{__version__}')

    args = parser.parse_args()
    config_file = args.config

    config = load_yaml(config_file)
    logger = create_logger(**config['LOGGING'])

    if None in (args.start_date, args.end_date):
        command_line_input = False
    else:
        if args.start_date is not None:
            if args.end_date is None:
                parser.error("Specify end date")
        else:
            command_line_input = True

        if args.end_date is not None:
            if args.start_date is None:
                parser.error("Specify start date")
        else:
            command_line_input = True

        if args.start_date == "":
            parser.error("Specify start date value")
        else:
            command_line_input = True
        if args.end_date == "":
            parser.error("Specify end date value")
        else:
            command_line_input = True


    query = ''
    # Set frequency
    if (config.get('scan_range_in_minutes') is None or config.get('scan_range_in_minutes')==0) and (args.start_date is None and args.end_date is None):
        query = config['scan_query_default']
    elif config.get('scan_range_in_minutes') > 0:
        freq = config['scan_range_in_minutes']
        starttime = datetime.now(timezone.utc) - timedelta(minutes=(freq))
        starttime = starttime.replace(second=0).replace(microsecond=0)
        endtime = datetime.now(timezone.utc) - timedelta(minutes=1)
        endtime = endtime.replace(second=0).replace(microsecond=0)
        starttime = starttime.strftime("%Y-%m-%d %H:%M:%S")
        endtime = endtime.strftime("%Y-%m-%d %H:%M:%S")
        # If query has a start time and end time, insert actual timestamps
        mod_query = config['scan_query_custom_1'].replace("'starttime'", "'" + str(starttime) + "'")
        query = mod_query.replace("'endtime'", "'" + str(endtime) + "'")

    elif args.start_date and args.end_date:
        start_date=datetime.strptime(args.start_date, "%Y-%m-%d %H:%M:%S")
        end_date= datetime.strptime(args.end_date, "%Y-%m-%d %H:%M:%S")
        starttime = start_date.strftime("%Y-%m-%d %H:%M:%S")
        endtime = start_date.strftime("%Y-%m-%d %H:%M:%S")
        # If query has a start time and end time, insert actual timestamps
        mod_query = config['scan_query_custom_1'].replace("'starttime'", "'" + str(starttime) + "'")
        query = mod_query.replace("'endtime'", "'" + str(endtime) + "'")


    postgresql_client= None
    try:
        logger.info(f'Starting pre-scanner for service [Tableau]')
        # collection of metadata using service-specific logic
        logger.debug(f'Creating Postgresql connection to [Tableau]')
        postgresql_client = db_connect_util(config['CONNECTION_INFO'],**config['DB_CONFIG'])
        data = postgresql_client.execute_query(query=query)

        active_objects = [{
            'name': str(row[0]),
            'LastModifiedOn': str(row[3]),
            'user': str(row[1]),
            'Created_On': str(row[2])
        } for row in data if row and row[5] is False]
        deleted_objects = [{
            'name': str(row[0]),
            'LastModifiedOn': str(row[3]),
            'user': str(row[1]),
            'Created_On': str(row[2])
        } for row in data if row and row[5] is True]
        # ingestion of metadata into inventory
        UpdateInventory(active_objects, deleted_objects, **config['INVENTORY_CONFIG'])

    except Exception as e:
        logger.error(f"Error occured: {e}")

    finally:
        ...  # handle closing of connections here
        if postgresql_client: postgresql_client.close_connection()