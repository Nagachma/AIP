if __name__ == "__main__":
    rfe_input_files=[]

    with scan_directory(path="./Correlation_map/input/") as file_list:
        for file in file_list:
            if "RFE" in str(file):
                rfe_input_files.append(file.path)
