"""Apply PCA to a excel file and find feature correlation."""

import numpy as np
from pandas.api.types import is_numeric_dtype
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
import pandas as pd
from sklearn.preprocessing import StandardScaler
import logging
import csv

plt.style.use('ggplot')


def PCA_model(file_name, log_file_name):
    """config logging file"""
    logging.basicConfig(level=logging.INFO, filename=log_file_name,
                        format='%(asctime)s :: %(levelname)s :: %(message)s')
    # logging.getLogger().addHandler(logging.StreamHandler())

    for index, input_file_name in enumerate(file_name):
        """Load data."""
        # sheet_name = input("Enter sheet name:")
        dataset = pd.read_csv(input_file_name)

        """extract X and Y feature"""
        X = dataset.drop(dataset.columns[[0, 1, 2]], axis=1)
        X = X.drop(['run_id', 'start_time', 'end_time'], axis=1, errors='ignore')
        for colname, coltype in X.dtypes.iteritems():
            colname_flag = colname + '_Flag'
            if (not is_numeric_dtype(X[colname])) and (colname_flag in X.columns):
                X[colname] = X[colname_flag]
        X = X.drop(X.filter(regex='_Flag').columns, axis=1, errors='ignore')
        # y = dataset.iloc[:, 0]

        """score the features"""
        scaler = StandardScaler()
        scaler.fit(X)
        X = scaler.transform(X)

        """training the PCA"""
        pca = PCA(n_components=1)  # estimate only 1 PCs
        pca.fit_transform(X)  # project the original data into the PCA space

        """output and print the result"""
        # print(pca.explained_variance_ratio_)
        # print(abs(pca.components_)[0])

        X_metrics = X.columns.values.tolist()
        coefficients = abs(pca.components_)[0]
        logging.info(X_metrics)
        logging.info(coefficients)

        """save result to csv"""
        # field names
        fields = ['Y metric', 'X metric', 'coefficient']
        csv_result = []

        for i in range(len(coefficients)):
            csv_result.append([dataset.columns.values[0], X_metrics[i], coefficients[i]])

        with open("./csv_result/PCA_" + input_file_name, 'w', newline='') as f:
            # using csv.writer method from CSV package
            write = csv.writer(f)
            write.writerow(fields)
            write.writerows(csv_result)

        # # plotting
        # plot_x = dataset.columns.tolist()[3:]
        # plot_y = np.reshape(abs(pca.components_), len(plot_x))
        #
        # plt.title("PCA Correlation graph (" + faile_name + ")")
        # plt.xlabel("Feature")
        # plt.ylabel("Feature Importance")
        # plt.plot(plot_x, plot_y, color="green")
        # plt.xticks(rotation=90)
        # plt.gcf().subplots_adjust(bottom=0.3)
        # plt.show()
