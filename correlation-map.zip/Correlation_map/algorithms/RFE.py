"""Apply RFE to a excel file and find feature correlation."""
import numpy as np
import pandas as pd
import yaml
from pandas.api.types import is_numeric_dtype
from sklearn.feature_selection import RFE, RFECV
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import RandomForestRegressor
from sklearn.pipeline import Pipeline
from operator import itemgetter
import requests
import logging
import csv
import sys
from sys import exit as exit_python
from pymysql import connect as mysql_connect
from pymysql.err import OperationalError as PyMySQLOperationalError
from sqlalchemy import create_engine
from sqlalchemy.exc import OperationalError as SQLAlchemyOperationalError
import pymysql
import time
import ssl
import requests
import hvac
from cryptography.fernet import Fernet

def read_yaml():
    """ A function to read YAML file"""
    with open('/config/config.yml') as f:
        config = yaml.safe_load(f)

    return config

def update_yaml(data):
    """ A function to update YAML file"""
    with open('/config/config.yml', 'w') as f:
        yaml.dump(data, f, default_flow_style=False)

def get_db_connection(vault_url,vault_key):

    client = hvac.Client(
    url=vault_url,
    verify = False,
    token=vault_key,
    )
    db_response = client.secrets.kv.read_secret_version(path='orchestraidb')
    
    return db_response

def create_mysql_connection(username, passwd, hostname, db_name, port_number):
    url = "https://s3.amazonaws.com/rds-downloads/rds-combined-ca-bundle.pem"
    filename = "rds-combined-ca-bundle.pem"
    response = requests.get(url, verify=False)

    with open(filename, "wb") as f:
        f.write(response.content)

    # SSL_CA = os.path.abspath(filename)
    SSL_CA = filename
    print(SSL_CA)
    try:
        cnx = mysql_connect(user=username, password=passwd, host=hostname, database=db_name, port=port_number,
                            autocommit=True,ssl_ca=SSL_CA)
    except PyMySQLOperationalError as err:
        err.errno = err.args[0]
        if err.errno == 1044:
            print("ERROR: Access is denied to the user '" + username + "' on the database called '" + db_name + "'.")
            print("Please validate that said user has the correct level of access.")
            exit_python()
        elif err.errno == 1045:
            print("ERROR: Access is denied to the user '" + username + "' on host '" + hostname + "'.")
            print("Please validate that the username and password are correct.")
            exit_python()
        elif err.errno == 1049:
            print("ERROR: The database called '" + db_name + "'does not exist.")
            print("Please validate that database name is spelled correctly and exists.")
            exit_python()
        elif err.errno == 2003:
            print("ERROR: Unable to connect to host '" + hostname + "' on port '" + str(port_number) + "'.")
            print("Please validate your network connectivity and that the hostname and port is correct.")
            exit_python()
        else:
            print("ERROR: Unhandled MySQL Error.")
            print(err)
            exit_python()
    else:
        return cnx
def create_mysql_engine(username, passwd, hostname, db_name, port_number):
    try:
        ca_path = "rds-combined-ca-bundle.pem"
        ssl_args = {'ssl_ca': ca_path}
        engine = create_engine(url="mysql+pymysql://" + username + ":" + passwd + "@" + hostname + ":" + str(port_number) + "/" + db_name,execution_options={"isolation_level": "AUTOCOMMIT"},connect_args=ssl_args)
        cnx = engine.connect()
    except SQLAlchemyOperationalError as err:
        err.errno = int(err.args[0].split(") (")[1].split(",")[0])
        if err.errno == 1044:
            print("ERROR: Access is denied to the user '" + username + "' on the database called '" + db_name + "'.")
            print("Please validate that said user has the correct level of access.")
            exit_python()
        elif err.errno == 1045:
            print("ERROR: Access is denied to the user '" + username + "' on host '" + hostname + "'.")
            print("Please validate that the username and password are correct.")
            exit_python()
        elif err.errno == 1049:
            print("ERROR: The database called '" + db_name + "'does not exist.")
            print("Please validate that database name is spelled correctly and exists.")
            exit_python()
        elif err.errno == 2003:
            print("ERROR: Unable to connect to host '" + hostname + "' on port '" + str(port_number) + "'.")
            print("Please validate your network connectivity and that the hostname and port is correct.")
            exit_python()
        else:
            print("ERROR: Unhandled MySQL Error.")
            print(err)
            exit_python()
    else:
        cnx.close()
        return engine
def connect_to_mysql(username, passwd, hostname, db_name, port_number):
    cnx = create_mysql_connection(username, passwd, hostname, db_name, port_number)
    engine = create_mysql_engine(username, passwd, hostname, db_name, port_number)
    return cnx, engine
def get_top_three_features(config, service_name, outcome_metric,Y_metric):
    vault_url = config['platformops']['vault_url']
    vault_key = config['platformops']['vault_key']
    f = config['platformops']['key']
    f = Fernet(f)
    vault_key = f.decrypt(vault_key.encode()).decode()
    key_url = config['platformops']['key_url']

    db_details = get_db_connection(vault_url,vault_key)

    jdbc_url = db_details['data']['data']['jdbc-url']
    db_username = db_details['data']['data']['username']
    db_passowrd = db_details['data']['data']['password']
    db_host = jdbc_url.split("/")[-2].split(":")[0]
    db_name = jdbc_url.split("/")[-1]
    mysql_cnx, mysql_engine = connect_to_mysql(db_username,db_passowrd,db_host,db_name,3306)
    mysql_cursor = mysql_cnx.cursor()
    query = "SELECT service_id FROM services WHERE service_name = '%s'"
    mysql_cursor.execute(query, (str(service_name), ))
    service_id = mysql_cursor.fetchone()[0]
    query = """SELECT me.metric_name FROM causal_metrics AS cm
                INNER JOIN metrics AS me ON cm.correlation_x_metric_id = me.metric_id
                WHERE cm.coefficient_flag = 1 AND cm.service_id = {service_id} AND cm.outcome_metric = '{outcome_metric}'
                GROUP BY correlation_x_metric_id
                ORDER BY COUNT(cm.correlation_x_metric_id) DESC
                LIMIT 3;""".format(service_id=service_id, outcome_metric=outcome_metric)
    df = pd.read_sql(query, mysql_cnx)
    df.insert(loc=0, column='Y metric', value=Y_metric)
    df["coefficient"] = 0
    return df.values.tolist()

def get_Y_metric(config, service_name, outcome_metric):
    vault_url = config['platformops']['vault_url']
    vault_key = config['platformops']['vault_key']
    f = config['platformops']['key']
    f = Fernet(f)
    vault_key = f.decrypt(vault_key.encode()).decode()
    key_url = config['platformops']['key_url']

    db_details = get_db_connection(vault_url,vault_key)

    jdbc_url = db_details['data']['data']['jdbc-url']
    db_username = db_details['data']['data']['username']
    db_passowrd = db_details['data']['data']['password']
    db_host = jdbc_url.split("/")[-2].split(":")[0]
    db_name = jdbc_url.split("/")[-1]

    mysql_cnx, mysql_engine = connect_to_mysql(db_username,db_passowrd,db_host,db_name,3306)
    mysql_cursor = mysql_cnx.cursor()
    query_1 = "SELECT service_id FROM services WHERE service_name = %s"
    mysql_cursor.execute(query_1, (service_name, ))    
    service_id = mysql_cursor.fetchone()[0]
    query = """SELECT m.metric_name FROM service_to_outcome_metric_mapping s 
                JOIN metrics m ON
                m.metric_id = s.correlated_metric_id
                WHERE s.outcome_metric_name = '{outcome_metric}' AND s.service_id = {service_id};""".format(service_id=service_id, outcome_metric=outcome_metric)

    print(query)
    mysql_cursor.execute(query)
    #Y_metric = mysql_cursor.fetchone()[0]
    Y_metric_name = mysql_cursor.fetchone()[0]
    print(Y_metric_name)
    if outcome_metric == "slowness":    Y_metric = service_name.lower() + "_y1_" + Y_metric_name + "_Flag"
    if outcome_metric == "failure":    Y_metric = service_name.lower() + "_y2_" + Y_metric_name + "_Flag"
    print(Y_metric)
    return Y_metric

def brute_force(dataset, config, Y_metric, file_name,service_name):
    csv_result = []
    selected_features = []
    if service_name  not in  config['brute_force_list'].keys():
        return csv_result,selected_features
    brute_force_list = config['brute_force_list'][service_name]
    #if b
    #print(brute_force_list)
    b=0
    for item in brute_force_list:
        if item=="Task_Status" and item in dataset.columns and (dataset[item]==1).any() and b<=3:
            b+=1
            csv_result.append([Y_metric, item, 0.5])
            selected_features.append([Y_metric, item, 0.5])

        if item in dataset.columns and (dataset[item]>=1).any() and (2 not in dataset[item].values) and b<=3:
            b+=1
            csv_result.append([Y_metric, item, 0.5])
            selected_features.append([Y_metric, item, 0.5])
    for task_status in selected_features:
        if task_status[1] == "Task_Status" and len(selected_features)<2:
            selected_features=[]
    return csv_result,selected_features     

def RFE_model(input_path, log_file_name, range_min, range_max):
    """config logging file"""
    logging.basicConfig(level=logging.INFO, filename=log_file_name,
                        format='%(asctime)s :: %(levelname)s :: %(message)s')
    # logging.getLogger().addHandler(logging.StreamHandler())
    config = read_yaml()
    cause_metrics_dic = config['cause_metrics']
    print(cause_metrics_dic)
    if cause_metrics_dic is None:
        cause_metrics_dic={}


    """Load data."""
    # sheet_name = input("Enter sheet name:")

    file_name=input_path.split('/')[-1]
    service_name = file_name.split('_')[2].capitalize()
    dataset = pd.read_csv(input_path)

    csv_result = []
    selected_features = []
    if dataset.shape[0] < config['rfe_minimum_row_number']:
        print(file_name + " does not contain enough rows.")
        if 'anomaly_failure' in dataset.columns:
            Y_metric = get_Y_metric(config, service_name, 'failure')
            csv_result, selected_features=brute_force(dataset, config, Y_metric, file_name,service_name)
            #return csv_result, selected_features
    else:
        dataset.fillna(0,inplace=True)
    
        """extract X feature"""
        # dataset = dataset[dataset.iloc[:, 0] != -1]
        # y_column=dataset.columns[0]
        # metric_name=y_column.split('_')[-2]
    
        # cause_metrics_dic[y_column] = []
    
        # X = dataset.drop(dataset.columns[[0, 1, 2]], axis=1)
    
        # y = dataset.iloc[:, 0].astype('float64')
    
        anomaly_list = ['anomaly_failure', 'anomaly_slowness']
        if (anomaly_list[0] in dataset.columns) and (anomaly_list[1] in dataset.columns):
            if len(dataset['anomaly_failure'].unique()) != 2 and dataset['anomaly_failure'].unique()[0] == 1 and len(
                    dataset['anomaly_slowness'].unique()) != 2 and dataset['anomaly_slowness'].unique()[0] == 1:
                temp_df = dataset.mode().dropna()
                for column in temp_df:
                    temp_df[column] = np.where(
                        (temp_df[column] != -1) & (temp_df[column] != 0) & (is_numeric_dtype(temp_df[column])), 0,
                        temp_df[column])
                # print(temp_df)
                temp_df['anomaly_failure'][0] = 0
                temp_df['anomaly_slowness'][0] = 0
                dataset = pd.concat([dataset, temp_df])
            for item in anomaly_list:
                outcome_metric = item.split('_')[-1]
                Y_metric = get_Y_metric(config, service_name, outcome_metric)
                cause_metrics_dic[Y_metric] = []
    
                if dataset[item].astype('float64').isin([0, -1]).all():
                    print("All anomaly value are Zero or Empty")
                else:
                    dataset = dataset[dataset[item] != -1]
                    y = dataset[item].astype('float64')
                    csv_result_sub, selected_features_sub = calculate_RFE(dataset, anomaly_list, y, Y_metric, cause_metrics_dic, config, service_name, outcome_metric,
                                range_min, range_max, file_name)
    
                    csv_result.extend(csv_result_sub)
                    selected_features.extend(selected_features_sub)
        else:
            if 'anomaly_failure' in dataset.columns and len(dataset['anomaly_failure'].unique()) != 2 and dataset['anomaly_failure'].unique()[0] == 1:
                temp_df = dataset.mode().dropna()
                for column in temp_df:
                    temp_df[column] = np.where(
                        (temp_df[column] != -1) & (temp_df[column] != 0) & (is_numeric_dtype(temp_df[column])), 0,
                        temp_df[column])
                # print(temp_df)
                temp_df['anomaly_failure'][0] = 0
                dataset = pd.concat([dataset, temp_df])
            elif 'anomaly_slowness' in dataset.columns and len(dataset['anomaly_slowness'].unique()) != 2 and dataset['anomaly_slowness'].unique()[0] == 1:
                temp_df = dataset.mode().dropna()
                for column in temp_df:
                    temp_df[column] = np.where(
                        (temp_df[column] != -1) & (temp_df[column] != 0) & (is_numeric_dtype(temp_df[column])), 0,
                        temp_df[column])
                # print(temp_df)
                temp_df['anomaly_slowness'][0] = 0
                dataset = pd.concat([dataset, temp_df])
            outcome_metric = dataset.columns[0].split('_')[-1]
            Y_metric = get_Y_metric(config, service_name, outcome_metric)
            cause_metrics_dic[Y_metric] = []
    
            if dataset.iloc[:, 0].astype('float64').isin([0, -1]).all():
                print("All anomaly value are Zero or Empty")
            else:
                dataset = dataset[dataset.iloc[:, 0] != -1]
                y = dataset.iloc[:, 0].astype('float64')
                csv_result_sub, selected_features_sub = calculate_RFE(dataset, anomaly_list, y, Y_metric, cause_metrics_dic, config, service_name, outcome_metric,
                            range_min, range_max, file_name)
    
                csv_result.extend(csv_result_sub)
                selected_features.extend(selected_features_sub)

    fields = ['Y metric', 'X metric', 'coefficient']
    file_name = file_name.replace("_input_", "_")
    with open("./Correlation_map/output/" + file_name, 'w', newline='') as f:
        # using csv.writer method from CSV package
        write1 = csv.writer(f)
        write1.writerow(fields)
        write1.writerows(csv_result)

    # if sum(coef)==0:
    #     result=pd.DataFrame(columns=['Y metric', 'X metric', 'coefficient'])
    #     selected_file_name = file_name.split("_")
    #     selected_file_name.insert(-1, 'selected')
    #     selected_file_name = "_".join(selected_file_name)
    #     result.to_csv(selected_file_name)
    # else:
    selected_file_name = file_name.split("_")
    selected_file_name.insert(-1, 'selected')
    selected_file_name = "_".join(selected_file_name)
    with open("./Correlation_map/output/" + selected_file_name, 'w', newline='') as sf:
        # using csv.writer method from CSV package
        write2 = csv.writer(sf)
        write2.writerow(fields)
        write2.writerows(selected_features)


def calculate_RFE(dataset, anomaly_list, y, Y_metric, cause_metrics_dic, config, service_name, outcome_metric, range_min, range_max, file_name):
    config_drop_list = config['config_drop_list']
    db_Y_metric = Y_metric.split('_')[2:]
    if len(db_Y_metric) <= 2:
        db_Y_metric = db_Y_metric[0]
    else:
        db_Y_metric = "_".join(db_Y_metric[:-1])
    drop_list = [db_Y_metric, anomaly_list[0], anomaly_list[1]] + config_drop_list
    # print(drop_list)
    X = dataset.drop(drop_list, axis=1, errors='ignore')
    for colname, coltype in X.dtypes.items():
        colname_flag = colname + '_Flag'
        if (not is_numeric_dtype(X[colname])) and (colname_flag in X.columns):
            X[colname] = X[colname_flag]
        if (not is_numeric_dtype(X[colname])):
            X.drop(colname, axis=1, inplace=True)

    X = X.drop(X.filter(regex='_Flag').columns, axis=1, errors='ignore')
    #X.fillna(0,inplace=True)
    X = X.loc[:, X.ne(-1).any()]
    X = X.loc[:, X.ne(0).any()]
    for column in X.columns:
        if X[column].isin([0, -1]).all():
            X = X.drop(column, axis=1)
    # print(X)
    csv_result = []
    selected_features = []
    if X.empty:
        print("No input value.")
        return csv_result, selected_features

    if X.shape[1] < 2:
        print("RFE require minimum of 2 features")
        if outcome_metric == 'failure':
            csv_result, selected_features=brute_force(X, config, Y_metric, file_name,service_name)
            return csv_result, selected_features
        else:
            return csv_result, selected_features

    """training the rfe"""
    features_to_select_number = 3
    regressor = RandomForestRegressor(n_estimators=100, max_depth=10, random_state=42)
    rfe = RFE(estimator=regressor, n_features_to_select=features_to_select_number)
    # rfe = RFECV(estimator=regressor)
    model = RandomForestClassifier(max_depth=10, random_state=42)
    pipeline = Pipeline(steps=[('s', rfe), ('m', model)])
    # fit the model on all available data
    pipeline.fit(X, y)

    """output and print the result"""
    names = np.array(X.columns.tolist())

    coef = list(rfe.estimator_.feature_importances_)


    result = []
    coefficient_all_zero_flag = 1
    # summarize all features
    for i in range(X.shape[1]):
        if rfe.support_[i] == True:
            current_coef = coef.pop(0)
            result.append([Y_metric, i, rfe.support_[i], rfe.ranking_[i], names[i], current_coef])
            selected_features.append([Y_metric, names[i], current_coef])
            cause_metrics_dic[Y_metric].append(str(names[i]))
            coefficient_all_zero_flag = 0
        else:
            result.append([Y_metric, i, rfe.support_[i], rfe.ranking_[i], names[i], str(0)])

    logging.info(result)


    # outcome_metric_flag = file_name.split('_')[1]
    # if outcome_metric_flag == 'slow':
    #     outcome_metric = 'slowness'
    # else:
    #     outcome_metric = 'failure'
    # if coefficient_all_zero_flag == 1:
    #     # print(service_name,outcome_metric,Y_metric)
    #     selected_features = get_top_three_features(config, service_name, outcome_metric,
    #                                                Y_metric)
        # print(selected_features)

    for i in result:
        if range_min <= float(i[5]) <= range_max:
            csv_result.append([i[0], i[4], i[5]])


    # print(cause_metrics_dic)
    config['cause_metrics'] = cause_metrics_dic
    #update_yaml(config)

    return csv_result, selected_features


