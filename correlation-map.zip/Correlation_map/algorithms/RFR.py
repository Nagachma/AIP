"""Apply RFR to a excel file and find feature correlation."""
import numpy as np
import pandas as pd
from pandas.api.types import is_numeric_dtype
from sklearn.feature_selection import RFE, RFECV
from sklearn.ensemble import RandomForestRegressor
from sklearn.pipeline import Pipeline
from operator import itemgetter
import logging
import csv


def RFR_model(file_name, log_file_name):
    """config logging file"""
    logging.basicConfig(level=logging.INFO, filename=log_file_name,
                        format='%(asctime)s :: %(levelname)s :: %(message)s')
    # logging.getLogger().addHandler(logging.StreamHandler())

    for index, input_file_name in enumerate(file_name):
        """Load data."""
        # sheet_name = input("Enter sheet name:")
        dataset = pd.read_csv(input_file_name)

        """extract X and Y feature"""
        X = dataset.drop(dataset.columns[[0, 1, 2]], axis=1)
        X = X.drop(['run_id', 'start_time', 'end_time'], axis=1, errors='ignore')
        for colname, coltype in X.dtypes.iteritems():
            colname_flag = colname + '_Flag'
            if (not is_numeric_dtype(X[colname])) and (colname_flag in X.columns):
                X[colname] = X[colname_flag]
        X = X.drop(X.filter(regex='_Flag').columns, axis=1, errors='ignore')

        y = dataset.iloc[:, 0].astype('float64')

        """training the RFR"""
        rfr = RandomForestRegressor(n_estimators=100, random_state=42)
        rfr.fit(X, y)

        """output and print the result"""
        names = np.array(X.columns.tolist())
        result = []
        # summarize all features
        for i in range(len(names)):
            result.append([dataset.columns.values[0], names[i], rfr.feature_importances_[i]])
            # print(result)

        logging.info(result)

        # print the result
        # for item in sorted(result, key=itemgetter(2)):
        #     print('Name: %s, Importance: %.2f' % (item[1], item[2]))

        """save result to csv"""
        # field names
        fields = ['Y metric', 'X metric', 'coefficient']

        with open("./csv_result/RFR_" + input_file_name, 'w', newline='') as f:
            # using csv.writer method from CSV package
            write = csv.writer(f)
            write.writerow(fields)
            write.writerows(result)
