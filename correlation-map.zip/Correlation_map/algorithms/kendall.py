"""Apply PCA to a excel file and find feature correlation."""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sb
import logging
from algorithms.utility import read_yaml
import csv
import warnings
warnings.filterwarnings('ignore')
def apply_rule(x):
    config = read_yaml()
    if 0 < x < config['pearson_range_min']:
        return 'rule 1: less than 2%'
    elif config['pearson_range_min'] <= x <= config['pearson_range_mid']:
        return 'rule 2:between 2% to 30%'
    elif config['pearson_range_mid'] < x <= config['pearson_range_max']:
        return 'rule 3:greater than 30%'

def kendall_model(data, file_name, log_file_name, range_min, range_max):
    """config logging file"""
    logging.basicConfig(level=logging.INFO, filename=log_file_name,
                        format='%(asctime)s :: %(levelname)s :: %(message)s')
    config=read_yaml()
    # data = pd.read_csv('./Correlation_map/Correlation_Data.csv')

    correlation_lists = config['Correlation_list']
    for index, correlation_list in enumerate(correlation_lists):
        correlation_list = [item.lower() for item in correlation_list]
        # print(correlation_list)
        column_list = list(data.columns.values)
        # column_list = [item.lower() for item in column_list]
        # print(column_list)
        input_column_list = []
        for column in column_list:
            column_service = column.split("_")[0].lower()
            if column_service in correlation_list:
                input_column_list.append(column.strip())

        if len(input_column_list) < 2:
            continue
        # print(input_column_list)
        input_data = data[input_column_list]
        # print("input df")
        # print(input_data)

        """apply kendall algorithm and output the result"""
        kendallcorr = input_data.corr(method='kendall')
        #print(kendallcorr)
        logging.info(kendallcorr)
        kendallcorr.to_csv(config['kendall_output'] + str(index) + "_" + file_name)
        print(kendallcorr)

        stack = kendallcorr.stack().reset_index()
        if stack.shape[0]==1:
            logging.info("only one job running and doesnt have another to correlate ")

        stack.columns = ['Y metric1', 'Y metric2', 'coefficient']
        stack_dups = (stack[['Y metric1', 'Y metric2']].apply(frozenset, axis=1).duplicated()) | (
                    stack['Y metric1'] == stack['Y metric2'])
        print(stack)
        stack = stack[~stack_dups]

        stack['coefficient'] = stack['coefficient'].apply(lambda x: 0 if x < 0 else x)
        # stack[stack['coefficient'] < 0]['coefficient'] = 0
        # print(stack)
        stack = stack[~stack_dups]
        print(stack)
        # stack['coefficient']=abs(stack['coefficient'])

        result = stack.sort_values(by=['coefficient'], ascending=False)
        print(result)
        result = stack.loc[(stack['coefficient'] >= range_min)]
        result['percentage'] = result['coefficient'] * 100
        result['rule'] = result['coefficient'].apply(apply_rule)

        # if 0 < stack['coefficient'].max() < range_min:
        #     result = stack.sort_values(by=['coefficient'], ascending=False).head(4)
        #     result['percentage'] = result['coefficient'] * 100
        #     result['rule'] = 'rule 1: less than 20%'
        # elif range_min<= stack['coefficient'].max() <= range_mid:
        #     result = stack.loc[(stack['coefficient'] >= range_min) & (stack['coefficient'] <= range_max)]
        #     result['percentage'] = result['coefficient'] * 100
        #     result['rule'] = 'rule 2: greater than 30%'

        selected_file_name = file_name.split("_")
        selected_file_name.insert(-1, 'selected')
        selected_file_name = "_".join(selected_file_name)
        #print(config['kendall_output_selected'] + selected_file_name)
        result.to_csv(config['kendall_output_selected'] + str(index) + "_" + selected_file_name, index=False)
        # print(result)

        # sb.heatmap(kendallcorr,
        #            xticklabels=kendallcorr.columns,
        #            yticklabels=kendallcorr.columns,
        #            cmap='RdBu_r',
        #            annot=True,
        #            linewidth=0.5)

        #plt.show()
