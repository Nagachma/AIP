"""Apply lasso to a excel file and find feature correlation."""
import numpy as np
import pandas as pd
from pandas.api.types import is_numeric_dtype
from sklearn.linear_model import Lasso
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.model_selection import GridSearchCV, train_test_split, RepeatedKFold
import logging
import csv


def lasso_model(file_name, log_file_name):
    """config logging file"""
    logging.basicConfig(level=logging.INFO, filename=log_file_name,
                        format='%(asctime)s :: %(levelname)s :: %(message)s')
    # logging.getLogger().addHandler(logging.StreamHandler())

    for index, input_file_name in enumerate(file_name):
        """Load data."""
        # sheet_name = input("Enter sheet name:")
        dataset = pd.read_csv(input_file_name)

        """extract X and Y feature"""
        X = dataset.drop(dataset.columns[[0, 1, 2]], axis=1)
        X = X.drop(['run_id', 'start_time', 'end_time'], axis=1, errors='ignore')
        for colname, coltype in X.dtypes.iteritems():
            colname_flag = colname + '_Flag'
            if (not is_numeric_dtype(X[colname])) and (colname_flag in X.columns):
                X[colname] = X[colname_flag]
        X = X.drop(X.filter(regex='_Flag').columns, axis=1, errors='ignore')

        y = dataset.iloc[:, 0].astype('float64')

        """training the lasso"""
        # X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33, random_state=42)

        pipline = Pipeline([
            ('scaler', StandardScaler()),
            ('model', Lasso())
        ])

        cv = RepeatedKFold(n_splits=10, n_repeats=3, random_state=1)
        search = GridSearchCV(pipline,
                              {'model__alpha': np.arange(0.1, 3, 0.1)},
                              cv=cv,
                              scoring='neg_mean_squared_error',
                              verbose=3)

        search.fit(X, y)

        """output and print the result"""
        coef = search.best_estimator_[1].coef_
        logging.info(coef)
        # print(coef)

        log_info_1 = 'Features considered by the model: ' + str(np.array(dataset.columns.tolist()[3:])[coef != 0])
        log_info_2 = 'Features discarded by the model: ' + str(np.array(dataset.columns.tolist()[3:])[coef == 0])
        logging.info(log_info_1)
        logging.info(log_info_2)

        # print the result
        # print('Features considered by the model: ', np.array(dataset.columns.tolist()[3:])[coef != 0])
        # print('Features discarded by the model: ', np.array(dataset.columns.tolist()[3:])[coef == 0])

        """save result to csv"""
        X_metrics = X.columns.values.tolist()

        # field names
        fields = ['Y metric', 'X metric', 'coefficient']
        csv_result = []

        for i in range(len(coef)):
            csv_result.append([dataset.columns.values[0], X_metrics[i], coef[i]])

        with open("./csv_result/lasso_" + input_file_name, 'w', newline='') as f:
            # using csv.writer method from CSV package
            write = csv.writer(f)
            write.writerow(fields)
            write.writerows(csv_result)
