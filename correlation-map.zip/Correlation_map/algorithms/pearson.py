"""Apply PCA to a excel file and find feature correlation."""
import sys

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sb
import logging
import yaml
#from algorithms.Granger_Causalit_Test_for_advanced_correlation import grangers_causation_test
import csv


def read_yaml():
    """ A function to read YAML file"""
    with open('/config/config.yml') as f:
        config = yaml.safe_load(f)

    return config


def apply_rule(x):
    config = read_yaml()
    if 0 < x < config['pearson_range_min']:
        return config['pearson_range_min_text']
    elif config['pearson_range_min'] <= x <= config['pearson_range_mid']:
        return config['pearson_range_mid_text']
    elif config['pearson_range_mid'] < x <= config['pearson_range_max']:
        return config['pearson_range_max_text']


# def set_zero(x):
#     if x < 0:
#         return 0
#     else:
#         return x

def pearson_model(file_path, log_file_name, range_min, range_mid, range_max):
    """config logging file"""
    logging.basicConfig(level=logging.INFO, filename=log_file_name,
                        format='%(asctime)s :: %(levelname)s :: %(message)s')

    data = pd.read_csv(file_path)
    data = data.dropna(how='all', axis=1)
    for column in data:
        if data[column].count()<5:
            data = data.drop(column, axis=1)
    print(data)
    # print(data.columns)
    """apply pearson algorithm and output the result"""
    pearsoncorr = data.corr(method='pearson')
    stack = pearsoncorr.stack().reset_index()
    # print(type(pearsoncorr))
    # print('----')

    columns_list = pearsoncorr.columns.to_list()
    # print(columns_list)
    for i in columns_list:
        pearsoncorr[i] = pearsoncorr[i].apply(lambda x: 0 if x < 0 else x)
        # pearsoncorr[i] = pearsoncorr[i].apply(lambda x: 0 if x.isnull()  else x)
    pearsoncorr.fillna(0, inplace=True)
    # print(pearsoncorr)
    # pearsoncorr[columns_list]=pearsoncorr[columns_list].apply(set_zero)

    logging.info(pearsoncorr)
    file_name = file_path.split('/')[-1]

    pearsoncorr.to_csv("./Correlation_map/output/pearson_" + file_name)

    stack.columns = ['Y metric1', 'Y metric2', 'coefficient']
    stack_dups = (stack[['Y metric1', 'Y metric2']].apply(frozenset, axis=1).duplicated()) | (
            stack['Y metric1'] == stack['Y metric2'])

    stack['coefficient'] = stack['coefficient'].apply(lambda x: 0 if x < 0 else x)
    # stack[stack['coefficient'] < 0]['coefficient'] = 0
    # print(stack)
    stack = stack[~stack_dups]
    # stack['coefficient']=abs(stack['coefficient'])

    result = stack.sort_values(by=['coefficient'], ascending=False)
    result = stack.loc[(stack['coefficient'] >= range_min)]
    result['percentage'] = result['coefficient'] * 100
    result['rule'] = result['coefficient'].apply(apply_rule)
    print(result)
    # if 0 < stack['coefficient'].max() < range_min:
    #     result = stack.loc[(stack['coefficient'] >= 0) & (stack['coefficient'] <= range_min)]
    #     #result = stack.sort_values(by=['coefficient'], ascending=False).head(4)
    #     result['percentage'] = result['coefficient'] * 100
    #     result['rule'] = 'rule 1: less than 20%%'
    # elif range_min <= stack['coefficient'].max() <= range_mid:
    #     result = stack.loc[(stack['coefficient'] >= range_min) & (stack['coefficient'] <= range_mid)]
    #     result['percentage'] = result['coefficient'] * 100
    #     result['rule'] = 'rule 2:between 20% to 30%'
    # elif range_mid <= stack['coefficient'].max() <= range_max:
    #     print('condition3')
    #     print(stack['coefficient'].max())
    #     result = stack.loc[(stack['coefficient'] >= range_mid) & (stack['coefficient'] <= range_max)]
    #     result['percentage'] = result['coefficient'] * 100
    #     result['rule'] = 'rule 3: greater than 30%'
    # elif stack['coefficient'].max()<=0:
    #     result=pd.DataFrame(columns=['Y metric1','Y metric2','coefficient','percentage','rule'])
    #     selected_file_name = file_name.split("_")
    #     selected_file_name.insert(-1, 'selected')
    #     selected_file_name = "_".join(selected_file_name)
    #     result.to_csv("./Correlation_map/output/pearson_" + selected_file_name, index=False)
    #     sys.exit(1)
    print(result)

    selected_file_name = file_name.split("_")
    selected_file_name.insert(-1, 'selected')
    selected_file_name = "_".join(selected_file_name)
    result.to_csv("./Correlation_map/output/pearson_" + selected_file_name, index=False)

    # if not result.empty:
    #     grangers_causation_test(result)

    # sb.heatmap(pearsoncorr,
    #            xticklabels=pearsoncorr.columns,
    #            yticklabels=pearsoncorr.columns,
    #            cmap='RdBu_r',
    #            annot=True,
    #            linewidth=0.5)

    # plt.show()
