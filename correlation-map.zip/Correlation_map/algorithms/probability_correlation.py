"""Apply PCA to a excel file and find feature correlation."""
import numpy as np
import pandas as pd
#import entry
import os
import glob
from os import listdir
import matplotlib.pyplot as plt
import seaborn as sb
from statsmodels.tsa.stattools import grangercausalitytests
import statsmodels
import logging
from algorithms.utility import read_yaml
import csv
import warnings
#from algorithms.Granger_Causalit_Test_for_advanced_correlation import grangers_causation_test
warnings.filterwarnings('ignore')
def apply_rule(x):
    config = read_yaml()
    if 0 < x < config['probability_range_min']:
        return config['probability_range_min_text']
    elif config['probability_range_min'] <= x <= config['probability_range_mid']:
        return config['probability_range_mid_text']
    elif config['probability_range_mid'] < x <= config['probability_range_max']:
        return config['probability_range_max_text']
def find_csv_filenames( path_to_dir, suffix=".csv" ):
    filenames = listdir(path_to_dir)
    file_list=[ filename for filename in filenames if filename.endswith( suffix ) ]
    return file_list
def probability_correlation(file_name,log_file_name, range_min = 0, range_max = 1):
    """config logging file"""
    logging.basicConfig(level=logging.INFO, filename=log_file_name,
                        format='%(asctime)s :: %(levelname)s :: %(message)s')
    config=read_yaml()
    data = pd.read_csv(file_name)
    # print(data)

    correlation_lists = config['Correlation_list']
    # print(correlation_lists)
    df_cons=pd.DataFrame()
    selected_fields = ['Y metric1', 'Y metric2', 'coefficient', 'percentage', 'rule']
    #df_selected=pd.DataFrame()
    df_selected_list=[]
    df_list=[]
    for index, correlation_list in enumerate(correlation_lists):
        correlation_list = [item.lower() for item in correlation_list]
        # print(correlation_list)
        column_list = list(data.columns.values)
        # print(column_list)
        # column_list = [item.lower() for item in column_list]
        # print(column_list)
        input_column_list = []
        for column in column_list:
            column_service = column.split("_")[0].lower()
            if column_service in correlation_list:
                input_column_list.append(column.strip())

        if len(input_column_list) < 2:
            continue
        # print(input_column_list)
        # input_data = data[input_column_list]
        # print("input df")
        # print(input_data)
        output_list = []
        selected_output_list = []
        for i in range(len(input_column_list)):
            for j in range(len(input_column_list)):
                column1_name = input_column_list[i]
                column2_name = input_column_list[j]
                if column1_name == column2_name:
                    p2 = 1
                else:
                    input_data = data[[column1_name, column2_name]]

                    number_of_11_df = input_data.loc[(input_data[column1_name] == 1) & (input_data[column2_name] == 1)]
                    number_of_11 = number_of_11_df.shape[0]
                    number_of_01_df = input_data.loc[(input_data[column1_name] == 0) & (input_data[column2_name] == 1)]
                    number_of_01 = number_of_01_df.shape[0]
                    # total_number = input_data.shape[0]

                    # p1 = number_of_11/total_number
                    if (number_of_11 + number_of_01) != 0:
                        p2 = number_of_11/(number_of_11 + number_of_01)
                    else:
                        p2 = 0

                output_list.append([column1_name, column2_name, p2])

                if 0 < p2 < config['probability_range_min'] and column1_name != column2_name:
                    rule = 'rule 1: less than 2%'
                    selected_output_list.append([column1_name, column2_name, p2, p2 * 100, rule])
                elif config['probability_range_min'] <= p2 <= config['probability_range_mid'] and column1_name != column2_name:
                    rule = 'rule 2:between 2% to 30%'
                    selected_output_list.append([column1_name, column2_name, p2, p2 * 100, rule])
                elif config['probability_range_mid'] < p2 <= config['probability_range_max'] and column1_name != column2_name:
                    rule = 'rule 3:greater than 30%'
                    selected_output_list.append([column1_name, column2_name, p2, p2 * 100, rule])

        #print(selected_output_list)
        fields = ['Y metric1', 'Y metric2', 'coefficient']
        output_list_df = pd.DataFrame(output_list, columns=fields)
        df_list.append(output_list_df)
        #fields = ['Y metric1', 'Y metric2', 'coefficient']
        #output_list_df_selected = pd.DataFrame(selected_output_list, columns=fields)
        #df_cons=df_cons.append(output_list_df)
        #print('--------')
        #print(output_list_df1)


        output_list_df1 = output_list_df.pivot(index='Y metric1', columns='Y metric2', values='coefficient')
        output_list_df1.index.rename('', inplace=True)
        output_list_df1.to_csv("./Correlation_map/output/probability_correlation_" + str(index) + ".csv")

        # with open("./Correlation_map/output/probability_correlation_" + str(index) + ".csv", 'w', newline='') as f:
        #     # using csv.writer method from CSV package
        #     write1 = csv.writer(f)
        #     write1.writerow(fields)
        #     write1.writerows(output_list)



        df_temp = pd.DataFrame(selected_output_list, columns=selected_fields)
        df_selected_list.append(df_temp)
        df_temp.to_csv("./Correlation_map/output/probability_correlation_selected_"+str(index) + ".csv", index=False)
        #selected_output_list.to_csv("./Correlation_map/output/probability_correlation_selected_"+str(index) + ".csv")
        #df_selected=pd.concat([df_selected,df_temp],ignore_index=True)
    # df_cons=pd.concat(df_list,ignore_index=True)
    # df_cons = df_cons.pivot(index='Y metric1', columns='Y metric2', values='coefficient')
    # df_cons.index.rename('', inplace=True)
    #df_cons.to_csv("./Correlation_map/output/probability_correlation_all.csv")
    #print("-----")
    # df_selected=pd.concat(df_selected_list,ignore_index=True)
    #print(df_selected)
    #print('-----')
    #df_selected.to_csv("./Correlation_map/output/probability_correlation_selected.csv")
    # if not df_selected.empty:
    #     try:
    #         grangers_causation_test(df_selected)
    #     except statsmodels.tools.sm_exceptions.InfeasibleTestError as e:
    #         print("Not enough data to run Advanced correlation")
    #         print(e)
    #         print("using RFE for calculating Casaulity metrics")






