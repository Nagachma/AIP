"""Apply PCA to a excel file and find feature correlation."""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sb
import logging
from algorithms.utility import read_yaml
import csv
import warnings
warnings.filterwarnings('ignore')
def apply_rule(x):
    config = read_yaml()
    if 0 < x < config['probability_range_min']:
        return 'rule 1: less than 2%'
    elif config['probability_range_min'] <= x <= config['probability_range_mid']:
        return 'rule 2:between 2% to 30%'
    elif config['probability_range_mid'] < x <= config['probability_range_max']:
        return 'rule 3:greater than 30%'

def probability_correlation(log_file_name, range_min = 0, range_max = 1):
    """config logging file"""
    logging.basicConfig(level=logging.INFO, filename=log_file_name,
                        format='%(asctime)s :: %(levelname)s :: %(message)s')
    config=read_yaml()
    data = pd.read_csv('./Correlation_map/outcome_y.csv')

    correlation_lists = config['Correlation_list']
    for index, correlation_list in enumerate(correlation_lists):
        correlation_list = [item.lower() for item in correlation_list]
        # print(correlation_list)
        column_list = list(data.columns.values)
        # column_list = [item.lower() for item in column_list]
        # print(column_list)
        input_column_list = []
        for column in column_list:
            column_service = column.split("_")[0].lower()
            if column_service in correlation_list:
                input_column_list.append(column.strip())

        if len(input_column_list) < 2:
            continue
        # print(input_column_list)
        # input_data = data[input_column_list]
        # print("input df")
        # print(input_data)
        output_list = []
        selected_output_list = []
        for i in range(len(input_column_list)):
            for j in range(i + 1, len(input_column_list)):
                column1_name = input_column_list[i]
                column2_name = input_column_list[j]
                input_data = data[[column1_name, column2_name]]

                number_of_11_df = input_data.loc[(input_data[column1_name] == 1) & (input_data[column2_name] == 1)]
                number_of_11 = number_of_11_df.shape[0]
                number_of_01_df = input_data.loc[(input_data[column1_name] == 0) & (input_data[column2_name] == 1)]
                number_of_01 = number_of_01_df.shape[0]
                # total_number = input_data.shape[0]

                # p1 = number_of_11/total_number
                if (number_of_11 + number_of_01) != 0:
                    p2 = number_of_11/(number_of_11 + number_of_01)
                else:
                    p2 = 0

                output_list.append([column1_name, column2_name, p2])

                if 0 < p2 < config['probability_range_min']:
                    rule = 'rule 1: less than 2%'
                    selected_output_list.append([column1_name, column2_name, p2, p2 * 100, rule])
                elif config['probability_range_min'] <= p2 <= config['probability_range_mid']:
                    rule = 'rule 2:between 2% to 30%'
                    selected_output_list.append([column1_name, column2_name, p2, p2 * 100, rule])
                elif config['probability_range_mid'] < p2 <= config['probability_range_max']:
                    rule = 'rule 3:greater than 30%'
                    selected_output_list.append([column1_name, column2_name, p2, p2 * 100, rule])


        fields = ['Y metric1', 'Y metric2', 'coefficient']

        with open("./Correlation_map/output/probability_correlation_" + str(index) + ".csv", 'w', newline='') as f:
            # using csv.writer method from CSV package
            write1 = csv.writer(f)
            write1.writerow(fields)
            write1.writerows(output_list)

        selected_fields = ['Y metric1', 'Y metric2', 'coefficient', 'percentage', 'rule']

        with open("./Correlation_map/output/probability_correlation_selected_" + str(index) + ".csv", 'w', newline='') as f1:
            # using csv.writer method from CSV package
            write2 = csv.writer(f1)
            write2.writerow(selected_fields)
            write2.writerows(selected_output_list)

