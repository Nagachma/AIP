import pandas as pd
import sys
import logging
import requests
import csv
import yaml
from pymysql import connect as mysql_connect
from pymysql.err import OperationalError as PyMySQLOperationalError
from sqlalchemy import create_engine
from sqlalchemy.exc import OperationalError as SQLAlchemyOperationalError
import warnings
from sys import exit as exit_python
import hvac
from cryptography.fernet import Fernet
warnings.filterwarnings('ignore')

def read_yaml():
    """ A function to read YAML file"""
    with open('/config/config.yml') as f:
        config = yaml.safe_load(f)

    return config

def get_db_connection(vault_url,vault_key):

    client = hvac.Client(
    url=vault_url,
    verify = False,
    token=vault_key,
    )
    db_response = client.secrets.kv.read_secret_version(path='orchestraidb')
    
    return db_response

def create_mysql_connection(username, passwd, hostname, db_name, port_number):
    url = "https://s3.amazonaws.com/rds-downloads/rds-combined-ca-bundle.pem"
    filename = "rds-combined-ca-bundle.pem"
    response = requests.get(url, verify=False)

    with open(filename, "wb") as f:
        f.write(response.content)

    # SSL_CA = os.path.abspath(filename)
    SSL_CA = filename
    print(SSL_CA)
    try:
        cnx = mysql_connect(user=username, password=passwd, host=hostname, database=db_name, port=port_number,
                            autocommit=True,ssl_ca=SSL_CA)
    except PyMySQLOperationalError as err:
        err.errno = err.args[0]
        if err.errno == 1044:
            print("ERROR: Access is denied to the user '" + username + "' on the database called '" + db_name + "'.")
            print("Please validate that said user has the correct level of access.")
            exit_python()
        elif err.errno == 1045:
            print("ERROR: Access is denied to the user '" + username + "' on host '" + hostname + "'.")
            print("Please validate that the username and password are correct.")
            exit_python()
        elif err.errno == 1049:
            print("ERROR: The database called '" + db_name + "'does not exist.")
            print("Please validate that database name is spelled correctly and exists.")
            exit_python()
        elif err.errno == 2003:
            print("ERROR: Unable to connect to host '" + hostname + "' on port '" + str(port_number) + "'.")
            print("Please validate your network connectivity and that the hostname and port is correct.")
            exit_python()
        else:
            print("ERROR: Unhandled MySQL Error.")
            print(err)
            exit_python()
    else:
        return cnx


def create_mysql_engine(username, passwd, hostname, db_name, port_number):
    try:
        ca_path = "rds-combined-ca-bundle.pem"
        ssl_args = {'ssl_ca': ca_path}
        engine = create_engine(url="mysql+pymysql://" + username + ":" + passwd + "@" + hostname + ":" + str(port_number) + "/" + db_name,execution_options={"isolation_level": "AUTOCOMMIT"},connect_args=ssl_args)
        cnx = engine.connect()
    except SQLAlchemyOperationalError as err:
        err.errno = int(err.args[0].split(") (")[1].split(",")[0])
        if err.errno == 1044:
            print("ERROR: Access is denied to the user '" + username + "' on the database called '" + db_name + "'.")
            print("Please validate that said user has the correct level of access.")
            exit_python()
        elif err.errno == 1045:
            print("ERROR: Access is denied to the user '" + username + "' on host '" + hostname + "'.")
            print("Please validate that the username and password are correct.")
            exit_python()
        elif err.errno == 1049:
            print("ERROR: The database called '" + db_name + "'does not exist.")
            print("Please validate that database name is spelled correctly and exists.")
            exit_python()
        elif err.errno == 2003:
            print("ERROR: Unable to connect to host '" + hostname + "' on port '" + str(port_number) + "'.")
            print("Please validate your network connectivity and that the hostname and port is correct.")
            exit_python()
        else:
            print("ERROR: Unhandled MySQL Error.")
            print(err)
            exit_python()
    else:
        cnx.close()
        return engine


def connect_to_mysql(username, passwd, hostname, db_name, port_number):
    cnx = create_mysql_connection(username, passwd, hostname, db_name, port_number)
    engine = create_mysql_engine(username, passwd, hostname, db_name, port_number)
    return cnx, engine

def create_kendall_input(outcome,log_file_name):
    #print('inside kendall input')
    logging.basicConfig(level=logging.INFO, filename=log_file_name,
                        format='%(asctime)s :: %(levelname)s :: %(message)s')

    config = read_yaml()
    vault_url = config['platformops']['vault_url']
    vault_key = config['platformops']['vault_key']
    f = config['platformops']['key']
    f = Fernet(f)
    vault_key = f.decrypt(vault_key.encode()).decode()
    key_url = config['platformops']['key_url']

    db_details = get_db_connection(vault_url,vault_key)

    jdbc_url = db_details['data']['data']['jdbc-url']
    db_username = db_details['data']['data']['username']
    db_passowrd = db_details['data']['data']['password']
    db_host = jdbc_url.split("/")[-2].split(":")[0]
    db_name = jdbc_url.split("/")[-1]

    mysql_cnx, mysql_engine = connect_to_mysql(db_username,db_passowrd,db_host,db_name,3306)
    mysql_cursor = mysql_cnx.cursor()
    logging.info('reading {outcome} data from db'.format(outcome=outcome))

    select_failure = ("SELECT * FROM `metrics_proc_staging_data`where outcome_state = '%s'", (outcome,))
    #print(select_failure)
    kendall_failure_df = pd.read_sql(select_failure, mysql_cnx, index_col='metrics_proc_staging_data_id')
    flag=0
    if kendall_failure_df.empty != True:



        kendall_failure_df.drop(['ser_id_outcome_map_id', 'metric_collection_timestamp', 'outcome_state'], axis=1, inplace=True)

        kendall_failure_df = kendall_failure_df.pivot(index='outcome_temp_index', columns=['correlated_metrics'], values=['correlated_value'])



        kendall_failure_df.columns=kendall_failure_df.columns.droplevel(0)
        kendall_failure_df.columns.name = None
        kendall_failure_df.index.name = None

        kendall_failure_df.reset_index(drop=True,inplace=True)
    else:
        print("no outcomes")
        logging.error("no outcome records from {outcome} ".format(outcome=outcome))
        flag=1
        kendall_failure_df=None
        #sys.exit(1)
    return kendall_failure_df,flag

def truncate_data():
    config = read_yaml()
    vault_url = config['platformops']['vault_url']
    vault_key = config['platformops']['vault_key']
    f = config['platformops']['key']
    f = Fernet(f)
    vault_key = f.decrypt(vault_key.encode()).decode()
    key_url = config['platformops']['key_url']

    db_details = get_db_connection(vault_url,vault_key)

    jdbc_url = db_details['data']['data']['jdbc-url']
    db_username = db_details['data']['data']['username']
    db_passowrd = db_details['data']['data']['password']
    db_host = jdbc_url.split("/")[-2].split(":")[0]
    db_name = jdbc_url.split("/")[-1]

    mysql_cnx, mysql_engine = connect_to_mysql(db_username,db_passowrd,db_host,db_name,3306)
    mysql_cursor = mysql_cnx.cursor()

    delete_Rows = "TRUNCATE `metrics_proc_staging_data`"
    mysql_cursor.execute(delete_Rows)
    return
def concat_df(df1,df2):
    if df1 is None:
        return df2
    if df2 is None:
        return df1
    df = pd.concat([df1, df2], axis=1).reindex(df1.index)
    return df

    # ---------------------------
    # select_slowness = "SELECT * FROM `metrics_proc_staging_data`where outcome_state = 'slowness'"
    # kendall_slowness_df = pd.read_sql(select_slowness, mysql_cnx, index_col='metrics_proc_staging_data_id')
    #
    # kendall_slowness_df.drop(['ser_id_outcome_map_id', 'metric_collection_timestamp', 'outcome_state'], axis=1,
    #                         inplace=True)
    #
    # kendall_slowness_df = kendall_slowness_df.pivot(index='outcome_temp_index', columns=['correlated_metrics'],
    #                                             values=['correlated_value'])
    #
    # kendall_slowness_df.columns = kendall_slowness_df.columns.droplevel(0)
    # kendall_slowness_df.columns.name = None
    # kendall_slowness_df.index.name = None
    #
    # kendall_slowness_df.reset_index(drop=True, inplace=True)

    #kendall_failure_df.to_csv("linear_regression/output/kendall_input_df.csv", index=False)