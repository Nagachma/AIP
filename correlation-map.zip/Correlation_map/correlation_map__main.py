import csv
import argparse, yaml
import pandas as pd
# from write_config import write_thresshold
import re
import json
from datetime import datetime,timedelta
import sys
import requests
import itertools
import time
import os.path
import numpy as np
from os import path
from sys import platform
import multiprocessing
def check_create_folder(path, folder_name):
    folder_path=path+folder_name
    #print(folder_path)
    if not(os.path.exists(folder_path)):
        #print(folder_name,'not present')
        os.makedirs(folder_path)


if __name__ == "__main__":
    folder_list = [ 'input','output','input_correlation']
    print("checking and creating relevant folder")
    for folder in folder_list:
        check_create_folder('Correlation_map/', folder)


    #time.sleep(10)
    print("Loading from the metrics processor....")
    os.system("python ./Correlation_map/read_db_1.py ")
    print("Created RFE input file....")
    os.system("python ./Correlation_map/read_db_2.py ")

    os.system("python ./Correlation_map/pearson_input_v2.py")
    print("Created pearson Input file ...")

    try:
        data = pd.read_csv("./Correlation_map/input_correlation/pearson_input.csv")
        if np.count_nonzero(data) == 0:
            print("No anomaly detected")
            exit()
    except OSError as e:
        print("Unable to open './Correlation_map/input_correlation/pearson_input.csv'")
        exit()

    os.system("python ./Correlation_map/entry.py RFE")
    print("Completed RFE ...")

    # os.system("python ./metric_processor/pearson_input_v2.py "+ timestamp)

    os.system("python ./Correlation_map/entry.py probability_correlation")
    print("Completed Probability correlation ...")

    os.system("python ./Correlation_map/load_table.py correlated_table")


    # os.system("python ./metric_processor/upload_to_mysql_test.py")

    # os.system("python ./metric_processor/datasec_ops.py")

    # os.system("python ./metric_processor/mlops_ingestion.py")