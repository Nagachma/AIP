import yaml
import sys
import pprint
from algorithms.RFE import RFE_model
from algorithms.lasso import lasso_model
from algorithms.PCA import PCA_model
from algorithms.RFR import RFR_model
from algorithms.pearson import pearson_model
from algorithms.kendall import kendall_model
from algorithms.utility import create_kendall_input,concat_df,truncate_data
from algorithms.probability_correlation import probability_correlation
import warnings
import os
from os import scandir as scan_directory
import pandas as pd
import logging
warnings.filterwarnings('ignore')


def check_create_folder(path, folder_name):
    folder_path=path+folder_name
    #print(folder_path)
    if not(os.path.exists(folder_path)):
        #print(folder_name,'not present')
        os.makedirs(folder_path)

def read_yaml():
    """ A function to read YAML file"""
    with open('/config/config.yml') as f:
        config = yaml.safe_load(f)

    return config


def get_input_file_name(servers_name):
    """ Get the input csv file name"""
    my_config=read_yaml()
    if servers_name in my_config:
        return my_config[servers_name]
    else:
        print("Cannot find the server name")
        sys.exit(1)

#def main(args):
#    args_list=args.split(' ')
if __name__ == "__main__":

    # read the config yaml
    my_config = read_yaml()


    # pretty print my_config
    # pprint.pprint(my_config)

    algorithm_name = sys.argv[1]


    folder_list = ['Config', 'input', 'logging', 'output']
    #logging.info('checking and creating folders ')
    for folder in folder_list:
        check_create_folder('Correlation_map/', folder)

    # if algorithm_name != 'pearson' and algorithm_name != 'kendall' and algorithm_name != 'probability_correlation':
    #     #servers_name = args_list[1]
    #     #input_file_name = get_input_file_name(servers_name)
    #     input_file_name = args_list[1]

     #algorithm_name:
    if algorithm_name== 'RFE':


        with scan_directory(path="./Correlation_map/input/") as file_list:


            flag=0
            for file in file_list:
                if "RFE" in str(file):
                    flag=1

                    RFE_model(file.path, my_config["RFE_log_file_name"], my_config["RFE_range_min"],
                             my_config["RFE_range_max"])
            if flag==0:
                print("No Rfe input exiting run")
                exit()
        #try:
        #RFE_model(input_file_name, my_config["RFE_log_file_name"], my_config["RFE_range_min"],
                  #my_config["RFE_range_max"])
        #except Exception as e:
            #sys.exit(1)
    elif algorithm_name=='RFR':
        try:
            RFR_model(input_file_name, my_config["RFR_log_file_name"])
        except Exception as e:
            sys.exit(1)
    elif algorithm_name =='lasso':
        try:
            lasso_model(input_file_name, my_config["lasso_log_file_name"])
        except Exception as e:
            sys.exit(1)
    elif algorithm_name == 'pearson':
        #try:
        pearson_model(my_config["pearson"], my_config["pearson_log_file_name"],
                      my_config["pearson_range_min"],my_config["pearson_range_mid"],
                      my_config["pearson_range_max"])
        #except Exception as e:
         #   sys.exit(1)
    elif algorithm_name == 'kendall':
        #try:
        #print('called kendall')
        failure_df,flag1=create_kendall_input('failure',my_config['kendall_data_fetch_log_file_name'])
        slowness_df,flag2=create_kendall_input('slowness',my_config['kendall_data_fetch_log_file_name'])
        if flag1==1 and flag2==1:
            logging.info("No failure occured")
            print("No slowness/failure occured")
            empty_df = pd.DataFrame()
            empty_df.to_csv(my_config['kendall_output'] + my_config["kendall"])
            selected_file_name = my_config["kendall"].split("_")
            selected_file_name.insert(-1, 'selected')
            selected_file_name = "_".join(selected_file_name)
            empty_df.to_csv(my_config['kendall_output_selected'] + selected_file_name, index=False)

        else:
            kendall_input_df=concat_df(failure_df,slowness_df)
            kendall_model(kendall_input_df,my_config["kendall"], my_config["kendall_log_file_name"],
                          my_config["kendall_range_min"],
                          my_config["kendall_range_max"])
            truncate_data()
        #except Exception as e:
            #sys.exit(1)
    elif algorithm_name == 'probability_correlation':
        #try:
        probability_correlation(my_config["pearson"],my_config["probability_log_file_name"],
                      my_config["probability_range_min"], my_config["probability_range_max"])
        #except Exception as e:
         #   sys.exit(1)
    elif algorithm_name ==  'PCA':
        try:
            PCA_model(input_file_name, my_config["PCA_log_file_name"])
        except Exception as e:
            sys.exit(1)
    else:
        print("Cannot find the algorithm name")
