#####
#
# upload_to_mysql.py is a Python program that processes
# output CSVs containing metrics from various cloud services
# and uploads this data in the correct format to MySQL tables
# used by AIOPS/XOPS
#
# Version 1.3 - 2022/10/20
#
# Written by: Zachary Williams
#
######

from datetime import datetime, timedelta, timezone
from numpy import nan as NaN
from os import scandir as scan_directory
from pandas import DataFrame
from pymysql import connect as mysql_connect
from pymysql.err import OperationalError as PyMySQLOperationalError
from sqlalchemy import create_engine
from sqlalchemy.exc import OperationalError as SQLAlchemyOperationalError
from sys import exit as exit_python
from tabulate import tabulate
import json
import os
import yaml
import sys
import pymysql
import time
import ssl
import requests
import pandas as pd
import re
import hvac
from cryptography.fernet import Fernet


##################################################
#
#	name: 	create_mysql_connection
# 	desc:	function that creates a PyMySQL connection object.
#			Connection is used to create a cursor object that can be
#			called to execute arbitary SQL code on a MySQL database.
#	args:
#			username	- username of user in MySQL
#			passwd		- password of user in MySQL
#			hostname	- hostname of the MySQL Server
#			db_name		- database name in the MySQL Server
#			port_number	- port number of the MySQL Server
#	returns:
#			cnx			- A PyMySQL Connection object
#
#################################################
def create_mysql_connection(username, passwd, hostname, db_name, port_number):
    url = "https://s3.amazonaws.com/rds-downloads/rds-combined-ca-bundle.pem"
    filename = "rds-combined-ca-bundle.pem"
    response = requests.get(url, verify=False)

    with open(filename, "wb") as f:
        f.write(response.content)

    # SSL_CA = os.path.abspath(filename)
    SSL_CA = filename
    print(SSL_CA)
    try:
        cnx = mysql_connect(user=username, password=passwd, host=hostname, database=db_name, port=port_number,
                            autocommit=True, ssl_ca=SSL_CA)
    except PyMySQLOperationalError as err:
        err.errno = err.args[0]
        if err.errno == 1044:
            print("ERROR: Access is denied to the user '" + username + "' on the database called '" + db_name + "'.")
            print("Please validate that said user has the correct level of access.")
            exit_python()
        elif err.errno == 1045:
            print("ERROR: Access is denied to the user '" + username + "' on host '" + hostname + "'.")
            print("Please validate that the username and password are correct.")
            exit_python()
        elif err.errno == 1049:
            print("ERROR: The database called '" + db_name + "'does not exist.")
            print("Please validate that database name is spelled correctly and exists.")
            exit_python()
        elif err.errno == 2003:
            print("ERROR: Unable to connect to host '" + hostname + "' on port '" + str(port_number) + "'.")
            print("Please validate your network connectivity and that the hostname and port is correct.")
            exit_python()
        else:
            print("ERROR: Unhandled MySQL Error.")
            print(err)
            exit_python()
    else:
        return cnx


##################################################
#
#	name: 	create_mysql_engine
# 	desc:	function that creates a SQLAlchemy connection engine object.
#			The engine is used by pandas DataFrame's to_sql function
#			to insert DataFrames into MySQL tables.
#	args:
#			username	- username of user in MySQL
#			passwd		- password of user in MySQL
#			hostname	- hostname of the MySQL Server
#			db_name		- database name in the MySQL Server
#			port_number	- port number of the MySQL Server
#	returns:
#			engine		- A SQLAlchemy Engine object
#
#################################################
def create_mysql_engine(username, passwd, hostname, db_name, port_number):
    try:
        ca_path = "rds-combined-ca-bundle.pem"
        ssl_args = {'ssl_ca': ca_path}
        engine = create_engine(
            url="mysql+pymysql://" + username + ":" + passwd + "@" + hostname + ":" + str(port_number) + "/" + db_name,
            execution_options={"isolation_level": "AUTOCOMMIT"}, connect_args=ssl_args)
        cnx = engine.connect()
    except SQLAlchemyOperationalError as err:
        err.errno = int(err.args[0].split(") (")[1].split(",")[0])
        if err.errno == 1044:
            print("ERROR: Access is denied to the user '" + username + "' on the database called '" + db_name + "'.")
            print("Please validate that said user has the correct level of access.")
            exit_python()
        elif err.errno == 1045:
            print("ERROR: Access is denied to the user '" + username + "' on host '" + hostname + "'.")
            print("Please validate that the username and password are correct.")
            exit_python()
        elif err.errno == 1049:
            print("ERROR: The database called '" + db_name + "'does not exist.")
            print("Please validate that database name is spelled correctly and exists.")
            exit_python()
        elif err.errno == 2003:
            print("ERROR: Unable to connect to host '" + hostname + "' on port '" + str(port_number) + "'.")
            print("Please validate your network connectivity and that the hostname and port is correct.")
            exit_python()
        else:
            print("ERROR: Unhandled MySQL Error.")
            print(err)
            exit_python()
    else:
        cnx.close()
        return engine


def connect_to_mysql(username, passwd, hostname, db_name, port_number):
    cnx = create_mysql_connection(username, passwd, hostname, db_name, port_number)
    engine = create_mysql_engine(username, passwd, hostname, db_name, port_number)
    return cnx, engine

def get_db_connection(vault_url,vault_key):

    client = hvac.Client(
    url=vault_url,
    verify = False,
    token=vault_key,
    )
    db_response = client.secrets.kv.read_secret_version(path='orchestraidb')
    
    return db_response

def show_table_columns(mysql_cursor, table):
    mysql_cursor.execute("show columns from %s;", (table, ))
    print(tabulate(mysql_cursor.fetchall(), headers=("Field", "Type", "Null", "Key", "Default", "Extra"),
                   tablefmt="psql"))


def show_all_tables_columns(mysql_cursor):
    mysql_cursor.execute("show tables;")
    for table in mysql_cursor.fetchall():
        table = table[0]
        print("\n" + table)
        show_table_columns(mysql_cursor, table)


def get_table_column_names(mysql_cursor, table):
    mysql_cursor.execute("show columns from %s;", (table, ))
    return [item[0] for item in mysql_cursor.fetchall()]


def select_table_firstrow(mysql_cursor, table):
    column_names = get_table_column_names(mysql_cursor, table)
    mysql_cursor.execute("select * from %s limit 1", (table, ))
    data = mysql_cursor.fetchall()
    print(tabulate(data, headers=column_names, tablefmt="psql"))


def select_all_tables_firstrow(mysql_cursor):
    mysql_cursor.execute("show tables;")
    for table in mysql_cursor.fetchall():
        table = table[0]
        print("\n" + table)
        select_table_firstrow(mysql_cursor, table)


def drop_table_data(mysql_cursor, table):
    mysql_cursor.execute("SET FOREIGN_KEY_CHECKS=0")
    mysql_cursor.execute("TRUNCATE TABLE %s;", (table, ))
    mysql_cursor.execute("SET FOREIGN_KEY_CHECKS=1")


def drop_all_table_data(mysql_cursor):
    print("Dropping ALL data from ALL tables...")
    mysql_cursor.execute("show tables;")
    for table in mysql_cursor.fetchall():
        table = table[0]
        drop_table_data(mysql_cursor, table)
        print("Successfully dropped ALL data from: '" + table + "'.")


def isNaN(variable):
    return variable != variable


def process_correlation_csvs():
    correlation_csv_files = []
    with scan_directory(path="./Correlation_map/output/") as file_list:
        for file in file_list:
            if file.is_file() and file.name.endswith(".csv"):
                correlation_csv_files.append(file.path)

    print(correlation_csv_files)

    pearson_csv_dict = {}
    rfe_csv_dict = {}
    for csv_path in correlation_csv_files:
        csv_file = csv_path.split("/")[-1].split(".csv")[0]
        correlation = csv_file.split("_")[0]
        if correlation == "RFE":
            service = csv_file.split("_")[1]
            if csv_file.split("_")[2] != "selected" and not csv_file.split("_")[2].isnumeric():
                service += "_" + csv_file.split("_")[2]
                if csv_file.split("_")[2] == "selected":
                    selected = True
                elif csv_file.split("_")[3].isnumeric():
                    selected = False
            elif csv_file.split("_")[2] == "selected":
                selected = True
            elif csv_file.split("_")[2].isnumeric():
                selected = False

            if service not in rfe_csv_dict.keys():
                rfe_csv_dict[service] = {}
            fp = open(csv_path, "r")
            index = 0
            for line in fp.readlines():
                if index == 0:
                    index += 1
                else:
                    line = line.strip().split(",")
                    metric = line[1]
                    if metric not in rfe_csv_dict[service].keys():
                        if not selected:
                            rfe_csv_dict[service][metric] = [line[0], (float(line[2])), 0]
                        else:
                            rfe_csv_dict[service][metric] = [line[0], (float(line[2])), 1]
                    else:
                        if selected:
                            if rfe_csv_dict[service][metric][0] == line[0]:
                                rfe_csv_dict[service][metric][2] = 1
                            else:
                                metric = metric + "*metric2"
                                rfe_csv_dict[service][metric] = [line[0], (float(line[2])), 1]
                        else:
                            if rfe_csv_dict[service][metric][0] != line[0]:
                                metric = metric + "*metric2"
                                rfe_csv_dict[service][metric] = [line[0], (float(line[2])), 0]
            fp.close()
        elif correlation == "probability":
            if csv_file.split("_")[2] == "selected":
                selected = True
            else:
                selected = False

            if not selected:
                fp = open(csv_path, "r")
                index = 0
                for line in fp.readlines():
                    if index == 0:
                        headers = line.strip().split(",")[1:]
                        print(headers)
                        for header in headers:
                            if header not in pearson_csv_dict.keys():
                                pearson_csv_dict[header] = {}
                        index += 1
                    else:
                        line = line.strip().split(",")
                        metric = line[0]
                        line = line[1:]
                        for i in range(len(line)):
                            if headers[i] not in pearson_csv_dict[metric].keys():
                                try:
                                    pearson_csv_dict[metric][headers[i]] = [float(line[i]), 0, 'Not Selected', 0]

                                except ValueError:
                                    pearson_csv_dict[metric][headers[i]] = [0.0, 0, 'Not Selected', 0]
                fp.close()
            else:
                fp = open(csv_path, "r")
                index = 0
                for line in fp.readlines():
                    if index == 0:
                        index += 1
                    else:
                        line = line.strip().split(",")
                        metric = line[0]
                        if metric not in pearson_csv_dict.keys():
                            pearson_csv_dict[metric] = {line[1]: [float(line[2]), 1]}
                        else:
                            pearson_csv_dict[metric][line[1]][1] = 1
                            pearson_csv_dict[metric][line[1]][2] = line[4]
                            pearson_csv_dict[metric][line[1]][3] = line[3]
                fp.close()

    print(rfe_csv_dict)
    return rfe_csv_dict, pearson_csv_dict


def write_rfe_to_mysql(rfe_csv_dict, time_window_id, mysql_engine, mysql_cursor, correlated_metric_list, config):
    # NEED TO UPDATE THE x_job_details_id and y_job_details_id COLUMNS
    rfe_df_data = {"execution_id": [], "time_window_id": [], "service_id": [], "correlation_y_metric_id": [], "correlation_x_metric_id": [],
                   "outcome_metric": [], "coefficient_value": [], "coefficient_flag": []}
    for key in rfe_csv_dict.keys():
        service_name = key.split("_")[0].lower()
        # service_name = config[service_name]['alias']
        # if service_name == "sm":
        #     service_name = "sagemaker"
        # elif service_name == "aurora":
        #     service_name = "Amazon Aurora PostgreSQL"
        param_service_name = f"%{service_name.lower()}%"
        query = "SELECT service_id FROM services WHERE LOWER(service_name) LIKE %s "
        mysql_cursor.execute(query, (param_service_name, ))
        service_id = mysql_cursor.fetchall()
        if len(service_id) > 0:
            service_id = service_id[0][0]
        else:
            service_id = NaN
        for subkey in rfe_csv_dict[key].keys():
            # try:

            y_metric = rfe_csv_dict[key][subkey][0]
            correlation_y_metric = '_'.join(y_metric.split('_')[2:-1])
            #correlation_y_metric = y_metric.split("_")[2].lower()
            # if correlation_y_metric == "query":
            #     correlation_y_metric = "query_total_time"
            # elif correlation_y_metric == "load":
            #     correlation_y_metric = "load_time"
            # elif correlation_y_metric == "total":
            #     correlation_y_metric = "total_elapsed_time"
            # elif correlation_y_metric == "duration":
            #     correlation_y_metric = "DURATION_IN_SECONDS"
            # elif correlation_y_metric == "workflow":
            #     correlation_y_metric = "Workflow_Status"
            print("-----------")
            print(subkey)
            print(correlation_y_metric)
            print("-----------")
            try:
                if "*metric2" in subkey:
                    decode_subkey = subkey.split("*")[0]
                    query1 = "select metric_id from metrics where metric_name = %s and service_id =  %s "
                    mysql_cursor.execute(query1, (decode_subkey, str(service_id)))
                else:
                    query2 = "select metric_id from metrics where metric_name = %s and service_id =  %s "
                    mysql_cursor.execute(query2, (subkey, str(service_id)))
                get_correlation_x_metric_id = mysql_cursor.fetchone()[0]
                # correlation_y_metric = rfe_csv_dict[key][subkey][0]
                query3 = "select metric_id from metrics where metric_name = %s and service_id =  %s "
                mysql_cursor.execute(query3, (correlation_y_metric, str(service_id)))
                get_correlation_y_metric_id = mysql_cursor.fetchone()[0]
            except:
                print("inside Except")
                continue
            query4 = "select outcome_metric_name from service_to_outcome_metric_mapping where correlated_metric_id = %s"
            mysql_cursor.execute(query4, (str(get_correlation_y_metric_id), ))
            outcome_met = mysql_cursor.fetchone()[0]

            rfe_df_data["execution_id"].append('')
            rfe_df_data["time_window_id"].append(time_window_id)
            rfe_df_data["service_id"].append(service_id)
            rfe_df_data["outcome_metric"].append(outcome_met)
            rfe_df_data["correlation_y_metric_id"].append(get_correlation_y_metric_id)
            rfe_df_data["correlation_x_metric_id"].append(get_correlation_x_metric_id)
            rfe_df_data["coefficient_value"].append(rfe_csv_dict[key][subkey][1])
            rfe_df_data["coefficient_flag"].append(rfe_csv_dict[key][subkey][2])
            # except TypeError:
            #     continue

    print(tabulate(rfe_df_data, headers=rfe_df_data.keys(), tablefmt="psql"))

    df = DataFrame(rfe_df_data)
    if len(correlated_metric_list) != 0:
        df = df[df['correlation_y_metric_id'].isin(correlated_metric_list)]
    # print (df)
    df.to_sql(name="causal_metrics",con=mysql_engine,if_exists="append",index=False,method="multi")


def write_pearson_to_mysql(pearson_csv_dict, time_window_id, mysql_engine):
    raw_metric_id = 1
    pearson_df_data = {"execution_id": [], 'time_window_id': [], "service_id": [], "rule_name": [], "correlation_metric_id": [],
                       "outcome_metric_id": [], "value": [], "stickiness_flag": []}
    for key in pearson_csv_dict.keys():
        for subkey in pearson_csv_dict[key].keys():
            #correlation_y_metric = subkey.split("_")[2].lower()
            #correlation_x_metric = key.split("_")[2].lower()
            correlation_y_metric = '_'.join(subkey.split('_')[2:])
            correlation_x_metric = '_'.join(key.split('_')[2:])
            # if correlation_y_metric == "query":
            #     correlation_y_metric = "query_total_time"
            # elif correlation_y_metric == "load":
            #     correlation_y_metric = "load_time"
            # elif correlation_y_metric == "total":
            #     correlation_y_metric = "total_elapsed_time"
            # elif correlation_y_metric == "duration":
            #     correlation_y_metric = "DURATION_IN_SECONDS"
            # elif correlation_y_metric == "workflow":
            #     correlation_y_metric = "Workflow_Status"
            #
            # if correlation_x_metric == "query":
            #     correlation_x_metric = "query_total_time"
            # elif correlation_x_metric == "load":
            #     correlation_x_metric = "load_time"
            # elif correlation_x_metric == "total":
            #     correlation_x_metric = "total_elapsed_time"
            # elif correlation_x_metric == "duration":
            #     correlation_x_metric = "DURATION_IN_SECONDS"
            # elif correlation_x_metric == "workflow":
            #     correlation_x_metric = "Workflow_Status"

            service_name = key.split("_")[0].lower()

            subkey_service_name = subkey.split("_")[0].lower()
            query = "select service_id from services where service_name = %s "
            mysql_cursor.execute(query, (str(service_name), ))
            service_id = mysql_cursor.fetchone()[0]
            query1 = "select service_id from services where service_name = %s "
            mysql_cursor.execute(query1, (str(subkey_service_name), ))
            subkey_service_id = mysql_cursor.fetchone()[0]

            query2 = "select metric_id from metrics where metric_name = %s and service_id = %s "
            mysql_cursor.execute(query2, (correlation_y_metric, str(subkey_service_id)))
            outcome_metric_id = mysql_cursor.fetchone()[0]
            query3 = "select metric_id from metrics where metric_name = %s and service_id = %s "
            mysql_cursor.execute(query3, (correlation_x_metric, str(service_id)))
            correlation_metric_id = mysql_cursor.fetchone()[0]

            pearson_df_data["execution_id"].append('')
            pearson_df_data['time_window_id'].append(time_window_id)
            # pearson_df_data["raw_metric_id"].append(raw_metric_id)
            # pearson_df_data["y_job_details_id"].append(y_job_details_id)
            pearson_df_data["rule_name"].append(pearson_csv_dict[key][subkey][2])
            # pearson_df_data["rule_name"].append(pearson_csv_dict[key][subkey][3])
            pearson_df_data["service_id"].append(service_id)
            pearson_df_data["correlation_metric_id"].append(correlation_metric_id)
            pearson_df_data["outcome_metric_id"].append(outcome_metric_id)
            pearson_df_data["value"].append(pearson_csv_dict[key][subkey][0])
            pearson_df_data["stickiness_flag"].append(pearson_csv_dict[key][subkey][1])
            raw_metric_id = raw_metric_id + 1

    print(tabulate(pearson_df_data, headers=pearson_df_data.keys(), tablefmt="psql"))

    df = DataFrame(pearson_df_data)
    all_zero_stickiness_flag = 0
    if df.empty:
        print('pearson DataFrame is empty!')
        correlated_metric_list = []
        all_zero_stickiness_flag = 1
        return correlated_metric_list, all_zero_stickiness_flag
    else:
        if (df['stickiness_flag'] == 0).all():
            all_zero_stickiness_flag = 1
        correlated_metric_list = list(set(df['correlation_metric_id'].tolist()))
        print('Active outcome metrics in the current execution id:', str(correlated_metric_list))
        # return correlated_metric_list
        # print (df)
        df.to_sql(name="correlated_metrics",con=mysql_engine,if_exists="append",index=False,method="multi")
        return correlated_metric_list, all_zero_stickiness_flag


def read_yaml(filename):
    """ A function to read YAML file"""
    with open(filename) as f:
        config = yaml.safe_load(f)

    return config


def get_outcome_metric(service_name):
    config = read_yaml('/config/config.yml')
    service_name = config[service_name]['alias']
    vault_url = config['platformops']['vault_url']
    vault_key = config['platformops']['vault_key']
    f = config['platformops']['key']
    f = Fernet(f)
    vault_key = f.decrypt(vault_key.encode()).decode()
    key_url = config['platformops']['key_url']

    db_details = get_db_connection(vault_url,vault_key)

    jdbc_url = db_details['data']['data']['jdbc-url']
    db_username = db_details['data']['data']['username']
    db_passowrd = db_details['data']['data']['password']
    db_host = jdbc_url.split("/")[-2].split(":")[0]
    db_name = jdbc_url.split("/")[-1]

    mysql_cnx, mysql_engine = connect_to_mysql(db_username,db_passowrd,db_host,db_name,3306)
    mysql_cursor = mysql_cnx.cursor()
    outcome_metrics = {}
    query = "select service_id from services where service_name = %s "
    mysql_cursor.execute(query, (str(service_name), ))
    service_id = mysql_cursor.fetchone()[0]
    query1 = "select metric_name from metrics where metric_id = (select correlated_metric_id from service_to_outcome_metric_mapping where service_id = %s and outcome_metric_name = 'slowness')"
    mysql_cursor.execute(query1, (str(service_id), ))
    slowness_metric_names_all = mysql_cursor.fetchall()
    if len(slowness_metric_names_all) > 0:
        slowness = slowness_metric_names_all[0][0]
    else:
        slowness = None

    query2 = "select metric_name from metrics where metric_id = (select correlated_metric_id from service_to_outcome_metric_mapping where service_id = %s and outcome_metric_name = 'failure')"
    mysql_cursor.execute(query2, (str(service_id), ))
    failure_metric_names_all = mysql_cursor.fetchall()
    if len(failure_metric_names_all) > 0:
        failure = failure_metric_names_all[0][0]
    else:
        failure = None

    outcome_metrics['slowness'] = slowness
    outcome_metrics['failure'] = failure

    return outcome_metrics


def process_metric_csvs(file, config, mysql_cursor):
    metric_csv_files = []
    # with scan_directory(path="./metric_processor/temp/") as file_list:
    #     for file in file_list:
    #         if file.is_file() and file.name.endswith(".csv"):
    #             metric_csv_files.append(file.path)

    metric_csv_files.append(file)
    metric_csv_dict = {}
    for csv_file in metric_csv_files:
        print(csv_file)
        csv = csv_file.split("/")[-1].split(".csv")[0].split("_")[0]
        outcome_metrics = get_outcome_metric(csv)
        job_name = config[csv]["JobName"]
        run_id = config[csv]["RunId"]
        slowness = outcome_metrics['slowness']
        failure = outcome_metrics['failure']
        if csv not in metric_csv_dict.keys():
            metric_csv_dict[csv] = {"column_index": []}
        else:
            continue
        fp = open(csv_file, "r", encoding='utf-8-sig')
        index = 0
        for line in fp.readlines():
            if index == 0:
                missing_completed = False
                for column in line.strip().split(","):
                    if column not in metric_csv_dict[csv]["column_index"]:
                        if column == "timestamp":
                            column = "MetricDate"
                        elif column == job_name:
                            column = "JobName"
                        elif column == run_id:
                            column = "run_id"
                        elif column == slowness:
                            column = "slowness"
                        elif column == failure:
                            column = "failure"
                        elif column == "start_time":
                            column = "StartedOn"
                        elif column == "start_time_Flag":
                            column = "StartedOn_Flag"
                        elif column == "end_time":
                            column = "CompletedOn"
                        elif column == "end_time_Flag":
                            column = "CompletedOn_Flag"
                        elif column == "start_on":
                            column = "StartedOn"
                        elif column == "start_on_Flag":
                            column = "StartedOn_Flag"
                        elif column == "completed_on":
                            column = "CompletedOn"
                        elif column == "completed_on_Flag":
                            column = "CompletedOn_Flag"

                            missing_completed = True
                        metric_csv_dict[csv]["column_index"].append(column)
                        metric_csv_dict[csv][column] = []
                if missing_completed:
                    metric_csv_dict[csv]["column_index"].append("CompletedOn")
                    metric_csv_dict[csv]["CompletedOn"] = []
                if "slowness" not in metric_csv_dict[csv].keys():
                    metric_csv_dict[csv]["column_index"].append("slowness")
                    metric_csv_dict[csv]["slowness"] = []
                if "run_id" not in metric_csv_dict[csv].keys():
                    metric_csv_dict[csv]["column_index"].append("run_id")
                    metric_csv_dict[csv]["run_id"] = []
                index += 1
            else:
                cells = line.strip().split(",")
                for i in range(len(cells)):
                    # convert columns to correct timestamp format that MySQL understands
                    if metric_csv_dict[csv]["column_index"][i] in ["StartedOn", "CompletedOn", "MetricDate",
                                                                   "eventTime", "Interval", "LastModifiedOn"]:
                        if "/" in cells[i]:
                            cells[i] = datetime.strptime(cells[i], "%m/%d/%Y %H:%M").strftime("%Y-%m-%d %H:%M:%S")
                        elif "+" in cells[i] and cells[i].replace("+", "").isnumeric():
                            cells[i] = datetime.utcfromtimestamp(float(cells[i].replace("+", "")) / 1000.0).strftime(
                                "%Y-%m-%d %H:%M:%S")
                        elif cells[i].isnumeric():
                            cells[i] = datetime.utcfromtimestamp(float(cells[i]) / 1000.0).strftime("%Y-%m-%d %H:%M:%S")
                        elif "+" in cells[i]:
                            cells[i] = cells[i].split("+")[0]
                        elif "." in cells[i]:
                            cells[i] = cells[i].split(".")[0]
                        elif cells[i].strip() != "" and cells[i].split("-")[0].isnumeric() and len(
                                cells[i].split("-")[0]) == 4:
                            pass
                        elif cells[i].strip() != "":
                            print(cells)
                            print(i)
                            try:
                                cells[i] = datetime.strptime(cells[i], "%m-%d-%Y %H:%M:%S").strftime(
                                    "%Y-%m-%d %H:%M:%S")
                            except:
                                cells[i] = NaN
                        else:
                            cells[i] = NaN
                    # convert empty values to numpy NaN, which MySQL reads as NONE
                    elif cells[i].strip() == "":
                        cells[i] = NaN
                    metric_csv_dict[csv][metric_csv_dict[csv]["column_index"][i]].append(cells[i])
                if len(cells) < len(metric_csv_dict[csv]["column_index"]):
                    try:
                        if len(metric_csv_dict[csv]["CompletedOn"]) < len(metric_csv_dict[csv]["slowness"]):
                            metric_csv_dict[csv]["CompletedOn"].append((datetime.strptime(
                                metric_csv_dict[csv]["StartedOn"][-1], "%Y-%m-%d %H:%M:%S") + timedelta(
                                milliseconds=int(float(metric_csv_dict[csv]["slowness"][-1])))).strftime(
                                "%Y-%m-%d %H:%M:%S"))
                            cells.append(0)
                        elif len(metric_csv_dict[csv]["CompletedOn"]) > len(metric_csv_dict[csv]["slowness"]):
                            metric_csv_dict[csv]["slowness"].append(int((datetime.strptime(
                                metric_csv_dict[csv]["CompletedOn"][-1], "%Y-%m-%d %H:%M:%S") - datetime.strptime(
                                metric_csv_dict[csv]["StartedOn"][-1], "%Y-%m-%d %H:%M:%S")).total_seconds()))
                            cells.append(0)
                    except KeyError:
                        continue
                if len(cells) < len(metric_csv_dict[csv]["column_index"]):
                    metric_csv_dict[csv]["run_id"].append(
                        metric_csv_dict[csv]["JobName"][-1] + "_" + metric_csv_dict[csv]["StartedOn"][-1])

        fp.close()

    for key in metric_csv_dict.keys():
        for subkey in sorted(metric_csv_dict[key].keys()):
            if subkey == "column_index":
                del metric_csv_dict[key][subkey]

    return metric_csv_dict


def fetch_service_info_from_mysql(metric_csv_dict, mysql_cursor, environment_id):
    group = 0
    mysql_cursor.execute("select max(inventory_scan_group * 1) from inventory_scans")
    scan_group = mysql_cursor.fetchone()[0]
    scan_group = int(scan_group) + 1
    for key in metric_csv_dict.keys():
        service_name = key.lower()
        service_name = config[service_name]['alias']
        # if service_name == "sm":
        #     service_name = "sagemaker"
        # if service_name == "aurora":
        #     service_name = "Amazon Aurora PostgreSQL"

        param_service_name = f"%{service_name.lower()}%"
        query = "SELECT service_id FROM services WHERE LOWER(service_name) LIKE %s "
        mysql_cursor.execute(query, (param_service_name, ))
        service_id = mysql_cursor.fetchall()
        if len(service_id) > 0:
            service_id = int(service_id[0][0])
        else:
            ## add service to services table if it doesn't exist??
            service_id = NaN

        if not isNaN(service_id):
            ### THIS WILL EVENTUALLY NEED environment_id AS WELL
            print("select service_onboard_id from service_onboarded where service_id=" + str(
                service_id) + " and environment_id = " + str(environment_id))
            query1 = "select service_onboard_id from service_onboarded where service_id= %s and environment_id = %s "
            mysql_cursor.execute(query1, (str(service_id), str(environment_id)))
            service_onboard_id = mysql_cursor.fetchall()
            if len(service_onboard_id) > 0:
                service_onboard_id = int(service_onboard_id[0][0])
            else:
                service_onboard_id = NaN
        else:
            service_onboard_id = NaN

        # print(metric_csv_dict[key].keys())

        metric_csv_dict[key]["service_id"] = service_id
        metric_csv_dict[key]["service_onboard_id"] = service_onboard_id
        metric_csv_dict[key]["inventory_id"] = []

        for i in range(len(metric_csv_dict[key]["MetricDate"])):
            if isNaN(metric_csv_dict[key]["run_id"][i]):
                metric_csv_dict[key]["run_id"][i] = metric_csv_dict[key]["JobName"][i] + "_" + str(
                    metric_csv_dict[key]["StartedOn"][i])

            # print ("select inventory_id from inventory where inventory_name='" + metric_csv_dict[key]["JobName"][i] + "' and service_onboard_id=" + str(metric_csv_dict[key]["service_onboard_id"]))
            query2 = "select inventory_id from inventory where inventory_name= %s and service_onboard_id= %s "
            mysql_cursor.execute(query2, (metric_csv_dict[key]["JobName"][i], str(metric_csv_dict[key]["service_onboard_id"])))
            inventory_id = mysql_cursor.fetchall()
            if len(inventory_id) > 0:
                inventory_id = int(inventory_id[0][0])
            else:
                ### THIS WILL EVENTUALLY NEED environment_id AS WELL
                # inventory_id = 119
                if group == 0:
                    start_time = datetime.now(timezone.utc)
                    query3 = "insert into inventory_scans (inventory_scan_group,environment_id,service_id,inventory_scan_started,inventory_scan_ended,is_completed,inserted_by) values ( %s, %s, %s, %s, %s,0,'Metrics Processer Python Code')"
                    mysql_cursor.execute(query3, (str(scan_group), str(environment_id), str(metric_csv_dict[key]["service_id"]), start_time.strftime(
                            "%Y-%m-%d %H:%M:%S"), start_time.strftime("%Y-%m-%d %H:%M:%S")))
                    mysql_cursor.execute("select max(inventory_scan_id) from inventory_scans")
                    inventory_scan_id = int(mysql_cursor.fetchone()[0])
                    group = 1
                query4 = "insert into inventory (service_onboard_id,service_id,environment_id,inventory_name,is_active,inserted_by) values ( %s, %s, %s, %s,1,'Metrics Processer Python Code')"
                mysql_cursor.execute(query4, (str(metric_csv_dict[key]["service_onboard_id"]), str(metric_csv_dict[key]["service_id"]), str(environment_id), metric_csv_dict[key]["JobName"][i]))
                mysql_cursor.execute("select max(inventory_id) from inventory")
                inventory_id = int(mysql_cursor.fetchone()[0])
                # mysql_cursor.execute("insert into inventory_categories (inventory_id,category_id,is_active,inserted_by) values ( " + str(inventory_id) + ", 3, 1, 'Metrics Processor Upload to MySQL Python Code')")
                query5 = "insert into inventory_scan_details (inventory_scan_id,inventory_id,inserted_by) values ( %s, %s,'Metrics Processer Python Code')"
                mysql_cursor.execute(query5, (str(inventory_scan_id), str(inventory_id)))
            metric_csv_dict[key]["inventory_id"].append(inventory_id)

    end_time = datetime.now(timezone.utc)
    # mysql_cursor.execute ("update inventory_scans set is_completed = 1,inventory_scan_ended = '"+ end_time.strftime("%Y-%m-%d %H:%M:%S") +"' where inventory_scan_group = "+str(scan_group))


def update_rfe_dict(rfe_csv_dict):
    flag = False
    for i in rfe_csv_dict.values():
        # print (i))
        for j in i.values():
            if j[2] != 0.0:
                flag = True
        if flag == False:
            for j in i.values():
                j[2] = 2
    # print (rfe_csv_dict)
    return (rfe_csv_dict)


def write_job_metrics_to_mysql(metric_csv_dict, execution_id, mysql_engine):
    jobdetails_df_data = {"service_onboard_id": [], "job_name": [], "run_id": [], "execution_id": [],
                          "job_start_timestamp": [], "job_end_timestamp": [], "anomaly_failure": [],
                          "metric_timestamp": [], "inserted_by": []}
    for key in metric_csv_dict.keys():
        for i in range(len(metric_csv_dict[key]["MetricDate"])):
            jobdetails_df_data["service_onboard_id"].append(metric_csv_dict[key]["service_onboard_id"])
            jobdetails_df_data["job_name"].append(metric_csv_dict[key]["JobName"][i])
            jobdetails_df_data["run_id"].append(metric_csv_dict[key]["run_id"][i])
            jobdetails_df_data["execution_id"].append(execution_id)
            if "StartedOn" in metric_csv_dict[key].keys():
                jobdetails_df_data["job_start_timestamp"].append(metric_csv_dict[key]["StartedOn"][i])
            else:
                jobdetails_df_data["job_start_timestamp"].append(NaN)

            if "CompletedOn" in metric_csv_dict[key].keys():
                jobdetails_df_data["job_end_timestamp"].append(metric_csv_dict[key]["CompletedOn"][i])
            else:
                jobdetails_df_data["job_end_timestamp"].append(NaN)

            jobdetails_df_data["metric_timestamp"].append(metric_csv_dict[key]["MetricDate"][i])
            jobdetails_df_data["inserted_by"].append("Metrics Processer Python Code")
            if "failure" in metric_csv_dict[key].keys():
                # print (metric_csv_dict[key]["failure"][i])
                if (metric_csv_dict[key]["failure"][i] == "SUCCEEDED" or metric_csv_dict[key]["failure"][
                    i] == "Successful" or metric_csv_dict[key]["failure"][i] == '0.0' or
                        metric_csv_dict[key]["failure"][i] == '0' or metric_csv_dict[key]["failure"][i] == None or
                        metric_csv_dict[key]["failure"][i] == -1 or metric_csv_dict[key]["failure"][i] == 0.0 or
                        metric_csv_dict[key]["failure"][i] == 0 or isNaN(metric_csv_dict[key]["failure"][i])):
                    jobdetails_df_data["anomaly_failure"].append(0)
                else:
                    jobdetails_df_data["anomaly_failure"].append(1)
            else:
                jobdetails_df_data["anomaly_failure"].append(0)

    print(tabulate(jobdetails_df_data, headers=jobdetails_df_data.keys(), tablefmt="psql"))

    df = DataFrame(jobdetails_df_data)
    # df.to_sql(name="servicewise_job_details",con=mysql_engine,if_exists="append",index=False,method="multi")


def write_record_metrics_to_mysql(metric_csv_dict, execution_id, mysql_engine, mysql_cursor):
    metrics_df_data = {"job_details_id": [], "metric_id": [], "raw_value": [], "metric_timestamp": [],
                       "inventory_id": []}
    metrics_varchar_df_data = {"job_details_id": [], "metric_id": [], "raw_text": [], "metric_timestamp": [],
                               "inventory_id": []}

    for key in metric_csv_dict.keys():
        # print (len(metric_csv_dict[key]["MetricDate"]))
        for i in range(len(metric_csv_dict[key]["MetricDate"])):
            # print ("select job_details_id from servicewise_job_details where run_id='" + metric_csv_dict[key]["run_id"][i] + "' and metric_timestamp='" + metric_csv_dict[key]["MetricDate"][i] + "' and execution_id=" + str(execution_id))
            query = "select job_details_id from servicewise_job_details where run_id= %s and metric_timestamp= %s "
            mysql_cursor.execute(query, (metric_csv_dict[key]["run_id"][i], metric_csv_dict[key]["MetricDate"][i]))
            job_id = mysql_cursor.fetchone()[0]

            for subkey in metric_csv_dict[key].keys():
                if subkey != "service_id" and subkey != "service_onboard_id" and subkey != "inventory_id" and subkey != "JobName" and subkey != "run_id" and subkey != "MetricDate" and subkey != "StartedOn" and subkey != "CompletedOn":
                    # print (key +"----------" +subkey+"---------"+str())
                    # print ("--------------------")
                    # if not isNaN(metric_csv_dict[key][subkey][i]):
                    # print (subkey)
                    flag = subkey.split("_")[-1] == "Flag"
                    if not flag:
                        # flag_subkey = [ky for ky in metric_csv_dict[key].keys() if ky.endswith(subkey + "_Flag")]
                        # if len(flag_subkey) > 0:
                        #     flag_subkey = flag_subkey[0]

                        query1 = "select metric_id from metrics where metric_name= %s and service_id =  %s"
                        mysql_cursor.execute(query1, (subkey, str(metric_csv_dict[key]["service_id"])))
                        metric_id = mysql_cursor.fetchall()
                        if len(metric_id) > 0:
                            metric_id = metric_id[0][0]
                        else:
                            # print (subkey)
                            query2 = "insert into metrics (service_id,metric_name,inserted_by,metric_incoming_source) values ( %s, %s,'Metrics_processor','Appops') "
                            mysql_cursor.execute(query2, (str(metric_csv_dict[key]["service_id"]), subkey))
                            query3 = "select metric_id from metrics where metric_name= %s and service_id = %s "
                            mysql_cursor.execute(query3, (subkey, str(metric_csv_dict[key]["service_id"])))
                            metric_id = mysql_cursor.fetchone()[0]

                        try:
                            # print (metric_csv_dict[key][subkey][i])
                            if isNaN(metric_csv_dict[key][subkey][i]):
                                float_metric = -1
                            else:

                                if metric_csv_dict[key][subkey][i].strip() == "":
                                    float_metric = NaN
                                else:
                                    float_metric = float(metric_csv_dict[key][subkey][i])
                            # print (float_metric)
                            metrics_df_data["job_details_id"].append(job_id)
                            metrics_df_data["metric_id"].append(metric_id)
                            metrics_df_data["raw_value"].append(float_metric)
                            # metrics_df_data["outcome_metric_flag"].append(metric_csv_dict[key][flag_subkey][i])
                            metrics_df_data["inventory_id"].append(metric_csv_dict[key]["inventory_id"][i])
                            metrics_df_data["metric_timestamp"].append(metric_csv_dict[key]["MetricDate"][i])

                        except ValueError:
                            metrics_varchar_df_data["job_details_id"].append(job_id)
                            metrics_varchar_df_data["metric_id"].append(metric_id)
                            metrics_varchar_df_data["raw_text"].append(metric_csv_dict[key][subkey][i])
                            # metrics_varchar_df_data["outcome_metric_flag"].append("NaN")
                            metrics_varchar_df_data["inventory_id"].append(metric_csv_dict[key]["inventory_id"][i])
                            metrics_varchar_df_data["metric_timestamp"].append(metric_csv_dict[key]["MetricDate"][i])

        # break

    print(tabulate(metrics_df_data, headers=metrics_df_data.keys(), tablefmt="psql"))
    print(tabulate(metrics_varchar_df_data, headers=metrics_df_data.keys(), tablefmt="psql"))

    df = DataFrame(metrics_df_data)
    # df.to_sql(name="raw_metric",con=mysql_engine,if_exists="append",index=False,method="multi")

    df2 = DataFrame(metrics_varchar_df_data)
    # df2.to_sql(name="raw_metric_text",con=mysql_engine,if_exists="append",index=False,method="multi")


def update_table(service_id, id):
    query = "select correlated_metric_id from service_to_outcome_metric_mapping where service_id = %s and outcome_metric_name = 'slowness'"
    mysql_cursor.execute(query, (str(service_id), ))

    slow_metric_id = mysql_cursor.fetchone()[0]
    print(slow_metric_id)
    insert = ""

    if slow_metric_id is not None:
        query1 = "select raw_metric_id from raw_metric where job_details_id = %s and metric_id = %s"
        mysql_cursor.execute(query1, (str(id), str(slow_metric_id)))
        slow_raw_metric_id = mysql_cursor.fetchone()[0]
        query2 = "select outcome_metric_flag from view_raw_metric_outcomes where raw_metric_id = %s"
        mysql_cursor.execute(query2, (str(slow_raw_metric_id), ))
        slow_flag = mysql_cursor.fetchone()[0]
    else:
        slow_raw_metric_id = -1
        slow_flag = 0

    if slow_flag == 2:
        slow_flag = 1

    print("select correlated_metric_id from service_to_outcome_metric_mapping where service_id = " + str(
        service_id) + " and outcome_metric_name = 'failure'")
    query3 = "select correlated_metric_id from service_to_outcome_metric_mapping where service_id = %s and outcome_metric_name = 'failure'"
    mysql_cursor.execute(query3, (str(service_id), ))
    failure_metric_id = mysql_cursor.fetchall()
    print(failure_metric_id)
    if len(failure_metric_id) != 0:
        failure_metric_id = failure_metric_id[0][0]
    else:
        failure_metric_id = None
        insert = "nil"

    print(failure_metric_id)

    if failure_metric_id is not None:

        try:
            print("select raw_metric_id from raw_metric where job_details_id = " + str(id) + " and metric_id = " + str(
                failure_metric_id))
            query4 = "select raw_metric_id from raw_metric where job_details_id = %s and metric_id = %s "
            mysql_cursor.execute(query4 , (str(id), str(failure_metric_id)))
            failure_raw_metric_id = mysql_cursor.fetchone()[0]
            insert = "int"
        except TypeError:
            query5 = "select raw_metric_id from raw_metric_text where job_details_id = %s and metric_id = %s"
            mysql_cursor.execute(query5, (str(id), str(failure_metric_id)))
            failure_raw_metric_id = mysql_cursor.fetchone()[0]
            insert = "text"
    else:
        failure_raw_metric_id = -1

    ## Update the servicewise_job_details Table
    if insert == "text":
        print("update servicewise_job_details set anomaly_slowness = " + str(
            slow_flag) + " , anomaly_failure_raw_metric_text_id = " + str(
            failure_raw_metric_id) + " ,anomaly_slowness_raw_metric_id = " + str(
            slow_raw_metric_id) + " where job_details_id = " + str(id))
        query6 = "update servicewise_job_details set anomaly_slowness = %s , anomaly_failure_raw_metric_text_id = %s ,anomaly_slowness_raw_metric_id = %s where job_details_id = %s"
        mysql_cursor.execute(query6, (str(slow_flag), str(failure_raw_metric_id), str(slow_raw_metric_id), str(id)))
    elif insert == "int":
        print("update servicewise_job_details set anomaly_slowness = " + str(
            slow_flag) + " , anomaly_failure_raw_metric_id = " + str(
            failure_raw_metric_id) + " ,anomaly_slowness_raw_metric_id = " + str(
            slow_raw_metric_id) + " where job_details_id = " + str(id))
        
        query7 = "update servicewise_job_details set anomaly_slowness = %s, anomaly_failure_raw_metric_id = %s ,anomaly_slowness_raw_metric_id = %s where job_details_id = %s"
        mysql_cursor.execute(query7, (str(slow_flag), str(failure_raw_metric_id), str(slow_raw_metric_id), str(id)))
    elif insert == "nil":
        print("update servicewise_job_details set anomaly_slowness = " + str(
            slow_flag) + " ,anomaly_slowness_raw_metric_id = " + str(
            slow_raw_metric_id) + " where job_details_id = " + str(id))
        
        query8 = "update servicewise_job_details set anomaly_slowness = %s ,anomaly_slowness_raw_metric_id = %s where job_details_id = %s"
        mysql_cursor.execute(query8, (str(slow_flag), str(slow_raw_metric_id), str(id)))


def update_execution_details():
    config = read_yaml('/config/config.yml')
    vault_url = config['platformops']['vault_url']
    vault_key = config['platformops']['vault_key']
    f = config['platformops']['key']
    f = Fernet(f)
    vault_key = f.decrypt(vault_key.encode()).decode()
    key_url = config['platformops']['key_url']

    db_details = get_db_connection(vault_url,vault_key)

    jdbc_url = db_details['data']['data']['jdbc-url']
    db_username = db_details['data']['data']['username']
    db_passowrd = db_details['data']['data']['password']
    db_host = jdbc_url.split("/")[-2].split(":")[0]
    db_name = jdbc_url.split("/")[-1]

    mysql_cnx, mysql_engine = connect_to_mysql(db_username,db_passowrd,db_host,db_name,3306)
    mysql_cursor = mysql_cnx.cursor()
    cur_date = datetime.now(timezone.utc)
    # set execution timestamp for this job's run

    # mysql_cursor.execute("insert into metrics_processor_output_time (execution_timestamp) values ('" + cur_date.strftime("%Y-%m-%d %H:%M:%S") + "')")
    query = "select execution_id from metrics_processor_output_time where execution_timestamp= %s"
    mysql_cursor.execute(query, (cur_date.strftime("%Y-%m-%d %H:%M:%S"), ))
    execution_id = mysql_cursor.fetchone()[0]
    return execution_id


def update_outcome_metrics(metric_csv_dict, mysql_cursor):
    for i in metric_csv_dict:
        outcome_metrics = get_outcome_metric(i)
        if outcome_metrics['slowness'] is not None and outcome_metrics['failure'] is not None:
            metric_csv_dict[i][outcome_metrics['slowness']] = metric_csv_dict[i]['slowness']
            del metric_csv_dict[i]['slowness']
            metric_csv_dict[i][outcome_metrics['failure']] = metric_csv_dict[i]['failure']
            del metric_csv_dict[i]['failure']
        elif outcome_metrics['slowness'] is None and outcome_metrics['failure'] is not None:
            metric_csv_dict[i][outcome_metrics['failure']] = metric_csv_dict[i]['failure']
            del metric_csv_dict[i]['failure']
        elif outcome_metrics['slowness'] is not None and outcome_metrics['failure'] is None:
            metric_csv_dict[i][outcome_metrics['slowness']] = metric_csv_dict[i]['slowness']
            del metric_csv_dict[i]['slowness']


def show_one_service_graph(time_window_id, mysql_cursor):
    # print("select * from correlated_metrics where time_window_id = " + str(time_window_id) + " and stickiness_flag = 1")
    query = "select * from correlated_metrics where time_window_id = %s and stickiness_flag = 1"
    mysql_cursor.execute(query, (str(time_window_id), ))
    stickeness_flag_list = mysql_cursor.fetchall()
    if len(stickeness_flag_list) == 0:
        query1 = "select distinct(service_id) from causal_metrics where time_window_id = %s"
        mysql_cursor.execute(query1, (str(time_window_id), ))
        services_list = mysql_cursor.fetchall()
        for service in services_list:
            # print(time_window_id, service[0])
            query2 = "select distinct(outcome_metric) from causal_metrics where time_window_id = %s and service_id = %s"
            mysql_cursor.execute(query2, (str(time_window_id), str(service[0])))
            outcome_metrics_list = mysql_cursor.fetchall()
            for outcome_metric in outcome_metrics_list:
                # print(time_window_id, service[0], str(outcome_metric[0]))
                query3 = "select * from causal_metrics where time_window_id = %s and service_id = %s and outcome_metric = %s and coefficient_flag = 1"
                mysql_cursor.execute(query3, (str(time_window_id), str(service[0]), str(outcome_metric[0])))
                coefficient_flag_list = mysql_cursor.fetchall()
                if len(coefficient_flag_list) > 0:
                    query4 = "select distinct(correlation_y_metric_id) from causal_metrics where time_window_id = %s and service_id = %s and outcome_metric = %s"
                    mysql_cursor.execute(query4, (str(time_window_id), str(service[0]), str(outcome_metric[0])))
                    correlation_y_metric_id = mysql_cursor.fetchone()[0]

                    query5 = "select * from correlated_metrics where time_window_id = %s and correlation_metric_id = %s and outcome_metric_id = %s"
                    mysql_cursor.execute(query5, (str(time_window_id), str(correlation_y_metric_id), str(correlation_y_metric_id)))
                    stickiness_flag_list = mysql_cursor.fetchall()
                    if len(stickiness_flag_list) > 0:
                        query6 = "update correlated_metrics set stickiness_flag = 1 where time_window_id = %s and correlation_metric_id = %s and outcome_metric_id = %s"
                        mysql_cursor.execute(query6, (str(time_window_id), str(correlation_y_metric_id), str(correlation_y_metric_id)))
                    else:
                        cur_date = datetime.now(timezone.utc)
                        query7 = "insert into correlated_metrics (time_window_id,service_id,correlation_metric_id,outcome_metric_id,value,stickiness_flag,rule_name,insert_timestamp) values ( %s, %s, %s, %s,0,1,'Not Selected', %s)"
                        mysql_cursor.execute(query7, (str(time_window_id), str(service[0]), str(correlation_y_metric_id), str(correlation_y_metric_id), cur_date.strftime("%Y-%m-%d %H:%M:%S")))


def orphaned_service(all_zero_stickiness_flag, rfe_dict, time_window_id, mysql_cursor):
    print("We have an orphaned service with no causes and stickiness")
    if all_zero_stickiness_flag != 0:
        empty_flag = 0
        if rfe_dict:
            for j in rfe_dict:
                if not (rfe_dict[j]):
                    empty_flag = 1
        else:
            empty_flag = 1
        print("empty_flag:", empty_flag)
        if empty_flag:
            df = pd.read_csv('./Correlation_map/input_correlation/pearson_input.csv')
            if df.empty:
                exit()
            service_name_list = []
            outcome_name_list = []
            for i in df.columns:
                if df[i].isin([1]).any():
                    service_name_list.append(i.split('_')[0])

                    # outcome_name=i.split('_')[-1]
                    # print(re.search(r'(?<=-_y2_ :)[^.\s]*',i))
                    regexp = re.compile("_y[0-9]_(.*)$")
                    outcome_name_list.append(regexp.search(i).group(1))

            for service_name, metric_name in zip(service_name_list, outcome_name_list):
                service_name = service_name.lower()
                #print(service_name)
                query = "select service_id from services where lower(service_name) = %s"
                #print(query)
                mysql_cursor.execute(query, (str(service_name.lower()), ))
                service_id = mysql_cursor.fetchone()[0]
                
                query1 = "select metric_id from metrics where service_id = %s and  lower(metric_name) = %s"
                #print(query)

                mysql_cursor.execute(query1, (str(service_id), str(metric_name.lower())))
                correlation_y_metric_id = mysql_cursor.fetchone()[0]
                cur_date = datetime.now(timezone.utc)

                query2 = "select * from correlated_metrics where time_window_id = %s and correlation_metric_id = %s and outcome_metric_id = %s"
                mysql_cursor.execute(query2, (str(time_window_id), str(correlation_y_metric_id), str(correlation_y_metric_id)))
                stickiness_flag_list = mysql_cursor.fetchall()
                if len(stickiness_flag_list) > 0:
                    query3 = "update correlated_metrics set stickiness_flag = 1 where time_window_id = %s and correlation_metric_id = %s and outcome_metric_id = %s"
                    mysql_cursor.execute(query3, (str(time_window_id), str(correlation_y_metric_id), str(correlation_y_metric_id)))
                else:
                    query4 = "insert into correlated_metrics (time_window_id,service_id,correlation_metric_id,outcome_metric_id,value,stickiness_flag,rule_name,insert_timestamp) values ( %s, %s, %s, %s,0,1,'Not Selected', %s)"
                    mysql_cursor.execute(query4, (str(time_window_id), str(service_id), str(correlation_y_metric_id), str(correlation_y_metric_id), cur_date.strftime("%Y-%m-%d %H:%M:%S")))


#
# def show_one_service_graph(execution_id,mysql_cursor):
#     mysql_cursor.execute(
#         "select * from correlated_metrics where execution_id = " + str(execution_id) + " and stickiness_flag = 1")
#     stickeness_flag_list = mysql_cursor.fetchall()
#     if len(stickeness_flag_list) == 0:
#         mysql_cursor.execute(
#             "select se.service_id,so.correlated_metric_id,se.service_name,ca.insert_timestamp,ca.execution_id,"
#             "ca.outcome_metric from causal_metrics ca join services se on "
#             "se.service_id=ca.service_id join metrics me on ca.correlation_x_metric_id=me.metric_id "
#             "join service_to_outcome_metric_mapping so on se.service_id=so.service_id and "
#             "ca.outcome_metric=so.outcome_metric_name where coefficient_flag=1 and execution_id=" + str(execution_id) + " group by "
#             "service_id order by insert_timestamp desc")
#         correlated_metric_list = mysql_cursor.fetchall()
#         for row in correlated_metric_list:
#             service_id = row[0]
#             correlated_metric_id = row[1]
#             # outcome_metric = row[5]

#             mysql_cursor.execute(
#                 "select * from correlated_metrics where execution_id = " + str(execution_id) +
#                 " and correlation_metric_id = " + str(correlated_metric_id) +
#                 " and outcome_metric_id = " + str(correlated_metric_id))
#             stickiness_flag_list = mysql_cursor.fetchall()
#             if len(stickiness_flag_list) > 0:
#                 mysql_cursor.execute(
#                     "update correlated_metrics set stickiness_flag = 1 where execution_id = " + str(
#                         execution_id) +
#                     " and correlation_metric_id = " + str(correlated_metric_id) +
#                     " and outcome_metric_id = " + str(correlated_metric_id))
#             else:
#                 cur_date = datetime.now(timezone.utc)
#                 mysql_cursor.execute(
#                     "insert into correlated_metrics (execution_id,service_id,correlation_metric_id,"
#                     "outcome_metric_id,value,stickiness_flag,rule_name,insert_timestamp) values ('" + str(
#                         execution_id) + "','" + str(service_id) + "','" + str(correlated_metric_id) +
#                         "','" + str(correlated_metric_id) + "',0,1,'Not Selected','" + cur_date.strftime("%Y-%m-%d %H:%M:%S") + "')")

def write_log_to_correlation_log(mysql_engine):
    log_dic = {"time_window_id": [], "last_raw_metric_id": [], "start_time": [], "end_time": []}
    try:
        log_df = pd.read_csv('Correlation_map/output/getSegmentedTimeWindowPrediction.csv')
    except FileNotFoundError:
        print("Unable to open 'Correlation_map/output/getSegmentedTimeWindowPrediction.csv'")
        exit()

    log_dic['time_window_id'].append(log_df.iloc[0]['time_window_id'])
    log_dic['last_raw_metric_id'].append(log_df.iloc[0]['last_raw_metric_id'])
    log_dic['start_time'].append(log_df.iloc[0]['start_time'])
    log_dic['end_time'].append(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

    df = DataFrame(log_dic)
    print(tabulate(log_dic, headers=log_dic.keys(), tablefmt="psql"))
    df.to_sql(name="correlation_log", con=mysql_engine, if_exists="append", index=False, method="multi")
    return

if __name__ == "__main__":
    config = read_yaml('/config/config.yml')
    vault_url = config['platformops']['vault_url']
    vault_key = config['platformops']['vault_key']
    f = config['platformops']['key']
    f = Fernet(f)
    vault_key = f.decrypt(vault_key.encode()).decode()
    key_url = config['platformops']['key_url']

    db_details = get_db_connection(vault_url,vault_key)

    jdbc_url = db_details['data']['data']['jdbc-url']
    db_username = db_details['data']['data']['username']
    db_passowrd = db_details['data']['data']['password']
    db_host = jdbc_url.split("/")[-2].split(":")[0]
    db_name = jdbc_url.split("/")[-1]

    mysql_cnx, mysql_engine = connect_to_mysql(db_username,db_passowrd,db_host,db_name,3306)
    mysql_cursor = mysql_cnx.cursor()
    env = config['database_env']
    organization_id = config['organization_id']
    sub_organization_id = config['sub_organization_id']
    category = sys.argv[1]

    query = "select environment_id from environments where environment_name= %s and organization_id= %s and sub_organization_id= %s"
    mysql_cursor.execute(query, (str(env), str(organization_id), str(sub_organization_id)))
    environment_id = mysql_cursor.fetchone()[0]

    if category == "raw_table":

        # get the current date and time
        # execution_id = sys.argv[2]
        file_name = sys.argv[2]
        execution_id = sys.argv[3]

        metric_csv_dict = process_metric_csvs(file_name, config, mysql_cursor)

        fetch_service_info_from_mysql(metric_csv_dict, mysql_cursor, environment_id)
        write_job_metrics_to_mysql(metric_csv_dict, execution_id, mysql_engine)
        update_outcome_metrics(metric_csv_dict, mysql_cursor)

        print(metric_csv_dict)
        # write_record_metrics_to_mysql(metric_csv_dict,execution_id,mysql_engine,mysql_cursor)

    elif category == "correlated_table":

        # query1 = "SELECT max(sj.execution_id) from servicewise_job_details sj join service_onboarded so ON sj.service_onboard_id = so.service_onboard_id WHERE so.environment_id = %s "
        # mysql_cursor.execute(query1, (str(environment_id), ))
        # execution_id = mysql_cursor.fetchone()[0]
        # print(execution_id)
        try:
            log_df = pd.read_csv('Correlation_map/output/getSegmentedTimeWindowPrediction.csv')
        except FileNotFoundError:
            print("Unable to open 'Correlation_map/output/getSegmentedTimeWindowPrediction.csv'")
            exit()

        time_window_id = log_df.iloc[0]['time_window_id']
        rfe_csv_dict, pearson_csv_dict = process_correlation_csvs()
        # rfe_csv_dict = update_rfe_dict(rfe_csv_dict)
        #
        #
        correlated_metric_list, all_zero_stickiness_flag = write_pearson_to_mysql(pearson_csv_dict, time_window_id,
                                                                                  mysql_engine)
        write_rfe_to_mysql(rfe_csv_dict, time_window_id, mysql_engine, mysql_cursor, correlated_metric_list, config)

        show_one_service_graph(time_window_id,mysql_cursor)
        orphaned_service(all_zero_stickiness_flag, rfe_csv_dict, time_window_id, mysql_cursor)

        write_log_to_correlation_log(mysql_engine)

    elif category == "update_main_table":

        query2 = "SELECT max(sj.execution_id) from servicewise_job_details sj join service_onboarded so ON sj.service_onboard_id = so.service_onboard_id WHERE so.environment_id = %s "
        mysql_cursor.execute(query2, (str(environment_id), ))
        execution_id = mysql_cursor.fetchone()[0]
        print(execution_id)
        # execution_id = 376

        query3 = "select job_details_id from servicewise_job_details where execution_id = %s"
        mysql_cursor.execute(query3 , (str(execution_id), ))
        job_id = mysql_cursor.fetchall()
        for i in job_id:
            id = i[0]

            query4 = "select service_id from service_onboarded where service_onboard_id = (select service_onboard_id from servicewise_job_details where job_details_id = %s)"
            mysql_cursor.execute(query4, (str(id), ))
            service_id = mysql_cursor.fetchone()[0]

            # print (str(service_id) + "______" +str(id))
            # update_table(service_id, id)

    mysql_cnx.close()