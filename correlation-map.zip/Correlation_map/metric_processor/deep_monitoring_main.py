import csv
import argparse, yaml, yamlordereddictloader
import pandas as pd
import re
import json
import sys
import os.path
import numpy as np
from os import path

def read_yaml():
    """ A function to read YAML file"""
    with open('./metric_processor/config.yml') as f:
        config = yaml.safe_load(f)

    return config
    
def read_json(input):
    j = open(input)
    data = json.load(j)
    return data

def get_jobnames (data):
    job_name = []
    metric_records = data['metric_records']
    for i in metric_records:
        names = i['metric_value'][0]
        job_name.append(names)
    return job_name

def get_timestamp (data):
    timestamp = []
    metric_records = data['metric_records']
    for i in metric_records:
        times = i['timestamp']
        timestamp.append(times)
    return timestamp

def remove_duplicates(list):
    list = [*set(list)]
    return list

def write_dict(data,service):
    job_names = get_jobnames(data)
    job_names = remove_duplicates(job_names)
    time_stamp = get_timestamp(data)
    time_stamp = remove_duplicates(time_stamp)
    time_stamp.sort()
    dict = {}
    for i in job_names:
        values = []
        for j in time_stamp:
            for k in data['metric_records']:
                value_len = len(k['metric_value'])
                if (j==k['timestamp'] and i==k['metric_value'][0]):
                    values.append(j)
                    count = 0
                    for l in (k['metric_value']):
                        if count != 0:
                            values.append(l)
                        count = count + 1
        dict[i] = values
    dict_map = {}
    dict_keys = list(dict.keys())
    dict_val = list(dict.values())
    for i in dict_keys:
        values = dict.get(i)
        total = []
        total = []
        dic_list = []
        if (service == "lambda"):
            split_num = len(values)/4
        elif (service == "s3"):
            split_num = len(values)/14
        elif (service == "glue"):
            split_num = len(values)/40
        elif (service == "sagemaker"):
            split_num = len(values)/27
        splits = np.array_split(values, split_num)
        for array in splits:
            dic_list.append(array.tolist())
        total.append(dic_list)
        dict_map[i]=total[0]
    return dict_map

def lambda_write_json(dict,template_file,main_json,service):
    json_template = template_file
    json_script = main_json

    map_dict = dict
    search_replace_dict = {}

    #time_stamp = ['01-08-2022 10:00:00', '01-08-2022 10:05:00', '01-08-2022 10:10:00', '01-08-2022 10:15:00', '01-08-2022 10:20:00', '01-08-2022 10:25:00', '01-08-2022 10:30:00']

    for i in (list(map_dict.keys())):
        for j in (map_dict.get(i)):
            search_replace_dict.update(job_name=i)
            search_replace_dict.update(Timestamp=j[0])
            search_replace_dict.update(Time_Taken=j[1])
            search_replace_dict.update(Concurrent_Executions=j[2])
            search_replace_dict.update(Provisioned_Concurrency_Utilization=j[3])

            if (service == "glue"):
                start = "{\n\t\"glue\": ["
            elif (service == "lambda"):
                start = "{\n\t\"lambda\": ["
            elif (service == "s3"):
                start = "{\n\t\"s3\": ["

            if (path.exists(json_script)):
                with open(json_template,'r') as firstfile, open(json_script,'a') as secondfile:
                    secondfile.write(",")
                    for line in firstfile:
                        secondfile.write(line)
            else:
                with open(json_template,'r') as firstfile, open(json_script,'a') as secondfile:
                    secondfile.write(start)
                    for line in firstfile:
                        secondfile.write(line)

            for key, val in search_replace_dict.items():
                search_string = key
                replace_string = val
                with open(json_script, "r+") as fp:
                    data = fp.read()
                    data = re.sub(search_string, replace_string, data)
                    fp.seek(0)
                    fp.write(data)
                    fp.truncate()
    with open(json_script,'a') as json_file:
                json_file.write("\t]\n}")

def s3_write_json(dict,template_file,main_json,service):
    json_template = template_file
    json_script = main_json

    map_dict = dict
    search_replace_dict = {}

    #time_stamp = ['01-08-2022 10:00:00', '01-08-2022 10:05:00', '01-08-2022 10:10:00', '01-08-2022 10:15:00', '01-08-2022 10:20:00', '01-08-2022 10:25:00', '01-08-2022 10:30:00']

    for i in (list(map_dict.keys())):
        for j in (map_dict.get(i)):
            search_replace_dict.update(job_name=i)
            search_replace_dict.update(Timestamp=j[0])
            search_replace_dict.update(All_Requests=j[1])
            search_replace_dict.update(Put_Requests=j[2])
            search_replace_dict.update(Delete_Requests=j[3])
            search_replace_dict.update(Head_Requests=j[4])
            search_replace_dict.update(Select_Requests=j[5])
            search_replace_dict.update(four_Errors=j[6])
            search_replace_dict.update(five_Errors=j[7])
            search_replace_dict.update(First_Byte_Latency=j[8])
            search_replace_dict.update(Total_Request_Latency=j[9])
            search_replace_dict.update(Bucket_Size_Bytes=j[10])
            search_replace_dict.update(NumberOf_Objects=j[11])
            search_replace_dict.update(Get_Requests=j[12])
            search_replace_dict.update(Post_Requests=j[13])

            if (service == "glue"):
                start = "{\n\t\"glue\": ["
            elif (service == "lambda"):
                start = "{\n\t\"lambda\": ["
            elif (service == "s3"):
                start = "{\n\t\"s3\": ["

            if (path.exists(json_script)):
                with open(json_template,'r') as firstfile, open(json_script,'a') as secondfile:
                    secondfile.write(",")
                    for line in firstfile:
                        secondfile.write(line)
            else:
                with open(json_template,'r') as firstfile, open(json_script,'a') as secondfile:
                    secondfile.write(start)
                    for line in firstfile:
                        secondfile.write(line)

            for key, val in search_replace_dict.items():
                search_string = key
                replace_string = val
                with open(json_script, "r+") as fp:
                    data = fp.read()
                    data = re.sub(search_string, replace_string, data)
                    fp.seek(0)
                    fp.write(data)
                    fp.truncate()
    with open(json_script,'a') as json_file:
        json_file.write("\t]\n}")
            
def glue_write_json(dict,template_file,main_json,service):
    json_template = template_file
    json_script = main_json

    map_dict = dict
    search_replace_dict = {}

    #time_stamp = ['01-08-2022 10:00:00', '01-08-2022 10:05:00', '01-08-2022 10:10:00', '01-08-2022 10:15:00', '01-08-2022 10:20:00', '01-08-2022 10:25:00', '01-08-2022 10:30:00']

    for i in (list(map_dict.keys())):
        for j in (map_dict.get(i)):
            search_replace_dict.update(job_name=i)
            search_replace_dict.update(Timestamp=j[0])
            search_replace_dict.update(run_id=j[1])
            search_replace_dict.update(execution_time=j[32])
            search_replace_dict.update(job_run_status=j[31])
            search_replace_dict.update(Driver_Bytes_Read=j[2])
            search_replace_dict.update(Driver_Elapsed_Time=j[3])
            search_replace_dict.update(Driver_NumCompleted_Stages=j[4])
            search_replace_dict.update(Driver_NumCompleted_Tasks=j[5])
            search_replace_dict.update(Driver_NumFailed_Tasks=j[6])
            search_replace_dict.update(Driver_NumKilled_Tasks=j[7])
            search_replace_dict.update(Driver_RecordsRead=j[8])
            search_replace_dict.update(Driver_ShuffleBytes_Written=j[9])
            search_replace_dict.update(Driver_ShuffleLocal_BytesRead=j[10])
            search_replace_dict.update(Driver_BlockManager_DiskSpaceUsed_MB=j[11])
            search_replace_dict.update(Driver_NumberAll_Executors=j[12])
            search_replace_dict.update(Driver_MaxNeeded_Executors=j[13])
            search_replace_dict.update(Driver_Jvm_HeapUsage=j[14])
            search_replace_dict.update(Executor_IdJvm_HeapUsage=j[15])
            search_replace_dict.update(Jvm_HeapUsage_All=j[16])
            search_replace_dict.update(Driver_Jvm_HeapUsed=j[17])
            search_replace_dict.update(ExecutorId_JvmHeapUsed=j[18])
            search_replace_dict.update(Jvm_HeapUsed_All=j[19])
            search_replace_dict.update(S3_Driver_ReadBytes=j[20])
            search_replace_dict.update(S3_ExecutorId_ReadBytes=j[21])
            search_replace_dict.update(S3_ReadBytes_All=j[22])
            search_replace_dict.update(S3_Driver_WriteBytes=j[23])
            search_replace_dict.update(S3_ExecutorId_WriteBytes=j[24])
            search_replace_dict.update(S3_WriteBytes_All=j[25])
            search_replace_dict.update(Driver_SystemCpu_SystemLoad=j[26])
            search_replace_dict.update(ExecutorId_SystemCpu_SystemLoad=j[27])
            search_replace_dict.update(Cpu_SystemLoad_All=j[28])
            search_replace_dict.update(Driver_NumRecords=j[29])
            search_replace_dict.update(DriverBatch_Processing_TimeinMs=j[30])
            search_replace_dict.update(allocated_capacity=j[36])
            search_replace_dict.update(Max_Capacity=j[37])
            search_replace_dict.update(Worker_Type=j[38])
            search_replace_dict.update(Number_Of_Workers=j[39])

            if (service == "glue"):
                start = "{\n\t\"glue\": ["
            elif (service == "lambda"):
                start = "{\n\t\"lambda\": ["
            elif (service == "s3"):
                start = "{\n\t\"s3\": ["

            if (path.exists(json_script)):
                with open(json_template,'r') as firstfile, open(json_script,'a') as secondfile:
                    secondfile.write(",")
                    for line in firstfile:
                        secondfile.write(line)
            else:
                with open(json_template,'r') as firstfile, open(json_script,'a') as secondfile:
                    secondfile.write(start)
                    for line in firstfile:
                        secondfile.write(line)

            for key, val in search_replace_dict.items():
                search_string = key
                replace_string = val
                with open(json_script, "r+") as fp:
                    data = fp.read()
                    data = re.sub(search_string, replace_string, data)
                    fp.seek(0)
                    fp.write(data)
                    fp.truncate()
    with open(json_script,'a') as json_file:
        json_file.write("\t]\n}")

def sagemaker_write_json(dict,template_file,main_json,service):
    json_template = template_file
    json_script = main_json

    map_dict = dict
    search_replace_dict = {}

    #time_stamp = ['01-08-2022 10:00:00', '01-08-2022 10:05:00', '01-08-2022 10:10:00', '01-08-2022 10:15:00', '01-08-2022 10:20:00', '01-08-2022 10:25:00', '01-08-2022 10:30:00']

    for i in (list(map_dict.keys())):
        for j in (map_dict.get(i)):
            #print (len(j))
            search_replace_dict.update(job_name=i)
            search_replace_dict.update(Timestamp=j[0])
            search_replace_dict.update(Invoc_=j[1])
            search_replace_dict.update(Model_Latency=j[2])
            search_replace_dict.update(Model_Loading_WaitTime=j[3])
            search_replace_dict.update(Model_LoadingTime=j[4])
            search_replace_dict.update(Loaded_ModelCount=j[5])
            search_replace_dict.update(CPU_Utilization=j[6])
            search_replace_dict.update(Memory_Utilization=j[7])
            search_replace_dict.update(GPU_Utilization=j[8])
            search_replace_dict.update(GPU_MemoryUtilization=j[9])
            search_replace_dict.update(Disk_Utilization=j[10])
            search_replace_dict.update(Active_Workers=j[11])
            search_replace_dict.update(DatasetObjects_LabelingFailed=j[12])
            search_replace_dict.update(Jobs_Failed=j[13])
            search_replace_dict.update(Jobs_Succeeded=j[14])
            search_replace_dict.update(Tasks_Accepted=j[15])
            search_replace_dict.update(Tasks_Declined=j[16])
            search_replace_dict.update(Tasks_Returned=j[17])
            search_replace_dict.update(Tasks_Submitted=j[18])
            search_replace_dict.update(Time_Spent=j[19])
            search_replace_dict.update(lat_=j[20])
            search_replace_dict.update(Execution_Failed=j[21])
            search_replace_dict.update(Execution_Succeeded=j[22])
            search_replace_dict.update(Execution_Duration=j[23])
            search_replace_dict.update(Step_Failed=j[24])
            search_replace_dict.update(Step_Succeeded=j[25])
            search_replace_dict.update(Step_Duration=j[26])

            if (service == "glue"):
                start = "{\n\t\"glue\": ["
            elif (service == "lambda"):
                start = "{\n\t\"lambda\": ["
            elif (service == "s3"):
                start = "{\n\t\"s3\": ["
            elif (service == "sagemaker"):
                start = "{\n\t\"sagemaker\": ["

            if (path.exists(json_script)):
                with open(json_template,'r') as firstfile, open(json_script,'a') as secondfile:
                    secondfile.write(",")
                    for line in firstfile:
                        secondfile.write(line)
            else:
                with open(json_template,'r') as firstfile, open(json_script,'a') as secondfile:
                    secondfile.write(start)
                    for line in firstfile:
                        secondfile.write(line)

            for key, val in search_replace_dict.items():
                search_string = key
                replace_string = val
                with open(json_script, "r+") as fp:
                    data = fp.read()
                    data = re.sub(search_string, replace_string, data)
                    fp.seek(0)
                    fp.write(data)
                    fp.truncate()
    with open(json_script,'a') as json_file:
        json_file.write("\t]\n}")

if __name__ == "__main__":
    config = read_yaml()
    service = sys.argv[1]
    service = service.lower()
    input_file = config[service]['input']
    main_json = config[service]['main_json']
    data = read_json(main_json)
    conv_json = config[service]['input']
    template_file = config[service]['template']

    if os.path.exists(conv_json):
        os.remove(conv_json)

    dict = write_dict(data,service)

    if (service == "glue"):
        glue_write_json(dict,template_file,conv_json,service)
        os.system("python ./metric_processor/dm_glue_main.py")
    elif (service == "lambda"):
        lambda_write_json(dict,template_file,conv_json,service)
        os.system("python ./metric_processor/dm_lambda_main.py")
    elif (service == "s3"):
        s3_write_json(dict,template_file,conv_json,service)
        os.system("python ./metric_processor/dm_s3_main.py")
    elif (service == "sagemaker"):
        #print (service)
        sagemaker_write_json(dict,template_file,conv_json,service)
        os.system("python ./metric_processor/dm_sagemaker_main.py")