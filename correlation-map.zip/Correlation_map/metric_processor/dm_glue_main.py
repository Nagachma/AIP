import csv
import argparse, yaml, yamlordereddictloader
import pandas as pd
import json
import sys
from datetime import datetime
import os.path
from os import path

def read_json(input):
    j = open(input)
    data = json.load(j)
    return data

def write_csv(row, output_csv,glue_header):
    file = open(output_csv, 'a', newline ='')
    with file:
        writer = csv.DictWriter(file, fieldnames = glue_header)
        writer.writerow(row)

def write_csv_header(row, writer):
    writer.writerow(row)

def get_values(data,thresshold_value):
    row = {}
    values = data['values'][0]
    row = values
    row['JobName'] = data['JobName']
    key_list = (list(values.keys()))
    #print (row)
    filter_list = key_list[2:33]
    #print (filter_list)
    for i in filter_list :
        if (i != "JobRunState"):
            flag_i = i + "_Flag"
            if (int(values.get(i)) > int(thresshold_value[i])):
                row[flag_i] = "1"
            else:
                row[flag_i] = "0"
    return row

def status_values(y1_row):
    row = {}
    row = y1_row
    status = row.get("JobRunState")
    status = status.lower()
    if status == "inprogress" or status == "":
        row['JobRunState_Flag'] = 0
    elif status == "success":
        row['JobRunState_Flag'] = 1
    elif status == "failed":
        row['JobRunState_Flag'] = 0
    return row


def add_rows(data,thresshold_value,output_csv_y1,glue_header_y1,output_csv_y2,glue_header_y2):
    j_len = len(data['glue'])
    for i in data['glue']:
        y1_row=get_values(i,thresshold_value)
        print (y1_row)
        write_csv(y1_row,output_csv_y1,glue_header_y1)
        y2_row=status_values(y1_row)
        write_csv(y2_row,output_csv_y2,glue_header_y2)
        
def read_yaml():
    """ A function to read YAML file"""
    with open('./metric_processor/config.yml') as f:
        config = yaml.safe_load(f)

    return config

if __name__ == "__main__":

    config = read_yaml()
    now = datetime.now()
    current_time = now.strftime("%y%m%d%H%M%S")
    extn = current_time + ".csv"
    slowness_output = config['glue']['y1_output']
    status_output = config['glue']['y2_output']
    output_csv_y1 = slowness_output + extn
    output_csv_y2 = status_output + extn
    glue_csv_y1 = open(output_csv_y1,'a',newline="")
    glue_csv_y2 = open(output_csv_y2,'a',newline="")

    glue_writer_y1 = csv.writer(glue_csv_y1)
    glue_writer_y2 = csv.writer(glue_csv_y2)

    #Getting values from config for further operations
    thresshold_value = (config['glue']['Threeshold'])
    glue_header_y1 = (config['glue']['glue_header_y1'])
    glue_header_y2 = (config['glue']['glue_header_y2'])

    #cprint (glue_header_y1)
    input = config['glue']['input']
    data=read_json(input)

    #Insert headers in the csv based on the header_flag Value
    write_csv_header(glue_header_y1,glue_writer_y1)
    write_csv_header(glue_header_y2,glue_writer_y2)
    glue_csv_y1.close()
    glue_csv_y2.close()

    #This function reads the data and add all the rows existing in the json for different jobs
    #add_data(data,metric_details,thresshold_value,status_writer,slow_writer)
    add_rows(data,thresshold_value,output_csv_y1,glue_header_y1,output_csv_y2,glue_header_y2)
