import csv
import argparse, yaml, yamlordereddictloader
import pandas as pd
import json
import sys
from datetime import datetime
import os.path
from os import path

def read_json(input):
    j = open(input)
    data = json.load(j)
    return data

def write_csv(row, output_csv,lambda_header):
    file = open(output_csv, 'a', newline ='')
    with file:
        writer = csv.DictWriter(file, fieldnames = lambda_header)
        writer.writerow(row)

def write_csv_header(row, writer):
    writer.writerow(row)

def get_values(data,thresshold_value):
    row = {}
    values = data['values'][0]
    key_list = (list(values.keys()))
    row = values
    #print (row)
    row['JobName'] = data['JobName']
    #print (row)
    #filter_list = key_list[2:32]
    #print (filter_list)
    for i in key_list :
        #print (i)
        if (i != "MetricDate"):
            flag_i = i + "_Flag"
            if (int(values.get(i)) > int(thresshold_value[i])):
                row[flag_i] = "1"
            else:
                row[flag_i] = "0"
    #print (row)
    return row

def add_rows(data,thresshold_value,output_csv,lambda_header):
    j_len = len(data['lambda'])
    for i in data['lambda']:
        #print (i)
        row=get_values(i,thresshold_value)
        write_csv(row,output_csv,lambda_header)
        #print (row)
        
def read_yaml():
    """ A function to read YAML file"""
    with open('./metric_processor/config.yml') as f:
        config = yaml.safe_load(f)

    return config

if __name__ == "__main__":

    config = read_yaml()
    now = datetime.now()
    current_time = now.strftime("%y%m%d%H%M%S")
    output_csv = config['lambda']['output']
    output_csv = output_csv + str(current_time) + ".csv"
    lambda_csv = open(output_csv,'a',newline="")

    lambda_writer = csv.writer(lambda_csv)

    #Getting values from config for further operations
    thresshold_value = (config['lambda']['Threeshold'])
    lambda_header = (config['lambda']['lambda_header'])
    #cprint (glue_header)
    input = config['lambda']['input']
    data=read_json(input)

    #Insert headers in the csv based on the header_flag Value
    write_csv_header(lambda_header,lambda_writer)
    lambda_csv.close()

    #This function reads the data and add all the rows existing in the json for different jobs
    #add_data(data,metric_details,thresshold_value,status_writer,slow_writer)
    add_rows(data,thresshold_value,output_csv,lambda_header)
