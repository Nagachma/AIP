import csv
import argparse, yaml, yamlordereddictloader
import pandas as pd
import json
import sys
from datetime import datetime
import os.path
from os import path

def read_json(input):
    j = open(input)
    data = json.load(j)
    return data

def write_csv(row, output_csv,s3_header):
    file = open(output_csv, 'a', newline ='')
    with file:
        writer = csv.DictWriter(file, fieldnames = s3_header)
        writer.writerow(row)

def write_csv_header(row, writer):
    writer.writerow(row)

def get_values(data,thresshold_value):
    row = {}
    values = data['values'][0]
    key_list = (list(values.keys()))
    row = values
    row['JobName'] = data['JobName']
    #print (key_list)
    #print (filter_list)
    for i in key_list :
        #print (i)
        if (i != "MetricDate"):
            flag_i = i + "_Flag"
            if (int(values.get(i)) > int(thresshold_value[i])):
                row[flag_i] = "1"
            else:
                row[flag_i] = "0"
    #print (row)
    return row

def add_rows(data,thresshold_value,output_csv,s3_header):
    j_len = len(data['s3'])
    for i in data['s3']:
        row=get_values(i,thresshold_value)
        #print (row)
        write_csv(row,output_csv,s3_header)

def read_yaml():
    """ A function to read YAML file"""
    with open('./metric_processor/config.yml') as f:
        config = yaml.safe_load(f)

    return config

if __name__ == "__main__":

    config = read_yaml()
    output_csv = config['s3']['output']
    now = datetime.now()
    current_time = now.strftime("%y%m%d%H%M%S")
    output_csv = output_csv + str(current_time) + ".csv"
    s3_csv = open(output_csv,'a',newline="")

    s3_writer = csv.writer(s3_csv)

    #Getting values from config for further operations
    thresshold_value = (config['s3']['Threeshold'])
    s3_header = (config['s3']['s3_header'])
    #cprint (glue_header)
    input = config['s3']['input']
    data=read_json(input)

    #Insert headers in the csv based on the header_flag Value
    write_csv_header(s3_header,s3_writer)
    s3_csv.close()

    #This function reads the data and add all the rows existing in the json for different jobs
    #add_data(data,metric_details,thresshold_value,status_writer,slow_writer)
    add_rows(data,thresshold_value,output_csv,s3_header)
