OrchestrAI:

OrchestrAI is an XOps as a Service solution tailored by industry that provides end-to-end operational monitoring and action to minimize AI project/process disruption​

This project contain different folder.Folder structure are below

    algorithms   --  feature selection algorithm files
    API JSON     --  JSON file
    d3           --  visualization file
    logging      -- feature selection logging file

## Conf
    
    ./config.yml:
        This file contain all configuration for different script.
    

## How to Run :

    Install Python 3.10.0
    open a terminal or a command prompt and navigate to the directory of your Python project. 
    Run `pip install -r requirements.txt`
    Run `python main.py service_name`
        (eg. python main.py Glue)
        (eg. python main.py s3)
        (eg. python main.py lambda)
        (eg. python main.py sagemaker)

    Note: The existing algorithms are RFE, RFR, lasso, PCA, pearson.
          The pearson algorithm does not require the server_name.
   
