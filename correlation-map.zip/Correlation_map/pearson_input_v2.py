import pandas as pd
from pandas import *
from os import scandir as scan_directory
import csv
import sys
import yaml
import os.path
from sys import exit as exit_python
from pymysql import connect as mysql_connect
from pymysql.err import OperationalError as PyMySQLOperationalError
from sqlalchemy import create_engine
from sqlalchemy.exc import OperationalError as SQLAlchemyOperationalError
import pymysql
import time
import ssl
import requests
import hvac
from cryptography.fernet import Fernet

def read_yaml():
    """ A function to read YAML file"""
    with open('/config/config.yml') as f:
        config = yaml.safe_load(f)

    return config

def update_yaml(data):
    """ A function to update YAML file"""
    with open('/config/config.yml', 'w') as f:
        yaml.dump(data, f, default_flow_style=False)

def create_mysql_connection(username, passwd, hostname, db_name, port_number):
    url = "https://s3.amazonaws.com/rds-downloads/rds-combined-ca-bundle.pem"
    filename = "rds-combined-ca-bundle.pem"
    response = requests.get(url,verify=False)

    with open (filename, "wb") as f:
        f.write(response.content)

    # SSL_CA = os.path.abspath(filename)
    SSL_CA = filename
    print (SSL_CA)
    try:
        cnx = mysql_connect(user=username, password=passwd, host=hostname, database=db_name, port=port_number,
                            autocommit=True,ssl_ca=SSL_CA)
    except PyMySQLOperationalError as err:
        err.errno = err.args[0]
        if err.errno == 1044:
            print("ERROR: Access is denied to the user '" + username + "' on the database called '" + db_name + "'.")
            print("Please validate that said user has the correct level of access.")
            exit_python()
        elif err.errno == 1045:
            print("ERROR: Access is denied to the user '" + username + "' on host '" + hostname + "'.")
            print("Please validate that the username and password are correct.")
            exit_python()
        elif err.errno == 1049:
            print("ERROR: The database called '" + db_name + "'does not exist.")
            print("Please validate that database name is spelled correctly and exists.")
            exit_python()
        elif err.errno == 2003:
            print("ERROR: Unable to connect to host '" + hostname + "' on port '" + str(port_number) + "'.")
            print("Please validate your network connectivity and that the hostname and port is correct.")
            exit_python()
        else:
            print("ERROR: Unhandled MySQL Error.")
            print(err)
            exit_python()
    else:
        return cnx
def create_mysql_engine(username, passwd, hostname, db_name, port_number):
    try:
        ca_path = "rds-combined-ca-bundle.pem"
        ssl_args = {'ssl_ca': ca_path}
        engine = create_engine(url="mysql+pymysql://" + username + ":" + passwd + "@" + hostname + ":" + str(port_number) + "/" + db_name,execution_options={"isolation_level": "AUTOCOMMIT"},connect_args=ssl_args)
        cnx = engine.connect()
    except SQLAlchemyOperationalError as err:
        err.errno = int(err.args[0].split(") (")[1].split(",")[0])
        if err.errno == 1044:
            print("ERROR: Access is denied to the user '" + username + "' on the database called '" + db_name + "'.")
            print("Please validate that said user has the correct level of access.")
            exit_python()
        elif err.errno == 1045:
            print("ERROR: Access is denied to the user '" + username + "' on host '" + hostname + "'.")
            print("Please validate that the username and password are correct.")
            exit_python()
        elif err.errno == 1049:
            print("ERROR: The database called '" + db_name + "'does not exist.")
            print("Please validate that database name is spelled correctly and exists.")
            exit_python()
        elif err.errno == 2003:
            print("ERROR: Unable to connect to host '" + hostname + "' on port '" + str(port_number) + "'.")
            print("Please validate your network connectivity and that the hostname and port is correct.")
            exit_python()
        else:
            print("ERROR: Unhandled MySQL Error.")
            print(err)
            exit_python()
    else:
        cnx.close()
        return engine

def get_db_connection(vault_url,vault_key):

    client = hvac.Client(
    url=vault_url,
    verify = False,
    token=vault_key,
    )
    db_response = client.secrets.kv.read_secret_version(path='orchestraidb')
    
    return db_response

def connect_to_mysql(username, passwd, hostname, db_name, port_number):
    cnx = create_mysql_connection(username, passwd, hostname, db_name, port_number)
    engine = create_mysql_engine(username, passwd, hostname, db_name, port_number)
    return cnx, engine


def get_Y_metric(config, service_name, outcome_metric):
    vault_url = config['platformops']['vault_url']
    vault_key = config['platformops']['vault_key']
    f = config['platformops']['key']
    f = Fernet(f)
    vault_key = f.decrypt(vault_key.encode()).decode()
    key_url = config['platformops']['key_url']

    db_details = get_db_connection(vault_url,vault_key)

    jdbc_url = db_details['data']['data']['jdbc-url']
    db_username = db_details['data']['data']['username']
    db_passowrd = db_details['data']['data']['password']
    db_host = jdbc_url.split("/")[-2].split(":")[0]
    db_name = jdbc_url.split("/")[-1]

    mysql_cnx, mysql_engine = connect_to_mysql(db_username,db_passowrd,db_host,db_name,3306)
    mysql_cursor = mysql_cnx.cursor()
    mysql_cursor.execute("SELECT service_id FROM services WHERE service_name = %s;", (service_name, ))
    service_id = mysql_cursor.fetchone()[0]
    query = """SELECT m.metric_name FROM service_to_outcome_metric_mapping s 
                JOIN metrics m ON
                m.metric_id = s.correlated_metric_id
                WHERE s.outcome_metric_name = '{outcome_metric}' AND s.service_id = {service_id};""".format(service_id=service_id, outcome_metric=outcome_metric)
    #print(query)
    mysql_cursor.execute(query)
    Y_metric = mysql_cursor.fetchone()[0]
    return Y_metric

def update_null(col):
    a = []
    for i in col:
        a.append(col.get(i))
    
    max_len = max([len(i) for i in a])
    print (max_len)
    for i in a:
        while len(i) <= max_len-1:
            i.append("00")
    data = col
    df = pd.DataFrame(data)
    df = df.fillna("00")
    df.to_csv('./Correlation_map/input_correlation/pearson_input.csv', index=False)
    

if __name__ == "__main__":
    #output_path = "./metric_processor/output"
    print('creating pearson input file')
    correlation_csv_files = []
    #timestamp = sys.argv[1]
    config = read_yaml()
    with scan_directory(path="./Correlation_map/input_correlation/") as file_list:
        for file in file_list:
            if "pearson"  in str(file) :
                correlation_csv_files.append(file.path)
    print(correlation_csv_files)

   # if len(correlation_csv_files) == 1:
   #     print ("There should two or more files to correlate, Exiting the process")
   #     exit()
        

        #y = dataset.iloc[:, 0].astype('float64')

    result_df=pd.DataFrame()
    for file_path in correlation_csv_files:
        file_name = file_path.split('/')[-1]
        #print(file_name)
        service_name = file_name.split('_')[2].capitalize()
        #print(file_path)
        dataset = pd.read_csv(file_path,sep=',')
        anomaly_cols = [col for col in dataset.columns if 'anomaly' in col]
        print(dataset[anomaly_cols].sum())
        #print(dataset['anomaly_slowness'].sum())
        dataset.fillna(0, inplace=True)
        dataset.sort_values(by='metric_timestamp', inplace = True)
        #print(dataset)
        service = []
        col = {}
        anomaly_list = ['anomaly_slowness', 'anomaly_failure']

        if (anomaly_list[0] in dataset.columns) and (anomaly_list[1] in dataset.columns):
            c=1
            for item in anomaly_list:
                outcome_metric = item.split('_')[-1]
                #print(service_name)
                #print(outcome_metric)
                Y_metric = get_Y_metric(config, service_name, outcome_metric)
                outcome_header=service_name+'_y'+str(c)+'_'+Y_metric

                # result_df[outcome_header]=dataset[item]
                temp_df = dataset[item].copy()
                result_df = pd.concat([result_df, temp_df], axis=1)
                result_df.rename(columns={result_df.columns[-1]: outcome_header}, inplace=True)
                c+=1
                #cause_metrics_dic[Y_metric] = []
                # y = dataset[item].astype('float64')

        else:
            if 'anomaly_slowness' in dataset.columns:
                outcome_metric = 'slowness'
                Y_metric = get_Y_metric(config, service_name, outcome_metric)
                outcome_header = service_name + '_y1_'  + Y_metric
                # result_df[outcome_header] = dataset['anomaly_slowness']
                temp_df = dataset['anomaly_slowness'].copy()
                result_df = pd.concat([result_df, temp_df], axis=1)
                result_df.rename(columns={result_df.columns[-1]: outcome_header}, inplace=True)
                #cause_metrics_dic[Y_metric] = []
            else:
                outcome_metric = 'failure'
                Y_metric = get_Y_metric(config, service_name, outcome_metric)
                outcome_header = service_name + '_y2_' + Y_metric
                # result_df[outcome_header] = dataset['anomaly_slowness']
                temp_df = dataset['anomaly_failure'].copy()
                result_df = pd.concat([result_df, temp_df], axis=1)
                result_df.rename(columns={result_df.columns[-1]: outcome_header}, inplace=True)
                # cause_metrics_dic[Y_metric] = []



    #if len(result_df.columns.to_list()) <= 1:
    #    print ("There should two or more files to correlate, Exiting the process")
    #    exit()

    update_null(result_df)
