from datetime import datetime, timedelta
import datetime
from numpy import nan as NaN
from os import scandir as scan_directory
from pandas import DataFrame
from pymysql import connect as mysql_connect
from pymysql.err import OperationalError as PyMySQLOperationalError
from sqlalchemy import create_engine
from sqlalchemy.exc import OperationalError as SQLAlchemyOperationalError
from sys import exit as exit_python
from tabulate import tabulate
import pandas as pd
import json
import os
import yaml
import sys
import pymysql
import time
import ssl
import requests
import hvac
from cryptography.fernet import Fernet
import time



def read_yaml():
    """ A function to read YAML file"""
    with open('/config/config.yml') as f:
        config = yaml.safe_load(f)

    return config

def check_create_folder(path, folder_name):
    folder_path=path+folder_name
    #print(folder_path)
    if not(os.path.exists(folder_path)):
        #print(folder_name,'not present')
        os.makedirs(folder_path)
def create_mysql_connection(username,passwd,hostname,db_name,port_number):
    url = "https://s3.amazonaws.com/rds-downloads/rds-combined-ca-bundle.pem"
    filename = "rds-combined-ca-bundle.pem"
    response = requests.get(url,verify=False)

    with open (filename, "wb") as f:
        f.write(response.content)

    # SSL_CA = os.path.abspath(filename)
    SSL_CA = filename
    print (SSL_CA)
    try:
        cnx = mysql_connect(user=username, password=passwd, host=hostname, database=db_name, port=port_number,autocommit=True,ssl_ca=SSL_CA)
    except PyMySQLOperationalError as err:
        err.errno = err.args[0]
        if err.errno == 1044:
            print("ERROR: Access is denied to the user '" + username + "' on the database called '"+ db_name + "'.")
            print("Please validate that said user has the correct level of access.")
            exit_python()
        elif err.errno == 1045:
            print("ERROR: Access is denied to the user '" + username + "' on host '" + hostname + "'.")
            print("Please validate that the username and password are correct.")
            exit_python()
        elif err.errno == 1049:
            print("ERROR: The database called '" + db_name + "'does not exist.")
            print("Please validate that database name is spelled correctly and exists.")
            exit_python()
        elif err.errno == 2003:
            print("ERROR: Unable to connect to host '"+ hostname + "' on port '" + str(port_number) + "'.")
            print("Please validate your network connectivity and that the hostname and port is correct.")
            exit_python()
        else:
            print("ERROR: Unhandled MySQL Error.")
            print(err)
            exit_python()
    else:
        return cnx

##################################################
#
#	name: 	create_mysql_engine
# 	desc:	function that creates a SQLAlchemy connection engine object.
#			The engine is used by pandas DataFrame's to_sql function
#			to insert DataFrames into MySQL tables.
#	args:
#			username	- username of user in MySQL
#			passwd		- password of user in MySQL
#			hostname	- hostname of the MySQL Server
#			db_name		- database name in the MySQL Server
#			port_number	- port number of the MySQL Server
#	returns:
#			engine		- A SQLAlchemy Engine object
#
#################################################
def create_mysql_engine(username,passwd,hostname,db_name,port_number):
    try:
        ca_path = "rds-combined-ca-bundle.pem"
        ssl_args = {'ssl_ca': ca_path}
        engine = create_engine(url="mysql+pymysql://" + username + ":" + passwd + "@" + hostname + ":" + str(port_number) + "/" + db_name,execution_options={"isolation_level": "AUTOCOMMIT"},connect_args=ssl_args)
        cnx = engine.connect()
    except SQLAlchemyOperationalError as err:
        err.errno = int(err.args[0].split(") (")[1].split(",")[0])
        if err.errno == 1044:
            print("ERROR: Access is denied to the user '" + username + "' on the database called '"+ db_name + "'.")
            print("Please validate that said user has the correct level of access.")
            exit_python()
        elif err.errno == 1045:
            print("ERROR: Access is denied to the user '" + username + "' on host '" + hostname + "'.")
            print("Please validate that the username and password are correct.")
            exit_python()
        elif err.errno == 1049:
            print("ERROR: The database called '" + db_name + "'does not exist.")
            print("Please validate that database name is spelled correctly and exists.")
            exit_python()
        elif err.errno == 2003:
            print("ERROR: Unable to connect to host '"+ hostname + "' on port '" + str(port_number) + "'.")
            print("Please validate your network connectivity and that the hostname and port is correct.")
            exit_python()
        else:
            print("ERROR: Unhandled MySQL Error.")
            print(err)
            exit_python()
    else:
        cnx.close()
        return engine

def get_db_connection(vault_url,vault_key):

    client = hvac.Client(
    url=vault_url,
    verify = False,
    token=vault_key,
    )
    db_response = client.secrets.kv.read_secret_version(path='orchestraidb')
    
    return db_response

def connect_to_mysql(username,passwd,hostname,db_name,port_number):
    cnx = create_mysql_connection(username,passwd,hostname,db_name,port_number)
    engine = create_mysql_engine(username,passwd,hostname,db_name,port_number)
    return cnx, engine

def clean_folder(path):
    for f in os.listdir(path):
        os.remove(os.path.join(path, f))

if __name__ == "__main__":
    config = read_yaml()
    vault_url = config['platformops']['vault_url']
    vault_key = config['platformops']['vault_key']
    f = config['platformops']['key']
    f = Fernet(f)
    vault_key = f.decrypt(vault_key.encode()).decode()
    key_url = config['platformops']['key_url']

    db_details = get_db_connection(vault_url,vault_key)

    jdbc_url = db_details['data']['data']['jdbc-url']
    db_username = db_details['data']['data']['username']
    db_passowrd = db_details['data']['data']['password']
    db_host = jdbc_url.split("/")[-2].split(":")[0]
    db_name = jdbc_url.split("/")[-1]

    mysql_cnx, mysql_engine = connect_to_mysql(db_username,db_passowrd,db_host,db_name,3306)
    mysql_cursor = mysql_cnx.cursor()

    limit = config['limit']

    prominance = config['prominance']
    # prominance = False

    mysql_cursor.callproc('getSegmentedTimeWindowPrediction')
    time_window_id = mysql_cursor.fetchone()

    mysql_cursor.callproc("getCorrelatedServiceInTimeWindow", [time_window_id[0]])
    service_id = mysql_cursor.fetchall()

    if len(service_id) == 0:
        job_running = 0
        # sys.exit()

    print(service_id)
    clean_folder('Correlation_map/input_correlation')
    service_list = []
    current_service_list = config['current_live_service']
    for i in service_id:
        if str(i[0]) not in current_service_list:
            continue
        job_running = 0
        service_query = "SELECT service_name FROM `services` WHERE service_id = %s "
        mysql_cursor.execute(service_query, (str(i[0])))
        service_name = mysql_cursor.fetchone()[0]
        # print("____service")
        # print(service_name)
        mysql_cursor.execute(
            "select outcome_metric_name from service_to_outcome_metric_mapping where service_id = %s;",
            (str(i[0]),))
        default_outcome_metric = mysql_cursor.fetchall()
        default_outcome_metric_list = []
        for item in default_outcome_metric:
            default_outcome_metric_list.append(item[0])
        # print(default_outcome_metric_list)

        sql_query = """call getCorrelationsDataInputs({service_id},{time_window_id});""".format(service_id=str(i[0]),
                                                                                                time_window_id=
                                                                                                time_window_id[0])
        # print(sql_query)
        df = pd.read_sql_query(sql_query, mysql_cnx)
        # print(df)
        outcome_list = list(df['outcome_metric_name'].astype(str).unique())
        # print(outcome_list)

        # print(df)
        time.sleep(10)
        print('completed sleep of 10s')
        if df.empty:
            print('no data from db')
            continue
        if 'anomaly_slowness' in df.columns:
            print('Sum of anomaly_slowness: ', df['anomaly_slowness'].sum())
        if 'anomaly_failure' in df.columns:
            print('Sum of anomaly_failure: ', df['anomaly_failure'].sum())
        # print(df)
        # df['job_details_id'] = df.index
        df = df.set_index('metric_timestamp')
        df['metric_timestamp'] = pd.to_datetime(df.index)
        print(df)
        pivot_df = df[
            ['metric_name', 'metric_timestamp', 'metric_value', 'job_details_id', 'start_time', 'end_time']].copy()
        # df2 = df[['job_details_id', 'job_name', 'anomaly_failure', 'anomaly_slowness']]
        pivot_df.drop_duplicates(inplace=True)
        pivot_df = pivot_df.set_index('metric_timestamp')
        output_df = pivot_df.pivot_table(index=[df.index, 'job_details_id'], columns="metric_name",
                                         values="metric_value",
                                         aggfunc='first')
        # df3.columns = df3.columns.droplevel(0)
        output_df.columns.name = None
        output_df = output_df.reset_index(level=("metric_timestamp",))
        output_df.reset_index(inplace=True)
        # df4=df3.join(df2,how='left')
        # service_name=check_service(service_name,service_list)
        # print(service_name)
        service_list.append(service_name)
        name = f'Correlation_map/input_correlation/pearson_input_{service_name}_{datetime.datetime.now().strftime("%H%M%m%d%Y")}.csv'.format(
            service_name=service_name)
        # df4=pd.concat([df3,df2],keys='job_details_id',axis=1)
        # print(df2)
        # print(output_df)
        # output_df.to_csv(name, index=False)

        for outcome_metric in outcome_list:
            if outcome_metric == 'None':
                continue
            outcome_df = df[['outcome_metric_name', 'job_details_id']].copy()
            outcome_df = outcome_df.loc[outcome_df['outcome_metric_name'] == outcome_metric]
            outcome_df[outcome_metric] = 1
            outcome_df.drop(['outcome_metric_name'], inplace=True, axis=1)

            output_df = pd.merge(output_df, outcome_df, how="left", on="job_details_id")
            output_df[outcome_metric] = output_df[outcome_metric].fillna(0)

            first_column = output_df.pop(outcome_metric)
            output_df.insert(0, outcome_metric, first_column)

        # df4 = df3.join(df2, on='job_details_id')
        # df4.drop(['job_details_id'],axis=1,inplace=True)
        # df4.reset_index(inplace=True)
        # df4['temp_index']=df4.index
        # print("___________df4")
        # print(df4.info())
        # df4.drop(['job_name'],inplace=True,axis=1)
        column_list = output_df.columns
        # print(column_list)
        column_list = column_list.to_list()

        for default_outcome_metric in default_outcome_metric_list:
            if default_outcome_metric not in column_list:
                output_df.insert(0, default_outcome_metric, 0)
                column_list.append(default_outcome_metric)

        if 'slowness' in column_list:
            output_df = output_df.rename(columns={'slowness': 'anomaly_slowness'})
        if 'failure' in column_list:
            output_df = output_df.rename(columns={'failure': 'anomaly_failure'})

        anomaly_cols = [col for col in output_df.columns if 'anomaly' in col]
        print('anomaly status')
        print(output_df[anomaly_cols].sum())

        print(name)
        output_df.to_csv(name, index = False)

        print('services running:', service_list)

    # Close the database connection
    mysql_cnx.close()
