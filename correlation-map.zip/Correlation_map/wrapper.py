import entry
import os
from os import scandir as scan_directory
print("running pearson")
#entry.main('RFE')
entry.main('probability_correlation')

# os.system('python .\\Correlation_map\\update_predicited_table.py')
