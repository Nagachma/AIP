# Load DB service 

## Dev setup (mac)
1. Install Python 3.10
2. run ```poetry shell```
3. run ```poetry install```
4. run ```python3 --version``` to confirm version 
5. run ```python3.10 -m loadservice.main``` to run service
6. run ```poetry build``` to share wheel file
7. run ```poetry shell``` use next time onwards to start working

## Testing (Load DB)
1. Test Data can be inserted using 
``` 
POST http://0.0.0.0:8080/loadservice/load_db/

Input:
{
  "dataframe_dict": {"JSON Converted Input DataFrame"},
  "service": "<Service Name as per the DB>",
  "env": "<Env for which the data is collected>",
  "metric_timestamp": "<Timestamp of the data collected>"
}

```
## Known issues 
1. New Inventory is not getting added due to service ID issue

## General Info:

# Input format:

{
    'dataframe_dict': <Dict>,
    'service': <str>,
    'env': <str>,
    'metric_timestamp': <str>
}

Input format for the Post method should be as above format, where

dataframe_dict - Dict converted format of Input dataframe which need to be updated to XOPS Table.
service - Exact service name as per the XOPS Table.
env - Exact Environment name for which the service data is being collected.
metric_timestamp - Timestamp for which the data is being collected. (Format: 'yyyy-mm-dd hh:mm:ss')

# Output Validation:
    - Validate the below tables:
        - metric_processor_output_time
        - servicewise_job_details
        - raw_metric
        - raw_metric_text
        - metrics (Optional)
        - inventory (Optional)
