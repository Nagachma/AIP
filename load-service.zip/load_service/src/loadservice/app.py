from fastapi import FastAPI

from loadservice.router.load_router import loaddbrouter

app = FastAPI()
app.include_router(loaddbrouter, tags=["inventory"], prefix="/loadservice")

@app.get("/", tags=["Root"])
async def read_root() -> dict:
    return {"message": "Welcome to your beanie powered metric-service!"}
