from fastapi import APIRouter, Body
from pydantic import BaseModel
from loadservice.server.db_insertion import *
import yaml
import logging

logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

loaddbrouter = APIRouter()

class ProcessDataInput(BaseModel):
    dataframe_dict: dict
    service: str
    env: str
    metric_timestamp: str

class ConnectorDataInput(BaseModel):
    start_time: str
    end_time: str
    service: str

class ProcessOutput(BaseModel):
    Result: str

def extract_yaml():
    """ A function to read YAML file"""
    filename = "/app/config/config.yaml"
    logger.info (filename)
    with open(filename) as f:
        config = yaml.safe_load(f)

    return config

@loaddbrouter.post("/load_db")
async def load_data(data: ProcessDataInput = Body(...)):
    # Reading the Config
    config = extract_yaml()

    # Input pattern of the Post Method call
    dataframe_json = data.dataframe_dict
    service_name = data.service
    environment_name = data.env
    timestamp = data.metric_timestamp

    # Data Ingesting to servicewise_job_details Table
    write_job_metrics_to_mysql(config,dataframe_json, service_name, environment_name,timestamp)
    # Data Ingesting to Raw_Metric and Raw_Metric_Text Table
    write_metrics_to_mysql(config,dataframe_json, service_name, environment_name,timestamp)