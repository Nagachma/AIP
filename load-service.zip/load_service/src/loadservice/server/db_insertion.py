from pymysql import connect as mysql_connect
from numpy import nan as NaN
from pymysql.err import OperationalError as PyMySQLOperationalError
from sqlalchemy import create_engine
from sqlalchemy.exc import OperationalError as SQLAlchemyOperationalError
from sys import exit as exit_python
from tabulate import tabulate
from datetime import datetime, timedelta, timezone
import requests
import logging
import yaml
import hvac
from pandas import DataFrame
from cryptography.fernet import Fernet

logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def create_mysql_connection(username, passwd, hostname, db_name, port_number):
    url = "https://s3.amazonaws.com/rds-downloads/rds-combined-ca-bundle.pem"
    filename = "rds-combined-ca-bundle.pem"

    try:
        response = requests.get(url, verify=False)
    except error:
        logger.info(error)

    with open(filename, "wb") as f:
        f.write(response.content)

    SSL_CA = filename
    try:
        cnx = mysql_connect(user=username, password=passwd, host=hostname, database=db_name, port=port_number,
                            autocommit=True, ssl_ca=SSL_CA)
    except PyMySQLOperationalError as err:
        err.errno = err.args[0]
        if err.errno == 1044:
            logger.info(
                "ERROR: Access is denied to the user '" + username + "' on the database called '" + db_name + "'.")
            logger.info("Please validate that said user has the correct level of access.")
            exit_python()
        elif err.errno == 1045:
            logger.info("ERROR: Access is denied to the user '" + username + "' on host '" + hostname + "'.")
            logger.info("Please validate that the username and password are correct.")
            exit_python()
        elif err.errno == 1049:
            logger.info("ERROR: The database called '" + db_name + "'does not exist.")
            logger.info("Please validate that database name is spelled correctly and exists.")
            exit_python()
        elif err.errno == 2003:
            logger.info("ERROR: Unable to connect to host '" + hostname + "' on port '" + str(port_number) + "'.")
            logger.info("Please validate your network connectivity and that the hostname and port is correct.")
            exit_python()
        else:
            logger.info("ERROR: Unhandled MySQL Error.")
            logger.info(err)
            exit_python()
    else:
        return cnx


##################################################
#
#	name: 	create_mysql_engine
# 	desc:	function that creates a SQLAlchemy connection engine object.
#			The engine is used by pandas DataFrame's to_sql function
#			to insert DataFrames into MySQL tables.
#	args:
#			username	- username of user in MySQL
#			passwd		- password of user in MySQL
#			hostname	- hostname of the MySQL Server
#			db_name		- database name in the MySQL Server
#			port_number	- port number of the MySQL Server
#	returns:
#			engine		- A SQLAlchemy Engine object
#
#################################################
def create_mysql_engine(username, passwd, hostname, db_name, port_number):
    try:
        ca_path = "rds-combined-ca-bundle.pem"
        ssl_args = {'ssl_ca': ca_path}
        engine = create_engine(
            url="mysql+pymysql://" + username + ":" + passwd + "@" + hostname + ":" + str(port_number) + "/" + db_name,
            execution_options={"isolation_level": "AUTOCOMMIT"}, connect_args=ssl_args)
        cnx = engine.connect()
    except SQLAlchemyOperationalError as err:
        err.errno = int(err.args[0].split(") (")[1].split(",")[0])
        if err.errno == 1044:
            logger.info(
                "ERROR: Access is denied to the user '" + username + "' on the database called '" + db_name + "'.")
            logger.info("Please validate that said user has the correct level of access.")
            exit_python()
        elif err.errno == 1045:
            logger.info("ERROR: Access is denied to the user '" + username + "' on host '" + hostname + "'.")
            logger.info("Please validate that the username and password are correct.")
            exit_python()
        elif err.errno == 1049:
            logger.info("ERROR: The database called '" + db_name + "'does not exist.")
            logger.info("Please validate that database name is spelled correctly and exists.")
            exit_python()
        elif err.errno == 2003:
            logger.info("ERROR: Unable to connect to host '" + hostname + "' on port '" + str(port_number) + "'.")
            logger.info("Please validate your network connectivity and that the hostname and port is correct.")
            exit_python()
        else:
            logger.info("ERROR: Unhandled MySQL Error.")
            logger.info(err)
            exit_python()
    else:
        cnx.close()
        return engine


def connect_to_mysql(username, passwd, hostname, db_name, port_number):
    cnx = create_mysql_connection(username, passwd, hostname, db_name, port_number)
    engine = create_mysql_engine(username, passwd, hostname, db_name, port_number)
    return cnx, engine

def read_yaml(filename):
    """ A function to read YAML file"""
    with open(filename) as f:
        config = yaml.safe_load(f)

    return config


def get_db_connection(vault_url, vault_key):
    client = hvac.Client(
        url=vault_url,
        verify=False,
        token=vault_key,
    )
    db_response = client.secrets.kv.read_secret_version(path='orchestraidb')

    return db_response

def isNaN(variable):
    return variable != variable

# Getting the details from Vault and cconnecting to DB

global config
config = read_yaml('/app/config/config.yaml')

def db_connection():
    vault_url = config['platformops']['vault_url']
    vault_key = config['platformops']['vault_key']
    f = config['platformops']['key']
    f = Fernet(f)
    vault_key = f.decrypt(vault_key.encode()).decode()
    key_url = config['platformops']['key_url']

    db_details = get_db_connection(vault_url, vault_key)

    jdbc_url = db_details['data']['data']['jdbc-url']
    db_username = db_details['data']['data']['username']
    db_passowrd = db_details['data']['data']['password']
    db_host = jdbc_url.split("/")[-2].split(":")[0]
    db_name = jdbc_url.split("/")[-1]
    # db_username = "admin"
    # db_passowrd = "P7eqBfg1kk5CU2p2PShL"
    # db_host = "orcaitessrds01.cdbmarpvctiu.us-east-1.rds.amazonaws.com"
    # db_name = "orchestrai_metered"

    mysql_cnx, mysql_engine = connect_to_mysql(db_username, db_passowrd, db_host, db_name, 3306)
    # global mysql_cursor
    mysql_cursor = mysql_cnx.cursor()
    return mysql_cursor,mysql_engine

def get_execution_id(mysql_cursor):
    # mysql_cursor = db_connection()
    cur_date = datetime.now(timezone.utc)
    query = "insert into metrics_processor_output_time (execution_timestamp) values ( %s )"
    mysql_cursor.execute(query, (cur_date.strftime("%Y-%m-%d %H:%M:%S"),))
    query1 = "select execution_id from metrics_processor_output_time where execution_timestamp= %s "
    mysql_cursor.execute(query1, (cur_date.strftime("%Y-%m-%d %H:%M:%S"),))
    execution_id = mysql_cursor.fetchone()[0]
    # mysql_cnx.close()
    return execution_id

def get_metric_id(metric_name, service_name,mysql_cursor):
    # mysql_cursor = db_connection()
    service_id_query = "select service_id from services where service_name = %s"
    mysql_cursor.execute(service_id_query, (service_name, ))
    service_id = mysql_cursor.fetchone()[0]

    query1 = "select metric_id from metrics where metric_name= %s and service_id = %s"
    mysql_cursor.execute(query1, (metric_name, str(service_id)))
    metric_id = mysql_cursor.fetchall()
    if len(metric_id) > 0:
        metric_id = metric_id[0][0]
    else:
        # logger.info (subkey)
        query2 = "insert into metrics (service_id,metric_name,inserted_by,metric_incoming_source) values (%s,%s,'Metrics_processor','Appops')"
        mysql_cursor.execute(query2, (str(service_id), metric_name))
        query3 = "select metric_id from metrics where metric_name=%s and service_id = %s"
        mysql_cursor.execute(query3, (metric_name, str(service_id)))
        metric_id = mysql_cursor.fetchone()[0]

    return metric_id

def get_inventory_id(job_name, service_onboard_id,env_name,mysql_cursor):
    # mysql_cursor = db_connection()
    query2 = "select inventory_id from inventory where inventory_name= %s and service_onboard_id= %s"
    mysql_cursor.execute(query2,(job_name, service_onboard_id))
    inventory_id = mysql_cursor.fetchall()

    service_id_query = "select service_id from service_onboarded where service_onboard_id = %s"
    mysql_cursor.execute(service_id_query, (service_onboard_id, ))
    service_id = mysql_cursor.fetchone()[0]

    if len(inventory_id) > 0:
        inventory_id = int(inventory_id[0][0])
    else:
        ### THIS WILL EVENTUALLY NEED environment_id AS WELL
        environment_id_query = "select environment_id from environments where environment_name= %s"
        mysql_cursor.execute(environment_id_query, (env_name, ))
        environment_id = mysql_cursor.fetchone()[0]

        mysql_cursor.execute("select max(inventory_scan_group * 1) from inventory_scans")
        scan_group = mysql_cursor.fetchone()[0]
        scan_group = int(scan_group) + 1

        start_time = datetime.now(timezone.utc)
        query3 = "INSERT INTO inventory_scans (inventory_scan_group, environment_id, service_id, inventory_scan_started, inventory_scan_ended, is_completed, inserted_by) VALUES (%s, %s, %s, %s, %s, 0, 'Metrics Processer Python Code')"
        print (query3, (str(scan_group), str(environment_id), str(service_id),start_time.strftime("%Y-%m-%d %H:%M:%S"), start_time.strftime("%Y-%m-%d %H:%M:%S")))
        mysql_cursor.execute(query3, (
            str(scan_group), str(environment_id), str(service_id),start_time.strftime("%Y-%m-%d %H:%M:%S"), start_time.strftime("%Y-%m-%d %H:%M:%S")))
        mysql_cursor.execute("select max(inventory_scan_id) from inventory_scans")
        inventory_scan_id = int(mysql_cursor.fetchone()[0])
            # group = 1
        query4 = "insert into inventory (service_onboard_id,service_id,environment_id,inventory_name,is_active,inserted_by) values (%s, %s, %s, %s,1,'Metrics Processer Python Code')"
        mysql_cursor.execute(query4, (
            str(service_onboard_id), str(service_id),
            str(environment_id), job_name))
        mysql_cursor.execute("select max(inventory_id) from inventory")
        inventory_id = int(mysql_cursor.fetchone()[0])
        query5 = "insert into inventory_categories (inventory_id,category_id,is_active,inserted_by,updated_by) values (%s,4,1,'Metric Processor','Metric Processor')"
        mysql_cursor.execute(query5, (str(inventory_id),))
        query6 = "insert into inventory_scan_details (inventory_scan_id,inventory_id,inserted_by) values (" + str(
            inventory_scan_id) + "," + str(inventory_id) + ",'Metrics Processer Python Code')"
        mysql_cursor.execute(query6, (str(inventory_scan_id), str(inventory_id)))
        end_time = datetime.now(timezone.utc)
        query7 = "UPDATE inventory_scans SET is_completed = 1, inventory_scan_ended = %s WHERE inventory_scan_group = %s"
        mysql_cursor.execute(query7, (end_time.strftime("%Y-%m-%d %H:%M:%S"), str(scan_group)))

    return inventory_id

def write_metrics_to_mysql(config,metric_dict, service_name, env_name, metric_timestamp):
    mysql_cursor,mysql_engine = db_connection()
    metrics_df_data = {"job_details_id": [], "metric_id": [], "raw_value": [], "metric_timestamp": [], "inventory_id": []}
    metrics_varchar_df_data = {"job_details_id": [], "metric_id": [], "raw_text": [], "metric_timestamp": [],
                               "inventory_id": []}

    service_id_query = "select service_id from services where service_name = %s"
    mysql_cursor.execute(service_id_query, (service_name))
    service_id = mysql_cursor.fetchall()

    environment_id_query = "select environment_id from environments where environment_name= %s"
    mysql_cursor.execute(environment_id_query, (env_name))
    environment_id = mysql_cursor.fetchone()[0]

    # Get the Service_onboard_id for the service
    service_onboard_query = ("select service_onboard_id from service_onboarded where service_id = %s and environment_id = %s ")

    print (service_onboard_query, (service_id, environment_id))

    mysql_cursor.execute(service_onboard_query, (service_id, environment_id))
    service_onboard_id = mysql_cursor.fetchone()[0]

    keys_list = list(metric_dict[config[service_name]['JobName']].keys())
    metric_list = list(metric_dict.keys())

    # Black List to Avoid few data like Job_name, Run_Id inserting to Raw_Metric tables
    black_list = config[service_name]['Blacklist']

    for i in keys_list:
        # Fetch Job Details ID
        query = "select job_details_id from servicewise_job_details where run_id= %s and metric_timestamp= %s and job_name = %s"
        mysql_cursor.execute(query, (metric_dict[config[service_name]['RunId']][i], metric_timestamp,
                                     metric_dict[config[service_name]['JobName']][i]))
        job_id = mysql_cursor.fetchone()[0]
        for j in metric_list:

            if j not in black_list:

                # Get the Metric ID
                metric_id = get_metric_id(j,service_name,mysql_cursor)

                # Get the Inventory ID
                inventory_id = get_inventory_id(metric_dict[config[service_name]['JobName']][i],service_onboard_id,env_name,mysql_cursor)

                # Exception block to load differentiate the Int and Text data
                try:
                    print ("Metric Name: "+str(j)+" Raw_value: "+str(metric_dict[j][i]))
                    if isNaN(metric_dict[j][i]):
                        print ("Inside isNaN")
                        float_metric = -1
                    elif metric_dict[j][i] == None:
                        float_metric = -1
                    else:
                        if str(metric_dict[j][i]).strip() == "":
                            float_metric = NaN

                        else:
                            float_metric = float(metric_dict[j][i])

                    metrics_df_data['job_details_id'].append(job_id)
                    metrics_df_data['metric_id'].append(metric_id)
                    metrics_df_data['raw_value'].append(float_metric)
                    metrics_df_data['metric_timestamp'].append(metric_timestamp)
                    metrics_df_data['inventory_id'].append(inventory_id)

                except ValueError:
                    metrics_varchar_df_data['job_details_id'].append(job_id)
                    metrics_varchar_df_data['metric_id'].append(metric_id)
                    metrics_varchar_df_data['raw_text'].append(metric_dict[j][i])
                    metrics_varchar_df_data['metric_timestamp'].append(metric_timestamp)
                    metrics_varchar_df_data['inventory_id'].append(inventory_id)


    print(tabulate(metrics_df_data, headers=metrics_df_data.keys(), tablefmt="psql"))
    print(tabulate(metrics_varchar_df_data, headers=metrics_varchar_df_data.keys(), tablefmt="psql"))

    # Pushing the data to Raw_Metric and Raw_Metric_Text Table
    df1 = DataFrame(metrics_df_data)
    df2 = DataFrame(metrics_varchar_df_data)
    df1.to_sql(name="raw_metric", con=mysql_engine, if_exists="append", index=False, method="multi")
    df2.to_sql(name="raw_metric_text", con=mysql_engine, if_exists="append", index=False, method="multi")

def write_job_metrics_to_mysql(config,metric_dict, service_name, env_name, metric_timestamp):
    mysql_cursor,mysql_engine = db_connection()
    jobdetails_df_data = {"service_onboard_id": [], "job_name": [], "run_id": [], "execution_id": [],"metric_timestamp": [],"inserted_by": []}
    #"job_start_timestamp": [], "job_end_timestamp": [], "inserted_by": []}

    # Get the Service_onboard_id for the service
    service_onboard_query = ("select service_onboard_id from service_onboarded where service_id = "
                             "(select service_id from services where service_name = %s ) and "
                             "environment_id = (select environment_id from environments where environment_name = %s )")

    mysql_cursor.execute(service_onboard_query,(service_name,env_name))
    service_onboard_id = mysql_cursor.fetchone()[0]

    # Fetch the Latest Execution_id
    execution_id = get_execution_id(mysql_cursor)

    keys_list = list(metric_dict[config[service_name]['JobName']].keys())
    metric_list = list(metric_dict.keys())
    print (metric_list)
    # Updating the jobdetails_df_data Dict
    for i in keys_list:
        jobdetails_df_data['job_name'].append(metric_dict[config[service_name]['JobName']][i])
        jobdetails_df_data['run_id'].append(metric_dict[config[service_name]['RunId']][i])
        jobdetails_df_data['service_onboard_id'].append(service_onboard_id)
        jobdetails_df_data['execution_id'].append(execution_id)
        jobdetails_df_data['metric_timestamp'].append(metric_timestamp)
        jobdetails_df_data['inserted_by'].append("Metric Insertion API")

    # print (jobdetails_df_data)
    print (tabulate(jobdetails_df_data, headers=jobdetails_df_data.keys(), tablefmt="psql"))

    # Pushing the data to Servicewise_job_details Table
    df = DataFrame(jobdetails_df_data)
    df.to_sql(name="servicewise_job_details", con=mysql_engine, if_exists="append", index=False, method="multi")
