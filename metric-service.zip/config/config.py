import os

from pydantic import BaseSettings, Field, BaseModel

# Get the Mongo URL from kubectl secrets
class Settings(BaseSettings):
    db_url: str = Field(<Add the Mongo URL>, env='DATABASE_URL')

class Service(BaseSettings):
    service_list: list = []

class Standalone(BaseModel):
    redshift: Dict
    informaticajvm: Dict
    ec2: Dict
    powerexchangejvm: Dict

settings = Settings()
services = Service()
standalone = Standalone()
