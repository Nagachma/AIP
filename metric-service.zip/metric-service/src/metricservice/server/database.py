from beanie import init_beanie
import motor.motor_asyncio
import os
import sys
import hvac
from cryptography.fernet import Fernet
import logging

from metricservice.server.models.hyperscale_sql import hyperscale_sql
from metricservice.server.models.sqlserver import sqlserver
from metricservice.server.models.stonebranch import stonebranch


def get_mongo_db(vault_url, vault_key, path):
    client = hvac.Client(
        url=vault_url,
        verify=False,
        token=vault_key,
    )

    print (path)
    mongo_url = client.secrets.kv.read_secret_version(path='mongodb')

    return mongo_url

# from metricservice.config import settings
from metricservice.server.models.adls import adls
from metricservice.server.models.glue import glue
from metricservice.server.models.s3 import s3
from metricservice.server.models.Lambda import Lambda
from metricservice.server.models.sagemaker import sagemaker
from metricservice.server.models.aurora_postgres import aurorapostgres
from metricservice.server.models.glueInvent import glue_custom
from metricservice.server.models.synapse import synapse
from metricservice.server.models.datafactory import datafactory
from metricservice.server.models.aks import aks
from metricservice.server.models.tableau import tableau
from metricservice.server.models.databricks import databricks
from metricservice.server.models.azure_ml import azure_ml
from metricservice.server.models.azurerediscache import azurerediscache
from metricservice.server.models.azure_sqlserver import azure_sqlserver
from metricservice.server.models.aws import aws_inventory
from metricservice.server.models.cloudstorage import cloudstorage
from metricservice.server.models.azure_inventory import azure_inventory
from metricservice.server.models.dataflow import dataflow
from metricservice.server.models.bigquery import bigquery
from metricservice.server.models.cloud_scheduler import cloud_scheduler
from metricservice.server.models.cloud_composer import cloud_composer
from metricservice.server.models.gcp_inventory import gcp_inventory
from metricservice.server.models.vertexai import vertexai
# from metricservice.server.models.standalone_inventory import standalone_inventory
from metricservice.server.models.redshift import redshift
from metricservice.server.models.rdsoracle import rdsoracle
from metricservice.server.models.ropen import ropen
from metricservice.server.models.ec2 import ec2
# from metricservice.server.models.informatica_powerexchange import informaticapowerexchange
from metricservice.server.models.informatica_jvm import informaticajvm
from metricservice.server.models.powerexchange_jvm import powerexchangejvm
from metricservice.server.models.informatica_jvmtest import informaticajvmtest
from metricservice.server.models.awsdatabricks import awsdatabricks
from metricservice.server.models.postgres import postgres
from metricservice.server.models.rapidv12 import rapidv12
from metricservice.server.models.informatica import informatica
from metricservice.server.models.rds_postgres import rds_postgres

current_dir = os.getcwd()
print ("Current: "+ str(current_dir))
parent_dir = os.path.dirname(current_dir)
print ("Parent Dir: "+ str(parent_dir))
sys.path.append("/app/dist/config")
from config import settings, services

sys.path.append("/app/dist/standalone_model")
from standalone_inventory import standalone_inventory
from pre_scan_inventory import pre_scan_inventory

# sys.path.append("/app/dist/standalone_route")
# from standalone_inventory import standalone_inventory

# calling vault
vault_url = settings.vault_url
vault_key = settings.vault_key
f = settings.key
path = settings.path
f = Fernet(f)
vault_key = f.decrypt(vault_key.encode()).decode()

# getting api_details
mongo_path = get_mongo_db(vault_url, vault_key, path)
mongo_url = mongo_path['data']['data']['mongo_url']
mongo_db = mongo_path['data']['data']['mongo_db']
mongo_connection_string = mongo_url+"/"+mongo_db

async def init_db():
    client = motor.motor_asyncio.AsyncIOMotorClient(
        mongo_connection_string
    )
    await init_beanie(database=client.get_default_database(), document_models=[glue, s3, awsdatabricks, Lambda, sagemaker, aurorapostgres, glue_custom, synapse, adls, aks, tableau, databricks, datafactory, azure_ml, aws_inventory, cloudstorage, azure_inventory, dataflow, bigquery, cloud_scheduler, azure_sqlserver, cloud_composer, gcp_inventory, vertexai,informatica,standalone_inventory,redshift,rdsoracle,ropen,ec2,informaticajvm,powerexchangejvm,informaticajvmtest,postgres,rapidv12,pre_scan_inventory, sqlserver, azurerediscache,hyperscale_sql,stonebranch, rds_postgres])

