from datetime import datetime
from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel , Field
from typing import Optional,Dict,List

class Run(BaseModel):
    Interval: Optional[datetime]
    start_on: Optional[datetime] #= Field(None, alias='start_on')
    completed_on: Optional[datetime] #= Field(None, alias='completed_on')
    BilledDuration: Optional[float] = Field(None, alias='Billed Duration (ms)')
    MemorySize: Optional[float] = Field(None, alias='Memory Size (MB)')
    MaxMemoryUsed: Optional[float] = Field(None, alias='Max Memory Used (MB)')
    UniqueID: Optional[str] = Field(None, alias='Unique ID')
    
class Function(BaseModel):
    functionName: str
    start_time: Optional[datetime]
    end_time: Optional[datetime]
    runs: Optional[List[Run]]
    Duration: Optional[float]
    ConcurrentExecutions: Optional[float]
    Throttles: Optional[float]
    Invocations: Optional[float]
    Errors: Optional[float]
    ProvisionedConcurrencyUtilization: Optional[float]
    PostRuntimeExtensionsDuration: Optional[float]
    ProvisionedConcurrencyInvocations: Optional[int]
    ProvisionedConcurrencySpilloverInvocations: Optional[int]
    ProvisionedConcurrentExecutions: Optional[int]

class Source(BaseModel):
    region: str
    env: str
    service_provider: str

class Lambda(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    functions: List[Function] = []

    class Settings:
        name: "Lambda"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field = "source",
            granularity=Granularity.minutes  # Optional
            #expire_after_seconds=2  # Optional
        )
