from datetime import datetime
from typing import Optional, List

from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel, Field

class Event(BaseModel):
    event_time:Optional[str]
    UID:Optional[str]
    OperationName:Optional[str]
    StatusCode:Optional[str]
    StatusText:Optional[str]
    DurationMs:Optional[str]
    ServerLatencyMs:Optional[str]
class Metrics(BaseModel):
    # account_name: str
    account_name: Optional[str] = Field(None, alias='account_name')
    timestamp: Optional[datetime] = Field(None, alias='timestamp')
    start_time: Optional[datetime] = Field(None, alias='start_time')
    end_time: Optional[datetime] = Field(None, alias='end_time')
    TotalStorage: Optional[float] = Field(None, alias='TotalStorage')
    DataRead: Optional[float] = Field(None, alias='DataRead')
    DataWritten: Optional[float] = Field(None, alias='DataWritten')
    ReadRequests: Optional[float] = Field(None, alias='ReadRequests')
    WriteRequests: Optional[float] = Field(None, alias='WriteRequests')
    Availability: Optional[float] = Field(None, alias='Availability')
    BlobCapacity: Optional[float] = Field(None, alias='BlobCapacity')
    BlobCount: Optional[float] = Field(None, alias='BlobCount')
    ContainerCount: Optional[float] = Field(None, alias='ContainerCount')
    Egress: Optional[float] = Field(None, alias='Egress')
    IndexCapacity: Optional[float] = Field(None, alias='IndexCapacity')
    Ingress: Optional[float] = Field(None, alias='Ingress')
    SuccessE2ELatency: Optional[float] = Field(None, alias='SuccessE2ELatency')
    SuccessServerLatency: Optional[float] = Field(None, alias='SuccessServerLatency')
    Transactions: Optional[float] = Field(None, alias='Transactions')
    hasFailure: Optional[bool]
    error_events: List[Event]=[]



class Source(BaseModel):
    region: str = Field(None, alias='region')
    env: str = Field(None, alias='prod')
    service_provider: str = Field(None, alias='Azure')


class adls(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    adls1: List[Metrics] = []
    adls2: List[Metrics] = []

    class Settings:
        name: "adls"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field="source",
            granularity=Granularity.minutes  # Optional
            # expire_after_seconds=2  # Optional
        )
