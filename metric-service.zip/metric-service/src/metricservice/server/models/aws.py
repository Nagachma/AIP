from datetime import datetime
from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel , Field
from typing import Optional,Dict,List

class Job(BaseModel):
    jobname: str
    runs = []

class Source(BaseModel):
    region: str
    env: str
    service_provider: str

class active(BaseModel):
    name: str
    LastModifiedOn: Optional[datetime]
    user: str
    Created_On: str

class Dict(BaseModel):
    Active: List[active] = []
    Deleted = []

class aws_inventory(Document):
    # source: Source
    # ts: datetime = Field(default_factory=datetime.now())
    # Inserted_time: str
    Glue: Dict
    Lambda: Dict
    Aurora: Dict
    S3: Dict
    Sagemaker: Dict

    class Settings:
        name: "aws_inventory"
        # timeseries = TimeSeriesConfig(
        #     time_field="ts",  # Required
        #     meta_field = "source",
        #     granularity=Granularity.minutes  # Optional
        #     #expire_after_seconds=2  # Optional
        # )
