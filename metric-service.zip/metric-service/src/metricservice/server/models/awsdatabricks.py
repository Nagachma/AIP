from datetime import datetime
from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel , Field
from typing import Optional,Dict,List

class Task(BaseModel):
    task: Optional[str]
    task_details: Optional[str]

class Job(BaseModel):
    job_id: Optional[str]
    job_run_id: Optional[str]
    job_creator_user_name: Optional[str]
    life_cycle_state: Optional[str]
    result_state: Optional[str]
    state_message: Optional[str]
    ebs_volume_type: Optional[str]
    ebs_volume_count: Optional[str]
    ebs_volume_size: Optional[str]
    job_start_time: Optional[str]
    job_end_time: Optional[str]
    setup_duration: Optional[str]
    execution_duration: Optional[str]
    cleanup_duration: Optional[str]
    run_duration: Optional[str]
    Tasks: Optional[List[Task]]


class Cluster(BaseModel):
    cluster_id: str
    insert_timestamp: Optional[datetime]
    creator_user_name: Optional[str]
    start_timestamp: Optional[str]
    cluster_name: Optional[str]
    availability: Optional[str]
    disk_count: Optional[str]
    disk_size: Optional[str]
    cluster_memory_mb: Optional[str]
    cluster_cores: Optional[str]
    start_time: Optional[datetime]
    last_activity_time: Optional[str]
    last_restarted_time: Optional[str]
    state: Optional[str]
    terminated_time: Optional[str]
    termination_reason: Optional[str]
    termination_status: Optional[str]
    cluster_run_time: Optional[str]
    Jobs: Optional[List[Job]]

class Source(BaseModel):
    region: str
    env: str
    service_provider: str

class awsdatabricks(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    clusters: List[Cluster] = []

    class Settings:
        name: "awsdatabricks"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field = "source",
            granularity=Granularity.minutes  # Optional
            #expire_after_seconds=2  # Optional
        )
