from datetime import datetime
from typing import Optional, List

from beanie import Document
from pydantic import BaseModel, Field


class Active(BaseModel):
    name: str
    lastModifiedOn: Optional[datetime] = Field(None, alias="LastModifiedOn")
    user: Optional[str]
    createdOn: datetime = Field(None, alias="Created_On")

    class Config:
        allow_population_by_field_name = True


class ResourceObject(BaseModel):
    active: Optional[List[Active]] = []
    deleted = []


class azure_inventory(Document):
    ADLSGEN1: Optional[ResourceObject]
    ADLSGEN2: Optional[ResourceObject]
    SQLServer: Optional[ResourceObject]
    SQLServer_Databases: Optional[ResourceObject]
    AzureML_Workspaces: Optional[ResourceObject]
    AzureML_Jobs: Optional[ResourceObject]
    Datafactory_Factories: Optional[ResourceObject]
    Datafactory_Pipelines: Optional[ResourceObject]
    Synapse_Workspaces: Optional[ResourceObject]
    Synapse_SQLPools: Optional[ResourceObject]
    Synapse_BigDataPools: Optional[ResourceObject]
    Databricks_Workspaces: Optional[ResourceObject]
    Databricks_Clusters: Optional[ResourceObject]
    Databricks_Jobs: Optional[ResourceObject]
    AKS_Clusters: Optional[ResourceObject]
    insertedTime: datetime

    class Settings:
        name: "azure_inventory"
