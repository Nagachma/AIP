from datetime import datetime
from typing import Optional, List

from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel, Field

class Source(BaseModel):
    region: str = Field(None, alias='region')
    env: str = Field(None, alias='prod')
    service_provider: str = Field(None, alias='Azure')


class Queries(BaseModel):
    sqldatabasesname: Optional[str]
    session_id: Optional[float]
    request_id: Optional[float]
    start_time: Optional[str]
    status: Optional[str]
    command: Optional[str]
    sql_handle: Optional[str]
    statement_start_offset: Optional[float]
    statement_end_offset: Optional[float]
    plan_handle: Optional[str]
    database_id: Optional[float]
    user_id: Optional[float]
    connection_id: Optional[str]
    blocking_session_id: Optional[float]
    wait_type: Optional[str]
    wait_time: Optional[float]
    last_wait_type: Optional[str]
    wait_resource: Optional[str]
    open_transaction_count: Optional[float]
    open_resultset_count: Optional[float]
    transaction_id: Optional[float]
    context_info: Optional[str]
    percent_complete: Optional[float]
    estimated_completion_time: Optional[float]
    cpu_time: Optional[float]
    total_elapsed_time: Optional[float]
    scheduler_id: Optional[float]
    task_address: Optional[str]
    reads: Optional[float]
    writes: Optional[float]
    logical_reads: Optional[float]
    text_size: Optional[float]
    language: Optional[str]
    date_format: Optional[str]
    date_first: Optional[float]
    quoted_identifier: Optional[str]
    arithabort: Optional[str]
    ansi_null_dflt_on: Optional[str]
    ansi_defaults: Optional[str]
    ansi_warnings: Optional[str]
    ansi_padding: Optional[str]
    ansi_nulls: Optional[str]
    concat_null_yields_null: Optional[str]
    transaction_isolation_level: Optional[float]
    lock_timeout: Optional[float]
    deadlock_priority: Optional[float]
    row_count: Optional[float]
    prev_error: Optional[float]
    nest_level: Optional[float]
    granted_query_memory: Optional[float]
    executing_managed_code: Optional[str]
    group_id: Optional[str]
    query_hash: Optional[str]
    query_plan_hash: Optional[str]
    statement_sql_handle: Optional[str]
    statement_context_id: Optional[str]
    dop: Optional[float]
    parallel_worker_count: Optional[str]
    external_script_request_id: Optional[str]
    is_resumable: Optional[str]
    page_resource: Optional[str]
    page_server_reads: Optional[float]
    dist_statement_id: Optional[str]
    label: Optional[str]
    server_name: Optional[str]
    metric_datetime: Optional[str]


class Databases(BaseModel):
    database_name: str = Field(None,alias='database_name')
    active_queries: Optional[str]
    allocated_data_storage: str = Field(None,alias='allocated_data_storage')
    app_cpu_billed: Optional[float]
    app_cpu_percent: Optional[float]
    app_memory_percent: Optional[float]
    base_blob_size_bytes: Optional[str]
    blocked_by_firewall: Optional[float]
    cache_hit_percent: Optional[str]
    cache_used_percent: Optional[str]
    connection_failed: Optional[float] = Field(None,alias='connection_failed')
    connection_successful: Optional[float] = Field(None,alias='connection_successful')
    cpu_limit: Optional[float]
    cpu_percent: Optional[float]= Field(None,alias='cpu_percent')
    cpu_used: Optional[float]
    deadlock: Optional[float] = Field(None,alias='deadlock')
    delta_num_of_bytes_read: Optional[float]
    dtu_limit: str = Field(None,alias='dtu_limit')
    dtu_used: str = Field(None,alias='dtu_used')
    log_write_percent: Optional[float] = Field(None,alias='log_write_percent')
    sessions_percent: Optional[float] = Field(None,alias='sessions_percent')
    sqlserver_process_core_percent: str = Field(None,alias='sqlserver_process_core_percent')
    sqlserver_process_memory_percent: str = Field(None,alias='sqlserver_process_memory_percent')
    storage: str = Field(None,alias='storage')
    storage_percent: str = Field(None,alias='storage_percent')
    tempdb_data_size: str = Field(None,alias='tempdb_data_size')
    tempdb_log_used_percent: str = Field(None,alias='tempdb_log_used_percent')
    workers_percent: Optional[float] = Field(None,alias='workers_percent')
    xtp_storage_percent: Optional[float] = Field(None,alias='xtp_storage_percent')
    dtu_consumption_percent: str = Field(None,alias='dtu_consumption_percent')
    physical_data_read_percent: Optional[float] = Field(None,alias='physical_data_read_percent')
    storage_limit: Optional[float]
    tempdb_log_size: str = Field(None,alias='tempdb_log_size')
    wlg_active_queries: Optional[str]
    wlg_active_queries_timeouts: Optional[str]
    wlg_allocation_relative_to_system_percent: Optional[str]
    wlg_allocation_relative_to_wlg_effective_cap_percent: Optional[str]
    wlg_effective_cap_resource_percent: Optional[str]
    wlg_effective_min_resource_percent: Optional[str]
    wlg_queued_queries: Optional[str]
    queries: Optional[List[Queries]]


class Server(BaseModel):
    server_name: str
    start_time: Optional[datetime]
    databases: Optional[List[Databases]]


class azure_sqlserver(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    servers: List[Server] = []

    class Settings:
        name: "azure_sqlserver"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field="source",
            granularity=Granularity.minutes  # Optional
            # expire_after_seconds=2  # Optional
        )
