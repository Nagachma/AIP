from datetime import datetime
from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel, Field
from typing import Optional, Dict, List




class AzureRedisCache(BaseModel):
    # Name: Optional[str] = Field(None, alias='Name')
    name: Optional[str] = Field(None, alias='name')
    id: Optional[str] = Field(None, alias='id')
    allcachehits: Optional[float] = Field(None,alias='allcachehits')
    cacheLatency: Optional[float] = Field(None,alias='cacheLatency')
    allcachemisses: Optional[float] = Field(None,alias='allcachemisses')
    cachemissrate: Optional[float] = Field(None,alias='cachemissrate')
    allcacheRead: Optional[float] = Field(None,alias='allcacheRead')
    allcacheWrite: Optional[float] = Field(None,alias='allcacheWrite')
    allconnectedclients: Optional[float] = Field(None,alias='allconnectedclients')
    # ConnectedClientsUsingAADToken: Optional[float] = Field(None,alias='ConnectedClientsUsingAADToken')
    errors: Optional[float] = Field(None,alias='errors')
    allevictedkeys: Optional[float] = Field(None,alias='allevictedkeys')
    allexpiredkeys: Optional[float] = Field(None,alias='allexpiredkeys')
    GeoReplicationConnectivityLag: Optional[float] = Field(None,alias='GeoReplicationConnectivityLag')
    GeoReplicationDataSyncOffset: Optional[float] = Field(None,alias='GeoReplicationDataSyncOffset')
    GeoReplicationFullSyncEventFinished: Optional[float] = Field(None,alias='GeoReplicationFullSyncEventFinished')
    GeoReplicationFullSyncEventStarted: Optional[float] = Field(None,alias='GeoReplicationFullSyncEventStarted')
    GeoReplicationHealthy: Optional[float] = Field(None,alias='GeoReplicationHealthy')
    allgetcommands: Optional[float] = Field(None,alias='allgetcommands')
    LatencyP99: Optional[float] = Field(None,alias='LatencyP99')
    alloperationsPerSecond: Optional[float] = Field(None,alias='alloperationsPerSecond')
    allpercentprocessortime: Optional[float] = Field(None,alias='allpercentprocessortime')
    allserverLoad: Optional[float] = Field(None,alias='allserverLoad')
    allsetcommands: Optional[float] = Field(None,alias='allsetcommands')
    alltotalcommandsprocessed: Optional[float] = Field(None,alias='alltotalcommandsprocessed')
    alltotalkeys: Optional[float] = Field(None,alias='alltotalkeys')
    allusedmemory: Optional[float] = Field(None,alias='allusedmemory')
    allusedmemorypercentage: Optional[float] = Field(None,alias='allusedmemorypercentage')
    allusedmemoryRss: Optional[float] = Field(None,alias='allusedmemoryRss')
    allConnectionsClosedPerSecond: Optional[float] = Field(None,alias='allConnectionsClosedPerSecond')
    allConnectionsCreatedPerSecond: Optional[float] = Field(None,alias='allConnectionsCreatedPerSecond')
    location: Optional[str] = Field(None, alias='location')
    host_name: Optional[str] = Field(None, alias='host_name')
    port: Optional[float] = Field(None, alias='port')
    public_network_access: Optional[str] = Field(None, alias='public_network_access')
    aof_backup_enabled: Optional[str] = Field(None, alias='aof_backup_enabled')
    maxclients: Optional[float] = Field(None, alias='maxclients')
    maxfragmentationmemory_reserved: Optional[float] = Field(None, alias='maxfragmentationmemory_reserved')
    maxmemory_delta: Optional[float] = Field(None, alias='maxmemory_delta')
    maxmemory_policy: Optional[str] = Field(None, alias='maxmemory_policy')
    maxmemory_reserved: Optional[float] = Field(None, alias='maxmemory_reserved')
    rdb_backup_enabled: Optional[str] = Field(None, alias='rdb_backup_enabled')
    rdb_backup_frequency: Optional[float] = Field(None, alias='rdb_backup_frequency')
    # rdb_backup_max_snapshot_count
    redis_version: Optional[float] = Field(None, alias='redis_version')
    replicas_per_master: Optional[float] = Field(None, alias='replicas_per_master')
    replicas_per_primary: Optional[float] = Field(None, alias='replicas_per_primary')
    shard_count: Optional[float] = Field(None, alias='shard_count')
    skuname: Optional[str] = Field(None, alias='skuname')
    ssl_port: Optional[float] = Field(None, alias='ssl_port')
    cachehitrate: Optional[float] = Field(None, alias='cachehitrate')


class Source(BaseModel):
    region: str = Field(None, alias='region')
    env: str = Field(None, alias='prod')
    service_provider: str = Field(None, alias='Azure')

class azurerediscache(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    azure_redis_cache: List[AzureRedisCache] = []

    class Settings:
        name: "azurerediscache"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field = "source",
            granularity=Granularity.minutes  # Optional
            # expire_after_seconds=2  # Optional
        )
