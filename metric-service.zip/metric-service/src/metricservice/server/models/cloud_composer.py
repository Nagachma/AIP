from datetime import datetime
from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel , Field
from typing import Optional,Dict,List

class tasks(BaseModel):
    task_name: Optional[str]
    workflow_task_run_count: Optional[float] = Field(None,alias='workflow_task_run_count')
    workflow_task_run_duration: Optional[float] = Field(None, alias='workflow_task_run_duration')
    workflow_task_run_state: Optional[str] = Field(None,alias='workflow_task_run_state')

class workflows(BaseModel):
    workflow_name: Optional[str]
    workflow_run_count: Optional[float] = Field(None,alias='workflow_run_count')
    workflow_run_duration: Optional[float] = Field(None, alias='workflow_run_duration')
    workflow_run_status: Optional[str] = Field(None,alias='workflow_run_status')
    tasks: Optional[List[tasks]]

class webservers(BaseModel):
    instance_id: Optional[str]
    environment_web_server_memory_bytes_used: Optional[float] = Field(None, alias='environment_web_server_memory_bytes_used')
    environment_web_server_memory_quota: Optional[float] = Field(None, alias='environment_web_server_memory_quota')
    environment_web_server_cpu_reserved_cores: Optional[float] = Field(None,alias='environment_web_server_cpu_reserved_cores')
    environment_web_server_cpu_usage_time: Optional[float] = Field(None, alias='environment_web_server_cpu_usage_time')

class queues(BaseModel):
    queue_name: Optional[str]
    environment_task_queue_length: Optional[float] = Field(None, alias='environment_task_queue_length')
    environment_worker_scale_factor_target: Optional[float] = Field(None, alias='environment_worker_scale_factor_target')

class pools(BaseModel):
    pool_name: Optional[str]
    environment_pool_open_slots: Optional[float] = Field(None, alias='environment_pool_open_slots')
    environment_pool_running_slots: Optional[float] = Field(None, alias='environment_pool_running_slots')
    environment_pool_starving_tasks: Optional[float] = Field(None, alias='environment_pool_starving_tasks')
    environment_scheduler_pod_eviction_count: Optional[float] = Field(None, alias='environment_scheduler_pod_eviction_count')

class environments(BaseModel):
    environment_name: Optional[str]
    environment_api_request_count: Optional[float] = Field(None, alias='environment_api_request_count')
    environment_api_request_latencies: Optional[float] = Field(None, alias='environment_api_request_latencies')
    environment_api_request_status: Optional[str] = Field(None, alias='environment_api_request_status')
    environment_web_server_health: Optional[str] = Field(None, alias='environment_web_server_health')
    environment_dagbag_size: Optional[float] = Field(None, alias='environment_dagbag_size')
    environment_healthy: Optional[str] = Field(None, alias='environment_healthy')
    environment_num_celery_workers: Optional[float] = Field(None, alias='environment_num_celery_workers')
    environment_scheduler_heartbeat_count: Optional[float] = Field(None, alias='environment_scheduler_heartbeat_count')
    environment_zombie_task_killed_count: Optional[float] = Field(None, alias='environment_zombie_task_killed_count')
    environment_finished_task_instance_count: Optional[float] = Field(None, alias='environment_finished_task_instance_count')
    environment_unfinished_task_instances: Optional[float] = Field(None, alias='environment_unfinished_task_instances')
    environment_web_server_cpu_reserved_cores: Optional[float] = Field(None, alias='environment_web_server_cpu_reserved_cores')
    environment_web_server_cpu_usage_time: Optional[float] = Field(None, alias='environment_web_server_cpu_usage_time')
    environment_database_health: Optional[float] = Field(None, alias='environment_database_health')
    environment_dag_processing_parse_error_count: Optional[float] = Field(None, alias='environment_dag_processing_parse_error_count')
    environment_dag_processing_processes: Optional[float] = Field(None, alias='environment_dag_processing_processes')
    environment_dag_processing_processor_timeout_count: Optional[float] = Field(None, alias='environment_dag_processing_processor_timeout_count')
    environment_dag_processing_total_parse_time: Optional[float] = Field(None, alias='environment_dag_processing_total_parse_time')
    environment_email_sla_notification_failure_count: Optional[float] = Field(None, alias='environment_email_sla_notification_failure_count')
    environment_database_airflow_size: Optional[float] = Field(None, alias='environment_database_airflow_size')
    environment_database_cpu_reserved_cores: Optional[float] = Field(None, alias='environment_database_cpu_reserved_cores')
    environment_database_cpu_usage_time: Optional[float] = Field(None, alias='environment_database_cpu_usage_time')
    environment_database_cpu_utilization: Optional[float] = Field(None, alias='environment_database_cpu_utilization')
    environment_database_disk_bytes_used: Optional[float] = Field(None, alias='environment_database_disk_bytes_used')
    environment_database_disk_quota: Optional[float] = Field(None, alias='environment_database_disk_quota')
    environment_database_disk_utilization: Optional[float] = Field(None, alias='environment_database_disk_utilization')
    environment_database_memory_bytes_used: Optional[float] = Field(None, alias='environment_database_memory_bytes_used')
    environment_database_memory_quota: Optional[float] = Field(None, alias='environment_database_memory_quota')
    environment_database_memory_utilization: Optional[float] = Field(None, alias='environment_database_memory_utilization')
    environment_database_network_connections: Optional[float] = Field(None, alias='environment_database_network_connections')
    environment_database_network_max_connections: Optional[float] = Field(None, alias='environment_database_network_max_connections')
    environment_database_network_received_bytes_count: Optional[float] = Field(None, alias='environment_database_network_received_bytes_count')
    environment_database_network_sent_bytes_count: Optional[float] = Field(None, alias='environment_database_network_sent_bytes_count')
    environment_executor_open_slots: Optional[float] = Field(None, alias='environment_executor_open_slots')
    environment_executor_queued_tasks: Optional[float] = Field(None, alias='environment_executor_queued_tasks')
    environment_executor_running_tasks: Optional[float] = Field(None, alias='environment_executor_running_tasks')
    environment_smart_sensor_exception_failures: Optional[float] = Field(None, alias='environment_smart_sensor_exception_failures')
    environment_smart_sensor_infra_failures: Optional[float] = Field(None, alias='environment_smart_sensor_infra_failures')
    environment_smart_sensor_poked_exception: Optional[float] = Field(None, alias='environment_smart_sensor_poked_exception')
    environment_smart_sensor_poked_success: Optional[float] = Field(None, alias='environment_smart_sensor_poked_success')
    environment_smart_sensor_poked_tasks: Optional[float] = Field(None, alias='environment_smart_sensor_poked_tasks')
    environment_snapshot_creation_count: Optional[float] = Field(None, alias='environment_snapshot_creation_count')
    environment_snapshot_creation_elapsed_time: Optional[float] = Field(None, alias='environment_snapshot_creation_elapsed_time')
    environment_snapshot_size: Optional[float] = Field(None, alias='environment_snapshot_size')
    environment_trigger_blocking_count: Optional[float] = Field(None, alias='environment_trigger_blocking_count')
    environment_trigger_failed_count: Optional[float] = Field(None, alias='environment_trigger_failed_count')
    environment_trigger_succeeded_count: Optional[float] = Field(None, alias='environment_trigger_succeeded_count')
    environment_worker_max_workers: Optional[float] = Field(None, alias='environment_worker_max_workers')
    environment_worker_min_workers: Optional[float] = Field(None, alias='environment_worker_min_workers')
    environment_worker_pod_eviction_count: Optional[float] = Field(None, alias='environment_worker_pod_eviction_count')
    pools: Optional[List[pools]]
    queues: Optional[List[queues]]
    webservers: Optional[List[webservers]]
    workflows: Optional[List[workflows]]

class prjcts(BaseModel):
    project_id: Optional[str]
    environments: Optional[List[environments]]


class Source(BaseModel):
    region: str
    env: str
    service_provider: str

class cloud_composer(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    projects: List[prjcts] = []

    class Settings:
        name: "cloud_composer"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field = "source",
            granularity=Granularity.minutes  # Optional
            #expire_after_seconds=2  # Optional
        )
