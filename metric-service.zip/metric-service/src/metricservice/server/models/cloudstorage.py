from datetime import datetime
from typing import Optional, List

from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel, Field


class Response(BaseModel):
    uuid: Optional[str] = Field(None, alias='UUID')
    start_time: Optional[datetime] = Field(None, alias='start_time')
    end_time: Optional[datetime] = Field(None, alias='end_time')
    request_count: Optional[int]
    response_code: Optional[str]


class Metrics(BaseModel):
    bucket_name: Optional[str]
    start_time: Optional[datetime] = Field(None, alias='start_time')
    end_time: Optional[datetime] = Field(None, alias='end_time')
    # request_count: Optional[float]
    authentication_count: Optional[float]
    acl_based_object_access_count: Optional[float]
    acl_operations_count: Optional[float]
    object_specific_acl_mutation_count: Optional[float]
    transition_operation_count: Optional[float]
    transitioned_bytes_count: Optional[float]
    received_bytes_count: Optional[float]
    sent_bytes_count: Optional[float]
    missing_rpo_minutes_last_30d: Optional[float]
    object_replications_last_30d: Optional[float]
    time_since_metrics_updated: Optional[float]
    object_count: Optional[float] = Field(None, alias='object_count')
    total_byte_seconds: Optional[float]
    total_bytes: Optional[float]
    upload_latency: Optional[float]
    download_latency: Optional[float]
    delete_latency: Optional[float]
    metadata_latency: Optional[float]
    has_errors: Optional[str]
    responses: Optional[List[Response]] = []

class Source(BaseModel):
    region: str = Field(None, alias='region')
    env: str = Field(None, alias='prod')
    service_provider: str = Field(None, alias='GCP')

class cloudstorage(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    buckets: List[Metrics] = []

    class Settings:
        name: "cloudstorage"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field="source",
            granularity=Granularity.minutes  # Optional
            # expire_after_seconds=2  # Optional
        )