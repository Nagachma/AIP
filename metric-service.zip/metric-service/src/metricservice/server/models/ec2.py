from datetime import datetime
from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel, Field
from typing import Optional, List


class Disk(BaseModel):
    run_id: Optional[str] = Field(None, alias='run_id')
    disk_name: Optional[str] = Field(None, alias='disk_name')
    disk_mount_path: Optional[str] = Field(None, alias='disk_mount_path')
    disk_status: Optional[str] = Field(None, alias='disk_status')
    inaccessible_mount_point: Optional[str] = Field(None, alias='inaccessible_mount_point')
    failure: Optional[int] = Field(None, alias='Failure')
    slowness: Optional[int] = Field(None, alias='Slowness')

class instance(BaseModel):
    instance_ip: Optional[str] = Field(None, alias='instance_ip')
    instance_name: Optional[str] = Field(None, alias='instance_name')
    # CPU_Utilization: Optional[str] = Field(None, alias='CPU_Utilization')
    NetworkIn: Optional[str] = Field(None, alias='NetworkIn')
    Networkout: Optional[str] = Field(None, alias='Networkout')
    DiskReadBytes: Optional[str] = Field(None, alias='DiskReadBytes')
    DiskWriteBytes: Optional[str] = Field(None, alias='DiskWriteBytes')
    DiskReadOps: Optional[str] = Field(None, alias='DiskReadOps')
    DiskWriteOps: Optional[str] = Field(None, alias='DiskWriteOps')
    # Total_Network_Traffic : Optional[str] = Field(None, alias='Total_network_traffic')
    disks: List[Disk] = []

class Source(BaseModel):
    region: str
    env: str
    service_provider: str


class ec2(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    disk_connectivity: List[instance] = []

    class Settings:
        name: "ec2"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field="source",
            granularity=Granularity.minutes  # Optional
            # expire_after_seconds=2  # Optional
        )
