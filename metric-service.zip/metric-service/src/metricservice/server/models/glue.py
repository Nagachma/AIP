from datetime import datetime
from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel , Field
from typing import Optional,Dict,List

class Run(BaseModel):
    job_run_id: str
    glue_driver_jvm_heap_usage: Optional[float] = Field(None, alias='glue.driver.jvm.heap.usage')
    glue_driver_aggregate_bytesRead: Optional[float] = Field(None, alias='glue.driver.aggregate.bytesRead')
    glue_driver_aggregate_elapsedTime: Optional[int] = Field(None, alias='glue.driver.aggregate.elapsedTime')
    glue_driver_aggregate_numCompletedStages: Optional[int] = Field(None, alias='glue.driver.aggregate.numCompletedStages')
    glue_driver_aggregate_numCompletedTasks: Optional[int] = Field(None, alias='glue.driver.aggregate.numCompletedTasks')
    glue_driver_aggregate_numFailedTasks: Optional[int] = Field(None, alias='glue.driver.aggregate.numFailedTasks')
    glue_driver_aggregate_numKilledTasks: Optional[int] = Field(None, alias='glue.driver.aggregate.numKilledTasks')
    glue_driver_aggregate_recordsRead: Optional[int] = Field(None, alias='glue.driver.aggregate.recordsRead')
    glue_driver_aggregate_shuffleBytesWritten: Optional[int] = Field(None, alias='glue.driver.aggregate.shuffleBytesWritten')
    glue_driver_aggregate_shuffleLocalBytesRead: Optional[int] = Field(None, alias='glue.driver.aggregate.shuffleLocalBytesRead')
    glue_driver_BlockManager_disk_diskSpaceUsed_MB: Optional[int] = Field(None, alias='glue.driver.BlockManager.disk.diskSpaceUsed_MB')
    glue_ALL_jvm_heap_usage: Optional[float] = Field(None, alias='glue.ALL.jvm.heap.usage')
    glue_driver_jvm_heap_used: Optional[int] = Field(None, alias='glue.driver.jvm.heap.used')
    glue_ALL_jvm_heap_used: Optional[int] = Field(None, alias='glue.ALL.jvm.heap.used')
    glue_driver_s3_filesystem_read_bytes: Optional[int] = Field(None, alias='glue.driver.s3.filesystem.read_bytes')
    glue_ALL_s3_filesystem_read_bytes: Optional[int] = Field(None, alias='glue.ALL.s3.filesystem.read_bytes')
    glue_driver_s3_filesystem_write_bytes: Optional[int] = Field(None, alias='glue.driver.s3.filesystem.write_bytes')
    glue_ALL_s3_filesystem_write_bytes: Optional[int] = Field(None, alias='glue.ALL.s3.filesystem.write_bytes')
    glue_driver_system_cpuSystemLoad: Optional[float] = Field(None, alias='glue.driver.system.cpuSystemLoad')
    glue_ALL_system_cpuSystemLoad: Optional[float] = Field(None, alias='glue.ALL.system.cpuSystemLoad')
    ExecutionTime: Optional[int]
    JobRunState: Optional[str]
    StartedOn: Optional[datetime]
    LastModifiedOn: Optional[datetime]
    CompletedOn: Optional[datetime]
    AllocatedCapacity: Optional[float]
    WorkerType: Optional[str]
    NumberOfWorkers: Optional[int]
    GlueVersion: Optional[float]
    ErrorMessage: Optional[str]

class Job(BaseModel):
    jobname: str
    runs: List[Run]

class Source(BaseModel):
    region: str
    env: str
    service_provider: str

class glue(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    jobs: List[Job] = []

    class Settings:
        name: "glue"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field = "source",
            granularity=Granularity.minutes  # Optional
            #expire_after_seconds=2  # Optional
        )
