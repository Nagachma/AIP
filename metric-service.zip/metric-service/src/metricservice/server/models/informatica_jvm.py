from datetime import datetime
from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel, Field
from typing import Optional, List


class Task(BaseModel):
    run_id: Optional[str] = Field(None, alias='run_id')
    SITE_NO: Optional[str] = Field(None, alias='SITE_NO')
    Start_Time: Optional[datetime] = Field(None, alias='Start_Time')
    End_Time: Optional[datetime] = Field(None, alias='End_Time')
    WORKFLOW_EXECUTION_ID: Optional[int] = Field(None, alias='WORKFLOW_EXECUTION_ID')
    # CPU_PERECNT: Optional[str] = Field(None, alias='CPU_PERECNT')
    # MEMORY_USAGE_IN_MB: Optional[str] = Field(None, alias='MEMORY_USAGE_IN_MB')
    SUCCESSFUL_SOURCE_ROWS: Optional[str] = Field(None, alias='SUCCESSFUL_SOURCE_ROWS')
    FAILED_SOURCE_ROWS: Optional[str] = Field(None, alias='FAILED_SOURCE_ROWS')
    SUCCESSFUL_TARGET_ROWS: Optional[str] = Field(None, alias='SUCCESSFUL_TARGET_ROWS')
    FAILED_TARGET_ROWS: Optional[str] = Field(None, alias='FAILED_TARGET_ROWS')
    Task_Status: Optional[str] = Field(None, alias='Task_Status')
    # DURATION_IN_SECONDS: Optional[str] = Field(None, alias='DURATION_IN_SECONDS')
    AggIndexCacheSizeMB: Optional[str] = Field(None, alias='AggIndexCacheSizeMB')
    AggDataCacheSizeMB: Optional[str] = Field(None, alias='AggDataCacheSizeMB')
    JnrIndexCacheSizeMB: Optional[str] = Field(None, alias='JnrIndexCacheSizeMB')
    JnrDataCacheSizeMB: Optional[str] = Field(None, alias='JnrDataCacheSizeMB')
    TASK_NAME: Optional[str] = Field(None, alias='TASK_NAME')
    INTEGRATION_SERVICE: Optional[str] = Field(None, alias='INTEGRATION_SERVICE')
    Folder_Name: Optional[str] = Field(None, alias='Folder_Name')
    pid: Optional[str] = Field(None, alias='pid')
    Stale_data_DBConnect_status: Optional[str] = Field(None, alias='Stale_data_DBConnect_status')
    # cur_S0_cap: Optional[str] = Field(None, alias='cur_S0_cap(kB)')
    # cur_S1_cap: Optional[str] = Field(None, alias='cur_S1_cap(kB)')
    # S0_util: Optional[str] = Field(None, alias='S0_util(kB)')
    # S1_util: Optional[str] = Field(None, alias='S1_util(kB)')
    # cur_eden_cap: Optional[str] = Field(None, alias='cur_eden_cap(kB)')
    # eden_util: Optional[str] = Field(None, alias='eden_util(kB)')
    # cur_old_cap: Optional[str] = Field(None, alias='cur_old_cap(kB)')
    # old_util: Optional[str] = Field(None, alias='old_util(kB)')
    # metaspace_cap: Optional[str] = Field(None, alias='metaspace_cap(kB)')
    # metaspace_util: Optional[str] = Field(None, alias='metaspace_util(kB)')
    # compr_class_cap: Optional[str] = Field(None, alias='compr_class_cap(kB)')
    # compr_class_util: Optional[str] = Field(None, alias='compr_class_util(kB)')
    # young_GC_events: Optional[str] = Field(None, alias='young_GC_events')
    # young_GC_time: Optional[str] = Field(None, alias='young_GC_time')
    # full_GC_events: Optional[str] = Field(None, alias='full_GC_events')
    # full_GC_time: Optional[str] = Field(None, alias='full_GC_time')
    # total_GC_time: Optional[str] = Field(None, alias='total_GC_time')
    # kBytes_loaded: Optional[str] = Field(None, alias='kBytes_loaded')
    # classes_loaded: Optional[str] = Field(None, alias='classes_loaded')
    # classes_unloaded: Optional[str] = Field(None, alias='classes_unloaded')
    # kBytes_unloaded: Optional[str] = Field(None, alias='kBytes_unloaded')
    # time_taken_on_loading_unloading: Optional[str] = Field(None, alias='time_taken_on_loading_unloading')
    # compilation_tasks: Optional[str] = Field(None, alias='compilation_tasks')
    # compilation_tasks_failed: Optional[str] = Field(None, alias='compilation_tasks_failed')
    # invalid_compilation_tasks: Optional[str] = Field(None, alias='invalid_compilation_tasks')
    # time_taken_on_compliation: Optional[str] = Field(None, alias='time_taken_on_compliation')
    # last_failed_type: Optional[str] = Field(None, alias='last_failed_type')
    # last_failed_method: Optional[str] = Field(None, alias='last_failed_method')


class WorkFlow(BaseModel):
    Workflow_Name: Optional[str] = Field(None, alias='Workflow_Name')
    site_run_time: Optional[str] = Field(None, alias='site_run_time')
    block: Optional[str] = Field(None, alias='block')
    subject_area: Optional[str] = Field(None, alias='subject_area')
    file_name: Optional[str] = Field(None, alias='file_name')
    missing_file_Status: Optional[str] = Field(None, alias='missing_file_Status')
    inbound_path: Optional[str] = Field(None, alias='inbound_path')
    Workflow_Status: Optional[str] = Field(None, alias='Workflow_Status')
    DURATION_IN_SECONDS: Optional[str] = Field(None, alias='DURATION_IN_SECONDS')
    run_id: Optional[str] = Field(None, alias='run_id')
    site_no: Optional[str] = Field(None, alias='site_no')
    Tasks: Optional[List[Task]] = []


class Source(BaseModel):
    region: str
    env: str
    service_provider: str


class informaticajvm(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    workflows: List[WorkFlow] = []

    class Settings:
        name: "informaticajvm"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field="source",
            granularity=Granularity.minutes  # Optional
            # expire_after_seconds=2  # Optional
        )
