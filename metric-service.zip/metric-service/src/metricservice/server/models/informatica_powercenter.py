from datetime import datetime
from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel, Field
from typing import Optional, List


class Task(BaseModel):
    Start_Time: Optional[datetime] = Field(None, alias='Start_Time')
    End_Time: Optional[datetime] = Field(None, alias='End_Time')
    Workflow_Execution_ID: Optional[int] = Field(None, alias='Workflow_Execution_ID')
    CPU_PERECNT: Optional[str] = Field(None, alias='CPU_PERECNT')
    MEMORY_USAGE_IN_MB: Optional[str] = Field(None, alias='MEMORY_USAGE_IN_MB')
    SUCCESSFUL_SOURCE_ROWS: Optional[int] = Field(None, alias='SUCCESSFUL_SOURCE_ROWS')
    FAILED_SOURCE_ROWS: Optional[int] = Field(None, alias='FAILED_SOURCE_ROWS')
    SUCCESSFUL_TARGET_ROWS: Optional[int] = Field(None, alias='SUCCESSFUL_TARGET_ROWS')
    FAILED_TARGET_ROWS: Optional[int] = Field(None, alias='FAILED_TARGET_ROWS')
    STATUS: Optional[str] = Field(None, alias='STATUS')
    DURATION_IN_SECONDS: Optional[str] = Field(None, alias='DURATION_IN_SECONDS')
    AggIndexCacheSizeMB: Optional[str] = Field(None, alias='AggIndexCacheSizeMB')
    AggDataCacheSizeMB: Optional[str] = Field(None, alias='AggDataCacheSizeMB')
    JnrIndexCacheSizeMB: Optional[str] = Field(None, alias='JnrIndexCacheSizeMB')
    JnrDataCacheSizeMB: Optional[str] = Field(None, alias='JnrDataCacheSizeMB')
    TASK_NAME: Optional[str] = Field(None, alias='TASK_NAME')
    INTEGRATION_SERVICE: Optional[str] = Field(None, alias='INTEGRATION_SERVICE')
    Folder_Name: Optional[str] = Field(None, alias='Folder_Name')


class WorkFlow(BaseModel):
    Workflow_Name: Optional[str] = Field(None, alias='Workflow_Name')
    Tasks: List[Task] = []


class Source(BaseModel):
    region: str
    env: str
    service_provider: str


class informatica(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    workflows: List[WorkFlow] = []

    class Settings:
        name: "informatica"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field="source",
            granularity=Granularity.minutes  # Optional
            # expire_after_seconds=2  # Optional
        )
