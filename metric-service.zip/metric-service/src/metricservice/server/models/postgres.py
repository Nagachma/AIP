from datetime import datetime
from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel , Field
from typing import Optional,Dict,List

class Query_duration(BaseModel):
    pid: Optional[str]
    query: Optional[str]
    start_time: Optional[datetime]
    duration: Optional[str]
    state: Optional[str]

class Tables(BaseModel):
    table_name: Optional[str]
    hot_rate: Optional[float]
    analyze_count: Optional[float]
    autoanalyze_count: Optional[float]
    autovacuum_count: Optional[float]
    last_analyze: Optional[str]
    last_autoanalyze: Optional[str]
    last_vacuum: Optional[str]
    last_autovacuum: Optional[str]
    vacuum_count: Optional[float]
    n_live_tup: Optional[float]

class Databases(BaseModel):
    database_name: Optional[str]
    connection_count: Optional[float]
    xact_rollback: Optional[float]
    conflicts: Optional[float]
    deadlocks: Optional[float]
    hit_ratio: Optional[float]
    temp_bytes: Optional[float]
    temp_files: Optional[float]
    query_duration: Optional[List[Query_duration]]
    tables: Optional[List[Tables]]

class Instances(BaseModel):
    instance_name: Optional[str]
    instance_created_unique_id: Optional[str]
    res_for_super: Optional[float]
    max_conn: Optional[float]
    MemInfo_MemFree: Optional[float]
    MemInfo_MemAvailable: Optional[float]
    MemInfo_Buffers: Optional[float]
    MemInfo_Cached: Optional[float]
    MemInfo_Active: Optional[float]
    MemInfo_Inactive: Optional[float]
    MemInfo_CommitLimit: Optional[float]
    MemInfo_Committed_AS: Optional[float]
    MemInfo_Percpu: Optional[float]
    databases: Optional[List[Databases]]

class Source(BaseModel):
    region: str
    env: str
    service_provider: str

class postgres(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    instances: List[Instances] = []

    class Settings:
        name: "postgres"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field = "source",
            granularity=Granularity.minutes  # Optional
            #expire_after_seconds=2  # Optional
        )
