from datetime import datetime
from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel , Field
from typing import Optional,Dict,List

class Instance(BaseModel):
    instance_name: str
    start_time: Optional[datetime]
    end_time: Optional[datetime]
    BaseGcTotalOldGeneration: Optional[float]
    BaseGcTotalYoungGeneration: Optional[float]
    BaseGcTimeTotalSecondsOldGeneration: Optional[float]
    BaseGcTimeTotalSecondsYoungGeneration: Optional[float]
    BaseMemoryUsedHeapBytes: Optional[float]
    WildflyIoConnectionCount: Optional[float]

class Source(BaseModel):
    region: str
    env: str
    service_provider: str

class rapid(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    instances: List[Instance] = []

    class Settings:
        name: "rapid"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field = "source",
            granularity=Granularity.minutes  # Optional
            #expire_after_seconds=2  # Optional
        )