from datetime import datetime
from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel, Field
from typing import Optional, List


class AvgCPU(BaseModel):
    user: Optional[float]
    nice: Optional[float]
    system: Optional[float]
    iowait: Optional[float]
    steal: Optional[float]
    idle: Optional[float]


class Disk(BaseModel):
    disk_device: str
    tps: Optional[float]
    kB_read_s: Optional[float] = Field(None, alias='kB_read/s')
    kB_wrtn_s: Optional[float] = Field(None, alias='kB_wrtn/s')
    kB_dscd_s: Optional[float] = Field(None, alias='kB_dscd/s')
    kB_read: Optional[float]
    kB_wrtn: Optional[float]
    kB_dscd: Optional[float]


class Statistics(BaseModel):
    avg_cpu: AvgCPU = Field(None, alias='avg-cpu')
    disk: List[Disk]


class Process(BaseModel):
    pid: int
    Command: str
    elapsed: str
    user: str
    per_usr: Optional[float]
    per_system: Optional[float]
    per_guest: Optional[float]
    per_cpu: Optional[float]
    cpu: Optional[float]
    minflt_s: Optional[float]
    majflt_s: Optional[float]
    vsz: Optional[float]
    rss: Optional[float]
    per_mem: Optional[float]
    kB_rd_s: Optional[float]
    kB_wr_s: Optional[float]
    kB_ccwr_s: Optional[float]
    iodelay: Optional[str]


class Instance(BaseModel):
    nodename: str
    sysname: Optional[str]
    release: Optional[str]
    machine: Optional[str]
    number_of_cpus: int = Field(None, alias='number-of-cpus')
    statistics: Optional[List[Statistics]]
    processes: Optional[List[Process]]


class Source(BaseModel):
    region: str
    env: str
    service_provider: str


class ropen(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    instances: List[Instance]

    class Settings:
        name: "ropen"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field="source",
            granularity=Granularity.minutes  # Optional
            # expire_after_seconds=2  # Optional
        )
