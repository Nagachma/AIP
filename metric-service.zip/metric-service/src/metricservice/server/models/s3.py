from datetime import datetime
from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel , Field
from typing import Optional,Dict,List


class Event(BaseModel):
    eventID: str
    eventTime: Optional[datetime]
    eventSource: Optional[str]
    eventName: Optional[str]
    eventType: Optional[str]
    awsRegion: Optional[str]
    sourceIPAddress: Optional[str]
    errorCode: Optional[str]
    errorMessage: Optional[str]
    bucketName: Optional[str]
    key: Optional[str]
    requestID: Optional[str]


class Bucket(BaseModel):
    bucket_name: str
    start_time: Optional[datetime]
    end_time: Optional[datetime]
    BucketSizeBytes: Optional[float]
    NumberOfObjects: Optional[float]
    AllRequests: Optional[float]
    HeadRequests: Optional[float]
    BytesDownloaded: Optional[float]
    BytesUploaded: Optional[float]
    DeleteRequests: Optional[float]
    GetRequests: Optional[float]
    ListRequests: Optional[float]
    PostRequests: Optional[float]
    PutRequests: Optional[float]
    SelectRequests: Optional[float]
    FirstByteLatency: Optional[float]
    TotalRequestLatency: Optional[float]
    SelectBytesScanned: Optional[float]
    SelectBytesReturned: Optional[float]
    Events: Optional[List[Event]]


class Source(BaseModel):
    region: str
    env: str
    service_provider: str

class s3(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    buckets: List[Bucket] = []

    class Settings:
        name: "s3"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field = "source",
            granularity=Granularity.minutes  # Optional
            #expire_after_seconds=2  # Optional
        )
