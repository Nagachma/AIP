from datetime import datetime
from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel , Field
from typing import Optional,Dict,List

class processingjob(BaseModel):
    Host: str
    processing_jobs_id: Optional[str] = Field(None, alias='ProcessingJobs.id')
    processing_jobs_CPUUtilization: Optional[float] = Field(None, alias='ProcessingJobs.CPUUtilization')
    processing_jobs_MemoryUtilization: Optional[float] = Field(None, alias='ProcessingJobs.MemoryUtilization')
    processing_jobs_GPUUtilization: Optional[float] = Field(None, alias='ProcessingJobs.GPUUtilization')
    processing_jobs_GPUMemoryUtilization: Optional[float] = Field(None, alias='ProcessingJobs.GPUMemoryUtilization')
    processing_jobs_DiskUtilization: Optional[float] = Field(None, alias='ProcessingJobs.DiskUtilization')

class trainingjob(BaseModel):
    Host: str
    training_jobs_id: Optional[str] = Field(None, alias='TrainingJobs.id')
    training_jobs_CPUUtilization: Optional[float] = Field(None, alias='TrainingJobs.CPUUtilization')
    training_jobs_MemoryUtilization: Optional[float] = Field(None, alias='TrainingJobs.MemoryUtilization')
    training_jobs_GPUUtilization: Optional[float] = Field(None, alias='TrainingJobs.GPUUtilization')
    training_jobs_GPUMemoryUtilization: Optional[float] = Field(None, alias='TrainingJobs.GPUMemoryUtilization')
    training_jobs_DiskUtilization: Optional[float] = Field(None, alias='TrainingJobs.DiskUtilization')

class transformjob(BaseModel):
    Host: str
    transform_jobs_id: Optional[str] = Field(None, alias='TransformJobs.id')
    transform_jobs_CPUUtilization: Optional[float] = Field(None, alias='TransformJobs.CPUUtilization')
    transform_jobs_MemoryUtilization: Optional[float] = Field(None, alias='TransformJobs.MemoryUtilization')
    transform_jobs_GPUUtilization: Optional[float] = Field(None, alias='TransformJobs.GPUUtilization')
    transform_jobs_GPUMemoryUtilization: Optional[float] = Field(None, alias='TransformJobs.GPUMemoryUtilization')


class endpoint(BaseModel):
    EndpointName: str
    endpoint_id: Optional[str] = Field(None, alias='Endpoint.id')
    endpoint_Invocation4xxErrors: Optional[float] = Field(None, alias='Endpoint.Invocation4XXErrors')
    endpoint_Invocation5xxErrors: Optional[float] = Field(None, alias='Endpoint.Invocation5XXErrors')
    endpoint_Invocations: Optional[float] = Field(None, alias='Endpoint.Invocations')
    endpoint_InvocationsPerInstance: Optional[float] = Field(None, alias='Endpoint.InvocationsPerInstance')
    endpoint_ModelLatency: Optional[float] = Field(None, alias='Endpoint.ModelLatency')
    endpoint_OverheadLatency: Optional[float] = Field(None, alias='Endpoint.OverheadLatency')
    endpoint_ModelSetupTime: Optional[float] = Field(None, alias='Endpoint.ModelSetupTime')
    endpoint_ModelLoadingWaitTime: Optional[float] = Field(None, alias='Endpoint.ModelLoadingWaitTime')
    endpoint_ModelUnloadingTime: Optional[float] = Field(None, alias='Endpoint.ModelUnloadingTime')
    endpoint_ModelDownloadingTime: Optional[float] = Field(None, alias='Endpoint.ModelDownloadingTime')
    endpoint_ModelLoadingTime: Optional[float] = Field(None, alias='Endpoint.ModelLoadingTime')
    endpoint_ModelCacheHit: Optional[float] = Field(None, alias='Endpoint.ModelCacheHit')
    endpoint_LodadedModelCount: Optional[float] = Field(None, alias='Endpoint.LoadedModelCount')
    endpoint_CPUUtilization: Optional[float] = Field(None, alias='Endpoint.CPUUtilization')
    endpoint_MemoryUtilization: Optional[float] = Field(None, alias='Endpoint.MemoryUtilization')
    endpoint_DiskUtilization: Optional[float] = Field(None, alias='Endpoint.DiskUtilization')

class groundtruth(BaseModel):
    LabelingJobName: str
    Groundtruth_id:  Optional[str] = Field(None, alias='Groundtruth.id')
    Groundtruth_DatasetObjectsAutoAnnotated: Optional[float] = Field(None, alias='Groundtruth.DatasetObjectsAutoAnnotated')
    Groundtruth_TotalDatasetObjectsLabeled: Optional[float] = Field(None, alias='Groundtruth.TotalDatasetObjectsLabeled')
    Groundtruth_DatasetObjectsHumanAnnotated: Optional[float] = Field(None, alias='Groundtruth.DatasetObjectsHumanAnnotated')
    Groundtruth_DatasetObjectsLabelingFailed: Optional[float] = Field(None, alias='Groundtruth.DatasetObjectsLabelingFailed')
    Groundtruth_JobsFailed: Optional[float] = Field(None, alias='Groundtruth.JobsFailed')
    Groundtruth_JobsSucceeded: Optional[float] = Field(None, alias='Groundtruth.JobsSucceeded')
    Groundtruth_JobsStopped: Optional[float] = Field(None, alias='Groundtruth.JobsStopped')

class workteam(BaseModel):
    LabelingJob: str
    workteam_id: Optional[str] = Field(None, alias='Workteam.id')
    Workteam_ActiveWorkers: Optional[float] = Field(None, alias='Workteam.ActiveWorkers')
    Workteam_TasksAccepted: Optional[float] = Field(None, alias='Workteam.TasksAccepted')
    Workteam_TasksDeclined: Optional[float] = Field(None, alias='Workteam.TasksDeclined')
    Workteam_TasksReturned: Optional[float] = Field(None, alias='Workteam.TasksReturned')
    Workteam_TasksSubmitted: Optional[float] = Field(None, alias='Workteam.TasksSubmitted')
    Workteam_TimeSpent: Optional[float] = Field(None, alias='Workteam.TimeSpent')

class pipeline(BaseModel):
    PipelineName: str
    pipeline_id: Optional[str] = Field(None, alias='Pipeline.id')
    pipeline_ExecutionStarted: Optional[float] = Field(None, alias='Pipeline.ExecutionStarted')
    pipeline_ExecutionFailed: Optional[float] = Field(None, alias='Pipeline.ExecutionFailed')
    pipeline_ExecutionSucceeded: Optional[float] = Field(None, alias='Pipeline.ExecutionSucceeded')
    pipeline_ExecutionStopped: Optional[float] = Field(None, alias='Pipeline.ExecutionStopped')
    pipeline_ExecutionDuration: Optional[float] = Field(None, alias='Pipeline.ExecutionDuration')
    pipeline_StepStarted: Optional[float] = Field(None, alias='Pipeline.StepStarted')
    pipeline_StepFailed: Optional[float] = Field(None, alias='Pipeline.StepFailed')
    pipeline_StepSucceeded: Optional[float] = Field(None, alias='Pipeline.StepSucceeded')
    pipeline_StepStopped: Optional[float] = Field(None, alias='Pipeline.StepStopped')
    pipeline_StepDuration: Optional[float] = Field(None, alias='Pipeline.StepDuration')

class feature(BaseModel):
    FeatureGroupName: str
    feature_id: Optional[str] = Field(None, alias='Feature.id')
    feature_ConsumedReadRequestsUnits: Optional[float] = Field(None, alias='Feature.ConsumedReadRequestsUnits')
    feature_ConsumedWriteRequestsUnits: Optional[float] = Field(None, alias='Feature.ConsumedWriteRequestsUnits')
    feature_Invocations: Optional[float] = Field(None, alias='Feature.Invocations')
    feature_Operation4XXErrors: Optional[float] = Field(None, alias='Feature.Operation4XXErrors')
    feature_Operation5XXErrors: Optional[float] = Field(None, alias='Feature.Operation5XXErrors')
    feature_ThrottledRequests: Optional[float] = Field(None, alias='Feature.ThrottledRequests')
    feature_Latency: Optional[float] = Field(None, alias='Feature.Latency')

class Source(BaseModel):
    region: str
    env: str
    service_provider: str

class sagemaker(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    trainingjobs: List[trainingjob] = []
    processingjobs: List[processingjob] = []
    transformjobs: List[transformjob] = []
    endpoints: List[endpoint] = []
    groundtruths: List[groundtruth] = []
    pipelines: List[pipeline] = []
    workteams: List[workteam] = []
    features: List[feature] = []

    class Settings:
        name: "sagemaker"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field = "source",
            granularity=Granularity.minutes  # Optional
            #expire_after_seconds=2  # Optional
        )
