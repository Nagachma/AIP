from datetime import datetime
from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel , Field
from typing import Optional,Dict,List
import os
import sys

current_dir = os.getcwd()
print ("Current: "+ str(current_dir))
parent_dir = os.path.dirname(current_dir)
print ("Parent Dir: "+ str(parent_dir))
sys.path.append("/app/dist/config")

from config import settings, services, doc

class Job(BaseModel):
    jobname: str
    runs = []

class Source(BaseModel):
    region: str
    env: str
    service_provider: str

class active(BaseModel):
    name: str
    LastModifiedOn: str
    user: str
    Created_On: str

class Dict(BaseModel):
    Active: List[active] = []
    Deleted = []

class standalone_inventory(Document):
    def __init__ (self):
        doc()

    # # source: Source
    # # ts: datetime = Field(default_factory=datetime.now())
    # # Inserted_time: str
    # # informatica: Dict
    # # tableau: Dict
    # redshift: Dict
    # informaticajvm: Dict
    # ec2: Dict
    # powerexchangejvm: Dict
    # # rdsoracle: Dict

    class Settings:
        name: "standalone_inventory"
        # timeseries = TimeSeriesConfig(
        #     time_field="ts",  # Required
        #     meta_field = "source",
        #     granularity=Granularity.minutes  # Optional
        #     #expire_after_seconds=2  # Optional
        # )
