
from datetime import datetime
from typing import List, Optional

from beanie import Document, TimeSeriesConfig, Granularity
from pydantic import BaseModel, Field


class Source(BaseModel):
    region: str
    env: str
    service_provider: str



# class NodeInfo(BaseModel):
#     build: Optional[str]
#     buildDate: Optional[str]
#     databaseConnections: Optional[str]
#     databaseName: Optional[str]
#     databaseType: Optional[str]
#     databaseURL: Optional[str]
#     license: Optional[str]
#     licenseExpired: Optional[bool]
#     memoryFree: Optional[str]
#     memoryMaximum: Optional[str]
#     memoryUsed: Optional[str]
#     nodeId: Optional[str]
#     nodeMode: Optional[str]
#     nodeTime: Optional[str]
#     nodeUptime: Optional[str]
#     release: Optional[str]

class TaskWorkflowInfo(BaseModel):
    task_uniqueId: Optional[str]
    task_instanceNumber: Optional[int]
    task_businessService: Optional[str]
    task_taskName: Optional[str]
    task_executionUser: Optional[str]
    task_status: Optional[str]
    task_statusDescription: Optional[str]
    task_exitCode: Optional[str]
    task_progress_percent: Optional[int]
    task_startTime: Optional[str]
    task_endTime: Optional[str]
    task_duration_ms: Optional[int]
    task_agent: Optional[str]
    task_taskId: Optional[str]
    task_triggerTime: Optional[str]
    task_triggeredBy: Optional[str]
    task_type: Optional[str]
    databricks_api_return_code: Optional[str]
    databricks_run_id: Optional[str]
    databricks_result_state: Optional[str]
    databricks_job_id: Optional[str]
    databricks_lifecycle_state: Optional[str]
    SB_DBricks_conn_fail: Optional[int]
    sbranchCancel_dbricksRunning: Optional[int]
    sbranchStart_dbricksFail: Optional[int]
    sbranchSuccess_dbricksFail: Optional[int]
    workflow_instanceName: Optional[str]
    workflow_definitionId: Optional[str]
    workflow_instanceId: Optional[str]
    workflow_instanceNumber: Optional[int]
    workflow_startTime: Optional[str]
    workflow_endTime: Optional[str]
    workflow_businessService: Optional[str]
    workflow_executionUser: Optional[str]
    workflow_status: Optional[str]
    workflow_statusDescription: Optional[str]
    workflow_progress_percent: Optional[int]
    workflow_duration_ms: Optional[int]

class stonebranch(Document):
    source: Source
    ts: datetime = Field(default_factory=datetime.now())
    # status: Optional[NodeInfo]
    tasks: List[TaskWorkflowInfo] = []

    class Settings:
        name: "stonebranch"
        timeseries = TimeSeriesConfig(
            time_field="ts",  # Required
            meta_field = "source",
            granularity=Granularity.minutes  # Optional
            #expire_after_seconds=2  # Optional
        )