from __future__ import annotations
from metricservice.server.models.aks import aks
from metricservice.server.models.aks import ManagedClusters
from metricservice.server.models.aks import Computer
from metricservice.server.models.aks import Container
from metricservice.server.models.aks import Node

from fastapi import APIRouter
import datetime

aksnoderouter = APIRouter()


def prepare_aks_response(start_date: datetime.datetime,
                         end_date: datetime.datetime,
                         env: str,
                         results: aks) -> dict:
    # print("RESULTS: ", results)

    # get all the metric key names by creating test object
    m = ManagedClusters(aks_name="example", Node=[])
    n = Node()

    metric_names = list(m.dict(by_alias=True, exclude={'Computer', 'Container', 'Node'})) + list(n.dict(by_alias=True))

    # flatten the JSON object
    flat_list = []
    for record in results:
        managed_cluster_metric_value = []
        for job1 in record.managed_clusters:
            for key in job1.dict().keys():
                if key != "Computer" and key != "Container" and key != "Node":
                    value = job1.dict()[key]
                    if value is not None:
                        managed_cluster_metric_value.append(str(value))
                    else:
                        managed_cluster_metric_value.append("")
            if job1.Node is not None:
                if len(job1.Node) > 0:
                    for job2 in job1.Node:
                        metric_record = {"timestamp": str(record.ts), "metric_value": managed_cluster_metric_value.copy()}
                        metric_value = []
                        for key in job2.dict().keys():
                            value = job2.dict()[key]
                            if value is not None:
                                metric_value.append(str(value))
                            else:
                                metric_value.append("")
                        metric_record["metric_value"] += metric_value;
                        flat_list.append(metric_record)
                else:
                    metric_record = {"timestamp": str(record.ts), "metric_value": managed_cluster_metric_value.copy()}
                    n1 = Node()
                    l = len(n1.dict().keys())
                    metric_value = [''] * l
                    metric_record["metric_value"] += metric_value;
                    flat_list.append(metric_record)

    # create final response
    response_metrics_record = {
        "service_provider": "",
        "env_name": env,
        "account_id": "",
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["aks_name", "ShortInstanceName"], "metric_name": list(metric_names)},
        "metric_records": flat_list
    }
    return response_metrics_record


# TODO: removed optional params and test with paging before production
@aksnoderouter.get("/", response_description="Metric records retrieved")
async def get_aks_node_record(start_date: datetime.datetime | None = None,
                             end_date: datetime.datetime | None = None,
                             env: str | None = None) -> aks:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await aks.find_all().to_list();
    else:
        criteria = {"$and": [{"ts": {"$gte": start_date, "$lte": end_date}},
                             {"source.env": {"$eq": env}}
                             ]}
        results = await aks.find_many(criteria).to_list();
    return prepare_aks_response(start_date, end_date, env, results)


# TODO: remove this end point before production
@aksnoderouter.post("/", response_description=" Metrics added to the database")
async def add_aks_node_record(review: aks) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}
