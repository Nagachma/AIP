from __future__ import annotations
from metricservice.server.models.aurora_postgres import aurorapostgres
from metricservice.server.models.aurora_postgres import Instance
from metricservice.server.models.aurora_postgres import Query

from fastapi import APIRouter
import datetime


aurorapostgres_query_router = APIRouter()

def prepare_aurorapostgres_query_response(start_date: datetime.datetime,
                    end_date: datetime.datetime,
                    env: str,
                    results: aurorapostgres) -> dict:

    # print("RESULTS: ", results)

    # get all the metric key names by creating test object
    i = Instance(instance_name="example", conn_count=[], conn_used=[], hot_rate=[], percent_of_times_index=[], pg_stat_database=[], pg_stat_user_tables=[], res_for_super=[])
    q = Query()

    metric_names = list(i.dict(by_alias=True, exclude={'conn_count', 'conn_used', 'hot_rate', 'percent_of_times_index', 'pg_stat_database', 'pg_stat_user_tables', 'queries','res_for_super'})) + list(q.dict(by_alias=True))

    # flatten the JSON object
    flat_list = []
    for record in results:
        instance_metric_value = []
        for job1 in record.instances:
            for key in job1.dict().keys():
                if key != "conn_count" and key != "conn_used" and key!= "hot_rate" and key!= "percent_of_times_index" and key!= "pg_stat_database" and key!= "pg_stat_user_tables" and key!= "res_for_super" and key!= "queries":
                    value = job1.dict()[key]
                    if value is not None:
                        instance_metric_value.append(str(value))
                    else:
                        instance_metric_value.append("")
            if job1.queries is not None:
                if len(job1.queries) > 0:
                    for job2 in job1.queries:
                        metric_record = {"timestamp": str(record.ts), "metric_value": instance_metric_value.copy()}
                        metric_value = []
                        for key in job2.dict().keys():
                            value = job2.dict()[key]
                            if value is not None:
                                metric_value.append(str(value))
                            else:
                                metric_value.append("")
                        metric_record["metric_value"] += metric_value;
                        flat_list.append(metric_record)
                else:
                    metric_record = {"timestamp": str(record.ts), "metric_value": instance_metric_value.copy()}
                    q1 = Query()
                    l = len(q1.dict().keys())
                    metric_value = [''] * l
                    metric_record["metric_value"] += metric_value;
                    flat_list.append(metric_record)

    # create final response
    response_metrics_record = {
        "service_provider": "",
        "env_name": env,
        "account_id": "",
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["instance_name", "datid"], "metric_name": list(metric_names)},    #, "PipelineName", "LabelingJobName", "LabelingJob"
        "metric_records": flat_list
    }
    return response_metrics_record

# TODO: removed optional params and test with paging before production
@aurorapostgres_query_router.get("/", response_description="Metric records retrieved")
async def get_aurorapostgres_conn_count_record(start_date: datetime.datetime | None = None,
                        end_date: datetime.datetime | None = None,
                        env: str | None = None) -> aurorapostgres:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await aurorapostgres.find_all().to_list();
    else:
        criteria = {"$and": [ {"ts": {"$gte": start_date, "$lte": end_date}},
                            {"source.env": {"$eq": env}}
                            ]}
        results = await aurorapostgres.find_many(criteria).to_list();
    return prepare_aurorapostgres_query_response(start_date, end_date, env, results)

# TODO: remove this end point before production
@ aurorapostgres_query_router.post("/", response_description=" Metrics added to the database")
async def add_aurorapostgres_conn_count_record(review: aurorapostgres) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}