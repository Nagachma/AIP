from fastapi import APIRouter
import datetime
from metricservice.server.models.awsdatabricks import awsdatabricks
from metricservice.server.models.awsdatabricks import Cluster
from metricservice.server.models.awsdatabricks import Job
from metricservice.server.models.awsdatabricks import Task

awsdatabricksrouter = APIRouter()

def prepare_awsdatabricks_response(start_date: datetime.datetime,
                     end_date: datetime.datetime,
                     env: str,
                     results: awsdatabricks) -> dict:
    # flatten the JSON object
    flat_list = [] 
    for record in results:
        for cluster in record.clusters:
            #bucket_metric_value = []
            cluster_metric_value = []
            is_job=False

            for key in cluster.dict().keys():
                value = cluster.dict()[key]
                if key == 'Jobs' and value is not None:
                    is_job=True
                elif value is not None:
                    cluster_metric_value.append(str(value))
                else:
                    cluster_metric_value.append('')

            if is_job:
                for job in cluster.dict()['Jobs']:
                    print("job", job)
                    is_taskp=False
                    #bucket_metric_value_temp = []
                    cluster_metric_value_temp = []
                    cluster_metric_value_temp.extend(cluster_metric_value)

                    for key in job.keys():
                        value_ = job[key]
                        # print("Key", key)
                        # print("job value", value_)
                        if key == 'Tasks' and value_ is not None:
                            # print("is it going in this loop")
                            is_taskp=True
                        elif value_ is not None:
                            cluster_metric_value_temp.append(str(value_))
                        else:
                            cluster_metric_value_temp.append('')

                    if is_taskp:
                        print("job['Tasks']", job['Tasks'])
                        # print("job.dict()['Tasks']", job.dict()['Tasks'])
                        for task in job['Tasks']:
                            cluster_metric_value_temp1 = []
                            cluster_metric_value_temp1.extend(cluster_metric_value_temp)
                            for key in task.keys():
                                valuee = task[key]
                                if valuee is not None:
                                    cluster_metric_value_temp1.append(str(valuee))
                                else:
                                    cluster_metric_value_temp1.append('')
                            metric_record_ = {"timestamp": str(record.ts), "metric_value": cluster_metric_value_temp1}
                            flat_list.append(metric_record_)
                    else:
                        eb = Task(task="abc")
                        l = len(eb.dict().keys()) - 1
                        cluster_metric_value_temp1 = ['']*l
                        cluster_metric_value_temp.extend(cluster_metric_value_temp1)
                        metric_record_= {"timestamp": str(record.ts), "metric_value": cluster_metric_value_temp} 
                        flat_list.append(metric_record_)

            else:
                eb = Job(job_id="1")
                l = len(eb.dict().keys())
                b = Task(task="abc")
                ll = len(b.dict().keys())
                l = l + ll - 2
                cluster_metric_value_temp = ['']*l
                cluster_metric_value.extend(cluster_metric_value_temp)
                metric_record = {"timestamp": str(record.ts), "metric_value": cluster_metric_value}
                flat_list.append(metric_record)

    # get all the metric key names by creating test object
    j = Task(task="abc")
    ev_ = Job(job_id="1")
    b = Cluster(cluster_id="0112-044605-csfvn6ja")
    metric_names = list(b.dict(by_alias=True, exclude={"Jobs"}))
    metric_names = metric_names + list(ev_.dict(by_alias=True, exclude={"Tasks"}))
    metric_names = metric_names + list(j.dict(by_alias=True))
    print(str(metric_names))


    # create final response
    response_metrics_record = {
        "service_provider": "",
        "env_name": env,
        "account_id": "",
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["cluster_name"], "metric_name": list(metric_names)},
        "metric_records": flat_list
    }
    return response_metrics_record   

# TODO: removed optional params and test with paging before production
@awsdatabricksrouter.get("/", response_description="Metric records retrieved")
async def get_awsdatabricks_record(start_date: datetime.datetime | None = None,
                        end_date: datetime.datetime | None = None,
                        env: str | None = None) -> awsdatabricks:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await awsdatabricks.find_all().to_list();
    else:
        criteria = {"$and": [ {"ts": {"$gte": start_date, "$lte": end_date}},
                              {"source.env": {"$eq": env}}
                              ]}
        results = await awsdatabricks.find_many(criteria).to_list();
    return prepare_awsdatabricks_response(start_date, end_date, env, results)

# TODO: remove this end point before production
@awsdatabricksrouter.post("/", response_description=" Metrics added to the database")
async def add_awsdatabricks_record(review: awsdatabricks) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}
