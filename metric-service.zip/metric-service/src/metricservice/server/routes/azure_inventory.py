from fastapi import APIRouter
from metricservice.server.models.azure_inventory import azure_inventory

azure_invent_router = APIRouter()


def prepare_response(ser,
                     results: azure_inventory) -> [dict]:
    # flatten the JSON object
    flat_list = []
    # results.sort(key=lambda obj: obj.get('insertedTime'), reverse=True)
    # print(results)
    # print(len(results))
    # print (ser)
    max_inserted_time = ''
    for doc in results:
        if '' == max_inserted_time:
            max_inserted_time = doc.insertedTime
        if max_inserted_time < doc.insertedTime:
            max_inserted_time = doc.insertedTime
    # print(f'max inserted time: {max_inserted_time}')

    for res in results:
        # print(res.insertedTime)
        # print (res[1])
        if max_inserted_time == res.insertedTime:
            for key in res.__dict__.keys():
                if key in ['id', 'revision_id', 'insertedTime']:
                    continue
                if len(ser) > 0:
                    if (key.lower()) in ser:
                        dict = {key: res.__dict__[key]}
                        flat_list.append(dict)
                else:
                    dict = {key: res.__dict__[key]}
                    flat_list.append(dict)
            break

    # create final response
    response_metrics_record = flat_list
    return response_metrics_record


# TODO: removed optional params and test with paging before production
@azure_invent_router.get("/", response_description="Metric records retrieved")
async def get_review_record(service: str | None = None, environment: str | None = None) -> azure_inventory:
    # print("Document: ", Document)

    if service is None:
        ser = []
        # ser = ["Glue","Lambda"]
    else:
        ser = [service.lower()]
    results = await azure_inventory.find_all().to_list()
    # print(ser)
    # print(results)
    return prepare_response(ser, results)


# TODO: remove this end point before production
@azure_invent_router.post("/", response_description="Metrics added to the database")
async def add_inventory_record(review: azure_inventory) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}
