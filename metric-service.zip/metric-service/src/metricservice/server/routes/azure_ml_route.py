import datetime

from fastapi import APIRouter

from metricservice.server.models.azure_ml import azure_ml
from metricservice.server.models.azure_ml import Workspace,Cluster,Jobs


azuremlrouter = APIRouter()


def prepare_azure_ml_response(start_date: datetime.datetime,
                                end_date: datetime.datetime,
                                env: str,
                                results: azure_ml) -> dict:
    flat_list = []
    for doc in results:

        azure_ml_metric_value = []
        if len(doc.workspaces) > 0:
            for workspace in doc.workspaces:
                # print(workspace.dict().keys())
                workspace_metric_value=[]
                for key in workspace.dict().keys():
                    if key != "Cluster" and key != "Jobs":
                        value1 = workspace.dict()[key]
                        if value1 is not None:
                            workspace_metric_value.append(str(value1))
                        else:
                            workspace_metric_value.append("")
                if workspace.Cluster is not None and len(workspace.Cluster) > 0:
                    for cluster in workspace.Cluster: # iterating clusters
                        clus_metric_value = []
                        clus_metric_value.extend(workspace_metric_value)
                        for key in cluster.dict().keys():
                            if key != "Jobs":
                                value1 = cluster.dict()[key]
                                if value1 is not None:
                                    clus_metric_value.append(str(value1))
                                else:
                                    clus_metric_value.append("")
                        if cluster.Jobs is not None and len(cluster.Jobs) > 0:
                            for job in cluster.Jobs: # iterating clusters
                                job_metric_value = []
                                job_metric_value.extend(clus_metric_value)
                                for key in job.dict().keys():
                                    value1 = job.dict()[key]
                                    if value1 is not None:
                                        job_metric_value.append(str(value1))
                                    else:
                                        job_metric_value.append("")
                                metric_record_ = {"timestamp": str(doc.ts), "metric_value": job_metric_value}
                                flat_list.append(metric_record_)
                        else:
                            metric_record = {"timestamp": str(doc.ts), "metric_value": clus_metric_value.copy()}
                            b1 = Jobs()
                            l = len(b1.dict().keys())
                            metric_value = [''] * l
                            metric_record["metric_value"] += metric_value
                            flat_list.append(metric_record)
                else:
                    metric_record = {"timestamp": str(doc.ts), "metric_value": workspace_metric_value.copy()}
                    b1 = Cluster()
                    l0 = len(b1.dict().keys())
                    metric_value = [''] * (l0 - 1)
                    metric_record["metric_value"] += metric_value
                    b2 = Jobs()
                    l1 = len(b2.dict().keys())
                    _metric_value = [''] * l1
                    metric_record["metric_value"] += _metric_value
                    flat_list.append(metric_record)

    # print(flat_list)
    # get all the metric key names by creating test object
    a1 = Jobs(JobName="example1")
    a2 = Cluster(ClusterName="example1")
    a3 = Workspace(workspace_name="example1")

    metric_names = list(a3.dict(by_alias=True, exclude={"Cluster"})) + list(a2.dict(by_alias=True, exclude={"Jobs"})) + list(a1.dict(by_alias=True))
    response_metrics_record = {
        "service_provider": "",
        "env_name": env,
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["workspace_name", "ClusterName", "JobName"],
                    "metric_name": metric_names},
        "metric_records": flat_list
    }
    return response_metrics_record


# TODO: removed optional params and test with paging before production
@azuremlrouter.get("/", response_description="Metric records retrieved")
async def get_azure_ml_record(start_date: datetime.datetime | None = None,
                                end_date: datetime.datetime | None = None,
                                env: str | None = None) -> azure_ml:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await azure_ml.find_all().to_list();
    else:
        criteria = {"$and": [{"ts": {"$gte": start_date, "$lte": end_date}},
                             {"source.env": {"$eq": env}}
                             ]}
        results = await azure_ml.find_many(criteria).to_list();
    return prepare_azure_ml_response(start_date, end_date, env, results)


# TODO: remove this end point before production
@azuremlrouter.post("/", response_description=" Metrics added to the database")
async def add_azure_ml_record(review: azure_ml) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}
