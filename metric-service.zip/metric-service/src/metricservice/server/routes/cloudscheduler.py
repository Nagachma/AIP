from __future__ import annotations

from metricservice.server.models.cloud_scheduler import cloud_scheduler, Job
from fastapi import APIRouter
import datetime

cloud_scheduler_router = APIRouter()


def prepare_jobs_response(start_date: datetime.datetime,
                          end_date: datetime.datetime,
                          env: str,
                          results: cloud_scheduler) -> dict:
    # get all the metric key names by creating test object
    j = Job(job_id="example1")

    metric_names = list(j.dict(by_alias=True))

    flat_list = []
    for record in results:
        for job in record.jobs:
            jobs_metric_value = [dict(job).get(metric) if dict(job).get(metric) is not None else ''
                                 for metric in metric_names]
            metric_record = {"timestamp": str(record.ts), "metric_value": jobs_metric_value}
            flat_list.append(metric_record)

    # create final response
    response_metrics_record = {
        "service_provider": "",
        "env_name": env,
        "account_id": "",
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["job_id"], "metric_name": list(metric_names)},
        "metric_records": flat_list
    }
    return response_metrics_record


# TODO: removed optional params and test with paging before production
@cloud_scheduler_router.get("/", response_description="Metric records retrieved")
async def get_jobs_record(start_date: datetime.datetime | None = None,
                          end_date: datetime.datetime | None = None,
                          env: str | None = None) -> dict:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await cloud_scheduler.find_all().to_list()
    else:
        criteria = {"$and": [{"ts": {"$gte": start_date, "$lte": end_date}},
                             {"source.env": {"$eq": env}}
                             ]}
        results = await cloud_scheduler.find_many(criteria).to_list()
    return prepare_jobs_response(start_date, end_date, env, results)


# TODO: remove this end point before production
@cloud_scheduler_router.post("/", response_description=" Metrics added to the database")
async def add_jobs_record(review: cloud_scheduler) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}
