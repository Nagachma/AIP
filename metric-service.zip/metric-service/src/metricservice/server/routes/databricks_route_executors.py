import datetime

from fastapi import APIRouter

from metricservice.server.models.databricks import Executor, Cluster, Workspace, Job, Run, Task
from metricservice.server.models.databricks import databricks

databricksexecutorrouter = APIRouter()


def prepare_databricks_response(start_date: datetime.datetime,
                                end_date: datetime.datetime,
                                env: str,
                                results: databricks) -> dict:
    flat_list = []
    # print(results)
    for doc in results:

        if len(doc.workspaces) > 0:
            for workspace in doc.workspaces:
                databricks_metric_value = []
                for key in workspace.dict().keys():
                    value1 = workspace.dict()[key]

                    if value1 is None:
                        databricks_metric_value.append('')
                    elif value1 is not None and type(value1) != list:
                        databricks_metric_value.append(value1)
                    elif key=='cluster' and value1 is not None and type(value1) == list: #cluster
                        i = 0

                        for i in range(len(value1)):
                            cluster_metric_value = []
                            for keys1, val1 in value1[i].items():
                                if keys1 == 'executor' and val1 is None:
                                    databricks_metric_value_temp = []
                                    e = Executor()
                                    l = len(e.dict().keys())
                                    executor_metric_value_temp = [''] * l
                                    print(executor_metric_value_temp)
                                    databricks_metric_value_temp = databricks_metric_value + cluster_metric_value + executor_metric_value_temp
                                    metric_record = {"timestamp": str(doc.ts),
                                                     "metric_value": databricks_metric_value_temp}
                                    flat_list.append(metric_record)
                                # iterating clusters
                                elif val1 is None and (keys1!='executor' or keys1!='jobs'):
                                    cluster_metric_value.append('')
                                elif val1 is not None and type(val1) != list:
                                    cluster_metric_value.append(str(val1))
                                elif keys1=='executor' and val1 is not None and type(val1) == list: #jobs/executors

                                    print("\n\n.....\n",val1,"\n.....\n\n")
                                    j = 0
                                    for j in range(len(val1)):
                                        databricks_metric_value_temp=[]
                                        executor_metric_value = []
                                        for keys2, val2 in val1[j].items(): #iterating jobs/executors
                                            # print(keys2, val2)
                                            if val2 is not None and type(val2) != list:
                                                executor_metric_value.append(str(val2))
                                            else:
                                                executor_metric_value.append('')

                                        print(executor_metric_value)
                                        databricks_metric_value_temp=databricks_metric_value+cluster_metric_value+executor_metric_value
                                        metric_record = {"timestamp": str(doc.ts), "metric_value": databricks_metric_value_temp}
                                        flat_list.append(metric_record)
                                        j = j + 1

                            i = i + 1

    print(flat_list)
    # get all the metric key names by creating test object
    a1 = Executor(executor="example1")
    a2 = Cluster(ClusterId="example1")
    a3 = Workspace(workspaceName="example1", timeGenerated="example1")

    metric_names = list(a3.dict(by_alias=True, exclude={"cluster"})) + list(a2.dict(by_alias=True, exclude={"executor","jobs"})) + list(a1.dict(by_alias=True))
    response_metrics_record = {
        "service_provider": "",
        "env_name": env,
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["workspaceName", "ClusterId", "executor"],
                    "metric_name": metric_names},
        "metric_records": flat_list
    }
    return response_metrics_record


# TODO: removed optional params and test with paging before production
@databricksexecutorrouter.get("/", response_description="Metric records retrieved")
async def get_databricks_record(start_date: datetime.datetime | None = None,
                                end_date: datetime.datetime | None = None,
                                env: str | None = None) -> databricks:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await databricks.find_all().to_list();
    else:
        criteria = {"$and": [{"ts": {"$gte": start_date, "$lte": end_date}},
                             {"source.env": {"$eq": env}}
                             ]}
        results = await databricks.find_many(criteria).to_list();
    return prepare_databricks_response(start_date, end_date, env, results)


# TODO: remove this end point before production
@databricksexecutorrouter.post("/", response_description=" Metrics added to the database")
async def add_databricks_record(review: databricks) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}