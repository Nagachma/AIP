import datetime

from fastapi import APIRouter

from metricservice.server.models.databricks import Executor, Cluster, Workspace, Job, Run, Task
from metricservice.server.models.databricks import databricks

databricksrunsrouter = APIRouter()


def prepare_databricks_response(start_date: datetime.datetime,
                                end_date: datetime.datetime,
                                env: str,
                                results: databricks) -> dict:
    flat_list = []
    # print(results)
    for doc in results:

        if len(doc.workspaces) > 0:
            for workspace in doc.workspaces:
                databricks_metric_value = []
                for key in workspace.dict().keys():
                    value1 = workspace.dict()[key]

                    if value1 is None:
                        databricks_metric_value.append('')
                    elif value1 is not None and type(value1) != list:
                        databricks_metric_value.append(value1)
                    elif key=='cluster' and value1 is not None and type(value1) == list: #cluster
                        if len(value1)> 0:
                            i=0
                            for i in range(len(value1)):

                                cluster_metric_value=[]
                                for keys1, val1 in value1[i].items():  # iterating clusters
                                    if keys1 =='jobs' and val1 is None:
                                        t = Task()
                                        l1 = len(t.dict().keys())
                                        task_metric_value_temp = [''] * l1
                                        r = Run()
                                        l2 = len(r.dict().keys()) - 1
                                        run_metric_value_temp = [''] * l2
                                        j = Job()
                                        l3 = len(j.dict().keys()) -1
                                        job_metric_value_temp=[''] * l3
                                        databricks_metric_value_temp = databricks_metric_value + cluster_metric_value + job_metric_value_temp + run_metric_value_temp + task_metric_value_temp
                                        metric_record = {"timestamp": str(doc.ts),
                                                         "metric_value": databricks_metric_value_temp}
                                        flat_list.append(metric_record)
                                    elif val1 is None and (keys1!='executor' or keys1!='jobs'):
                                        cluster_metric_value.append('')
                                    elif val1 is not None and type(val1) != list:
                                        cluster_metric_value.append(str(val1))
                                    elif keys1=='jobs' and val1 is not None and type(val1) == list: #jobs
                                        j = 0
                                        for j in range(len(val1)): #iterating jobs
                                            job_metric_value = []
                                            for key2, val2 in val1[j].items(): #iterating jobs
                                                if key2=='runs' and val2 is None:
                                                    t = Task()
                                                    l1 = len(t.dict().keys())
                                                    task_metric_value_temp = [''] * l1
                                                    r = Run()
                                                    l2 = len(r.dict().keys())-1
                                                    run_metric_value_temp=['']*l2
                                                    databricks_metric_value_temp = databricks_metric_value + cluster_metric_value + job_metric_value + run_metric_value_temp + task_metric_value_temp
                                                    metric_record = {"timestamp": str(doc.ts),
                                                                     "metric_value": databricks_metric_value_temp}
                                                    flat_list.append(metric_record)
                                                elif val2 is None and key2!='runs':
                                                    job_metric_value.append('')
                                                elif val2 is not None and type(val2) != list:
                                                    job_metric_value.append(str(val2))
                                                elif key2=='runs' and val2 is not None and type(val2) == list:

                                                    if len(val2)>0:
                                                        r = 0
                                                        for r in range(len(val2)):
                                                            databricks_metric_value_temp = []
                                                            run_metric_value=[]
                                                            for key3, val3 in val2[r].items():
                                                                if val3 is None:
                                                                    run_metric_value.append('')
                                                                elif val3 is not None and type(val3)!= list:
                                                                    run_metric_value.append(str(val3))
                                                            databricks_metric_value_temp = databricks_metric_value + cluster_metric_value + job_metric_value + run_metric_value
                                                            metric_record = {"timestamp": str(doc.ts),
                                                                             "metric_value": databricks_metric_value_temp}
                                                            flat_list.append(metric_record)
                                                            r=r+1

                                            j=j+1

                                i=i+1

    print(flat_list)
    # get all the metric key names by creating test object
    a2 = Cluster(ClusterId="example1")
    a3 = Workspace(workspaceName="example1", timeGenerated="example1")
    a4 = Job(job_id=1)
    a5 = Run(run_id=1)

    metric_names = list(a3.dict(by_alias=True, exclude={"cluster"})) + list(a2.dict(by_alias=True, exclude={"executor","jobs"})) +\
                   list(a4.dict(by_alias=True, exclude={"runs"}))+list(a5.dict(by_alias=True, exclude={"tasks"}))
    response_metrics_record = {
        "service_provider": "",
        "env_name": env,
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["workspaceName", "ClusterId", "job_id","run_id"],
                    "metric_name": metric_names},
        "metric_records": flat_list
    }
    return response_metrics_record


# TODO: removed optional params and test with paging before production
@databricksrunsrouter.get("/", response_description="Metric records retrieved")
async def get_databricks_record(start_date: datetime.datetime | None = None,
                                end_date: datetime.datetime | None = None,
                                env: str | None = None) -> databricks:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await databricks.find_all().to_list();
    else:
        criteria = {"$and": [{"ts": {"$gte": start_date, "$lte": end_date}},
                             {"source.env": {"$eq": env}}
                             ]}
        results = await databricks.find_many(criteria).to_list();
    return prepare_databricks_response(start_date, end_date, env, results)


# TODO: remove this end point before production
@databricksrunsrouter.post("/", response_description=" Metrics added to the database")
async def add_databricks_record(review: databricks) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}