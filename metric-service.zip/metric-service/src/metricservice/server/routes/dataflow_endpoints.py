import datetime

from fastapi import APIRouter

from metricservice.server.models.dataflow import dataflow
from metricservice.server.models.dataflow import Endpoints


dataflow_endpoints_router = APIRouter()


def prepare_dataflow_response(start_date: datetime.datetime,
                                end_date: datetime.datetime,
                                env: str,
                                results: dataflow) -> dict:
    flat_list = []
    for record in results:
        # if len(record.jobs) > 0:
        for endpoint in record.endpoints:
            endpoint_metric_value=[]
            for key in endpoint.dict().keys():
                value1 = endpoint.dict()[key]
                if value1 is not None:
                    endpoint_metric_value.append(str(value1))
                else:
                    endpoint_metric_value.append("")
            metric_record = {"timestamp": str(record.ts), "metric_value": endpoint_metric_value.copy()}
            flat_list.append(metric_record)
    
    print(flat_list)
            
    # get all the metric key names by creating test object
    a1 = Endpoints(EndpointName="example1")

    metric_names = list(a1.dict(by_alias=True))
    response_metrics_record = {
        "service_provider": "",
        "env_name": env,
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["endpoint"],"metric_name": list(metric_names)},
        "metric_records": flat_list
    }
    return response_metrics_record


# TODO: removed optional params and test with paging before production
@dataflow_endpoints_router.get("/", response_description="Metric records retrieved")
async def get_dataflow_record(start_date: datetime.datetime | None = None,
                                end_date: datetime.datetime | None = None,
                                env: str | None = None) -> dataflow:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await dataflow.find_all().to_list();
    else:
        criteria = {"$and": [{"ts": {"$gte": start_date, "$lte": end_date}},
                             {"source.env": {"$eq": env}}
                             ]}
        results = await dataflow.find_many(criteria).to_list();
    return prepare_dataflow_response(start_date, end_date, env, results)


# TODO: remove this end point before production
@dataflow_endpoints_router.post("/", response_description=" Metrics added to the database")
async def add_dataflow_record(review: dataflow) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}
