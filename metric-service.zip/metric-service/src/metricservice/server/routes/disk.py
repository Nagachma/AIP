from __future__ import annotations
from metricservice.server.models.disk import disk
from metricservice.server.models.disk import disk_connectivity
from metricservice.server.models.disk import disks
from fastapi import APIRouter
import datetime


diskrouter = APIRouter()

def prepare_disk_response(start_date: datetime.datetime,
                     end_date: datetime.datetime,
                     env: str,
                     results: disk) -> dict:

    # print("RESULTS: ", results)

    # get all the metric key names by creating test object
    dc = disk_connectivity(disks=[])
    d = disks()

    metric_names = list(d.dict(by_alias=True))

    # flatten the JSON object
    flat_list = []
    for record in results:
        diskconnectivity_metric_value = []
        for job1 in record.disk_connectivity:
            for key in job1.dict().keys():
                if key !="disks":
                    value = job1.dict()[key]
                    if value is not None:
                        diskconnectivity_metric_value.append(str(value))
                    else:
                        diskconnectivity_metric_value.append("")
            if job1.disks is not None:
                if len(job1.disks) > 0:
                    for job2 in job1.disks:
                        metric_record = {"timestamp": str(record.ts), "metric_value": diskconnectivity_metric_value.copy()}
                        metric_value = []
                        for key in job2.dict().keys():
                            value = job2.dict()[key]
                            if value is not None:
                                metric_value.append(str(value))
                            else:
                                metric_value.append("")
                        metric_record["metric_value"] += metric_value
                        flat_list.append(metric_record)
                else:
                    metric_record = {"timestamp": str(record.ts), "metric_value": diskconnectivity_metric_value.copy()}
                    d = disks()
                    l = len(d.dict().keys())
                    metric_value = [''] * l
                    metric_record["metric_value"] += metric_value
                    flat_list.append(metric_record)

    # create final response
    response_metrics_record = {
        "service_provider": "",
        "env_name": env,
        "account_id": "",
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["disk_name"], "metric_name": list(metric_names)},    #, "PipelineName", "LabelingJobName", "LabelingJob"
        "metric_records": flat_list
    }
    return response_metrics_record

# TODO: removed optional params and test with paging before production
@diskrouter.get("/", response_description="Metric records retrieved")
async def get_synapse_record(start_date: datetime.datetime | None = None,
                        end_date: datetime.datetime | None = None,
                        env: str | None = None) -> disk:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await disk.find_all().to_list();
    else:
        criteria = {"$and": [ {"ts": {"$gte": start_date, "$lte": end_date}},
                              {"source.env": {"$eq": env}}
                              ]}
        results = await disk.find_many(criteria).to_list();
    return prepare_disk_response(start_date, end_date, env, results)

# TODO: remove this end point before production
@diskrouter.post("/", response_description=" Metrics added to the database")
async def add_disk_record(review: disk) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}





