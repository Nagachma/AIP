from __future__ import annotations

from metricservice.server.models.ec2 import ec2, Disk, instance

from fastapi import APIRouter
import datetime

ec2_router = APIRouter()


def prepare_metrics_response(start_date: datetime.datetime.now(),
                          env: str,
                          results: ec2) -> dict:
    # print (results)
    # get all the metric key names by creating test object
    i = instance(TASK_NAME='example1')
    metric_names = []
    metric_names.extend(list(i.dict(by_alias=True)))
    # print (metric_names)
    j = Disk(TASK_NAME='example1')
    # metric_names = []
    metric_names.extend(list(j.dict(by_alias=True)))
    metric_names.remove('disks')
    # print (metric_names)

    flat_list = []
    # # print (results.workflows)
    for record in results:
        for metrics in record.disk_connectivity:
            print (metrics)
            
            for disk in dict(metrics).get('disks'):
                metrics_value_list = []
                metrics_value_list.append(dict(metrics).get('instance_ip'))
                metrics_value_list.append(dict(metrics).get('instance_name'))
                # metrics_value_list.append(dict(metrics).get('CPU_Utilization'))
                metrics_value_list.append(dict(metrics).get('NetworkIn'))
                metrics_value_list.append(dict(metrics).get('Networkout'))
                metrics_value_list.append(dict(metrics).get('DiskReadBytes'))
                metrics_value_list.append(dict(metrics).get('DiskWriteBytes'))
                metrics_value_list.append(dict(metrics).get('DiskReadOps'))
                metrics_value_list.append(dict(metrics).get('DiskWriteOps'))
                # metrics_value_list.append(dict(metrics).get('Total_Network_Traffic'))
                metrics_value_list.extend(list(dict(disk).values()))
                metric_record = {"timestamp": str(record.ts), "metric_value": metrics_value_list}
                flat_list.append(metric_record)

    # create final response
    response_metrics_record = {
        "service_provider": "ec2",
        "env_name": env,
        "metrics": {"dimension": ["instance_name"], "metric_name": list(metric_names)},
        "metric_records": flat_list
    }
    return response_metrics_record


# TODO: removed optional params and test with paging before production
@ec2_router.get("/", response_description="Metric records retrieved")
async def get_informatica_sgws_record(start_date: datetime.datetime | None = None,
                          end_date: datetime.datetime | None = None,
                          env: str | None = None) -> dict:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await ec2.find_all().to_list()
    else:
        criteria = {"$and": [{"ts": {"$gte": start_date, "$lte": end_date}},
                             {"source.env": {"$eq": env}}
                             ]}
        results = await ec2.find_many(criteria).to_list()
    print (results)
    return prepare_metrics_response(start_date, env, results)


# TODO: remove this end point before production
# @informatica_sgws.post("/", response_description=" Metrics added to the database")
# async def add_informatica_sgws_record(review: informatica_sgws) -> dict:
#     await review.create()
#     return {"message": "Metrics added successfully"}
