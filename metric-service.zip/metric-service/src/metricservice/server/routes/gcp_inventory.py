from fastapi import APIRouter
from beanie.odm.enums import SortDirection
from metricservice.server.models.gcp_inventory import gcp_inventory

gcp_inventory_router = APIRouter()


def prepare_response(ser,
                     results: gcp_inventory) -> [dict]:

    if results is None:
        return []

    assets = dict(results)['assets']

    if ser is not None and len(ser) != 0:
        try:
            return [assets[[list(value.keys())[0].lower() for value in assets].index(ser.lower())]]
        except ValueError:
            return []
    elif ser is not None and len(ser) == 0:
        return []
    else:
        return assets


# TODO: removed optional params and test with paging before production
@gcp_inventory_router.get("/", response_description="Metric records retrieved")
async def get_review_record(service: str | None = None, project_id: str | None = None) -> gcp_inventory:
    if project_id is None:
        results = await gcp_inventory.find().sort(('insertedTime', SortDirection.DESCENDING)).first_or_none()
    else:
        criteria = {"$and": [{"projectId": {"$eq": project_id}}]}
        results = await gcp_inventory.find(criteria).sort(('insertedTime', SortDirection.DESCENDING)).first_or_none()
    return prepare_response(service, results)


# TODO: remove this end point before production
@gcp_inventory_router.post("/", response_description="Metrics added to the database")
async def add_inventory_record(review: gcp_inventory) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}
