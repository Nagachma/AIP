from fastapi import APIRouter
import datetime
from metricservice.server.models.glueInvent import glue_custom
from metricservice.server.models.glueInvent import Run

glue_invent_router = APIRouter()


def prepare_response(start_date: datetime.datetime,
                     end_date: datetime.datetime,
                     env: str,
                     results: glue_custom) -> dict:
    # flatten the JSON object
    flat_list = []
    for record in results:
        for job in record.jobs:
            for run in job.runs:
                metric_record = {"timestamp": str(record.ts), "metric_value": ""}
                metric_value = []
                metric_value.append(job.jobname)
                for key in run.dict().keys():
                    value = run.dict()[key]
                    if key == 'job_run_id' and value is not None:
                        metric_value.append(str(value))
                    elif key == 'job_run_id' and value is None:
                        metric_value.append('')
                metric_record["metric_value"] = metric_value;
                flat_list.append(metric_record)
    
    # get all the metric key names by creating test object
    #r = Run(job_run_id=1)
    fixed_names = ["jobname", "job_run_id"]
    metric_names = fixed_names 

    # create final response
    response_metrics_record = {
        "service_provider": "",
        "env_name": env,
        "account_id": "",
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["jobname"], "metric_name": list(metric_names)},
        "metric_records": flat_list
    }
    return response_metrics_record

# TODO: removed optional params and test with paging before production
@glue_invent_router.get("/", response_description="Metric records retrieved")
async def get_review_record(start_date: datetime.datetime | None = None,
                            end_date: datetime.datetime | None = None,
                            env: str | None = None) -> glue_custom:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await glue_custom.find_all().to_list();
    else:
        criteria = {"$and": [ {"ts": {"$gte": start_date, "$lte": end_date}},
                              {"source.env": {"$eq": env}}
                              ]}
        results = await glue_custom.find_many(criteria).to_list();
    return prepare_response(start_date, end_date, env, results)


# TODO: remove this end point before production
@glue_invent_router.post("/", response_description=" Metrics added to the database")
async def add_glue_record(review: glue_custom) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}
