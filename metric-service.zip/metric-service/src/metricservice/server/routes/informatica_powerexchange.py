from __future__ import annotations

from metricservice.server.models.informatica_powerexchange import informaticapowerexchange, Task, WorkFlow

from fastapi import APIRouter
import datetime

informatica_powerexchange_router = APIRouter()


def prepare_metrics_response(start_date: datetime.datetime.now(),
                          env: str,
                          results: informaticapowerexchange) -> dict:
    # get all the metric key names by creating test object
    j = Task(TASK_NAME='example1')
    metric_names = []
    metric_names.append('Workflow_Name')
    metric_names.extend(list(j.dict(by_alias=True)))

    flat_list = []
    for record in results:
        for metrics in record.workflows:
            for task in dict(metrics).get('Tasks'):
                metrics_value_list = []
                metrics_value_list.append(dict(metrics).get('Workflow_Name'))
                metrics_value_list.extend(list(dict(task).values()))
                metric_record = {"timestamp": str(record.ts), "metric_value": metrics_value_list}
                flat_list.append(metric_record)

    # create final response
    response_metrics_record = {
        "service_provider": "Informatica PowerExchange",
        "env_name": env,
        "metrics": {"dimension": ["WorkFlow_Name","TASK_NAME", "Workflow_Execution_ID"], "metric_name": list(metric_names)},
        "metric_records": flat_list
    }
    return response_metrics_record


# TODO: removed optional params and test with paging before production
@informatica_powerexchange_router.get("/", response_description="Metric records retrieved")
async def get_informatica_powerexchange_record(start_date: datetime.datetime | None = None,
                          end_date: datetime.datetime | None = None,
                          env: str | None = None) -> dict:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await informaticapowerexchange.find_all().to_list()
    else:
        criteria = {"$and": [{"ts": {"$gte": start_date, "$lte": end_date}},
                             {"source.env": {"$eq": env}}
                             ]}
        results = await informaticapowerexchange.find_many(criteria).to_list()
    return prepare_metrics_response(start_date, env, results)


# TODO: remove this end point before production
@informatica_powerexchange_router.post("/", response_description=" Metrics added to the database")
async def add_informatica_powerexchange_record(review: informaticapowerexchange) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}
