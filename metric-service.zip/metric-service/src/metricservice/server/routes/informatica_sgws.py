from __future__ import annotations

from metricservice.server.models.informatica_sgws import informatica_sgws, Task, WorkFlow

from fastapi import APIRouter
import datetime

informatica_sgws_router = APIRouter()


def prepare_metrics_response(start_date: datetime.datetime.now(),
                          env: str,
                          results: informatica_sgws) -> dict:
    # get all the metric key names by creating test object
    j = Task(TASK_NAME='example1')
    metric_names = []
    metric_names.append('Workflow_Name')
    metric_names.append('server_instance_name')
    metric_names.append('server_ip')
    metric_names.append('disk_name')
    metric_names.append('disk_mount_path')
    metric_names.append('disk_status')
    metric_names.append('pid')
    metric_names.append('name')
    metric_names.append('cur_S0_cap')
    metric_names.append('S0_util')
    metric_names.append('S1_util')
    metric_names.append('cur_eden_cap')
    metric_names.append('eden_util')
    metric_names.append('cur_old_cap')
    metric_names.append('old_util')
    metric_names.append('metaspace_cap')
    metric_names.append('metaspace_util')
    metric_names.append('compr_class_cap')
    metric_names.append('compr_class_util')
    metric_names.extend(list(j.dict(by_alias=True)))

    flat_list = []
    # print (results.workflows)
    for record in results:
        for metrics in record.workflows:
            print (metrics)
            
            for task in dict(metrics).get('Tasks'):
                metrics_value_list = []
                metrics_value_list.append(dict(metrics).get('Workflow_Name'))
                metrics_value_list.append(dict(metrics).get('server_instance_name'))
                metrics_value_list.append(dict(metrics).get('server_ip'))
                metrics_value_list.append(dict(metrics).get('disk_name'))
                metrics_value_list.append(dict(metrics).get('disk_mount_path'))
                metrics_value_list.append(dict(metrics).get('disk_status'))
                metrics_value_list.append(dict(metrics).get('pid'))
                metrics_value_list.append(dict(metrics).get('name'))
                metrics_value_list.append(dict(metrics).get('cur_S0_cap'))
                metrics_value_list.append(dict(metrics).get('S0_util'))
                metrics_value_list.append(dict(metrics).get('S1_util'))
                metrics_value_list.append(dict(metrics).get('cur_eden_cap'))
                metrics_value_list.append(dict(metrics).get('eden_util'))
                metrics_value_list.append(dict(metrics).get('cur_old_cap'))
                metrics_value_list.append(dict(metrics).get('old_util'))
                metrics_value_list.append(dict(metrics).get('metaspace_cap'))
                metrics_value_list.append(dict(metrics).get('metaspace_util'))
                metrics_value_list.append(dict(metrics).get('compr_class_cap'))
                metrics_value_list.append(dict(metrics).get('compr_class_util'))

                metrics_value_list.extend(list(dict(task).values()))
                metric_record = {"timestamp": str(record.ts), "metric_value": metrics_value_list}
                flat_list.append(metric_record)

    # create final response
    response_metrics_record = {
        "service_provider": "informatica_sgws",
        "env_name": env,
        "metrics": {"dimension": ["WorkFlow_Name","TASK_NAME", "Workflow_Execution_ID"], "metric_name": list(metric_names)},
        "metric_records": flat_list
    }
    return response_metrics_record


# TODO: removed optional params and test with paging before production
@informatica_sgws_router.get("/", response_description="Metric records retrieved")
async def get_informatica_sgws_record(start_date: datetime.datetime | None = None,
                          end_date: datetime.datetime | None = None,
                          env: str | None = None) -> dict:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await informatica_sgws.find_all().to_list()
    else:
        criteria = {"$and": [{"ts": {"$gte": start_date, "$lte": end_date}},
                             {"source.env": {"$eq": env}}
                             ]}
        results = await informatica_sgws.find_many(criteria).to_list()
    # print (results)
    return prepare_metrics_response(start_date, env, results)


# TODO: remove this end point before production
# @informatica_sgws.post("/", response_description=" Metrics added to the database")
# async def add_informatica_sgws_record(review: informatica_sgws) -> dict:
#     await review.create()
#     return {"message": "Metrics added successfully"}
