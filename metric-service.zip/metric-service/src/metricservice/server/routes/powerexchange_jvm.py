from __future__ import annotations

from fastapi import APIRouter
import datetime

from metricservice.server.models.powerexchange_jvm import powerexchangejvm, Task, WorkFlow

powerexchange_jvm_router = APIRouter()


def prepare_metrics_response(start_date: datetime.datetime.now(),
                             env: str,
                             results: powerexchangejvm) -> dict:
    # get all the metric key names by creating test object
    a1 = WorkFlow(host="example1")
    a2 = Task(db="example1")

    j = Task(TASK_NAME='example1')
    metric_names = list(a1.dict(by_alias=True, exclude={"Tasks","run_id"})) + list(a2.dict(by_alias=True))

    flat_list = []
    for record in results:
        for metrics in record.workflows:
            metrics_value_list = []
            metrics_value_list.append(dict(metrics).get('Workflow_Name'))
            metrics_value_list.append(
                '' if dict(metrics).get('Workflow_Status') is None else dict(metrics).get('Workflow_Status'))
            metrics_value_list.append(
                '' if dict(metrics).get('DURATION_IN_SECONDS') is None else dict(metrics).get('DURATION_IN_SECONDS'))
            if dict(metrics).get('run_id') is not None:
                metrics_value_list.append(
                    '' if dict(metrics).get('run_id') is None else dict(metrics).get('run_id'))
            if dict(metrics).get('Tasks') is not None and len(dict(metrics).get('Tasks')) > 0:
                for task in dict(metrics).get('Tasks'):
                    tmp_metrics_value_list = []
                    tmp_metrics_value_list.extend(metrics_value_list)
                    tmp_metrics_value_list.extend(list(dict(task).values()))
                    metric_record = {"timestamp": str(record.ts), "metric_value": tmp_metrics_value_list}
                    flat_list.append(metric_record)
            else:
                val_list = (dict(a2).values())
                tmp_list = list(val_list)[1:]
                metrics_value_list.extend('' if v is None else v for v in tmp_list)
                metric_record = {"timestamp": str(record.ts), "metric_value": metrics_value_list}
                flat_list.append(metric_record)

    # create final response
    response_metrics_record = {
        "service_provider": "Informatica-PowerExchange",
        "env_name": env,
        "metrics": {"dimension": ["WorkFlow_Name", "TASK_NAME", "Workflow_Execution_ID"],
                    "metric_name": list(metric_names)},
        "metric_records": flat_list
    }
    return response_metrics_record


# TODO: removed optional params and test with paging before production
@powerexchange_jvm_router.get("/", response_description="Metric records retrieved")
async def get_informatica_powercenter_record(start_date: datetime.datetime | None = None,
                                             end_date: datetime.datetime | None = None,
                                             env: str | None = None) -> dict:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await powerexchangejvm.find_all().to_list()
    else:
        criteria = {"$and": [{"ts": {"$gte": start_date, "$lte": end_date}},
                             {"source.env": {"$eq": env}}
                             ]}
        results = await powerexchangejvm.find_many(criteria).to_list()
    return prepare_metrics_response(start_date, env, results)


# TODO: remove this end point before production
@powerexchange_jvm_router.post("/", response_description=" Metrics added to the database")
async def add_informatica_powercenter_record(review: powerexchangejvm) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}
