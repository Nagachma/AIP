from fastapi import APIRouter
import datetime
from metricservice.server.models.rapid import rapid
from metricservice.server.models.rapid import Instance

rapidrouter = APIRouter()

def prepare_rapid_response(start_date: datetime.datetime,
                     end_date: datetime.datetime,
                     env: str,
                     results: rapid) -> dict:
    # flatten the JSON object
    flat_list = [] 
    for record in results:
        for instance in record.instances:
            instance_metric_value = []
            for key in instance.dict().keys():
                value = instance.dict()[key]
                if value is not None:
                    instance_metric_value.append(str(value))
                else:
                    instance_metric_value.append('')

            metric_record = {"timestamp": str(record.ts), "metric_value": instance_metric_value}
            flat_list.append(metric_record)

    # get all the metric key names by creating test object
    b = Instance(instance_name="example")
    metric_names = list(b.dict(by_alias=True))
    print(str(metric_names))


    # create final response
    response_metrics_record = {
        "service_provider": "",
        "env_name": env,
        "account_id": "",
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["instance_name"], "metric_name": list(metric_names)},
        "metric_records": flat_list
    }
    return response_metrics_record   

# TODO: removed optional params and test with paging before production
@rapidrouter.get("/", response_description="Metric records retrieved")
async def get_rapid_record(start_date: datetime.datetime | None = None,
                        end_date: datetime.datetime | None = None,
                        env: str | None = None) -> rapid:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await rapid.find_all().to_list();
    else:
        criteria = {"$and": [ {"ts": {"$gte": start_date, "$lte": end_date}},
                              {"source.env": {"$eq": env}}
                              ]}
        results = await rapid.find_many(criteria).to_list();
    return prepare_rapid_response(start_date, end_date, env, results)

# TODO: remove this end point before production
@rapidrouter.post("/", response_description=" Metrics added to the database")
async def add_rapid_record(review: rapid) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}
