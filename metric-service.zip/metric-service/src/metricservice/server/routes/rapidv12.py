from fastapi import APIRouter
import datetime
from metricservice.server.models.rapidv12 import rapidv12 as rapid
from metricservice.server.models.rapidv12 import Instance, Page

rapidv12router = APIRouter()


def prepare_rapid_response(start_date: datetime.datetime,
                           end_date: datetime.datetime,
                           env: str,
                           results: rapid) -> dict:
    # get all the metric key names by creating test object
    i = Instance(instance_name="example", URL="localhost:9990/metrics")
    p = Page(page_id="page_id")
    i_list = list(i.dict(by_alias=True))
    p_list = list(p.dict(by_alias=True))
    # if 'pages' in i_list:
    #     i_list.remove('pages')
    # flatten the JSON object
    flat_list = []
    for record in results:
        for instance in record.instances:
            instance_metric_value = [str(instance.dict()[key]) if instance.dict()[key] is not None else '' for key in \
                                     i_list]
            # for page in instance.pages:
            #     temp_list = instance_metric_value.copy()
            #     temp_list = temp_list + [str(page.dict()[key]) if page.dict()[key] is not None else '' for key in \
            #                              p_list]
            metric_record = {"timestamp": str(record.ts), "metric_value": instance_metric_value}
            flat_list.append(metric_record)

    # create final response
    response_metrics_record = {
        "service_provider": "",
        "env_name": env,
        "account_id": "",
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["instance_name"], "metric_name": i_list},
        "metric_records": flat_list
    }
    return response_metrics_record


# TODO: removed optional params and test with paging before production
@rapidv12router.get("/", response_description="Metric records retrieved")
async def get_rapid_record(start_date: datetime.datetime | None = None,
                           end_date: datetime.datetime | None = None,
                           env: str | None = None) -> dict:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await rapid.find_all().to_list();
    else:
        criteria = {"$and": [{"ts": {"$gte": start_date, "$lte": end_date}},
                             {"source.env": {"$eq": env}}
                             ]}
        results = await rapid.find_many(criteria).to_list();
    return prepare_rapid_response(start_date, end_date, env, results)


# TODO: remove this end point before production
@rapidv12router.post("/", response_description=" Metrics added to the database")
async def add_rapid_record(review: rapid) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}
