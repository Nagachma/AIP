from __future__ import annotations

from metricservice.server.models.rdsoracle import rdsoracle
from metricservice.server.models.rdsoracle import Instance
from metricservice.server.models.rdsoracle import queries
from metricservice.server.models.rdsoracle import table_size
from metricservice.server.models.rdsoracle import totalthreadcount
from metricservice.server.models.rdsoracle import querycount
from metricservice.server.models.rdsoracle import schemas



from fastapi import APIRouter
import datetime


rdsoracleschemasrouter = APIRouter()

def prepare_rdsoracleschemas_response(start_date: datetime.datetime,
                     end_date: datetime.datetime,
                     env: str,
                     results: rdsoracle) -> dict:

    print("RESULTS: ", results)

    # get all the metric key names by creating test object
    i = Instance(instance_name="example", schemas=[])
    s = schemas()
    t = table_size()
    total = totalthreadcount()
    qcnt = querycount()

    metric_names = list(i.dict(by_alias=True, exclude={'schemas'})) + list(s.dict(by_alias=True, exclude={'table_size','totalthreadcount','querycount'})) + list(t.dict(by_alias=True)) + list(total.dict(by_alias=True)) + list(qcnt.dict(by_alias=True))

    # flatten the JSON object
    flat_list = []
    for record in results:
        for job1 in record.instances:
            instance_metric_value = []
            metric_record = {}
            for key in job1.dict().keys():
                if key != "schemas":
                    value = job1.dict()[key]
                    if value is not None:
                        instance_metric_value.append(str(value))
                    else:
                        instance_metric_value.append("")

            if job1.schemas is not None:
                if len(job1.schemas) > 0:
                    for job2 in job1.schemas:
                        if job2.table_size is not None:
                            if len(job2.table_size) > 0:
                                for job3 in job2.table_size:
                                    metric_record = {"timestamp": str(record.ts), "metric_value": instance_metric_value.copy()}
                                    metric_value = []
                                    for key in job3.dict().keys():
                                        value = job3.dict()[key]
                                        if value is not None:
                                            metric_value.append(str(value))
                                        else:
                                            metric_value.append("")
                                    metric_record["metric_value"] += metric_value
                                    flat_list.append(metric_record)
                        else:
                            metric_record = {"timestamp": str(record.ts), "metric_value": instance_metric_value.copy()}
                            t1 = table_size()
                            l = len(t1.dict().keys())
                            metric_value = [''] * l
                            metric_record["metric_value"] += metric_value
                            flat_list.append(metric_record)

                        if job2.totalthreadcount is not None:
                            if len(job2.totalthreadcount) > 0:
                                for job3 in job2.totalthreadcount:
                                    metric_value = []
                                    for key in job3.dict().keys():
                                        value = job3.dict()[key]
                                        if value is not None:
                                            metric_value.append(str(value))
                                        else:
                                            metric_value.append("")
                                    metric_record["metric_value"] += metric_value
                                    flat_list.append(metric_record)
                        else:
                            total1 = totalthreadcount()
                            l = len(total1.dict().keys())
                            metric_value = [''] * l
                            metric_record["metric_value"] += metric_value
                            flat_list.append(metric_record)

                        if job2.querycount is not None:
                            if len(job2.querycount) > 0:
                                for job3 in job2.querycount:
                                    metric_value = []
                                    for key in job3.dict().keys():
                                        value = job3.dict()[key]
                                        if value is not None:
                                            metric_value.append(str(value))
                                        else:
                                            metric_value.append("")
                                    metric_record["metric_value"] += metric_value
                                    flat_list.append(metric_record)
                        else:
                            qcnt1 = querycount()
                            l = len(qcnt1.dict().keys())
                            metric_value = [''] * l
                            metric_record["metric_value"] += metric_value
                            flat_list.append(metric_record)

            else:
                metric_record = {"timestamp": str(record.ts), "metric_value": instance_metric_value.copy()}
                t2 = table_size()
                total2 = totalthreadcount()
                qcnt2 = querycount()
                l = len(t2.dict().keys()) + len(total2.dict().keys()) + len(qcnt2.dict().keys())
                metric_value = [''] * l
                metric_record["metric_value"] += metric_value
                flat_list.append(metric_record)

    # create final response
    response_metrics_record = {
        "service_provider": "",
        "env_name": env,
        "account_id": "",
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["instance_name","sql_id"], "metric_name": list(metric_names)},    #, "PipelineName", "LabelingJobName", "LabelingJob"
        "metric_records": flat_list
    }
    return response_metrics_record

# TODO: removed optional params and test with paging before production
@rdsoracleschemasrouter.get("/", response_description="Metric records retrieved")
async def get_rdsoracleschemas_record(start_date: datetime.datetime | None = None,
                        end_date: datetime.datetime | None = None,
                        env: str | None = None) -> rdsoracle:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await rdsoracle.find_all().to_list();
    else:
        criteria = {"$and": [ {"ts": {"$gte": start_date, "$lte": end_date}},
                              {"source.env": {"$eq": env}}
                              ]}
        results = await rdsoracle.find_many(criteria).to_list();
    return prepare_rdsoracleschemas_response(start_date, end_date, env, results)

# TODO: remove this end point before production
@rdsoracleschemasrouter.post("/", response_description=" Metrics added to the database")
async def add_rdsoracleschemas_record(review: rdsoracle) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}