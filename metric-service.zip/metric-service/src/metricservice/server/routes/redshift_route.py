import datetime

from fastapi import APIRouter

from metricservice.server.models.redshift import redshift
from metricservice.server.models.redshift import Clusters,Database,Queries


redshiftrouter = APIRouter()


def prepare_redshift_response(start_date: datetime.datetime,
                                end_date: datetime.datetime,
                                env: str,
                                results: redshift) -> dict:
    flat_list = []
    for doc in results:
        if len(doc.clusters) > 0:
            for cluster in doc.clusters:
                cluster_metric_value=[]
                for key in cluster.dict().keys():
                    if key != "databases" :
                        value1 = cluster.dict()[key]
                        if value1 is not None:
                            cluster_metric_value.append(str(value1))
                        else:
                            cluster_metric_value.append("")
                if cluster.databases is not None and len(cluster.databases) > 0:
                    for database in cluster.databases: # iterating databases
                        database_metric_value = []
                        database_metric_value.extend(cluster_metric_value)
                        for key in database.dict().keys():
                            if key != "queries":
                                value1 = database.dict()[key]
                                if value1 is not None:
                                    database_metric_value.append(str(value1))
                                else:
                                    database_metric_value.append("")
                        if database.queries is not None and len(database.queries) > 0:
                            for query in database.queries: # iterating clusters
                                query_metric_value = []
                                query_metric_value.extend(database_metric_value)
                                for key in query.dict().keys():
                                    value1 = query.dict()[key]
                                    if value1 is not None:
                                        query_metric_value.append(str(value1))
                                    else:
                                        query_metric_value.append("")
                                metric_record_ = {"timestamp": str(doc.ts), "metric_value": query_metric_value}
                                flat_list.append(metric_record_)
                        else:
                            metric_record = {"timestamp": str(doc.ts), "metric_value": database_metric_value.copy()}
                            b1 = Queries()
                            l = len(b1.dict().keys())
                            metric_value = [''] * l
                            metric_record["metric_value"] += metric_value
                            flat_list.append(metric_record)
                else:
                    metric_record = {"timestamp": str(doc.ts), "metric_value": cluster_metric_value.copy()}
                    b1 = Database()
                    l0 = len(b1.dict().keys())
                    metric_value = [''] * (l0 - 1)
                    metric_record["metric_value"] += metric_value
                    b2 = Queries()
                    l1 = len(b2.dict().keys())
                    _metric_value = [''] * l1
                    metric_record["metric_value"] += _metric_value
                    flat_list.append(metric_record)

    # print(flat_list)
    # get all the metric key names by creating test object
    a1 = Queries(query_id="example1")
    a2 = Database(database_name="example1")
    a3 = Clusters(cluster_name="example1")

    metric_names = list(a3.dict(by_alias=True, exclude={"databases"})) + list(a2.dict(by_alias=True, exclude={"queries"})) + list(a1.dict(by_alias=True))
    response_metrics_record = {
        "service_provider": "",
        "env_name": env,
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["cluster_name", "database_name", "query_id"],
                    "metric_name": metric_names},
        "metric_records": flat_list
    }
    return response_metrics_record


# TODO: removed optional params and test with paging before production
@redshiftrouter.get("/", response_description="Metric records retrieved")
async def get_redshift_record(start_date: datetime.datetime | None = None,
                                end_date: datetime.datetime | None = None,
                                env: str | None = None) -> redshift:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await redshift.find_all().to_list();
    else:
        criteria = {"$and": [{"ts": {"$gte": start_date, "$lte": end_date}},
                             {"source.env": {"$eq": env}}
                             ]}
        results = await redshift.find_many(criteria).to_list();
    return prepare_redshift_response(start_date, end_date, env, results)


# TODO: remove this end point before production
@redshiftrouter.post("/", response_description=" Metrics added to the database")
async def add_redshift_record(review: redshift) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}
