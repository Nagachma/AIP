from fastapi import APIRouter
import datetime
from metricservice.server.models.s3 import s3
from metricservice.server.models.s3 import Bucket
from metricservice.server.models.s3 import Event

s3_invent_router = APIRouter()

def prepare_s3_invent_response(start_date: datetime.datetime,
                     end_date: datetime.datetime,
                     env: str,
                     results: s3) -> dict:
    # flatten the JSON object
    flat_list = [] 
    for record in results:
        for bucket in record.buckets:
            bucket_metric_value = []
            is_event=False
            for key in bucket.dict().keys():
                value = bucket.dict()[key]
                if key == 'bucket_name' and value is not None:
                    bucket_metric_value.append(str(value))
                elif key == 'bucket_name' and value is None:
                    bucket_metric_value.append('')
                elif key == 'Events' and value is not None:
                    is_event=True
                elif key == 'Events' and value is None:
                    bucket_metric_value.append('')
                
            if is_event:
                for event in bucket.dict()['Events']:
                    bucket_metric_value_temp = []
                    bucket_metric_value_temp.extend(bucket_metric_value)
                    for key in event.keys():
                        if key == "eventID":
                            value_ = event[key]
                            bucket_metric_value_temp.append(str(value_))
                    metric_record_ = {"timestamp": str(record.ts), "metric_value": bucket_metric_value_temp}
                    flat_list.append(metric_record_)
            else:
                metric_record = {"timestamp": str(record.ts), "metric_value": bucket_metric_value}
                flat_list.append(metric_record)

    # get all the metric key names by creating test object
    ev_ = Event(eventID=1)
    b = Bucket(bucket_name="example")
    metric_names = list(b.dict(by_alias=True, exclude={"Events","start_time","end_time","BucketSizeBytes","NumberOfObjects","AllRequests","HeadRequests","FirstByteLatency","TotalRequestLatency"}))
    metric_names = metric_names + list(ev_.dict(by_alias=True, exclude={"bucketName","eventTime","eventSource","eventName","eventType","awsRegion","sourceIPAddress","errorCode","errorMessage","bucketName","key","requestID"}))
    print(str(metric_names))


    # create final response
    response_metrics_record = {
        "service_provider": "",
        "env_name": env,
        "account_id": "",
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["bucket_name"], "metric_name": list(metric_names)},
        "metric_records": flat_list
    }
    return response_metrics_record   

# TODO: removed optional params and test with paging before production
@s3_invent_router.get("/", response_description="Metric records retrieved")
async def get_s3_record(start_date: datetime.datetime | None = None,
                        end_date: datetime.datetime | None = None,
                        env: str | None = None) -> s3:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await s3.find_all().to_list();
    else:
        criteria = {"$and": [ {"ts": {"$gte": start_date, "$lte": end_date}},
                              {"source.env": {"$eq": env}}
                              ]}
        results = await s3.find_many(criteria).to_list();
    return prepare_s3_invent_response(start_date, end_date, env, results)

# TODO: remove this end point before production
@s3_invent_router.post("/", response_description=" Metrics added to the database")
async def add_s3_record(review: s3) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}
