import datetime

from fastapi import APIRouter
from metricservice.server.models.stonebranch import stonebranch

from metricservice.server.models.stonebranch import TaskWorkflowInfo

stonebranchTasksRouter = APIRouter()


def prepare_stonebranch_response(start_date: datetime.datetime,
                                 end_date: datetime.datetime,
                                 env: str,
                                 results: stonebranch) -> dict:
    stime = datetime.datetime.now(datetime.timezone.utc)

    # get all the metric key names by creating test object
    t = TaskWorkflowInfo(task_taskName="example", task_taskId="12y89173bba")
    t_list = list(t.dict(by_alias=True))
    flat_list = []
    for doc in results:

        for task in doc.tasks:
            metric_value = []
            task_metric_value = [str(task.dict()[key]) if task.dict()[key] is not None else '' for key in t_list]
            metric_value = task_metric_value

            metric_record = {"timestamp": str(doc.ts), "metric_value": metric_value}
            flat_list.append(metric_record)

    metric_name = t_list

    response_metrics_record = {
        "service_provider": "",
        "env_name": str(env),
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["task_uniqueId", "workflow_instanceName", "workflow_instanceId"],
                    "metric_name": metric_name},
        "metric_records": flat_list
    }
    return response_metrics_record


@stonebranchTasksRouter.get("/", response_description="Metric records retrieved")
async def get_stonebranch_record(start_date: datetime.datetime | None = None,
                                 end_date: datetime.datetime | None = None,
                                 env: str | None = None) -> stonebranch:
    sttime = datetime.datetime.now(datetime.timezone.utc)
    if start_date is None or end_date is None or env is None:
        results = await stonebranch.find_all().to_list()
    else:
        criteria = {"$and": [{"ts": {"$gte": start_date, "$lte": end_date}},
                             {"source.env": {"$eq": env}}
                             ]}
        results = await stonebranch.find_many(criteria).to_list()
    return prepare_stonebranch_response(start_date, end_date, env, results)
