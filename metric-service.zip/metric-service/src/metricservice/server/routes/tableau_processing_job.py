from __future__ import annotations
from metricservice.server.models.tableau import tableau
from metricservice.server.models.tableau import Workbook
from metricservice.server.models.tableau import Processwise

from fastapi import APIRouter
import datetime


tableau_processing_router = APIRouter()

def prepare_tableau_response(start_date: datetime.datetime,
                    end_date: datetime.datetime,
                    env: str,
                    results: tableau) -> dict:

    # get all the metric key names by creating test object
    i = Workbook(workbook_name="example", workbook_id= "3",workbook_size_bytes=321, Processwise=[])
    q = Processwise()

    metric_names = list(i.dict(by_alias=True, exclude={'processwise'})) + list(q.dict(by_alias=True))

    # flatten the JSON object
    flat_list = []
    for record in results:
        for job1 in record.workbooks:
            workbook_metric_value = []
            for key in job1.dict().keys():
                if key != "processwise" :
                    value = job1.dict()[key]
                    if value is not None:
                        workbook_metric_value.append(str(value))
                    else:
                        workbook_metric_value.append("")
            if job1.processwise is not None:
                if len(job1.processwise) > 0:
                    for job2 in job1.processwise:
                        metric_record = {"timestamp": str(record.ts), "metric_value": workbook_metric_value.copy()}
                        metric_value = []
                        for key in job2.dict().keys():
                            value = job2.dict()[key]
                            if value is not None:
                                metric_value.append(str(value))
                            else:
                                metric_value.append("")
                        metric_record["metric_value"] += metric_value;
                        flat_list.append(metric_record)
                else:
                    metric_record = {"timestamp": str(record.ts), "metric_value": workbook_metric_value.copy()}
                    q1 = Processwise()
                    l = len(q1.dict().keys())
                    metric_value = [''] * l
                    metric_record["metric_value"] += metric_value;
                    flat_list.append(metric_record)
            else:
                metric_record = {"timestamp": str(record.ts), "metric_value": workbook_metric_value.copy()}
                q1 = Processwise()
                l = len(q1.dict().keys())
                metric_value = [''] * l
                metric_record["metric_value"] += metric_value;
                flat_list.append(metric_record)


    # create final response
    response_metrics_record = {
        "service_provider": "",
        "env_name": env,
        "account_id": "",
        "start_time": str(start_date),
        "end_time": str(end_date),
        "metrics": {"dimension": ["workbook_name","unique_id"], "metric_name": list(metric_names)},    #, "PipelineName", "LabelingJobName", "LabelingJob"
        "metric_records": flat_list
    }
    return response_metrics_record

# TODO: removed optional params and test with paging before production
@tableau_processing_router.get("/", response_description="Metric records retrieved")
async def get_tableau_record(start_date: datetime.datetime | None = None,
                        end_date: datetime.datetime | None = None,
                        env: str | None = None) -> tableau:
    results = []
    if start_date is None or end_date is None or env is None:
        results = await tableau.find_all().to_list();
    else:
        criteria = {"$and": [ {"ts": {"$gte": start_date, "$lte": end_date}},
                            {"source.env": {"$eq": env}}
                            ]}
        results = await tableau.find_many(criteria).to_list();
    response = prepare_tableau_response(start_date, end_date, env, results)
    # return prepare_tableau_response(start_date, end_date, env, results)
    return response

# TODO: remove this end point before production
@tableau_processing_router.post("/", response_description=" Metrics added to the database")
async def add_aurorapostgres_conn_count_record(review: tableau) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}