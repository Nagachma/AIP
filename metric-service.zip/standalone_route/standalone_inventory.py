from fastapi import APIRouter
import datetime
from beanie import Document
sys.path.append("/app/dist/standalone_model")
from standalone_inventory import standalone_inventory

# sys.path.append("/app/dist/standalone_route")
# from standalone_inventory import standalone_inventory_router
# from metricservice.server.models.standalone_inventory import standalone_inventory

standalone_inventory_router = APIRouter()


def prepare_response(ser,
                     results: standalone_inventory) -> dict:
    # flatten the JSON object
    flat_list = []
    
    for res in results:
        # print (res[0])
        # print (res[1])
        if (res[0].lower()) in ser:
            dict = {}
            dict[res[0]] = res[1]
            flat_list.append(dict)

    # create final response
    response_metrics_record = flat_list
    return response_metrics_record

# TODO: removed optional params and test with paging before production
@standalone_inventory_router.get("/", response_description="Metric records retrieved")
async def get_review_record(Service: str | None = None, Environment: str | None = None) -> standalone_inventory:
    print ("Document")
    print (Document)
    results = []
    ser = ["glue","Lamda","s3"]
    # if Service is None:
    #     ser = ["informatica"]
    #     # ser = ["Glue","Lambda"]
    # else:
    #     if Service == "lambda":
    #         Service = "Lambda"
    #     ser = [Service.lower()]
    results = await standalone_inventory.find_one();
    print (results)
    return prepare_response(ser, results)


# TODO: remove this end point before production
@standalone_inventory_router.post("/", response_description=" Metrics added to the database")
async def add_glue_record(review: standalone_inventory) -> dict:
    await review.create()
    return {"message": "Metrics added successfully"}