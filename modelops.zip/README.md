# Overview

The *xops_demo.zip* file contains a folder with several resources inside.

The most important is the python script **xops_demo.py** which allows you to automatically populate the MM deployment with some data.

The MM entities automatically generated are:

- 1 Custom Envirnment with the following packages
    - pandas
    - numpy
    - sagemaker
    - boto3
    - psycopg2-binary
    - statsmodels
    - scikit-learn
    - sqlalchemy
    - sklearn
    - matplotlib
    - seaborn
- 1 Project called _AWS Project_
- 2 Input files
    - 1 data source file
    - 1 python module file
- 3 Models
    - *ML_Forecast*
    - *Sagemaker XGBoost*
    - *Vip Model Upsell*

For each Model, the tag _sagemaker_ has been added in the attributes section.

Also, several KPIs are defined
- _Accuracy_
- _MAPE_
- _Data Drift_
- _RMSE_

and for each KPI, some values are stored and associated to the Models.

For *ML_Forecast* Model, *Accuracy* and *Data Drift* KPIs violate the threshold.

For *Sagemaker XGBoost* Model, *Accuracy*, *Data Drift* and *MAPE* violate the threshold.

*Vip Model Upsell* is fine, meaning that no KPIs violate the threshold.

# How to

Running the script is very simple

- Download the *xops_demo.zip* file 
- Unzip it
- Enter the *xops_demo* folder
- **[Optional]** Open the *xops_demo.py* file and change the url of the environment you are pointing to. Currently, there are three options
    - _ds_ environment (by default it's _ds3_)
    - _dev_ environment
    - _dev2_ environment
- Run the file *xops_demo.py*
    - using any IDE compatible with python (like IntelliJ IDEA or Spyder)
    - opening a command prompt within the folder directory and running the command

```bash
python xops_demo.py
```

Note: the script execution may be a bit slow (2 minutes more or less) because the code is not optimized