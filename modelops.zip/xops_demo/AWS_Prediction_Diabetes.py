import pickle as pkl
import tarfile as tar
import tempfile

import xgboost as xgb
import mmlibrary as mm

# fetch model binary
model_binary = mm.get_model()
with tar.open(model_binary, 'r:gz') as t:
    t.extractall()
model = pkl.load(open('xgboost-model', 'rb'))
print("Model has been loaded")

# input data: in this example, read from CSV
diabetes_data = mm.get_binary_from_resource("Diabetes Data")
with tempfile.NamedTemporaryFile(mode="w+b") as input_data:
    input_data.write(diabetes_data)

    # predict using 'standard' XGBoost
    predict_data = xgb.DMatrix(input_data.name + '?format=csv&label_column=0')
    predictions = model.predict(predict_data)
    print(predictions)
