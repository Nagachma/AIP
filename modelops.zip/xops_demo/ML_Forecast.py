import numpy as np
import pandas as pd
import mmlibrary as mm
import pickle, io, sqlalchemy

from Module import Prediction

np.random.seed(1234)

SKU = mm.get_argument("SKU")
START_FORECAST_DATE = mm.get_argument("START_FORECAST_DATE")
END_FORECAST_DATE = mm.get_argument("END_FORECAST_DATE")
dates = [201512, 201601, 201602, 201603, 201604, 201605, 201606, 201607, 201608, 201609, 201610, 201611, 201612]


# The script's entry point starts here.

# conn = mm.get_db_connection('PostgreConnection')
# db = sqlalchemy.create_engine('postgresql://', creator=lambda:conn)
#
# time_series = pd.read_sql('SELECT * FROM mytable', db)
# time_series = time_series.drop(columns=['index'])

time_series_binary = mm.get_binary_from_resource("Actual Demand Time Series")
time_series = pd.read_csv(io.StringIO(time_series_binary.decode("utf-8")))

time_series = time_series[time_series['Date'] >= START_FORECAST_DATE].copy()
time_series = time_series[time_series['Date'] <= END_FORECAST_DATE].copy()
index = np.where(time_series.SKU.str.contains(SKU) == True)[0]
if len(index) <= 0:
    print(" [Error]: Couldn't find the requested SKU ", SKU, "!")
else:
    time_series = Prediction.processTestData(data_series=time_series)
    serie = time_series.iloc[index]
    # Load the model.
    modelBinaryPath = mm.get_model()
    model = pickle.load(open(modelBinaryPath, "rb" )) 
    # Perform the forecast.
    forecasted_data, predictions_DF = Prediction.perform_forecast(serie, model, START_FORECAST_DATE, END_FORECAST_DATE)

    # Free up memory.
    del serie, time_series, index

mm.save_binary_to_resource('ML Forecast', predictions_DF.to_csv(index = False).encode("utf-8"))

predictionsList = []

numberOfRows = predictions_DF.shape[0]
for i in range (0, numberOfRows):
    predictionsList.append(predictions_DF.loc[i, 0])

lists = [('Date', dates), ('Forecast', predictionsList)]
df = pd.DataFrame.from_dict(lists)
print(df)

#mm.save_kpi("MAPE", 11) TODO remove from here and put in a separate Step within a dedicated Pipeline to calculate KPI for this Model