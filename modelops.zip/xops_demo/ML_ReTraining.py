import numpy as np
import pandas as pd
import mmlibrary as mm
import pickle
import io

# from Module import Training

np.random.seed(1234)

# Parameters.
START_FIT_DATE = mm.get_argument("START_FIT_DATE")
END_FIT_DATE = mm.get_argument("END_FIT_DATE")
MODEL_LIST = ['RF']

data_series_binary = mm.get_binary_from_resource("Actual Demand Time Series")
data_series = pd.read_csv(io.StringIO(data_series_binary.decode("utf-8")))

# Filter the data per date.
fit_data = data_series[data_series['Date'] >= START_FIT_DATE].copy()
fit_data = fit_data[fit_data['Date'] <= END_FIT_DATE].copy()
del data_series
# _, fit_data = Training.processInputData(data_series=fit_data)

# model = Training.fitModel(fit_data,'RF')
modelBinary = pickle.dumps("model gem")

mm.new_version(modelBinary)

print("The Machine Learning Forecasting model has been successfully trained.")