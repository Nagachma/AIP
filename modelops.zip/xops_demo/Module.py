import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from statsmodels.tsa.arima_model import ARIMA

def computeMAPE(predictions, actuals):
    sum_actuals = np.sum(actuals)
    sum_predictions = np.sum(predictions)
    if sum_actuals == 0.0 and sum_predictions == 0.0:
        mape = 0.0
    elif sum_actuals == 0.0 and sum_predictions != 0.0:
        mape = 1.0
    else:
        mape = (np.sum(np.abs(actuals - predictions)) / sum_actuals)*100 
    return mape



class Training:
    def processInputData(data_series):
        """
        Given the raw data, it generates some features for the forecasting procedure.
            
        :param data_series: is the input data containing the series.
        :return: a tuple containing the skus and the processed data series.
        """
        # Transform categorical variables into one hot ones.
        tmp = pd.get_dummies(data_series['Component_type'])
        for myaxis in tmp.axes[1]:
            data_series['Is_' + myaxis] = tmp[myaxis]
        tmp = pd.get_dummies(data_series['Country_grouping'])
        for myaxis in tmp.axes[1]:
            data_series['Is_' + myaxis] = tmp[myaxis]
        tmp = pd.get_dummies(data_series['Market'])
        for myaxis in tmp.axes[1]:
            data_series['Is_' + myaxis] = tmp[myaxis]
        data_series.drop(['Component_type', 'Country_grouping', 'Market'], axis=1, inplace=True)
        # Transform dates.
        year, month = divmod(data_series['Date'], 100)
        data_series['Year'] = year
        data_series['Month'] = month
        data_series.drop(['Date'], axis=1, inplace=True)
        skus = data_series['SKU']
        # Also drop the SKU.
        data_series.drop(['SKU'], axis=1, inplace=True)
        return(skus, data_series)

    def fitModel(fit_data, selected_model="RF"):
        """
        It fits the model with the given data. Data are assumed to be in numeric
        form and not containing any missing values.
        
        :param fit_data: is the data to train the model.
        :param selected_model: is a string containing the name of the model.
        :return: the trained model.
        """
        model = None
        y_train = fit_data['Volume']
        X_train = fit_data.drop(['Volume'], axis=1)
        #if selected_model == 'RF':
        model = RandomForestRegressor(n_estimators=200, max_depth=30, min_samples_split=2,
                                      max_features="auto", 
                                      criterion="mse", n_jobs=3, random_state=1234)
        model.fit(X_train, y_train)
        return(model)
        
class Prediction:
    def processTestData(data_series):
        """
        Given the raw data, it generates some features for the forecasting procedure.
        
        :param data_series: is the input data containing the series.
        :return: the processed data series.
        """
        # Transform categorical variables into one hot ones.
        tmp = pd.get_dummies(data_series['Component_type'])
        for myaxis in tmp.axes[1]:
            data_series['Is_' + myaxis] = tmp[myaxis]
        tmp = pd.get_dummies(data_series['Country_grouping'])
        for myaxis in tmp.axes[1]:
            data_series['Is_' + myaxis] = tmp[myaxis]
        tmp = pd.get_dummies(data_series['Market'])
        for myaxis in tmp.axes[1]:
            data_series['Is_' + myaxis] = tmp[myaxis]
        data_series.drop(['Component_type', 'Country_grouping', 'Market'], axis=1, inplace=True)
        # Transform dates.
        year, month = divmod(data_series['Date'], 100)
        data_series['Year'] = year
        data_series['Month'] = month
        data_series.drop(['Date'], axis=1, inplace=True)
        return(data_series)

    def perform_forecast(test_data, model, start_date=201512, end_date=201704):
        """
        It performs the forecast in for the given model and data.
        
        :param test_data: is the data frame containing the time series.
		 :param model: is the model to perform the forecast with.
        :param start_date: is the forecast start date.
        :param end_date: is the forecat end date.
        :return: the results of the forecast.
        """
        forecast_definition = {'SKU': test_data.iloc[0, 0], 'Method': model.__class__, 'fcst_date_begin': start_date, 'fcst_date_end': end_date}   
        # Get the SKU data for the prediction.
        y_test = test_data['Volume'].to_numpy() #y_test = test_data['Volume'].as_matrix()
        X_test = test_data.copy()
        X_test.drop(['Volume'], axis=1, inplace=True)
        X_test.drop(['SKU'], axis=1, inplace=True)
        # perform the predictions.
        predictions = model.predict(X_test)
        # Compute the stats.
        for i in range(0, len(predictions)):
            forecast_definition.update({'lag' + str(i) : predictions[i]})
            forecast_definition.update({'error_lag' + str(i) : abs(y_test[i] - predictions[i])})
        # Transform our dictionary into a Pandas data frame.
        return pd.DataFrame(forecast_definition, index=[0]), pd.DataFrame(predictions)
    
def fitARIMA(serie, p=2, d=1, q=2):
    """
        It launches the ARIMA model with the given parameters.
        
        :param serie: is the time series array.
        :param p: is the AR component parameter.
        :param d: is the I component parameter.
        :param q: is the MA component parameter.
        :return: the fitted model.
    """
    model = ARIMA(serie, order=(p, d, q)).fit(disp=0)
    return model