import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import sklearn
import pickle

pred_df = pd.read_csv('PurchaseTransactions.csv', sep =';')
Gender = pd.get_dummies(pred_df['gender'],drop_first=True)
Pur_Type = pd.get_dummies(pred_df['purchase_type'],drop_first=True)
pred_transaction = pred_df[['transaction_id']]

pred_df.drop(['transaction_id','gender','address','purchase_type','shipping', 'insurance','tgt_vip_trial'],axis=1,inplace=True)
pred_df = pd.concat([pred_df,Gender,Pur_Type],axis=1)

loaded_model = pickle.load(open("Vip_Upsell_MLP.bin", 'rb'))
result = loaded_model.predict(pred_df)
result_df = pd.DataFrame(result, columns= ['Pred_VIP_Upsell'])

output_table = pd.concat([pred_transaction, result_df],axis=1)

output_table[['Pred_VIP_Upsell']].sum()
