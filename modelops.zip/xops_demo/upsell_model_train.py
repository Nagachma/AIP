import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import sklearn

train = pd.read_csv('PurchaseTransactions.csv', sep =';')
train.head()
sns.countplot(x='tgt_vip_trial',data=train)
sns.countplot(x='tgt_vip_trial',hue='purchase_type',data=train)
train.info()
Gender = pd.get_dummies(train['gender'],drop_first=True)
Pur_Type = pd.get_dummies(train['purchase_type'],drop_first=True)

train.drop(['gender','address','purchase_type','shipping', 'insurance'],axis=1,inplace=True)
train = pd.concat([train,Gender,Pur_Type],axis=1)
train.info()
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(train.drop(['transaction_id', 'tgt_vip_trial'],axis=1), 
                                                    train['tgt_vip_trial'], test_size=0.30, 
                                                    random_state=101)
from sklearn.neural_network import MLPClassifier
mlp_model = MLPClassifier(random_state=1, max_iter=300)
clf = mlp_model.fit(X_train, y_train)
predictions = mlp_model.predict(X_test)
from sklearn.metrics import classification_report
print(classification_report(y_test,predictions))

from sklearn.metrics import confusion_matrix

def accuracy(confusion_matrix):
   diagonal_sum = confusion_matrix.trace()
   sum_of_all_elements = confusion_matrix.sum()
   return diagonal_sum / sum_of_all_elements

cm = confusion_matrix(predictions, y_test)
print("Accuracy of MLPClassifier : ", accuracy(cm))
      
import pickle
filename = 'Vip_Upsell_MLP.bin'
pickle.dump(mlp_model, open(filename, 'wb'))
X_train.info()
