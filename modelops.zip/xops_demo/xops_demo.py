import json, random, sys, requests
import mm_python_client as mm
from datetime import datetime, timedelta, date
import time

# init the client
configuration = mm.Configuration()

# ds environment
configuration.host = sys.argv[3] if (len(sys.argv) > 3 and sys.argv[3] is not None) else "http://private-mm-ds3.rapiddev.accentureanalytics.com/v1"
project_endpoint = sys.argv[2] if (len(sys.argv) > 2 and sys.argv[2] is not None) else "http://private-ds3.rapiddev.accentureanalytics.com/dmz/api/mm/projects"

# # dev environment
# configuration.host = sys.argv[3] if (len(sys.argv) > 3 and sys.argv[3] is not None) else "http://private-mm-xops-dev.rapiddev.accentureanalytics.com/v1"
# project_endpoint = sys.argv[2] if (len(sys.argv) > 2 and sys.argv[2] is not None) else "http://private-xops-dev.rapiddev.accentureanalytics.com/dmz/api/mm/projects"

# dev2 environment
# configuration.host = sys.argv[3] if (len(sys.argv) > 3 and sys.argv[3] is not None) else "http://private-mm-xops-dev2.rapiddev.accentureanalytics.com/v1"
# project_endpoint = sys.argv[2] if (len(sys.argv) > 2 and sys.argv[2] is not None) else "http://private-xops-dev2.rapiddev.accentureanalytics.com/dmz/api/mm/projects"

username = sys.argv[1] if (len(sys.argv) > 1 and sys.argv[1] is not None) else "steve"  # This user must be a real user, i.e. it must exists on your deployment
headers_for_DS = {'username': username, 'Content-Type': 'application/json'}

#################### INSTANCES ####################
mm_client = mm.ApiClient(configuration)

environment_instance = mm.EnvironmentsApi(mm_client)
resource_instance = mm.ResourcesApi(mm_client)
model_instance = mm.ModelsApi(mm_client)
kpi_instance = mm.KPIApi(mm_client)
kpi_results_instance = mm.KPIResultsApi(mm_client)


######### DEFINING SOME USEFUL METHODS THAT WILL BE CALLED BELOW ########
def create_project(project_name_param,
                   project_description_param,
                   access_param,
                   project_endpoint_param,
                   headers_for_DS_param):
    payload = json.dumps({"name": project_name_param, "description": project_description_param, "access": access_param})
    response = requests.request("POST",
                                project_endpoint_param,
                                headers=headers_for_DS_param,
                                data=payload,
                                verify=False)
    response.raise_for_status()
    return json.loads(response.text)['projectId']


today = date.today()
t = time.localtime()
current_date = today.strftime("%b-%d-%Y")
current_time = time.strftime("%H:%M:%S", t)


def convert_to_millisec(date_time):
    millisec = date_time.timestamp() * 1000
    return millisec

current_dateTime = datetime.strptime(datetime.today().strftime('%d.%m.%Y %H:%M:%S'), '%d.%m.%Y %H:%M:%S')
yesterday = current_dateTime - timedelta(days=1)
startDateTime = current_dateTime - timedelta(days=25)
endDateTime = current_dateTime - timedelta(days=2)


def create_env_if_not_exist(local_env_name,
                            local_env_language,
                            local_author,
                            local_packages=None,
                            local_image_tag=None):
    for env in environment_instance.get_all_environments():
        if local_env_name == env.name:
            local_env = env
            break
    else:
        env_req_body = mm.EnvironmentCreateRequest(name=local_env_name,
                                                   language=local_env_language,
                                                   author=local_author,
                                                   libraries=local_packages,
                                                   container_image_tag=local_image_tag)
        local_env = environment_instance.create_environment(body=env_req_body)
    return local_env


#################### PRE-DEFINED labels and projects content ####################

AWS_env_name = "AWS Environment - " + current_date
AWS_env_language = 'python 3'
AWS_packages = [{"name": "pandas"},
                {"name": "numpy"},
                {"name": "boto3"},
                {"name": "sagemaker"},
                {"name": "psycopg2-binary"},
                {"name": "statsmodels"},
                {"name": "scikit-learn"},
                {"name": "sqlalchemy"},
                {"name": "sklearn"},
                {"name": "matplotlib"},
                {"name": "seaborn"}]

#### Labels and configurations for AWS Project
AWS_project_name = "AWS Project (" + current_date + ")"
AWS_project_access = "public"
AWS_project_description = "AWS Project for XOps demo. Created on " + current_date + " at " + current_time
fore_model_name = "ML_Forecast"
fore_model_tags = ['sagemaker']
AWS_model_name = "SageMaker XGBoost"
AWS_model_tags = ['sagemaker']
upsell_model_name = 'Vip Model Upsell'
upsell_model_tags = ['sagemaker']

print("Creating custom Virtual Environments...")
#################### ENVIRONMENTS CREATION ####################
AWS_environment = create_env_if_not_exist(local_env_name=AWS_env_name,
                                          local_env_language=AWS_env_language,
                                          local_author=username,
                                          local_packages=AWS_packages)

print("... done!")

print("Creating AWS Project...")
#################### AWS PROJECT CREATION ####################
AWS_project = create_project(project_name_param=AWS_project_name,
                             project_description_param=AWS_project_description,
                             access_param=AWS_project_access,
                             project_endpoint_param=project_endpoint,
                             headers_for_DS_param=headers_for_DS)

print("... done!")

print("Creating data file...")
#################### DATA RESOURCE CREATION (IT'S A .csv FILE) ####################
data_resource_name = 'Actual Demand Time Series'
data_resource_type = 'data_source'
data_resource_file = 'Actual_Python.csv'

data_resource = resource_instance.create_resource(name=data_resource_name,
                                                  author=username,
                                                  project=AWS_project,
                                                  type=data_resource_type,
                                                  file=data_resource_file)
print("... done!")

print("Creating module file...")
#################### MODULE RESOURCE CREATION ####################
module_resource_name = 'Module'
module_resource_type = 'python_module'
module_resource_file = 'Module.py'

module_resource = resource_instance.create_resource(name=module_resource_name,
                                                    author=username,
                                                    project=AWS_project,
                                                    type=module_resource_type,
                                                    file=module_resource_file)
print("... done!")


#################### MODELS CREATION ####################
print("Creating ML_Forecast Model...")
########## Forecast Model ##########
fore_input_res = [module_resource.resource_id, data_resource.resource_id]
fore_train_input_res = [module_resource.resource_id, data_resource.resource_id]
fore_prediction_recipe = 'ML_Forecast.py'
fore_training_recipe = 'ML_ReTraining.py'
fore_args = {"SKU": {"value": "ETR-gaNMqBBXjxC4TO9qvyjsTId6j-001",
                     "schema": {"type": "string"}
                     },
             "START_FORECAST_DATE": {"value": 201512,
                                     "schema": {"type": "integer"}
                                     },
             "END_FORECAST_DATE": {"value": 201612,
                                   "schema": {"type": "integer"}
                                   }
             }
fore_training_args = {"START_FIT_DATE": {"value": 201306,
                                         "schema": {"type": "integer"}
                                         },
                      "END_FIT_DATE": {"value": 201612,
                                       "schema": {"type": "integer"}
                                       }
                      }

fore_model_attributes = mm.ModelCreateRequestAttributes(name=fore_model_name,
                                                        language='python 3',
                                                        tags=fore_model_tags,
                                                        project=AWS_project)

fore_model_req_body = mm.ModelCreateJsonRequest(status='active',
                                                author=username,
                                                args=fore_args,
                                                attributes=fore_model_attributes,
                                                environment_id=AWS_environment.environment_id,
                                                training_args=fore_training_args,
                                                input_resources=fore_input_res,
                                                training_input_resources=fore_train_input_res)

fore_model = model_instance.create_model(request=json.dumps(fore_model_req_body.to_dict()),
                                         prediction_recipe=fore_prediction_recipe,
                                         training_recipe=fore_training_recipe)
print("... done!")

print("Creating AWS Model...")
########## AWS Model ##########
AWS_prediction_recipe = 'AWS_Prediction_Diabetes.py'
AWS_training_recipe = 'AWS_Training_Diabetes.py'

AWS_model_attributes = mm.ModelCreateRequestAttributes(name=AWS_model_name,
                                                       language='python 3',
                                                       tags=AWS_model_tags,
                                                       project=AWS_project)

AWS_model_req_body = mm.ModelCreateJsonRequest(status='active',
                                               author=username,
                                               attributes=AWS_model_attributes,
                                               environment_id=AWS_environment.environment_id)

AWS_model = model_instance.create_model(request=json.dumps(AWS_model_req_body.to_dict()),
                                        prediction_recipe=AWS_prediction_recipe,
                                        training_recipe=AWS_training_recipe)
print("... done!")

print("Creating VIP Model Upsell...")
########## Upsell Model ##########
upsell_model_binary = 'e2e_model'
upsell_prediction_recipe = 'upsell_model_pred.py'
upsell_training_recipe = 'upsell_model_train.py'

upsell_model_attributes = mm.ModelCreateRequestAttributes(name=upsell_model_name,
                                                          language='python 3',
                                                          tags=upsell_model_tags,
                                                          project=AWS_project)

upsell_model_req_body = mm.ModelCreateJsonRequest(status='active',
                                                  author=username,
                                                  attributes=upsell_model_attributes,
                                                  environment_id=AWS_environment.environment_id)

upsell_model = model_instance.create_model(request=json.dumps(upsell_model_req_body.to_dict()),
                                           model_binary=upsell_model_binary,
                                           prediction_recipe=upsell_prediction_recipe,
                                           training_recipe=upsell_training_recipe)
print("... done!")

print("Defining KPIs with thresholds...")
#################### DEFINE KPI WITH THRESHOLD ####################
mape_req_body = mm.KpiCreateRequest(project=AWS_project,
                                    author=username,
                                    name="MAPE",
                                    threshold=15)
mape_kpi = kpi_instance.create_kpi(body=mape_req_body)

accuracy_req_body = mm.KpiCreateRequest(project=AWS_project,
                                        author=username,
                                        name="Accuracy",
                                        threshold=90,
                                        to_be_minimized=False)
accuracy_kpi = kpi_instance.create_kpi(body=accuracy_req_body)

rmse_req_body = mm.KpiCreateRequest(project=AWS_project,
                                    author=username,
                                    name="RMSE")
rmse_kpi = kpi_instance.create_kpi(body=rmse_req_body)

dataDrift_req_body = mm.KpiCreateRequest(project=AWS_project,
                                         author=username,
                                         name="Data Drift",
                                         threshold=8)
dataDrift_kpi = kpi_instance.create_kpi(body=dataDrift_req_body)
print("... done!")

########## Storing random values for KPIs ##########
number_of_days = abs((endDateTime - startDateTime).days)

print("Storing KPIs values for ML_Forecast Model...")
########## ML_Forecast Model
#### Storing a fixed last value for each trend
accuracyKpi_result_body = mm.KpiResultCreateRequest(project=AWS_project,
                                                    timestamp=convert_to_millisec(yesterday),
                                                    kpi_result_value=88,
                                                    kpi_name='Accuracy',
                                                    model_id=fore_model.model_id,
                                                    model_version_id=1)
kpi_results_instance.create_kpi_result(body=accuracyKpi_result_body)

mapeKpi_result_body = mm.KpiResultCreateRequest(project=AWS_project,
                                                timestamp=convert_to_millisec(yesterday),
                                                kpi_result_value=10,
                                                kpi_name='MAPE',
                                                model_id=fore_model.model_id,
                                                model_version_id=1)
kpi_results_instance.create_kpi_result(body=mapeKpi_result_body)

dataDrift_result_body = mm.KpiResultCreateRequest(project=AWS_project,
                                                  timestamp=convert_to_millisec(yesterday),
                                                  kpi_result_value=13.2,
                                                  kpi_name='Data Drift',
                                                  model_id=fore_model.model_id,
                                                  model_version_id=1)
kpi_results_instance.create_kpi_result(body=dataDrift_result_body)

#### Storing random values for each trend
kpi_curr_date = startDateTime
for i in range(number_of_days+1):
    millisec = convert_to_millisec(kpi_curr_date)

    accuracy_value_forForeModel = round(random.uniform(91, 94), 2)
    accuracyKpi_result_forForeModel_body = mm.KpiResultCreateRequest(project=AWS_project,
                                                                     timestamp=millisec,
                                                                     kpi_result_value=accuracy_value_forForeModel,
                                                                     kpi_name='Accuracy',
                                                                     model_id=fore_model.model_id,
                                                                     model_version_id=1)
    kpi_results_instance.create_kpi_result(body=accuracyKpi_result_forForeModel_body)

    MAPE_value_forForeModel = round(random.uniform(12, 14), 1)
    mapeKpi_result_forForeModel_body = mm.KpiResultCreateRequest(project=AWS_project,
                                                                 timestamp=millisec,
                                                                 kpi_result_value=MAPE_value_forForeModel,
                                                                 kpi_name='MAPE',
                                                                 model_id=fore_model.model_id,
                                                                 model_version_id=1)
    kpi_results_instance.create_kpi_result(body=mapeKpi_result_forForeModel_body)

    RMSE_value_forForeModel = round(random.uniform(15, 25), 2)
    rmseKpi_result_forForeModel_body = mm.KpiResultCreateRequest(project=AWS_project,
                                                                 timestamp=millisec,
                                                                 kpi_result_value=RMSE_value_forForeModel,
                                                                 kpi_name='RMSE',
                                                                 model_id=fore_model.model_id,
                                                                 model_version_id=1)
    kpi_results_instance.create_kpi_result(body=rmseKpi_result_forForeModel_body)

    dataDrift_value_forForeModel = round(random.uniform(3, 7), 2)
    dataDriftKpi_result_forForeModel_body = mm.KpiResultCreateRequest(project=AWS_project,
                                                                      timestamp=millisec,
                                                                      kpi_result_value=dataDrift_value_forForeModel,
                                                                      kpi_name='Data Drift',
                                                                      model_id=fore_model.model_id,
                                                                      model_version_id=1)
    kpi_results_instance.create_kpi_result(body=dataDriftKpi_result_forForeModel_body)

    kpi_curr_date = kpi_curr_date + timedelta(days=1)

hours_param = 20
for i in range(4):
    MAPE_value = round(random.uniform(16, 18), 1)
    mapeKpi_result_forForeModel_body = mm.KpiResultCreateRequest(project=AWS_project,
                                                                 timestamp=convert_to_millisec(yesterday - timedelta(days=15,
                                                                                                                     hours=hours_param)),
                                                                 kpi_result_value=MAPE_value,
                                                                 kpi_name='MAPE',
                                                                 model_id=fore_model.model_id,
                                                                 model_version_id=1)
    kpi_results_instance.create_kpi_result(body=mapeKpi_result_forForeModel_body)

    accuracy_value = round(random.uniform(87, 89), 1)
    accuracyKpi_result_forForeModel_body = mm.KpiResultCreateRequest(project=AWS_project,
                                                                     timestamp=convert_to_millisec(yesterday - timedelta(days=15,
                                                                                                                         hours=hours_param)),
                                                                     kpi_result_value=accuracy_value,
                                                                     kpi_name='Accuracy',
                                                                     model_id=fore_model.model_id,
                                                                     model_version_id=1)
    kpi_results_instance.create_kpi_result(body=accuracyKpi_result_forForeModel_body)

    dataDrift_value = round(random.uniform(9, 12), 1)
    dataDriftKpi_result_forForeModel_body = mm.KpiResultCreateRequest(project=AWS_project,
                                                                      timestamp=convert_to_millisec(yesterday - timedelta(days=15,
                                                                                                                          hours=hours_param)),
                                                                      kpi_result_value=dataDrift_value,
                                                                      kpi_name='Data Drift',
                                                                      model_id=fore_model.model_id,
                                                                      model_version_id=1)
    kpi_results_instance.create_kpi_result(body=dataDriftKpi_result_forForeModel_body)
    hours_param = hours_param - 6
print("... done!")

print("Storing KPIs values for AWS Model...")
########## AWS Model
#### Storing a fixed last value for each trend
accuracyKpi_result_body = mm.KpiResultCreateRequest(project=AWS_project,
                                                    timestamp=convert_to_millisec(yesterday),
                                                    kpi_result_value=87.5,
                                                    kpi_name='Accuracy',
                                                    model_id=AWS_model.model_id,
                                                    model_version_id=1)
kpi_results_instance.create_kpi_result(body=accuracyKpi_result_body)

mapeKpi_result_body = mm.KpiResultCreateRequest(project=AWS_project,
                                                timestamp=convert_to_millisec(yesterday),
                                                kpi_result_value=18,
                                                kpi_name='MAPE',
                                                model_id=AWS_model.model_id,
                                                model_version_id=1)
kpi_results_instance.create_kpi_result(body=mapeKpi_result_body)

dataDrift_result_body = mm.KpiResultCreateRequest(project=AWS_project,
                                                  timestamp=convert_to_millisec(yesterday),
                                                  kpi_result_value=10.3,
                                                  kpi_name='Data Drift',
                                                  model_id=AWS_model.model_id,
                                                  model_version_id=1)
kpi_results_instance.create_kpi_result(body=dataDrift_result_body)

#### Storing random values for each trend
kpi_curr_date = startDateTime
for i in range(number_of_days+1):
    millisec = convert_to_millisec(kpi_curr_date)

    accuracy_value_forAWSModel = round(random.uniform(91, 94), 2)
    accuracyKpi_result_forAWSModel_body = mm.KpiResultCreateRequest(project=AWS_project,
                                                                    timestamp=millisec,
                                                                    kpi_result_value=accuracy_value_forAWSModel,
                                                                    kpi_name='Accuracy',
                                                                    model_id=AWS_model.model_id,
                                                                    model_version_id=1)
    kpi_results_instance.create_kpi_result(body=accuracyKpi_result_forAWSModel_body)

    MAPE_value_forAWSModel = round(random.uniform(12, 14), 1)
    mapeKpi_result_forAWSModel_body = mm.KpiResultCreateRequest(project=AWS_project,
                                                                timestamp=millisec,
                                                                kpi_result_value=MAPE_value_forAWSModel,
                                                                kpi_name='MAPE',
                                                                model_id=AWS_model.model_id,
                                                                model_version_id=1)
    kpi_results_instance.create_kpi_result(body=mapeKpi_result_forAWSModel_body)

    RMSE_value_forAWSModel = round(random.uniform(15, 25), 2)
    rmseKpi_result_forAWSModel_body = mm.KpiResultCreateRequest(project=AWS_project,
                                                                timestamp=millisec,
                                                                kpi_result_value=RMSE_value_forAWSModel,
                                                                kpi_name='RMSE',
                                                                model_id=AWS_model.model_id,
                                                                model_version_id=1)
    kpi_results_instance.create_kpi_result(body=rmseKpi_result_forAWSModel_body)

    dataDrift_value_forAWSModel = round(random.uniform(3, 7), 2)
    dataDriftKpi_result_forAWSModel_body = mm.KpiResultCreateRequest(project=AWS_project,
                                                                     timestamp=millisec,
                                                                     kpi_result_value=dataDrift_value_forAWSModel,
                                                                     kpi_name='Data Drift',
                                                                     model_id=AWS_model.model_id,
                                                                     model_version_id=1)
    kpi_results_instance.create_kpi_result(body=dataDriftKpi_result_forAWSModel_body)

    kpi_curr_date = kpi_curr_date + timedelta(days=1)

hours_param = 20
for i in range(4):
    MAPE_value = round(random.uniform(16, 18), 1)
    mapeKpi_result_forAWSModel_body = mm.KpiResultCreateRequest(project=AWS_project,
                                                                timestamp=convert_to_millisec(yesterday - timedelta(days=15,
                                                                                                                    hours=hours_param)),
                                                                kpi_result_value=MAPE_value,
                                                                kpi_name='MAPE',
                                                                model_id=AWS_model.model_id,
                                                                model_version_id=1)
    kpi_results_instance.create_kpi_result(body=mapeKpi_result_forAWSModel_body)

    accuracy_value = round(random.uniform(87, 89), 1)
    accuracyKpi_result_forAWSModel_body = mm.KpiResultCreateRequest(project=AWS_project,
                                                                    timestamp=convert_to_millisec(yesterday - timedelta(days=15,
                                                                                                                        hours=hours_param)),
                                                                    kpi_result_value=accuracy_value,
                                                                    kpi_name='Accuracy',
                                                                    model_id=AWS_model.model_id,
                                                                    model_version_id=1)
    kpi_results_instance.create_kpi_result(body=accuracyKpi_result_forAWSModel_body)

    dataDrift_value = round(random.uniform(9, 12), 1)
    dataDriftKpi_result_forAWSModel_body = mm.KpiResultCreateRequest(project=AWS_project,
                                                                     timestamp=convert_to_millisec(yesterday - timedelta(days=15,
                                                                                                                         hours=hours_param)),
                                                                     kpi_result_value=dataDrift_value,
                                                                     kpi_name='Data Drift',
                                                                     model_id=AWS_model.model_id,
                                                                     model_version_id=1)
    kpi_results_instance.create_kpi_result(body=dataDriftKpi_result_forAWSModel_body)
    hours_param = hours_param - 6
print("... done!")

print("Storing KPIs values for VIP Model Upsell...")
########## Vip Model upsell
#### Storing random values for each trend
kpi_curr_date = startDateTime
for i in range(number_of_days+1):
    millisec = convert_to_millisec(kpi_curr_date)

    MAPE_value_forUpsellModel = round(random.uniform(12, 14), 1)
    mapeKpi_result_forUpsellModel_body = mm.KpiResultCreateRequest(project=AWS_project,
                                                                   timestamp=millisec,
                                                                   kpi_result_value=MAPE_value_forUpsellModel,
                                                                   kpi_name='MAPE',
                                                                   model_id=upsell_model.model_id,
                                                                   model_version_id=1)
    kpi_results_instance.create_kpi_result(body=mapeKpi_result_forUpsellModel_body)

    dataDrift_value_forUpsellModel = round(random.uniform(3, 7), 2)
    dataDriftKpi_result_forUpsellModel_body = mm.KpiResultCreateRequest(project=AWS_project,
                                                                        timestamp=millisec,
                                                                        kpi_result_value=dataDrift_value_forUpsellModel,
                                                                        kpi_name='Data Drift',
                                                                        model_id=upsell_model.model_id,
                                                                        model_version_id=1)
    kpi_results_instance.create_kpi_result(body=dataDriftKpi_result_forUpsellModel_body)

    kpi_curr_date = kpi_curr_date + timedelta(days=1)

hours_param = 20
for i in range(4):
    MAPE_value = round(random.uniform(16, 18), 1)
    mapeKpi_result_forUpsellModel_body = mm.KpiResultCreateRequest(project=AWS_project,
                                                                   timestamp=convert_to_millisec(yesterday - timedelta(days=15,
                                                                                                                       hours=hours_param)),
                                                                   kpi_result_value=MAPE_value,
                                                                   kpi_name='MAPE',
                                                                   model_id=upsell_model.model_id,
                                                                   model_version_id=1)
    kpi_results_instance.create_kpi_result(body=mapeKpi_result_forUpsellModel_body)

    dataDrift_value = round(random.uniform(9, 12), 1)
    dataDriftKpi_result_forUpsellModel_body = mm.KpiResultCreateRequest(project=AWS_project,
                                                                        timestamp=convert_to_millisec(yesterday - timedelta(days=15,
                                                                                                                            hours=hours_param)),
                                                                        kpi_result_value=dataDrift_value,
                                                                        kpi_name='Data Drift',
                                                                        model_id=upsell_model.model_id,
                                                                        model_version_id=1)
    kpi_results_instance.create_kpi_result(body=dataDriftKpi_result_forUpsellModel_body)
    hours_param = hours_param - 6
print("... done!")
