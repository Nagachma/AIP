import logging
import pandas as pd
from sklearn.linear_model import LogisticRegression
#from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score,roc_auc_score,confusion_matrix

def lr_model_trainer (input filename,outcome,logging file,metrics_file,model_name):
    logging.basicConfig(level=logging.INFO, filename=log_file_name,
                        format='%(asctime)s :: %(levelname)s :: %(message)s')
    logging.info('selected training of logistic regression model')
    df=pd.read_csv(input_filename)
    logging.info("reading in put file to dataframe")


    lr=LogisticRegression()
    X=df.drop(outcome,axis=1)
    Y=df[outcome]
    logging.info("splitting to training and testing dataset")
    X_train,X_test,y_train,y_test=train_test_split(X,Y,test_size=0.2)
    logging.info("training classification model using Logistic regression")
    lr.fit(X_train,y_train)
    y_pred_train=lr.predict(X_train)
    y_pred_test=lr.predict(X_test)
    accuracy_score_train= accuracy_score(y_train,y_pred_train)
    accuracy_score_test=  accuracy_score(y_test,y_pred_test)
    auc=roc_auc_score(y_test,y_pred_test)
    logging.info('training  accuracy_score %(accuracy_score_train)')
    logging.info('training  accuracy_score %(accuracy_score_testing)')
    logging.info('roc_aoc score %(auc)')
    filename = 'lr_model.sav'
    output_file='performance.txt'
    logging.info('Saving model in file name %filename')
    pickle.dump(lr, open(filename, 'wb'))
    return