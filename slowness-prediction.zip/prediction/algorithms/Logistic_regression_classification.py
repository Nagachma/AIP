import logging
import pandas as pd
from sklearn.linear_model import LogisticRegression
#from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score,roc_auc_score,confusion_matrix

def lr_model_trainer (input_filename,outcome,logging_file_name,metrics_file,time,model_name):
    print(logging_file_name)

    logging.basicConfig(level=logging.INFO, filename=logging_file_name,
                        format='%(asctime)s :: %(levelname)s :: %(message)s',filemode='w')
    #logger = logging.getLogger()
    logging.info('selected training of logistic regression model')
    df = pd.read_csv(input_filename,parse_dates=['time'])
    logging.info("reading in put file to dataframe")

    lr = LogisticRegression()
    X = df.drop([outcome,time], axis=1)
    Y = df[outcome]
    logging.info("splitting to training and testing dataset")
    X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.2)
    logging.info("training classification model using Logistic regression")
    lr.fit(X_train, y_train)
    y_pred_train = lr.predict(X_train)
    y_pred_test = lr.predict(X_test)
    accuracy_score_train = accuracy_score(y_train, y_pred_train)
    accuracy_score_test = accuracy_score(y_test, y_pred_test)
    auc = roc_auc_score(y_test, y_pred_test)
    print("accuracy",accuracy_score_train)
    logging.info('training  accuracy_score %(accuracy_score_train)')
    logging.info('training  accuracy_score %(accuracy_score_testing)')
    logging.info('roc_aoc score %(auc)')
    file1 = open(metrics_file, 'w')


    # Writing a string to file
    file1.write("Metrics")
    file1.write("accuracy:{}".format(accuracy_score_train))
    file1.write("accuracy_test:{}".format(accuracy_score_train))
    file1.write("roc_auc:{}".format(auc))
    file1.close()
    #filename = 'model/lr_model.sav'
    output_file = 'performance.txt'
    logging.info('Saving model in file name %filename')
    pickle.dump(lr, open(filename, 'wb'))
    return


