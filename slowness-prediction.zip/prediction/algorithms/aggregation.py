import pandas as pd
import numpy as np
from datetime import timedelta
import datetime
import re
from scipy import stats

import warnings
from algorithms.utility import load_data,read_yaml,remove_space
warnings.filterwarnings("ignore")
def batcher_list(file_name_list,out_file_list,window,shift,time_column,service):
    #print('inside batch list')
    for file,out in zip(file_name_list,out_file_list):
        batcher(file,out,window,shift,time_column)


# def mode_custom(x, col):
#     # print(col)
#     x = x.mode(numeric_only=True)
#     if x.empty:
#         data={'errorCode':[0],'eventSource':[0]}
#         x=pd.DataFrame(data)
#     #print('in mode_custom')
#     #print(x)
#     return x.iloc[0]


def mode_custom(x, col):
    # print(col)
    x = x.mode(numeric_only=True)

    if x.empty:
        for i in col:
            data = {}
            data[i] = [0]
            # data={'errorCode':[0],'eventSource':[0]}
        x = pd.DataFrame(data)
    return x
def batcher(file_name,output_file, window, shift,time_column,training_flag,service):
    my_config=read_yaml()


    df=load_data(file_name,time_column)
    #print(df)
    #print(df.info())
    df.drop(['temp_index'],axis=1,inplace=True)
    #df = df.set_index(time_column)

    filter_columns=df.columns.to_list()
    print(filter_columns)
    if  my_config['categorical_columns'][service] != 'None' :

        categorical_list= my_config['categorical_columns'][service]
        categorical_list_m=categorical_list.copy()
        categorical_list_m.append(time_column)
        df_cat=df[categorical_list_m]

        df=df.drop(columns=categorical_list,axis=0)
        df_mode = df_cat.groupby(pd.Grouper(key=time_column, freq=window, label='right')).apply(mode_custom,col=categorical_list)

        df_mode = df_mode[categorical_list].add_suffix('_mode')
        df_mode.index = df_mode.index.droplevel(-1)




    df_mean = df.groupby(pd.Grouper(key=time_column, freq=window, label='right')).mean()
    df_max = df.groupby(pd.Grouper(key=time_column, freq=window, label='right')).max()
    df_min = df.groupby(pd.Grouper(key=time_column, freq=window, label='right')).min()
    df_median = df.groupby(pd.Grouper(key=time_column, freq=window, label='right')).median()





    column_names = filter_columns
    new_columns = {}
    for name in column_names:
        new_columns[name] = name + '_mean'
    df_mean.rename(columns=new_columns, inplace=True)
    #required_columns = list(set(df_mean.columns) - set(df.columns) - set([time_column]))
    #df_mean = df_mean[required_columns]

    column_names = df_max.columns
    new_columns = {}
    for name in column_names:
        new_columns[name] = name + '_max'
    df_max.rename(columns=new_columns, inplace=True)


    df_mean = df_mean.join(df_max, on=time_column, how='left')

    column_names = filter_columns
    new_columns = {}
    for name in column_names:
        new_columns[name] = name + '_min'
    df_min.rename(columns=new_columns, inplace=True)

    df_mean = df_mean.join(df_min, on=time_column, how='left')
    column_names = filter_columns
    new_columns = {}

    for name in column_names:
        new_columns[name] = name + '_median'
    df_median.rename(columns=new_columns, inplace=True)

    df_mean = df_mean.join(df_median, on=time_column, how='left')
    if my_config['categorical_columns'][service] != 'None':
        df_mean=df_mean.join(df_mode,on=time_column, how='left')

    #print(df_mean.info())
    print(df_mean)
    if (training_flag!= 'predict'):
        df_mean = df_mean.drop(columns=['outcome_min', 'outcome_mean', 'outcome_median'], axis=1)

    df_mean.rename(columns={"outcome_max":"outcome"},inplace=True)
    #df_mean.info()

    #print(shift)
    df_mean.shift(periods=shift, axis=0)
    df_mean.to_csv(output_file)
    #print('------')
    #print((output_file))


    return

