"""Apply PCA to a excel file and find feature correlation."""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sb
import logging
from algorithms.utility import read_yaml
import csv


def kendall_model(file_name, log_file_name, range_min, range_max):
    """config logging file"""
    logging.basicConfig(level=logging.INFO, filename=log_file_name,
                        format='%(asctime)s :: %(levelname)s :: %(message)s')
    config=read_yaml()
    data = pd.read_csv(file_name)

    """apply kendall algorithm and output the result"""
    kendallcorr = data.corr(method='kendall')
    # print(kendallcorr)
    logging.info(kendallcorr)
    kendallcorr.to_csv(config['kendall_output'])

    stack = kendallcorr.stack().reset_index()
    stack.columns = ['Y metric1', 'Y metric2', 'coefficient']
    stack_dups = (stack[['Y metric1', 'Y metric2']].apply(frozenset, axis=1).duplicated()) | (
                stack['Y metric1'] == stack['Y metric2'])
    stack = stack[~stack_dups]

    if 0 < stack['coefficient'].max() < range_min:
        result = stack.sort_values(by=['coefficient'], ascending=False).head(4)
        result['percentage'] = result['coefficient'] * 100
        result['rule'] = 'rule 1: less than 30%'
    elif range_min <= stack['coefficient'].max() <= range_max:
        result = stack.loc[(stack['coefficient'] >= range_min) & (stack['coefficient'] <= range_max)]
        result['percentage'] = result['coefficient'] * 100
        result['rule'] = 'rule 2: greater than 30%'

    selected_file_name = file_name.split("_")
    selected_file_name.insert(-1, 'selected')
    selected_file_name = "_".join(selected_file_name)
    result.to_csv(config['kendall_output_selected'], index=False)
    # print(result)

    sb.heatmap(kendallcorr,
               xticklabels=kendallcorr.columns,
               yticklabels=kendallcorr.columns,
               cmap='RdBu_r',
               annot=True,
               linewidth=0.5)

    #plt.show()
