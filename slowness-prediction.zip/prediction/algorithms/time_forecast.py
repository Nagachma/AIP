import pandas as pd
import numpy as np
from sklearn import model_selection
from sklearn.linear_model import LinearRegression,Lasso
from sklearn.linear_model import Ridge
from sklearn.linear_model import Lasso
from sklearn.linear_model import ElasticNet
from sklearn.neighbors import KNeighborsRegressor
from sklearn.tree import DecisionTreeRegressor
from sklearn.svm import SVR
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from pandas.api.types import is_numeric_dtype
from math import sqrt
import pickle
import logging
import yaml
import warnings
from algorithms.utility import load_data
# import mlflow
# import mlflow.sklearn
warnings.filterwarnings('ignore')


def read_yaml():
    """ A function to read YAML file"""
    with open('prediction/Config/test.yml') as f:
        config = yaml.safe_load(f)

    return config


def train_linear_regression(input_file_name, log_file_name, model_name, metrics_file, pred_column, service_name):
    logging.basicConfig(level=logging.INFO, filename=log_file_name,
                        format='%(asctime)s :: %(levelname)s :: %(message)s')
    config = read_yaml()
    # experiment_name = config['failure_time_prediction_exp'][service_name]
    # # EXPERIMENT_ID = mlflow.create_experiment(experiment_name)
    # print(experiment_name)
    # mlflow.set_tracking_uri(config['mlflow_url'])
    # mlflow.set_experiment(experiment_name)
    # current_experiment = dict(mlflow.tracking.MlflowClient().get_experiment_by_name(experiment_name))
    # exp_id2 = current_experiment['experiment_id']
    # print(exp_id2)
    # print(experiment_name)


    #print(pred_column)
    df=load_data(input_file_name,config['time'])
    df=df[df['outcome']==1]
    #df = pd.read_csv(input_file_name, parse_dates=[config['start_time_column'][service_name]])
    column_list = df.columns
    list2 = ['MetricDate', 'outcome', 'ErrorMessage','temp_index']
    list2.append(config['name_column'][0][service_name])
    # print(list2)
    df.drop(list2, axis=1, inplace=True, errors='ignore')




    # df.to_csv("linear_regression/output/s3_training_data.csv")

    target_column = [pred_column]

    predictors = list(df.columns)
   # print(predictors)
    predictors.remove(target_column[0])
    df[predictors] = (df[predictors] - df[predictors].min()) / (df[predictors].max() - df[predictors].min())
    #print("predictors________")
    #print(predictors)
    X = df[predictors]
    X = X.fillna(0)
    # X.to_csv("linear_regression/output/X_test.csv")
    y = df[target_column]



    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.30, random_state=40)
    #with mlflow.start_run(experiment_id=exp_id2):

    # print(X_train.shape); print(X_test.shape)
    lr = LinearRegression(positive=True)
    #lr=Lasso(alpha=0.01)
    print("training time model")
    lr.fit(X_train, y_train)
    pred_train_lr = lr.predict(X_train)
    mse = np.sqrt(mean_squared_error(y_train, pred_train_lr))
    #mlflow.log_metric("mean squared error",mse)
    print("mean squared errore :%f", mse)
    logging.info("mean squared errore :%f", mse)
    r2score = r2_score(y_train, pred_train_lr)
    #mlflow.log_metric("r2score", r2score)
    #mlflow.sklearn.log_model(lr,model_name)
    print("r2score:%f", r2score)
    logging.info("r2score:%f", r2score)
    #mlflow.end_run()
    # file1 = open(metrics_file, 'w')
    # file1.write("mean squared error {}".format(mse))
    # file1.close()

    pickle.dump(lr, open(model_name, 'wb'))


