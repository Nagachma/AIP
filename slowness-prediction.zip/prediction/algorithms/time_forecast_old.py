import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
import joblib
import warnings
warnings.filterwarnings("ignore")


def process_outcome(file_name):
    #print(file_name)
    df = pd.read_csv(file_name, parse_dates=['time'],index_col=0)
    #print(df['outcome_proba'])
    df['outcome_class'] = df['outcome_proba'].apply(lambda x: 1 if x > 0.5 else 0)
    df_anamoly = df[df['outcome_class'] == 1]
    df_anamoly.rename({'time': "time_of_failure"}, axis=1, inplace=True)
    df_anamoly['ttf'] = df_anamoly['time_of_failure'].diff().astype('timedelta64[m]')
    df_anamoly['start_time'] = df_anamoly['time_of_failure'].shift(1)
    df_anamoly.dropna(inplace=True)
    #print(df_anamoly.info())
    df_new = df_anamoly[['time_of_failure', 'ttf', 'outcome_proba']]
    #print(df_new.info())
    df_new['p']=pd.qcut(df_new['outcome_proba'], 100, labels=np.arange(100, 0,-1))
    #df_new['NumberRanks'] = df_new['outcome'].rank(method='first')

    #df_new['p'] = df_new['outcome'].transform(
    #    lambda x: pd.qcut(x.rank(method='first'), q=100, labels=np.arange(100, 0, -1)))
    #df_new.drop(['NumberRanks'], axis=1, inplace=True)
    # print(pct_rank_qcut(df_new['outcome'], 100))
    df_new.sort_values(by=['p'], inplace=True)

    return df_new


def time_forecast_training(df_new,model_file_name):
    lr=LinearRegression()
    X=df_new.drop(['ttf','time_of_failure'],axis=1)
    Y=df_new['ttf']
    lr.fit(X.values,Y.values)
    joblib.dump(lr, model_file_name)
    return True

def time_forecast_training_prediction(df,model_file_name):
    loaded_model = joblib.load(model_file_name)
    time=loaded_model.predict(df)
    return time
