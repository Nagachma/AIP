from os import listdir
import os
from benedict import benedict
import re
import logging
import pandas as pd
import yaml
from pymysql import connect as mysql_connect
from pymysql.err import OperationalError as PyMySQLOperationalError
from sqlalchemy import create_engine
from sqlalchemy.exc import OperationalError as SQLAlchemyOperationalError
from sys import exit as exit_python
from datetime import datetime, timedelta
import datetime
import pickle
import os
import entry
import joblib
from sklearn.preprocessing import OrdinalEncoder
import sys
import requests
import hvac


def label_encode_columns(df, encoders, columns, mode):
    print('encoding:',str(columns))
    if mode == 'train':
        encoders = {}
        for col in columns:
            ordinal_encoder = OrdinalEncoder(handle_unknown='use_encoded_value', unknown_value=-1)
            oe = ordinal_encoder.fit(df[col].to_numpy().reshape(-1, 1))
            df[col] = oe.transform(df[col].to_numpy().reshape(-1, 1))
            encoders[col] = oe
    elif mode == 'predict':
        #print(df)
        for col in columns:
            print(df[col], encoders[col])

            df[col] = encoders[col].transform(df[col].to_numpy().reshape(-1, 1))
    return df, encoders
def clean_folder(path):
    for f in os.listdir(path):
        os.remove(os.path.join(path, f))
def find_csv_filenames( path_to_dir, suffix=".csv" ):
    filenames = listdir(path_to_dir)
    file_list=[ filename for filename in filenames if filename.endswith( suffix ) ]

    new_file_list=[]
    for file in file_list:
        if not (file.__contains__('aggregated')) and not (file.__contains__('processed')):
            new_file_list.append(file)
    #print(new_file_list)
    return new_file_list
def identify_live_service(service_list,config_path):
    print("updating  live services")
    #config=read_yaml()
    dict1={}
    d = benedict.from_yaml(config_path)
    #if len(d['live_services'])==0 or service not in (d['live_services']):
     #   print(check_service(service,d['service_list']))
    d['live_services']=service_list
    #print(d['live_services'])
    d.to_yaml(filepath=config_path)
    return
 def get_db_connection(vault_url,vault_key):
     client = hvac.Client(
     url=vault_url,
     verify = False,
     token=vault_key,
     )
     db_response = client.secrets.kv.read_secret_version(path='orchestraidb')
    
     return db_response
   
def store_fields(file_name,service):
    config=read_new_yaml()
    df=pd.read_csv(file_name,index_col=0)
    df.drop(df.filter(regex="Unname"), axis=1, inplace=True)
    column_list=df.columns.to_list()
    #print(config['start_time'][0])
    if config['start_time'][service] not in column_list:
        column_list.append(config['start_time'][service])
    if 'outcome' in column_list:
        column_list.remove('outcome')
    col_name=service+'_Column_name'

    config[col_name]=column_list
    update_yaml_data(config)
    # col_filename="prediction/model/{service}_columns.bin".format(service=service)
    # with open(col_filename, "wb") as output:
    #     pickle.dump(df.columns.to_list(), output)
# def check_columns(file_name,service):
#     df=pd.read_csv(file_name)
#     print()
#     col_filename="prediction/model/{service}_columns.bin".format(service=service)
#     print('-----------')
#     print(col_filename)
#     with open(col_filename, "rb") as data:
#         column_list = pickle.load(data)
#     print(column_list)
#     list1=[]
#     flag=0
#     for i in df.columns.to_list():
#         if i in column_list:
#             continue
#         else:
#             flag=1
#             list1.append(i)
#     return flag,list1
# def store_fields(file_name,service,config):
#     df=pd.read_csv(file_name)
#     df.drop(df.filter(regex="Unname"), axis=1, inplace=True)
#     d = benedict.from_yaml(config)
#     if len(d['column_names'])==0:
#         dict1={}
#         dict1[service]=str(df.columns.to_list())
#         d['column_names'].append(dict1)
#     else:
#         dict1=d['column_names'][0]
#         if service in dict1.keys():
#             dict1[service]=str(df.columns.to_list())
#         else:
#             dict1.update({service:str(df.columns.to_list())})
#         print(dict1)
#         d['column_names'].insert(0,dict1)
#     print( d['column_names'])
#
#     d.to_yaml(filepath=config)
#     #d['column_names'].append(create_dict('prediction/input/{service}_processed_{timestamp}.csv', timestamp))
#
#     #col_filename="prediction/model/{service}_columns.bin".format(service=service)
#     # with open(col_filename, "wb") as output:
#     #     pickle.dump(df.columns.to_list(), output)
def check_model_columns(file_name,service):
    config=read_new_yaml()
    df=pd.read_csv(file_name,index_col=False)

    #print(file_name)
    #df.drop(df.filter(regex="Unname"), axis=1, inplace=True)
    column_list=config[service+'_Column_name']
    # col_filename="prediction/model/{service}_columns.bin".format(service=service)
    # with open(col_filename, "rb") as data:
    #     column_list = pickle.load(data)
    if 'temp_index' not in column_list:
        column_list.append('temp_index')

    if 'outcome'in column_list:
        column_list.remove('outcome')
    # if 'job_name'in column_list:
    #     column_list.remove('job_name')
    if 'StartedOn'in column_list:
        column_list.remove('StartedOn')
    if 'CompletedOn'in column_list:
        column_list.remove('CompletedOn')
    list2 = []


    for i in column_list:
        if not (i.__contains__('Unname')):
            list2.append(i)

    print('columns present in model:',str(column_list))
    df=df[list2]
    df.to_csv(file_name)
    return
def check_columns(file_name,service,column_list,log_file_name):
    logging.basicConfig(level=logging.INFO, filename=log_file_name,format='%(asctime)s :: %(levelname)s :: %(message)s')
    df=pd.read_csv(file_name,index_col=False)
    #print(file_name)
    print('-----')
    print(column_list)
    df.drop(df.filter(regex="Unname"), axis=1, inplace=True)
    # col_filename="prediction/model/{service}_columns.bin".format(service=service)
    # with open(col_filename, "rb") as data:
    #     column_list = pickle.load(data)
    print('columns in model :{model_list}'.format(model_list=str(column_list)))
    print('columns in Db :{model_list}'.format(model_list=str(df.columns.to_list())))
    logging.info('columns in model :{model_list}'.format(model_list=str(column_list)))
    logging.info('columns in Db :{model_list}'.format(model_list=str(df.columns.to_list())))

    #print('----------')
    #print(column_list)
    #print(df.columns.to_list())
    # if 'job_name'in column_list:
    #     column_list.remove('job_name')
    #column_list.append('temp_index')
    if 'outcome' in column_list:
        column_list.remove('outcome')
    if 'StartedOn' in column_list:
        column_list.remove('StartedOn')
    if 'CompletedOn'in column_list:
        column_list.remove('CompletedOn')
    list1=[]
    list2=[]
    flag=0
    for i in column_list:
        if i in df.columns.to_list() or i.__contains__('Unname'):
            list2.append(i)
            #continue
        else:
            flag=1
            list1.append(i)
    logging.info("missing columns :{model_list}".format(model_list=str(list1)))
    #print('------------------')
    print(list1,list2)
    #print(len(list1),len(list2))
    return flag,list1

def add_columns(file_path,column_list,service):
    config=read_yaml()
    df=pd.read_csv(file_path,index_col=False)
    df.drop(df.filter(regex="Unname"), axis=1, inplace=True)
    for i in column_list:
        if i==config['start_time'][service]:
            print('start_time')
            df[i]=str(df[config['time']])
        elif i==config['name_column'][service]:
            print('name...')
            df[i]="Name1"
        else:
            df[i]=0
    df.to_csv(file_path)
    return
#def presence
def check_service(service,service_list):
    for i in service_list:
        if i in service:
            return(i)



def read_from_db(database,service_list,log_file,config):
    logging.basicConfig(level=logging.INFO, filename=log_file,format='%(asctime)s :: %(levelname)s :: %(message)s')
    vault_url = config['platformops']['vault_url']
    vault_key = config['platformops']['vault_key']
    key_url = config['platformops']['key_url']

    db_details = get_db_connection(vault_url,vault_key)

    jdbc_url = db_details['data']['data']['jdbc-url']
    db_username = db_details['data']['data']['username']
    db_passowrd = db_details['data']['data']['password']
    db_host = jdbc_url.split("/")[-2].split(":")[0]
    db_name = jdbc_url.split("/")[-1]

   
    mysql_cnx, mysql_engine = connect_to_mysql(db_username, db_passowrd,  db_host,db_name,3306)    
    my_config = read_yaml()
    mysql_cursor = mysql_cnx.cursor()
    mysql_cursor.execute("SELECT max(`execution_id`) FROM metrics_processor_output_time")
    execution_id = mysql_cursor.fetchone()[0]
    #execution_id=853
    #print(execution_id)
    mysql_cursor.execute(
        "SELECT service_id,service_onboard_id from service_onboarded WHERE service_onboard_id in (SELECT distinct(service_onboard_id) FROM `servicewise_job_details` WHERE execution_id = " + str(execution_id) + ")")
    service_id = mysql_cursor.fetchall()
    if len(service_id)==0:
        job_running = 0
        #sys.exit()

    print(service_id)
    clean_folder('prediction/input')
    service_list=[]
    current_service_list = ['36','72', '79']
    for i in service_id:
        if str(i[0]) not in current_service_list:
            continue
        job_running=0
        service_query = "SELECT service_name FROM `services` WHERE service_id = {service_id}".format(service_id=str(i[0]))
        mysql_cursor.execute(service_query)
        service_name = mysql_cursor.fetchone()[0]
        #print("____service")
        #print(service_name)
        if i[0]== 4:
            #print("success")
            query = """SELECT me.metric_name ,rm.metric_timestamp as'MetricDate',rm.raw_value as'metric_value',rm.job_details_id,sd.job_name,sd.job_start_timestamp as'start_time' ,sd.job_end_timestamp AS 'end_time' FROM raw_metric as rm inner join metrics as me on rm.metric_id=me.metric_id
                                  inner join servicewise_job_details as sd on sd.job_details_id=rm.job_details_id   WHERE sd.service_onboard_id={service_id}
                                   AND sd.execution_id={execution_id}""".format(service_id=str(i[0]),
                                                                                execution_id=execution_id)
            #print(query)
            df = pd.read_sql(query, mysql_cnx, index_col='job_details_id')
        else:

            # # quey condition to add later
            query = """SELECT me.metric_name ,rm.metric_timestamp as'MetricDate',rm.raw_value as'metric_value',rm.job_details_id,sd.job_name,sd.job_start_timestamp as'start_time' ,sd.job_end_timestamp AS 'end_time' FROM raw_metric as rm inner join metrics as me on rm.metric_id=me.metric_id
                          inner join servicewise_job_details as sd on sd.job_details_id=rm.job_details_id   WHERE sd.service_onboard_id={service_id}
                           AND sd.execution_id={execution_id}""".format(service_id=str(i[1]), execution_id=execution_id)
            df = pd.read_sql(query, mysql_cnx, index_col='job_details_id')
        #print(df)
        if df.empty:
            print('no data from db')
            continue
        #print(df)
        df['job_details_id'] = df.index
        df2=df[['MetricDate','job_details_id','job_name','start_time','end_time']]
        df1 = df.drop(['MetricDate'], axis=1)
        df3 = df1.pivot(index='job_details_id', columns='metric_name', values=['metric_value'])
        df3.columns = df3.columns.droplevel(0)
        df3.columns.name = None
        df3.join(df2, on='job_details_id')
        #service_name=check_service(service_name,service_list)
        #print(service_name)
        # service_list.append(service_name)
        name = f'prediction/input/{service_name}_{datetime.datetime.now().strftime("%H%M%m%d%Y")}.csv'.format(service_name=service_name)

        df4 = df3.join(df2, on='job_details_id')
        df4.drop(['job_details_id'],axis=1,inplace=True)
        df4.reset_index(inplace=True)
        df4['temp_index']=df4.index
        #print("___________df4")
        #print(df4.info())
        column_list=df4.columns
        column_list=column_list.to_list()

        df4.to_csv(name,columns=column_list)

        if my_config['running_flag'][service_name][1] in df4[my_config['running_flag'][service_name][0]]:
            service_list.append(service_name)

    print('services running:',service_list)
    if len(service_list)==0:
        job_running=1
        logging.info("no jobs running")
    identify_live_service(service_list, 'prediction/Config/new.yml')
    return job_running
def set_outcome(outcome_value,service_name):
    if service_name =='Glue':
        if outcome_value=='FAILED':
            return 1
        else:
            return 0
    elif service_name =='Lambda':
        return outcome_value
    elif service_name =='S3':
        if outcome_value== None:
            return 0
        else:
            return 1
    elif service_name =='Sage':
        if outcome_value==1:
            return 0
        else:
            return 1
        return outcome_value

def read_from_db_train(database):
    #logging.basicConfig(level=logging.INFO, filename=log_file,format='%(asctime)s :: %(levelname)s :: %(message)s')
    vault_url = config['platformops']['vault_url']
    vault_key = config['platformops']['vault_key']
    key_url = config['platformops']['key_url']

    db_details = get_db_connection(vault_url,vault_key)

    jdbc_url = db_details['data']['data']['jdbc-url']
    db_username = db_details['data']['data']['username']
    db_passowrd = db_details['data']['data']['password']
    db_host = jdbc_url.split("/")[-2].split(":")[0]
    db_name = jdbc_url.split("/")[-1]

    
    mysql_cnx, mysql_engine = connect_to_mysql(db_username, db_passowrd,db_host, db_name,3306)
    mysql_cursor = mysql_cnx.cursor()
    # mysql_cursor.execute("SELECT max(`execution_id`) FROM metrics_processor_output_time")
    # execution_id = mysql_cursor.fetchone()[0]
    #execution_id=426
    #print(execution_id)
    # mysql_cursor.execute(
    #     "SELECT service_id from service_onboarded WHERE service_onboard_id in (SELECT distinct(service_onboard_id) FROM `servicewise_job_details` WHERE execution_id = " + str(execution_id) + ")")
    # service_id = mysql_cursor.fetchall()
    service_id = [ '4']
    # if len(service_id) == 0:
    #     logging.info("No service running currently")
    #     print("No service running currently")
    #     sys.exit()
    #
    # if len(service_id) == 1:
    #     logging.info("Only 1 service running currently")
    #     print("Only 1 service running currently")

    # print(service_id)
    # clean_folder('linear_regression/training')
    my_config = read_yaml()
    service_list=[]
    current_service_list = config['current_live_service']
    time_stamp=datetime.datetime.now().strftime("%H%M%m%d%Y")

    for i in service_id:
        if str(i[0]) not in current_service_list:
            continue
        job_running=0
        service_query = "SELECT service_name FROM `services` WHERE service_id = {service_id}".format(service_id=str(i[0]))
        mysql_cursor.execute(service_query)
        service_name = mysql_cursor.fetchone()[0]
        # execution_id=853
        # print(service_name)
        #sd.job_end_timestamp is NULL

        query = """SELECT me.metric_name ,rm.metric_timestamp as'MetricDate',rm.raw_value as'metric_value',rm.raw_metric_id,rm.job_details_id,sd.job_name,sd.job_start_timestamp as'start_time' ,sd.job_end_timestamp AS 'end_time',sd.anomaly_slowness as 'outcome_slowness',sd.anomaly_failure as 'outcome_failure' ,rm.outcome_metric_flag as 'outcome_flag',sd.job_run_status as 'outcome_value' FROM view_raw_metric_outcomes  as rm inner join metrics as me on rm.metric_id=me.metric_id
                    inner join servicewise_job_details as sd on sd.job_details_id=rm.job_details_id WHERE sd.service_onboard_id={service_id}
                       AND sd.metric_timestamp BETWEEN '{start_time}' AND '{end_time}'""".format(service_id=str(i[0]), start_time='2022-12-01 00:00:00', end_time='2023-01-20 00:00:00')
        df = pd.read_sql(query, mysql_cnx, index_col='job_details_id')

        if df.empty:
            continue
        #print(df)
        df['job_details_id'] = df.index

        df.index.name = None
        df2=df[['MetricDate','job_details_id','job_name','start_time','end_time','outcome_slowness','outcome_failure','outcome_flag','outcome_value']]
        df1 = df.drop(['MetricDate'], axis=1)
        #df3 = df1.pivot(index='raw_metric_id', columns='metric_name', values=['metric_value'])
        df3 = pd.pivot_table(df1,values=['metric_value'],index=['job_details_id'],columns='metric_name')
        df3.columns = df3.columns.droplevel(0)
        df3.columns.name = None
        df3.join(df2, on='job_details_id')
        #service_name=check_service(service_name,service_list)
        # print(service_name)
        service_list.append(service_name)
        name = f'prediction/training/{service_name}_train_{time_stamp}.csv'.format(service_name=service_name,time_stamp=time_stamp)

        train_input = service_name + '_train'
        my_config[train_input] = name

        df4 = df3.join(df2, on='job_details_id')
        df4.drop(['job_details_id'],axis=1,inplace=True)
        df4 = df4.drop_duplicates()
        #print(df4)
        #df4['outcome']=df4['outcome_value'].apply(lambda x:set_outcome(x,service_name))
        df4.drop(['outcome_value','outcome_failure','outcome_flag','outcome_slowness'],axis=1,inplace=True)
        df4.to_csv(name,index=False)
    #my_config["service_list"] = service_list
    #update_yaml(my_config)
def create_dict(pattern,service, time_stamp):
    config=read_yaml()
    dict1 = {}
    if config['training_flag']=='predict' and config['test_mode']!= 'test':
        if service in config['live_services']:
            dict1[service] = pattern.format(service=service, timestamp=time_stamp)
        # if ("S3" in config['live_services']) :
        #     dict1['S3'] = pattern.format(service="S3", timestamp=time_stamp)
        # if ("Lambda" in config['live_services']):
        #     dict1['Lambda'] = pattern.format(service="Lambda", timestamp=time_stamp)
        # if ("Glue" in config['live_services']):
        #     dict1['Glue'] = pattern.format(service="Glue", timestamp=time_stamp)
        # if("Sage" in config['live_services']):
        #     dict1['Sage'] = pattern.format(service="Sage", timestamp=time_stamp)
    elif config['training_flag']=='train' or config['test_mode']== 'test':
        dict1[service]=pattern.format(service=service, timestamp=time_stamp)
        # dict1['S3'] = pattern.format(service="S3", timestamp=time_stamp)
        # dict1['Lambda'] = pattern.format(service="Lambda", timestamp=time_stamp)
        # dict1['Glue'] = pattern.format(service="Glue", timestamp=time_stamp)
        # dict1['Sage'] = pattern.format(service="Sage", timestamp=time_stamp)

    return dict1
def fetch_correlation_metric(database):
    config=read_new_yaml()
    vault_url = config['platformops']['vault_url']
    vault_key = config['platformops']['vault_key']
    key_url = config['platformops']['key_url']

    db_details = get_db_connection(vault_url,vault_key)

    jdbc_url = db_details['data']['data']['jdbc-url']
    db_username = db_details['data']['data']['username']
    db_passowrd = db_details['data']['data']['password']
    db_host = jdbc_url.split("/")[-2].split(":")[0]
    db_name = jdbc_url.split("/")[-1]
    
    mysql_cnx, mysql_engine = connect_to_mysql(db_username, db_passowrd,db_host, db_name,3306)
    mysql_cursor = mysql_cnx.cursor()
    select_correlated = "SELECT ser.service_name,met.metric_id,met.metric_name as 'metric_name',met.service_id ,sto.outcome_metric_name FROM `metrics` as met inner JOIN service_to_outcome_metric_mapping as sto on sto.correlated_metric_id =met.metric_id inner join services as ser on ser.service_id=met.service_id WHERE sto.outcome_metric_name='{outcome}'".format(outcome='failure')

    # print(select_failure)
    correlated_metrics_df = pd.read_sql(select_correlated, mysql_cnx, index_col='metric_id')
    #print(correlated_metrics_df)
    dict1={}
    for index,row, in correlated_metrics_df.iterrows():
        if row['service_name'].lower() =='sagemaker':
            dict1['Sage'] = row['metric_name']
        else:
            dict1[row['service_name']]=row['metric_name']

    config['correlation_metric']=dict1
    dict2=config['categorical_columns']

    for i in config['live_services']:

         if dict1[i] in dict2[i] and dict2[i]!="None":
             list1=dict2[i]
             list1.remove(dict1[i])
             dict2[i]=list1
    config['categorical_columns']=dict2
    update_yaml_data(config)

    return
def update_yaml_data(data):
    """ A function to update YAML file"""
    with open('prediction/Config/new.yml', 'w') as f:
        yaml.dump(data, f)

def update_yaml(timestamp,service, config):

    d = benedict.from_yaml(config)
    #print(d['Database'])
    #fetch_correlation_metric(d['Database'])
    print("ggggggggggg")
    print(d['Input_Files'])

    #correlated_dict=fetch_correlation_metric(d['Database'])
    #print(correlated_dict)
    d['Training_files'].update(create_dict('prediction/training/{service}_train_{timestamp}.csv',service,timestamp))
    #d['Training_files'].append('training/' + service + '_' + timestamp + '.csv')
    #print(d['Training_files'])
    #print(create_dict('prediction/input/{service}_{timestamp}.csv',service,timestamp))
    d['Input_Files'].update(create_dict('prediction/input/{service}_{timestamp}.csv',service,timestamp))
    #d['Input_Files'].append('input/' + service + '_' + timestamp + '.csv')
    d['processed_file_list'].update(create_dict('prediction/input/{service}_processed_{timestamp}.csv',service,timestamp))
    #d['processed_file_list'].append('input/{ service }_processed_ {timestamp}.csv')
    d['aggregated_metrics'].update(create_dict('prediction/training/{service}_aggregated_{timestamp}.csv',service,timestamp))
    d['filtered_prediction_file_list'].update(create_dict('prediction/output/{service}_failure_prediction_filtered_{timestamp}.csv',service,timestamp))
   # d['aggregated_metrics'].append('training/' + service + '_aggregated_' + timestamp + '.csv')
    d['output_list'].update(create_dict('prediction/output/{service}_output_{timestamp}.csv',service,timestamp))
    d['xgb_experiment']=create_dict('{service}_failure_prediction_exp',service,timestamp)
    d['xgb_model'].update(create_dict('{service}_failure_prediction_model', service,timestamp))
    d['predict_xgb_prob_exp'] = create_dict('{service}_failure_xgb_prob_exp', service,timestamp)
    d['failure_time_prediction_exp'] = create_dict('{service}_failure_time_prediction_exp', service,timestamp)
    d['lr_model'].update(create_dict('{service}_failure_time_prediction_model', service,timestamp))
    #d['xgb_experiment']={'S3':'S3_XGB_classification_model','S3':'S3_XGB_classification_model','S3':'S3_XGB_classification_model','S3':'S3_XGB_classification_model'}
    #d['output_list'].append('output/' + service + '_output_' + timestamp + '.csv')
    d['training_outcome_list'].update(create_dict('prediction/training/{service}_outcome_{timestamp}.csv',service,timestamp))
    #d['training_outcome_list'].append('prediction/training/' + service + '_outcome_' + timestamp + '.csv')
    #d['model_prob'].append('model/' + service + '_model_' + timestamp + '.json')
    d['model_prob'].update(create_dict('prediction/model/{service}_model.json',service,timestamp))
    d['outcome_list'].update(create_dict('prediction/output/{service}_outcome_{timestamp}.csv',service,timestamp))
    #d['outcome_list'].append('output/' + service + '_outcome_' + timestamp + '.csv')
    d['time_prediction_model_list'].update(create_dict('prediction/model/{service}_failure_time_prediction_model.json',service,timestamp))
    #d['time_prediction_model_list'].append('model/' + service + '_timemodel_' + timestamp + '.json')
    #d['prediction_aggregated_file'].append('input/' + service + '_aggregated_' + timestamp + '.csv')
    d['prediction_aggregated_file'].update(create_dict('prediction/input/{service}_aggregated_{timestamp}.csv',service,timestamp))

    d['training_input_files'].update(create_dict('prediction/training/{service}_train_{timestamp}.csv',service,timestamp))
    d['prediction_file_list'].update(create_dict('prediction/output/{service}_failure_prediction_{timestamp}.csv',service,timestamp))
    #d['prediction_file_list'].append('output/' + service + '_prediction_' + timestamp + '.csv')
    d['training_processed_files'].update(create_dict('prediction/training/{service}_processed_{timestamp}.csv',service,timestamp))
    #d['training_processed_files'].append('training/'+ service + '_processed_' + timestamp + '.csv')
    d['feature_list'].update(create_dict('prediction/output/{service}_features_{timestamp}.csv',service,timestamp))
    #d['feature_list'].append('output/' + service + '_features_' + timestamp + '.csv')
    #print(d['training_processed_files'])

    #d['correlation_metric'].append(correlated_dict)
    d['time_model_training_file'].update(create_dict('prediction/training/{service}_time_{timestamp}.csv',service,timestamp))
    d['prediction_logging_file'].update(create_dict('prediction/logging/{service}_prediction_{timestamp}.log',service,timestamp))
    d['training_logging_file'].update(create_dict('prediction/logging/{service}_training_{timestamp}.log', service,timestamp))
    d['time_prediction_training_logging_file'].update(create_dict('prediction/logging/{service}_time_prediction_training_{timestamp}.log', service,timestamp))
    d['final_outcome_file'].update(create_dict('prediction/output/{service}_finaloutcome_{timestamp}.csv', service,timestamp))
    #d['time_model_training_file'].append('training/'+ service + '_time_' + timestamp + '.csv')
    d['lock']=1
    print("____________")
    print(d['Input_Files'])
    print(d['Training_files'])

    d.to_yaml(filepath=config)
    return

def read_yaml():
    """ A function to read YAML file"""
    with open('prediction/Config/test.yml') as f:
        config = yaml.safe_load(f)

    return config
def read_new_yaml():
    """ A function to read YAML file"""
    with open('prediction/Config/new.yml') as f:
        config = yaml.safe_load(f)

    return config
def find_service(file):
    print(file)
    print(file.split('/')[-1])
    pattern_text = r'(?P<service>^[\w ]+)_+(?P<time_stamp>\d+).csv'
    pattern = re.compile(pattern_text)
    match = pattern.match(file.split('/')[-1])
    print('____________')
    print(match.group('service'))


    if match == None:
        pattern_text = r'(?P<service>^[\w ]+)_train_+(?P<time_stamp>\d+).csv'
        pattern = re.compile(pattern_text)
        match = pattern.match(file.split('/')[-1])
        service = match.group('service')
        timestamp = match.group('time_stamp')
        print(service,timestamp)
        # if ' ' in service:
        #     service=service.replace(' ','_')
    match1 = pattern.match(file.split('/')[-1])
    #print(match)
    if match != None :
        service=match.group('service')
        timestamp=match.group('time_stamp')
        if 'train' in match.group('service'):
            service=service.split('_')[0]
            print("___")
            print(service)
        # if ' ' in service:
        #     service=service.replace(' ','_')
        return service,timestamp


def find_service_advanced(file_list):
    #print('inside')
    new_list = []
    for file in file_list:
        # print('test')
        # print(file)
        pattern_text = r'(?P<service>\w+)_+(?P<time_stamp>\d+).csv'
        # pattern_text = r'(?P<service>\w+)_(?!aggregated_)+(?P<time_stamp>\d+).csv'
        pattern = re.compile(pattern_text)

        match = pattern.match(file)
        #print(match)
        if match != None:
            # print(match)
            temp_dict = {}
            temp_dict['service'] = match.group('service')
            temp_dict['time_stamp'] = match.group('time_stamp')
            # print(temp_dict)
            new_list.append(temp_dict)
    #print(new_list)
    #print('completed file extraction')
    return new_list
def check_create_folder(path, folder_name):
    folder_path=path+folder_name
    #print(folder_path)
    if not(os.path.exists(folder_path)):
        #print(folder_name,'not present')
        os.makedirs(folder_path)



def update_yaml_service(file_list,config):
    for file in file_list:
        update_yaml(file['service'],file['time_stamp'],config)
def remove_space(string):
    return string.replace(" ","")
def get_latest_input(input_path):
    file_list = find_csv_filenames(input_path, suffix=".csv")
    #print(file_list)
    new_file_list = []
    for file in file_list:
        if not (file.__contains__('aggregated')) and not (file.__contains__('processed')):
            new_file_list.append(input_path + file)
    #max_file = max(new_file_list, key=os.path.getctime)

    return new_file_list
def apply_1(value):
    #print(value)
    if value== -1:
        return 0
    else:
        return value
def filter_by_correlation(df1,correlation):
    df=df1.drop(['temp_index'],axis=1)
    #df=pd.read_csv('Glue_train_210401122023.csv')
    matrix = df.corr().round(3)
    stack = matrix.stack().reset_index()
    stack.columns = ['Y metric1', 'Y metric2', 'coefficient']
    stack_dups = (stack[['Y metric1', 'Y metric2']].apply(frozenset, axis=1).duplicated()) | ( stack['Y metric1'] == stack['Y metric2'])

    stack['coefficient'] = stack['coefficient'].apply(lambda x: 0 if x < 0 else x)
    # stack[stack['coefficient'] < 0]['coefficient'] = 0
    # print(stack)
    stack = stack[~stack_dups]
    # stack['coefficient']=abs(stack['coefficient'])

    result = stack.sort_values(by=['coefficient'], ascending=False)
    result = stack.loc[(stack['coefficient'] >= correlation)]
    column_list=[*set(result['Y metric2'].to_list())]

    return column_list


def process_data(file_name, time_field, processed_file,service):
    config = read_new_yaml()
    df = pd.read_csv(file_name, index_col=False, encoding='utf-8-sig',encoding_errors='ignore')
    df.drop(df.filter(regex="Unname"), axis=1, inplace=True)
    df.drop(['CompletedOn'],axis=1,inplace=True,errors='ignore')
    df = df[[x for x in df if not x.endswith('_Flag')]]
    df.fillna(0,inplace=True)
    #print(config['correlation_metric'][service])
    df.drop(config['correlation_metric'][service],axis=1 ,inplace=True,errors='ignore')
    for x in df.columns:
     df[x]=df[x].apply(apply_1)
    #config=read_yaml()
    selected_columns=[x for x in df.columns if df[x].dtype in ['int64','float64']]
    selected_columns.append(time_field)
    print("-----")
    print(config['categorical_columns'][service])
    if config['correlation_metric'][service] not in config['categorical_columns'][service] and config['categorical_columns'][service] !='None':
    #if config['categorical_columns'][0][service] !='None' :
        for i in config['categorical_columns'][service]:
            if df[i].dtype!= object:
                df[i]=df[i].astype(str)
            else:
                selected_columns.append(i)
        #print("test")
        #selected_columns.extend(config['categorical_columns'][0][service])

    df=df[selected_columns]
    print(df.columns)
    if config['training_flag'] == 'train':
        df['temp_index']=df.index
        column_list = filter_by_correlation(df, config['correlation_filter'])
        drop_col_name = service + '_column_drop'
        if config['Time_predict_column'][service]in column_list:
            column_list.remove(config['Time_predict_column'][service])
        print("drop_column________")
        print(config[drop_col_name])
        column_list_config=  config[drop_col_name]
        column_list.extend(column_list_config)
        config[drop_col_name] = column_list
        update_yaml_data(config)

    #print(df.info())
    if config['training_flag']=='train' and config['categorical_columns'][service] !='None' :
        df,encoders=label_encode_columns(df, None,config['categorical_columns'][service], config['training_flag'])
        joblib.dump(encoders, config['encoder'][service])
    elif config['training_flag']=='predict' and config['categorical_columns'][service] !='None':
        print(config['categorical_columns'][service])
        #training_experiment = config['xgb_experiment'][service]

        #current_training_experiment = dict(mlflow.tracking.MlflowClient().get_experiment_by_name(training_experiment))
        #print(current_training_experiment)
        #df_run = mlflow.search_runs([current_training_experiment['experiment_id']], order_by=["end_time DESC"])
        #run_id = df_run.loc[0, 'run_id']
        encoder1 = joblib.load(config['encoder'][service])
        df, encoders = label_encode_columns(df, encoder1, config['categorical_columns'][service],
                                            config['training_flag'])
        #encoders.joblib.dump(encoders, config['encoder'][0][service])


    #print()
    df.drop(config[service + '_column_drop'], axis=1, inplace=True,errors='ignore')

    df.to_csv(processed_file)
    print("processsin file:",processed_file)

    return df


def load_data(file_name,time_field):
    df = pd.read_csv(file_name,parse_dates=[time_field] ,index_col=False,  encoding='utf-8-sig',encoding_errors='ignore')
    df[time_field] = pd.to_datetime(df[time_field], errors='coerce')

    df.drop(df.filter(regex="Unname"), axis=1, inplace=True)
    df.fillna(0,inplace=True)

    #df.reset_index(inplace=True)
    #df = df.rename(columns={'index': time_field})
    #df[time_field] = pd.to_datetime(df[time_field])
    return df
def create_mysql_connection(username, passwd, hostname, db_name, port_number):
    url = "https://s3.amazonaws.com/rds-downloads/rds-combined-ca-bundle.pem"
    filename = "rds-combined-ca-bundle.pem"
    response = requests.get(url, verify=False)

    with open(filename, "wb") as f:
        f.write(response.content)

    # SSL_CA = os.path.abspath(filename)
    SSL_CA = filename
    print(SSL_CA)
    try:
        cnx = mysql_connect(user=username, password=passwd, host=hostname, database=db_name, port=port_number,
                            autocommit=True,ssl_ca=SSL_CA)
    except PyMySQLOperationalError as err:
        err.errno = err.args[0]
        if err.errno == 1044:
            print("ERROR: Access is denied to the user '" + username + "' on the database called '" + db_name + "'.")
            print("Please validate that said user has the correct level of access.")
            exit_python()
        elif err.errno == 1045:
            print("ERROR: Access is denied to the user '" + username + "' on host '" + hostname + "'.")
            print("Please validate that the username and password are correct.")
            exit_python()
        elif err.errno == 1049:
            print("ERROR: The database called '" + db_name + "'does not exist.")
            print("Please validate that database name is spelled correctly and exists.")
            exit_python()
        elif err.errno == 2003:
            print("ERROR: Unable to connect to host '" + hostname + "' on port '" + str(port_number) + "'.")
            print("Please validate your network connectivity and that the hostname and port is correct.")
            exit_python()
        else:
            print("ERROR: Unhandled MySQL Error.")
            print(err)
            exit_python()
    else:
        return cnx


def create_mysql_engine(username, passwd, hostname, db_name, port_number):
    try:
        ca_path = "rds-combined-ca-bundle.pem"
        ssl_args = {'ssl_ca': ca_path}
        engine = create_engine(url="mysql+pymysql://" + username + ":" + passwd + "@" + hostname + ":" + str(port_number) + "/" + db_name,execution_options={"isolation_level": "AUTOCOMMIT"},connect_args=ssl_args)
        cnx = engine.connect()
    except SQLAlchemyOperationalError as err:
        err.errno = int(err.args[0].split(") (")[1].split(",")[0])
        if err.errno == 1044:
            print("ERROR: Access is denied to the user '" + username + "' on the database called '" + db_name + "'.")
            print("Please validate that said user has the correct level of access.")
            exit_python()
        elif err.errno == 1045:
            print("ERROR: Access is denied to the user '" + username + "' on host '" + hostname + "'.")
            print("Please validate that the username and password are correct.")
            exit_python()
        elif err.errno == 1049:
            print("ERROR: The database called '" + db_name + "'does not exist.")
            print("Please validate that database name is spelled correctly and exists.")
            exit_python()
        elif err.errno == 2003:
            print("ERROR: Unable to connect to host '" + hostname + "' on port '" + str(port_number) + "'.")
            print("Please validate your network connectivity and that the hostname and port is correct.")
            exit_python()
        else:
            print("ERROR: Unhandled MySQL Error.")
            print(err)
            exit_python()
    else:
        cnx.close()
        return engine



def connect_to_mysql(username, passwd, hostname, db_name, port_number):
    cnx = create_mysql_connection(username, passwd, hostname, db_name, port_number)
    engine = create_mysql_engine(username, passwd, hostname, db_name, port_number)
    return cnx, engine