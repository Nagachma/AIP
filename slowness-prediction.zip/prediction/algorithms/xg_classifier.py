import logging
import pandas as pd
import os
import sys
import numpy as np
from xgboost import XGBClassifier
from algorithms.utility import load_data,read_yaml
#from sklearn.linear_model import LogisticRegression
#from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score,roc_auc_score,confusion_matrix,f1_score
from sklearn.ensemble import IsolationForest
from datetime import timedelta
from xgboost import plot_tree
from matplotlib import pyplot as plt
from matplotlib import pyplot
from xgboost import plot_importance
import re
import datetime
#import mlflow
#import mlflow.sklearn
import warnings
#from mlflow.entities import Metric
#from mlflow.tracking import MlflowClient
import time
warnings.filterwarnings("ignore")


def gen_final_outcome(service):
    merged=df.merge(df1, on='time',how='left',indicator='outcome').assign(match=lambda d: d['outcome'].eq('both').astype(int))
    merged.to_csv()

def feature_map(xgb):
    plot_tree(xgb,  num_trees=xgb.get_booster().best_iteration)
    #plot_tree(xgb)
    fig = plt.gcf()
    fig.set_size_inches(30, 15)
    plt.show()



def xgboost_model_trainer (input_filename,outcome,time_column,logging_file,model_name,service):
    logging.basicConfig(level=logging.INFO, filename=logging_file,
                        format='%(asctime)s :: %(levelname)s :: %(message)s')
    print('Inside train')
    #print(input_filename)
    experiment_name = service + '_failure_prediction'


    config=read_yaml()
    #mlflow.set_tracking_uri(config['mlflow_url'])
    #mlflow.set_experiment(config['xgb_experiment'][service])
    #config['classification_experiment']={}
    df=load_data(input_filename,time_column)
    print(time_column)
    df.sort_values(by=time_column)
    #print(df['outcome'].unique())
    if len(df['outcome'].unique())!=2:
        print("Wrong number of classes or no other class present")
        sys.exit(1)


    X=df.drop(columns=['outcome',time_column],axis=1)
    print(X.columns)




    Y=df['outcome']

    scale=int((len(Y)-sum(Y))/sum(Y))
    print("scale:",scale)
    print(scale)
    params={ 'max_depth': 6,'scale_pos_weight': 9,'subsample': 0.5}
    #print(config['Xgb_parameters']['Glue'])
    #mlflow.start_run(experiment_name=experiment_name)
    xgb = XGBClassifier(reg_lambda =100,max_depth=6,n_estimators=300,scale_pos_weight=9,subsample=0.7,eta=0.05)
    #mlflow.log_artifact(config['encoder'][0][service],'column_encoder')
    #mlflow.log_params

    #print(Y.unique())
    X_train,X_test,y_train,y_test=train_test_split(X,Y,test_size=0.3)
    # define the datasets to evaluate each iteration
    evalset = [(X_train, y_train), (X_test, y_test)]
    xgb.fit(X_train, y_train, eval_metric='logloss', eval_set=evalset)
    results = xgb.evals_result()

    # plot learning curves
    plt.plot(results['validation_0']['logloss'], label='train')
    plt.plot(results['validation_1']['logloss'], label='test')
    # show the legend
    plt.legend()
    # show the plot
    learning_curve_plot="prediction/model/learning_curve"+service+".png"
    plt.show()
    plt.savefig(learning_curve_plot)
    #xgb.fit(X_train,y_train)
    print("splitting to training and testing dataset")
    logging.info("splitting to training and testing dataset")
    #X_train,X_test,y_train,y_test=train_test_split(X,Y,test_size=0.4)
    print("training classification model using Xgboost classifier")
    logging.info("training classification model using Xgboost classifier")
    print(X_train)
    y_pred_train=xgb.predict(X_train)
    y_pred_test=xgb.predict(X_test)
    accuracy_score_train= accuracy_score(y_train,y_pred_train)
    accuracy_score_test= accuracy_score(y_test,y_pred_test)
    auc_train=roc_auc_score(y_train,y_pred_train)
    auc_test = roc_auc_score(y_test, y_pred_test)
    f1_score_test= f1_score(y_test, y_pred_test)
    f1_score_train=f1_score(y_train, y_pred_train)

    # mlflow.log_metric("accuracy_score_train", accuracy_score_train)
    # mlflow.log_metric("accuracy_score_test", accuracy_score_test)
    # mlflow.log_metric("auc_score_train", auc_train)
    # mlflow.log_metric("auc_score_test", auc_test)
    # mlflow.log_metric("f1_score_test", f1_score_test)
    # mlflow.log_metric("f1_score_train", f1_score_train)



    #mlflow.sklearn.log_model(xgb, model_name)
    print("accuracy:{}".format(accuracy_score_train))
    print("accuracy_test:{}".format(accuracy_score_train))
    print("roc_auc_train:{}".format(auc_train))
    print(confusion_matrix(y_test, y_pred_test))
    print(confusion_matrix(y_train, y_pred_train))
    print("f1_score_test:{}".format(f1_score_test))
    print("f1_score_train:{}".format(f1_score_train))
    logging.info("accuracy:{}".format(accuracy_score_train))
    logging.info("accuracy_test:{}".format(accuracy_score_train))
    logging.info("roc_auc_test:{}".format(auc_test))
    # mlflow.end_run()


    #filename = 'model/model.json'

    #output_file='performance.txt'
    #filename='model/'+model_name
    #print('------')
    #print(filename)
    print()
    xgb.save_model(model_name)
    print('Saving model in file name %filename')
    logging.info('Saving model in file name %filename')

    return
def get_snapshot(df,time_now,time_column):

    start_time=time_now-timedelta(hours=4)
    #print(start_time,time_now)
    df_new=df[(df[time_column]>=start_time) & (df[time_column]<=time_now)]
    #print(df_new)
    return df_new

def find_anamoly(df_snap,prob_score,time_column):
    config = read_yaml()
    #print('finding anamoly in snapshot')

    model=IsolationForest(n_estimators=100,max_samples='auto',contamination=float(0.1),random_state=42)
    if(config['training_flag'])== 'training':
        X=df_snap.drop([time_column,'outcome','temp_index'],axis=1).copy()
    else:

        X = df_snap.drop([time_column,'temp_index'], axis=1).copy()


    model.fit(X.values)
    y_score=model.score_samples(X.values)
    y_pred=model.predict(X.values)

    df_snap['anomaly_score'] = y_pred.copy()

    #print(df_snap['anomaly_score'])
    df_snap['score']=y_score.copy()
    df_snap.loc[:,'prob_score']=prob_score

    flag=0
    df_snap['score']=df_snap['score'].round(2)
    for i in df_snap['anomaly_score']:
        if i==-1:
            flag=1
    largest=df_snap['score'].nlargest(1, keep='first')
    largest=largest.iloc[0].round(2)
    if flag==0:

        df_snap.loc[df_snap['score']==largest, 'anomaly_score'] = -1



    df_snap=df_snap[df_snap['anomaly_score']==-1]

    return df_snap
def xgboost_model_predict(model_path,input_file,unaggregated_input,time_column,outcome_file,output_file,feature_file,logging_file,train_flag,service):
    logging.basicConfig(level=logging.INFO, filename=logging_file,
                        format='%(asctime)s :: %(levelname)s :: %(message)s')
    pd.set_option('mode.chained_assignment', None)

    Job_running_status = 1
    config=read_yaml()
    # experiment_name = config['predict_xgb_prob_exp'][service]
    # #EXPERIMENT_ID = mlflow.create_experiment(experiment_name)
    # print(experiment_name)
    # current_experiment=dict(mlflow.tracking.MlflowClient().get_experiment_by_name(experiment_name))
    # exp_id2 = current_experiment['experiment_id']
    # print(exp_id2)
    # #print(experiment_name)
    # mlflow.set_tracking_uri(config['mlflow_url'])
    # mlflow.set_experiment(experiment_name)
    #print()

    #try:
    df=load_data(input_file,time_column)
    df.info()
    # if config['training_flag']=='train':
    #     client = mlflow.tracking.MlflowClient()
    #     #infos = client.list_run_infos('0')
    #     training_experiment=config['xgb_experiment'][service]
    #
    #     current_training_experiment=dict(mlflow.tracking.MlflowClient().get_experiment_by_name(training_experiment))
    #     print(current_training_experiment)
    #     df_run=mlflow.search_runs([current_training_experiment['experiment_id']],order_by=["end_time DESC"])
    #     run_id=df_run.loc[0,'run_id']
    #     loaded_model=mlflow.pyfunc.load_model(f"runs:/{run_id}/model")
    #     #                   print(client.list_run_infos(experiment_id=current_training_experiment))
    #     #print(mlflow.list_run_infos(current_training_experiment))
    # else:
    #     model_name=config['xgb_model'][service]
    #     #model_name='S3_Failure_prediction'
    #     model_uri = f"models:/{model_name}/1"
    #     loaded_model = mlflow.sklearn.load_model(model_uri)
    # #df[time_column]=df.index
    # #df.info()

    if config['training_flag']== 'train':
        if len(df['outcome'].unique())!=2:
            raise Exception('the aggregated dataset doesnt contain all classes ')
    xgb=XGBClassifier()
    logging.info("loading xgb model from file")

    if os.path.exists(model_path):
        xgb.load_model(model_path)
        print("loaded xgb model from file")
        print("loading unaggregated data")
        logging.info("loaded xgb model from file")
        logging.info("loading unaggregated data")
    else:
        raise Exception('trained model  not present ')
    df_unag=load_data(unaggregated_input,time_column)
    if(config['training_flag'])=='train':
        X=df.drop([config['time'],'outcome'],axis=1)
    else:
        X = df.drop([config['time']], axis=1)

    logging.info("predicting failure")


    outcome=xgb.predict_proba(X)
    #print(outcome)
    #feature_map(xgb)



    df['outcome_proba']=[i[1] for i in outcome]
    print('---------probaility score')
    print(df['outcome_proba'])
    # client = MlflowClient()
    # with mlflow.start_run(experiment_id=exp_id2):
    #     client.log_batch(mlflow.active_run().info.run_id,metrics=[Metric(key="sample_list", value=val, timestamp=int(time.time() * 1000), step=0) for val in df['outcome_proba'].tolist()])

        #mlflow.log_metric('failure_probability',df['outcome_proba'][0])
#    mlflow.log_metric("failure_probability:",df['outcome_proba'])
    #mlflow.log_batch(mlflow.active_run().info.run_id, metrics=[Metric(key="probabilty_score", value=val, timestamp=time, step=0) for val,time in zip(df['outcome_proba'].to_list(),df['MetricDate'].to_list())])
    #df['outcome'] = (xgb.predict_proba(X)[:, 1] >= 0.3).astype(bool)
    df['outcome']= df['outcome_proba'].apply(lambda x:1 if x >= config['classification_threshold'][service] else 0)
    df.to_csv(config['outcome_list'][service])
    feature_importances = pd.Series(xgb.feature_importances_, index=X.columns)

    df_filtered=df[df['outcome']==1]

    #df_filtered.info()

    if(df_filtered.shape[0]!=0):

        Job_running_status=0

        df_anamoly = pd.DataFrame()
        logging.info('loading snapshot data..')
        logging.info('finding cause of failure..')

        for index,row in df_filtered.iterrows():
            if row['outcome']==1:
                logging.info('loading snapshot data..')
                #print(row[str(time_column)])
                df_snap = get_snapshot(df_unag,row[time_column],time_column)
                prob_score=row['outcome_proba']

                #logging.info('finding cause of failure..')

                if(df_snap.shape[0]!=0):


                    df_anamoly = df_anamoly.append(find_anamoly(df_snap,prob_score,time_column),ignore_index=True)



        df_anamoly.to_csv(config['output_list'][service],index=False)


        feature_importances = pd.Series(xgb.feature_importances_, index=X.columns)
        df_feature=feature_importances.transpose()


        df_feature.to_csv(config['feature_list'][service])




    else:
        print("No Failures in the run")
        logging.info("No Failures in the run")
        Job_running_status = 1

    return Job_running_status
    ##logging.info('the prediction failed because of ',e)

