# This is a sample Python script.
import logging
import sys
import yaml
import pandas as pd
import re
import os
import shutil
import datetime
import pickle

import algorithms.time_forecast
from algorithms.utility import find_csv_filenames,find_service,update_yaml_service,process_data,check_create_folder,get_latest_input,update_yaml,connect_to_mysql,fetch_correlation_metric,read_from_db,load_data,store_fields,check_columns,add_columns,check_model_columns,identify_live_service,read_from_db_train
from algorithms.Logistic_regression_classification import lr_model_trainer
#from algorithms.time_forecast import process_outcome,time_forecast_training,time_forecast_training_prediction
from algorithms.kendall import kendall_model
from algorithms.xg_classifier import xgboost_model_trainer,xgboost_model_predict
from algorithms.aggregation import batcher
from datetime import datetime, timedelta
from algorithms.time_forecast import train_linear_regression
import warnings
import hvac
#import mlflow
#import mlflow.sklearn
warnings.filterwarnings("ignore")
failure_occured=0

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
def gen_final_outcome(service):
    my_config = read_yaml()
    df=pd.read_csv(my_config['processed_file_list'][service])
    df1=pd.read_csv(my_config['outcome_list'][service])
    merged = df.merge(df1, on=my_config['time'], how='left', indicator='match')

    print(my_config['correlation_metric'][service])
    merged[str(service)+'_'+str(my_config['correlation_metric'][service])] = merged['match'].apply(lambda x: 1 if x == 'both' else 0)

    merged[str(service)+'_'+str(my_config['correlation_metric'][service])].to_csv(my_config['final_outcome_file'][service],index=False)

    return

def get_db_connection(vault_url,vault_key):

    client = hvac.Client(
    url=vault_url,
    verify = False,
    token=vault_key,
    )
    db_response = client.secrets.kv.read_secret_version(path='orchestraidb')
    
    return db_response

def concat_kendall():
    my_config = read_yaml()
    print("inside conact")
    for i in my_config['final_outcome_file'].values():
        #print(i)
        if not (os.path.exists(i)):
            logging.error('no outcome files')
            print('no outcome files')
            return
    #print('reading_outcome file')
    list1=[]
    df=pd.DataFrame()
    for i in my_config['live_services']:
        df1 = pd.read_csv(my_config['final_outcome_file'][i])
        column_name=df1.columns.to_list()[0]
        #print(column_name)
        df[column_name]=df1[column_name]

    #if failure_occured==1:

    df.drop(df.filter(regex="Unname"), axis=1, inplace=True)
    df['outcome_temp_index']=df.index


    input_df = pd.melt(df,id_vars=['outcome_temp_index'], var_name="correlated_metrics", value_name="correlated_value")
    #service,ts=find_service(my_config['Input_Files'][0]['S3'])
    #input_df['metric_collection_timestamp'] = ts
    #input_df['outcome_state'] = 'failure'
    vault_url = config['platformops']['vault_url']
    vault_key = config['platformops']['vault_key']
    key_url = config['platformops']['key_url']

    db_details = get_db_connection(vault_url,vault_key)

    jdbc_url = db_details['data']['data']['jdbc-url']
    db_username = db_details['data']['data']['username']
    db_passowrd = db_details['data']['data']['password']
    db_host = jdbc_url.split("/")[-2].split(":")[0]
    db_name = jdbc_url.split("/")[-1]

    
    mysql_cnx, mysql_engine = connect_to_mysql(db_username,db_passowrd,db_host, db_name, 3306)
    mysql_cursor = mysql_cnx.cursor()
    select_failure = "SELECT * FROM `metrics_proc_staging_data`where outcome_state = '{outcome}'".format(
        outcome='failure')
   #print(input_df)
    # print(select_failure)
    kendall_failure_df = pd.read_sql(select_failure, mysql_cnx, index_col='metrics_proc_staging_data_id')
    input_df.to_csv(my_config['kendal_input_file'],index=False)
    if kendall_failure_df.empty == True:
        print('updated db')
        input_df['correlated_value'].fillna(0,inplace=True)
        input_df.to_sql(name='metrics_proc_staging_data', con=mysql_engine, if_exists='append', index=False)
        #print("written to db")
    else:
        print('not updating db')
    return
def time_forecast(temp_index,time_model,processed_file,service):
    config=read_yaml()
    #print(time)
    df=load_data(processed_file,config['time'])
    df=df.loc[df['temp_index']==temp_index]
    model_name = config['xgb_model'][service]
    # model_name='S3_Failure_prediction'
    #model_uri = f"models:/{model_name}/1"
    #loaded_model = mlflow.sklearn.load_model(model_uri)
    #df.drop
    #print('-----')
    #print(df.columns)
    loaded_model = pickle.load(open(time_model, 'rb'))
    df.drop([config['time'],'ErrorMessage',config['Time_predict_column'][service],'temp_index'],inplace=True,axis=1,errors='ignore')
    df['time']=loaded_model.predict(df)
    #print('-----')
    #print(df)
    #print("test...")
    #print(df['time'].values)
    return df['time'].values
# def predict_time(output_file, input_file, final_output, current_time,name_field,service):
#     #date_time_obj = datetime.strptime(current_time, '%m/%d/%Y %H:%M:%S')
#     my_config = read_yaml()
#     print(2)
#     time_column=my_config['time']
#     df = pd.read_csv(output_file, parse_dates=[time_column])
#     df1 = pd.read_csv(input_file, parse_dates=[time_column,my_config['Start_time'][0][service]])
#     #print(df1.columns)
#     if df.dtypes[time_column] == 'object':
#         df[time_column] = pd.to_datetime(time_column)
#     list2 = [time_column,my_config['Start_time'][0][service]]
#     if name_field != 'None':
#         list2.append(name_field)
#
#     df1 = df1[list2]
#
#     df_merged = pd.merge_asof(df, df1, on=time_column)
#
#     df_merged.sort_values(['score'])
#     if df_merged.shape[0]>1:
#         df_record = df_merged.iloc[0]
#     #current_time = df_record[my_config['Start_time'][0][service]] + pd.to_timedelta(15, unit='m')
#     #print(current_time)
#     #print(df_record)
#     #sys.exit(1)
#     time=time_forecast(df_record[my_config['time']],my_config['time_prediction_model_list'][service],my_config['processed_file_list'][service],service)
#     print(time/60000)
#     sys.exit(1)
#     if my_config['test_mode']=='test':
#         current_time=df_record[my_config['Start_time'][0][service]]+pd.to_timedelta(15, unit='minutes') #this line is added for testing only since we use past data change the mode to 'execute'while testing in live data will take the current time
#         #print(current_time)
#     else:
#         now = datetime.now()
#         current_time = now.strftime('%m/%d/%Y %H:%M:%S')
#
#     time_difference = current_time - df_record[my_config['Start_time'][0][service]]
#
#
#     minutes = time_difference.total_seconds() / 60
#     df_record['elapsed_time'] = minutes
#
#
#
#
#     timetofailure =  df_record['elapsed_time'] * df_record['prob_score']
#
#
#     df_record['ttf'] = current_time + timedelta(minutes=timetofailure)
#     df_record['ttf'] = df_record['ttf'].strftime("%Y-%m-%d %H:%M:%S")
#
#     return df_record
def predict_time(output_file, input_file, final_output, current_time,name_field,service):
    #date_time_obj = datetime.strptime(current_time, '%m/%d/%Y %H:%M:%S')
    print('predicting time')
    my_config = read_yaml()

    time_column=my_config['time']
    start_time_column=my_config['start_time'][service]
    df = pd.read_csv(output_file, parse_dates=[time_column])
    df1 = pd.read_csv(input_file, parse_dates=[time_column,my_config['start_time'][service]])
    #df1.info()
    #df1 = pd.read_csv(input_file, parse_dates=[time_column])
    #print('------final')
    #print(df)
    if df.dtypes[time_column] == 'object':
        df[time_column] = pd.to_datetime(time_column)
    #list2 = [time_column,my_config['Start_time'][0][service]]
    list2 = [time_column,start_time_column,'temp_index']
    if name_field != 'None':
        list2.append(name_field)

    df1 = df1[list2]

    #df_merged = pd.merge_asof(df, df1, on='temp_index')
    df_merged = pd.merge(df, df1, on='temp_index')

    df_merged.sort_values(['score'],ascending=False,inplace =True)
    #print(df_merged)

    if df_merged.shape[0]>1:
        df_record = df_merged.iloc[0]
    #print(df_record)

    time=time_forecast(df_record['temp_index'],my_config['time_prediction_model_list'][service],my_config['processed_file_list'][service],service)
    time=time*(1/my_config['time_conversion'][service])
    print("time--------")
    print(time)


    df_record['ttf'] = df_record[my_config['start_time'][service]] + pd.to_timedelta(time[0], unit='minutes')
    df_record['ttf'] = df_record['ttf'].strftime("%Y-%m-%d %H:%M:%S")
    #df_record['Job name'] = "job_name1"
    #print(df_record)
    return df_record

def create_output(feature_file):
    df_output = pd.read_csv(feature_file, header=None,skiprows=1, names=['causal_x_metric', 'coefficient'])
    #print(df_output.info())
    #df_output = df_output.iloc[1:]
    df_output['causal_x_metric'] = df_output['causal_x_metric'].apply(lambda x: x.replace('_' + x.split('_')[-1], ''))
    df_output=df_output.sort_values('coefficient', ascending=False).drop_duplicates('causal_x_metric')
    #print(df_output)
    return df_output

def check_service(file_name,service_list):
    if file_name in service_list:
        return file_name
    else:
        #print("Enter proper service")
        return



def read_yaml(config='prediction/Config/test.yml'):
    """ A function to read YAML file"""
    with open(config) as f:
        config = yaml.safe_load(f)
    return config


    return str(service+'_'+root+'_'+time_stamp)
# Press the green button in the gutter to run the script.
def remove_space(string):
    return string.replace(" ","")

#if __name__ == '__main__':
def main(args):
    '''This is the main function or entry gateway calling different processes of failure prediction'''
    #print(arg)



    arg_list=args.split(' ')

    #sys.exit(1)
    #print(arg_list)
    # read the yaml file for various configuration and file paths
    my_config = read_yaml()
    #setting the logger function for logging
    logging.basicConfig(level=logging.INFO, filename=my_config['main_log'],
                        format='%(asctime)s :: %(levelname)s :: %(message)s')
    #print(my_config['time'])
    global failure_occured
    action=''

    input_path='prediction/input/'
    train_path='prediction/training/'
    if my_config['test_mode']=='test':
        print('running in testing mode...')
    pd.options.mode.chained_assignment = None

    folder_list=['Config','input','logging','output','training'] #list of folders required for running failure prediction
    print("checking and creating relevant folders")
    logging.info('checking and creating folders ')
    # checking if required folders are present else create required folders
    for folder in folder_list:
        check_create_folder('prediction/',folder)

     #Check and update input/training files present in configuration files if not present
    # if len(my_config['Input_Files'])==0 or len(my_config['Training_files'])==0:
    #     logging.info('Input files not present')
    #     print('Input files not present')
    #     os.remove('prediction/Config/test.yml')
    #     shutil.copyfile('prediction/Config/new.yml', 'prediction/Config/test.yml')
    #     #finding csv files in the given folder
    #     file_list=find_csv_filenames('prediction/input', suffix=".csv")
    #     if len(os.listdir(train_path)) == 0:
    #         service = 'Glue'
    #         timestamp = 141911232022
    #     else:
    #         # finding  the lates files in the file path
    #         max_file = get_latest_input(input_path)
    #         # getting service name and timestamp from the file name
    #         service, timestamp = find_service(max_file)
    #
    #     #updating the yaml file based on latest file name
    #     update_yaml(timestamp, 'prediction/Config/test.yml')
    #     #reading the current yaml file
    #     my_config = read_yaml()
    #
    # else:
    #     print('reset the yaml file or provide input/training file')
    #     logging.info("reset the yaml or provide input file")
    #used for parsing the action along with the relevant service name
    service_name=''
    if len(arg_list) == 1:
        #print("test")
        action = arg_list[0]
    elif len(arg_list) == 2:
       action, service_name = arg_list[0],arg_list[1]
    elif len(sys.argv) == 3:
        action,service_name,training_mode= arg_list[0],arg_list[1],arg_list[2]
    my_config = read_yaml()

    logging.info('check if service name is present')
    print("checking service name is present")
    if '_' in service_name:
        service_name=service_name.replace('_'," ")
    if service_name!='':
        service=check_service(service_name,my_config['service_list'])


    if action =='yaml_reset':
        #resetting yaml file based on latest input or training file based explicit yaml_reset call
        print('resetting yaml')
        logging.info('resetting service name')
        os.remove('prediction/Config/test.yml')
        shutil.copyfile('prediction/Config/new.yml', 'prediction/Config/test.yml')
        print(my_config['training_flag'])
        # taking the current file from either input/training folder based on the training mode configured in the yaml file
        if my_config['training_flag']=='predict':
            #uses the input folder for latest file for yaml reset
            #print(os.listdir(input_path))
            if len(os.listdir(input_path)) == 0:
                service = 'Glue'
                timestamp = 141911232022
            else:
                input_file_list = get_latest_input(input_path)
                for i in input_file_list:
                    #max_file = get_latest_input(input_path)
                    print("-------------")
                    print(i)
                    service, timestamp = find_service(i)
                    print(service)
                    print(timestamp)
                    update_yaml(timestamp,service, 'prediction/Config/test.yml')
        elif my_config['training_flag']=='train':
            input_file_list=get_latest_input(train_path)
            for i in input_file_list:

                print("testing")
                #uses training folder for identifying latest filesfor yaml reset

                #max_file = get_latest_input(train_path)
                service, timestamp = find_service(i)
                #timestamp='175601122023'
                print(service)
                print(timestamp)
                print(i)
                update_yaml(timestamp,service, 'prediction/Config/test.yml')
        my_config = read_yaml()
        print('completed reset')
    #print(my_config['time'])
    elif action=='batch':
        logging.info('batching in %s',my_config['training_flag'])
        training_mode=my_config['training_flag']
        if training_mode=='predict':
            print("batching prediction file")
            print(my_config['processed_file_list'][service])

            process_data(my_config['Input_Files'][service], my_config['time'], my_config['processed_file_list'][service],service)

            batcher(my_config['processed_file_list'][service],my_config['prediction_aggregated_file'][service],my_config['window'], my_config['Shift'],my_config['time'],training_mode,service)
        elif training_mode=='train':
            print(service)
            print("btaching for training file")
            #print(my_config['Input_Files'][0][service])
            print(my_config['Training_files']['Informatica Power Exchange'])
            print(my_config['Training_files'][service])
            store_fields(my_config['Training_files'][service], service)
            process_data(my_config['Training_files'][service], my_config['time'], my_config['training_processed_files'][service],service)

            batcher(my_config['training_processed_files'][service],my_config['aggregated_metrics'][service], my_config['window'], my_config['Shift'],my_config['time'],training_mode,service)
        else:
            logging.error('Enter proper training flag')
            print("enter proper training flag")

    elif action=='train_xgb':
        logging.info('training started')
        print('training started')
        training_mode=my_config['training_flag']

        xgboost_model_trainer(my_config['aggregated_metrics'][service],my_config['training_outcome_list'][service],my_config['time'],my_config['training_logging_file'][service],my_config['model_prob'][service],service)
        job_running_status = xgboost_model_predict(my_config['model_prob'][service],
                                                   my_config['aggregated_metrics'][service],
                                                    my_config['training_processed_files'][service],
                                                   my_config['time'],
                                                    my_config['training_outcome_list'][service],
                                                    my_config['output_list'][service],
                                                    my_config['feature_list'][service],
                                                    my_config['prediction_logging_file'][service], training_mode,
                                                    service)

        #print(my_config['processed_file_list'][0][service], my_config['time_prediction_training_logging_file'][0][service], my_config['time_prediction_model_file_name'][0][service])
        train_linear_regression(my_config['training_processed_files'][service], my_config['time_prediction_training_logging_file'][service], my_config['lr_model'][service], 'test.txt', my_config['Time_predict_column'][service], service)

    elif action=='predict_xgb':
        logging.info('prediction started')
        print('prediction started')
        training_mode=my_config['training_flag']
        #job_running_status=1
        if training_mode=='train':
            job_running_status=xgboost_model_predict(my_config['model_prob'][service], my_config['aggregated_metrics'][service], my_config['training_processed_files'][service],my_config['time'],my_config['training_outcome_list'][service],my_config['output_list'][0][service],my_config['feature_list'][0][service],my_config['prediction_logging_file'][0][service],training_mode,service)
        elif training_mode=='predict':
            #print(service)
            job_running_status=xgboost_model_predict(my_config['model_prob'][service], my_config['prediction_aggregated_file'][service],
                                  my_config['processed_file_list'][service],
                                  my_config['time'],
                                  my_config['training_outcome_list'][service], my_config['output_list'][service],
                                  my_config['feature_list'][service],
                                  my_config['prediction_logging_file'][service], training_mode,service)
        print('---------------------')
        print('job_run_status:',job_running_status)
        if job_running_status==1:
            gen_final_outcome(service)
            logging.info("no failures in the time window")

            output=pd.DataFrame(columns=['Time_to_failure','job_name','OutcomeMetric','correlation_metric','causal_x_metric','coefficient_value'])
            output.to_csv(my_config['prediction_file_list'][service])
            output.to_csv(my_config['filtered_prediction_file_list'][service])


        else:
            gen_final_outcome(service)
            failure_occured=1
            #print('batching..')
            if my_config['test_mode']== 'test':
                date_time_obj = datetime.strptime(my_config['current_time'], '%m/%d/%Y %H:%M:%S')
            else:
                now = datetime.now()
                date_time_obj=now.strftime( '%m/%d/%Y %H:%M:%S')

            #print(my_config['output_list'][0][service],my_config['Input_Files'][0][service],my_config['prediction_file_list'][0][service],date_time_obj,my_config['name_column'][0][service])
            df_record=predict_time(my_config['output_list'][service],my_config['Input_Files'][service],my_config['prediction_file_list'][service],date_time_obj,my_config['name_column'][service],service)
            list2 = ['ttf']
            if my_config['name_column'][service] != 'None':
                list2.append(my_config['name_column'][service])
            df_output=create_output(my_config['feature_list'][service])
            df_record=df_record[list2]

            df_output['Job_name'] = df_record[my_config['name_column'][service]]
            print(df_record['ttf'])

            df_output['Time_Of_Failure']=df_record['ttf']
            df_output['OutcomeMetric ']='Failure'

            df_output['correlation']=my_config['correlation_metric'][service]

            df_output.reset_index()
            df_output.columns = df_output.columns.str.replace(" ", "")

            df_filtered=df_output.nlargest(3, ['coefficient'])
            df_filtered.columns = df_filtered.columns.str.replace(" ", "")
            df_filtered.reset_index()

            df_filtered.to_csv(my_config['filtered_prediction_file_list'][service],columns = ['OutcomeMetric', 'correlation', 'Time_Of_Failure', 'causal_x_metric','coefficient','Job_name'],index=False)

            df_output.to_csv(my_config['prediction_file_list'][service],columns = ['OutcomeMetric', 'correlation', 'Time_Of_Failure', 'causal_x_metric','coefficient','Job_name'],index=False)


    elif action=='kendall':
        print("creating  kendall input ")
        if failure_occured==1:
            concat_kendall()
        else:
            logging.info("no failures occured in any of the service")
            print("no failures occured in any of the service")

    elif action =='read_db':
        #print(my_config['Database'],my_config['service_list'],my_config['read_db_log'])
        print('reading from db')

        job_running=read_from_db(my_config['Database'],my_config['service_list'],my_config['read_db_log'],my_config)
        print('completed read from db')
        #job_running=0

        if job_running==0:
            file_list = find_csv_filenames('prediction/input')
            #print(file_list)
            service_list=[]
            for i in file_list:
                service,timestamp=find_service(i)
                service_list.append(service)
                print(my_config['check_column_log'][service])
                flag,list1=check_columns('prediction/input/'+str(i),service,my_config[service+'_Column_name'],my_config['check_column_log'][service])
                print(flag,list1)
                print('columns not in db:',str(list1))
                if flag==1:
                    logging.info("the input file has not have {column_list}".format(column_list=str(list1)))
                    input_data = pd.read_csv('prediction/input/'+str(i))
                    for name in list1:
                        input_data[name] = 0

                    input_data.to_csv('prediction/input/'+str(i))
                    #print(list1)
                print("***********")
                print (list1)
                add_columns('prediction/input/'+str(i), list1,service)
                check_model_columns('prediction/input/'+str(i),service)

    elif action == 'read_db_train':
        read_from_db_train("QA")


    else:
        print('enter proper keyword')
    return


# See PyCharm help at https://www.jetbrains.com/help/pycharm/
