#####
#
# upload_to_mysql.py is a Python program that processes 
# output CSVs containing metrics from various cloud services
# and uploads this data in the correct format to MySQL tables
# used by AIOPS/XOPS 
#
# Version 1.00 - 2022/09/29
#
#
######

from datetime import datetime, timedelta
from numpy import nan as NaN
from os import scandir as scan_directory
from pandas import DataFrame
from pymysql import connect as mysql_connect
from pymysql.err import OperationalError as PyMySQLOperationalError
from sqlalchemy import create_engine
from sqlalchemy.exc import OperationalError as SQLAlchemyOperationalError
from sys import exit as exit_python
from tabulate import tabulate
import os
import logging
import yaml
import requests
import hvac

def read_yaml():
    """ A function to read YAML file"""
    with open('prediction/Config/new.yml') as f:
        config = yaml.safe_load(f)

    return config

##################################################
#
#	name: 	create_mysql_connection
# 	desc:	function that creates a PyMySQL connection object.
#			Connection is used to create a cursor object that can be
#			called to execute arbitary SQL code on a MySQL database.
#	args:
#			username	- username of user in MySQL
#			passwd		- password of user  in MySQL
#			hostname	- hostname of the MySQL Server
#			db_name		- database name in the MySQL Server
#			port_number	- port number of the MySQL Server
#	returns:
#			cnx			- A PyMySQL Connection object
#
#################################################
def create_mysql_connection(username,passwd,hostname,db_name,port_number):
    url = "https://s3.amazonaws.com/rds-downloads/rds-combined-ca-bundle.pem"
    filename = "rds-combined-ca-bundle.pem"
    response = requests.get(url, verify=False)
    with open(filename, "wb") as f:
        f.write(response.content)
    # SSL_CA = os.path.abspath(filename)
    SSL_CA = filename
    print(SSL_CA)
    try:
        cnx = mysql_connect(user=username,password=passwd,host=hostname,database=db_name,port=port_number,autocommit=True,ssl_ca=SSL_CA)
    except PyMySQLOperationalError as err:
        err.errno = err.args[0]
        if err.errno == 1044:
            print("ERROR: Access is denied to the user '" + username + "' on the database called '"+ db_name + "'.")
            print("Please validate that said user has the correct level of access.")
            exit_python()
        elif err.errno == 1045:
            print("ERROR: Access is denied to the user '" + username + "' on host '" + hostname + "'.")
            print("Please validate that the username and password are correct.")
            exit_python()
        elif err.errno == 1049:
            print("ERROR: The database called '" + db_name + "'does not exist.")
            print("Please validate that database name is spelled correctly and exists.")
            exit_python()
        elif err.errno == 2003:
            print("ERROR: Unable to connect to host '"+ hostname + "' on port '" + str(port_number) + "'.")
            print("Please validate your network connectivity and that the hostname and port is correct.")
            exit_python()
        else:
            print("ERROR: Unhandled MySQL Error.")
            print(err)
            exit_python()
    else:
        return cnx

##################################################
#
#	name: 	create_mysql_engine
# 	desc:	function that creates a SQLAlchemy connection engine object.
#			The engine is used by pandas DataFrame's to_sql function
#			to insert DataFrames into MySQL tables.
#	args:
#			username	- username of user in MySQL
#			passwd		- password of user in MySQL
#			hostname	- hostname of the MySQL Server
#			db_name		- database name in the MySQL Server
#			port_number	- port number of the MySQL Server
#	returns:
#			engine		- A SQLAlchemy Engine object
#
#################################################
def create_mysql_engine(username,passwd,hostname,db_name,port_number):
    try:
        ca_path = "rds-combined-ca-bundle.pem"
        ssl_args = {'ssl_ca': ca_path}
        engine = create_engine(
            url="mysql+pymysql://" + username + ":" + passwd + "@" + hostname + ":" + str(port_number) + "/" + db_name,
            execution_options={"isolation_level": "AUTOCOMMIT"}, connect_args=ssl_args)
        cnx = engine.connect()
    except SQLAlchemyOperationalError as err:
        err.errno = int(err.args[0].split(") (")[1].split(",")[0])
        if err.errno == 1044:
            print("ERROR: Access is denied to the user '" + username + "' on the database called '"+ db_name + "'.")
            print("Please validate that said user has the correct level of access.")
            exit_python()
        elif err.errno == 1045:
            print("ERROR: Access is denied to the user '" + username + "' on host '" + hostname + "'.")
            print("Please validate that the username and password are correct.")
            exit_python()
        elif err.errno == 1049:
            print("ERROR: The database called '" + db_name + "'does not exist.")
            print("Please validate that database name is spelled correctly and exists.")
            exit_python()
        elif err.errno == 2003:
            print("ERROR: Unable to connect to host '"+ hostname + "' on port '" + str(port_number) + "'.")
            print("Please validate your network connectivity and that the hostname and port is correct.")
            exit_python()
        else:
            print("ERROR: Unhandled MySQL Error.")
            print(err)
            exit_python()
    else:
        cnx.close()
        return engine

def connect_to_mysql(username,passwd,hostname,db_name,port_number):
    cnx = create_mysql_connection(username,passwd,hostname,db_name,port_number)
    engine = create_mysql_engine(username,passwd,hostname,db_name,port_number)
    return cnx, engine

def predicited_correlation_csvs():
    predicited_csv_files = []
    with scan_directory(path="./prediction/output/") as file_list:
        for file in file_list:
            if file.is_file() and file.name.endswith(".csv"):
                predicited_csv_files.append(file.path)

    casual_csv_dict = {}
    correlated_csv_dict = {}
    print (predicited_csv_files)
    for csv_path in predicited_csv_files:
        csv_file = csv_path.split("/")[-1].split(".csv")[0]
        print(csv_file)
        print(len(csv_file.split("_")))
        if len(csv_file.split("_")) <= 3:
            continue
        correlation = csv_file.split("_")[0]
        if correlation.lower() != "kendall":
            service = csv_file.split("_")[0]

            if csv_file.split("_")[3] != "filtered" and not csv_file.split("_")[3].isnumeric():
                service += "_" + csv_file.split("_")[0]
                if csv_file.split("_")[3] == "filtered":
                    selected = True
                elif csv_file.split("_")[3].isnumeric():
                    selected = False
            elif csv_file.split("_")[3] == "filtered":
                selected = True
            elif csv_file.split("_")[3].isnumeric():
                selected = False
            
            if service not in correlated_csv_dict.keys():
                correlated_csv_dict[service] = {}
            fp = open(csv_path,"r")
            #print (fp.readlines())
            index = 0
            for line in fp.readlines():
                #print (line)
                if index == 0:
                    index += 1
                else:
                    line = line.strip().split(",")
                    metric = line[3]
                    #print (correlated_csv_dict[service])
                    if metric not in correlated_csv_dict[service].keys():
                        try:
                            if not selected:
                                correlated_csv_dict[service][metric] = [line[1],(float(line[4])),0]
                                correlated_csv_dict[service][metric].append(line[0])
                                correlated_csv_dict[service][metric].append(line[2])
                                correlated_csv_dict[service][metric].append(line[5])
                            else:
                                correlated_csv_dict[service][metric] = [line[1],(float(line[4])),1]
                                correlated_csv_dict[service][metric].append(line[0])
                                correlated_csv_dict[service][metric].append(line[2])
                                correlated_csv_dict[service][metric].append(line[5])
                        except ValueError:
                            continue
                    else:
                        if selected:
                            correlated_csv_dict[service][metric][2] = 1
            fp.close()
            #print (correlated_csv_dict)
            #print ("-----------------------------------------")

        elif correlation.lower() == "kendall":
            if csv_file.split("_")[2] == "selected":
                selected = True
            elif csv_file.split("_")[2] == "Data":
                selected = False

            if not selected:
                fp = open(csv_path,"r")
                index = 0
                for line in fp.readlines():
                    if index == 0:
                        headers = line.strip().split(",")[1:]
                        for header in headers:
                            if header not in casual_csv_dict.keys():
                                casual_csv_dict[header] = {}
                        index += 1
                    else:
                        line = line.strip().split(",")
                        metric = line[0]
                        line = line[1:]
                        for i in range(len(line)):
                            if headers[i] not in casual_csv_dict[metric].keys():
                                try:
                                    casual_csv_dict[metric][headers[i]] = [float(line[i]),0,'Not Selected',0]
                                except ValueError:
                                    casual_csv_dict[metric][headers[i]] = [0.0,0,'Not Selected',0]
                fp.close()
            else:
                fp = open(csv_path,"r")
                index = 0
                for line in fp.readlines():
                    if index == 0:
                        index += 1
                    else:
                        line = line.strip().split(",")
                        # print(casual_csv_dict)
                        metric = line[0]
                        if metric not in casual_csv_dict.keys():
                            casual_csv_dict[metric] = {line[1]:[float(line[2]),1,(line[3]),(line[4])]}
                        else:
                            # if 
                            casual_csv_dict[metric][line[1]] = [float(line[2]),1,(line[3]),(line[4])]
                fp.close()
    return correlated_csv_dict,casual_csv_dict

def filter_correlated_dict(predicted_correlated):
    for key in predicted_correlated.keys():
        for j in list(predicted_correlated.get(key)):
            if len(predicted_correlated[key][j]) == 2:
                del predicted_correlated[key][j]

    #print (predicted_correlated)
    return (predicted_correlated)

def filter_casual_dict(predicted_casual):
    for key in predicted_casual.keys():
        for j in list(predicted_casual.get(key)):
            if (predicted_casual[key][j][2] != 1):
                del predicted_casual[key][j]

    return (predicted_casual)

def get_db_connection(vault_url,vault_key):

    client = hvac.Client(
    url=vault_url,
    verify = False,
    token=vault_key,
    )
    db_response = client.secrets.kv.read_secret_version(path='orchestraidb')
    
    return db_response


def write_casual_to_mysql(filtered_casual_dict,mysql_engine,execution_id):
    causal_df_data = {"execution_id":[],"inventory_id":[],"service_id":[],"outcome_metric":[],"job_name":[],"correlation_metric_id":[],"time_of_failure":[],"casual_x_metric_id":[],"coefficient_value":[],"coefficient_flag":[]}
    for key in filtered_casual_dict.keys():
        for subkey in filtered_casual_dict[key].keys():
            mysql_cursor.execute("select service_id from services where service_name='" + key + "'")
            service_id = mysql_cursor.fetchone()[0]
            print ("select metric_id from metrics where metric_name='" + filtered_casual_dict[key][subkey][0] + "'")
            mysql_cursor.execute("select metric_id from metrics where metric_name='" + filtered_casual_dict[key][subkey][0] + "'")
            cor_met = mysql_cursor.fetchone()[0]
            print ("select metric_id from metrics where metric_name='" + subkey + "'")
            mysql_cursor.execute("select metric_id from metrics where metric_name='" + subkey + "'")
            cau_x = mysql_cursor.fetchone()[0]
            print("select inventory_id from inventory where inventory_name ='" + filtered_casual_dict[key][subkey][5] + "' and service_id = 1")
            mysql_cursor.execute("select inventory_id from inventory where inventory_name ='" + filtered_casual_dict[key][subkey][5] + "' and service_id = "+str(service_id))
            try:
                inv_no = mysql_cursor.fetchone()[0]
            except TypeError:
                inv_no = 1

            causal_df_data["execution_id"].append(execution_id)
            causal_df_data["inventory_id"].append(inv_no)
            causal_df_data["service_id"].append(service_id)
            causal_df_data["outcome_metric"].append(filtered_casual_dict[key][subkey][3])
            causal_df_data["correlation_metric_id"].append(cor_met)
            causal_df_data["time_of_failure"].append(filtered_casual_dict[key][subkey][4])
            causal_df_data["casual_x_metric_id"].append(cau_x)
            causal_df_data["coefficient_value"].append(filtered_casual_dict[key][subkey][1])
            causal_df_data["coefficient_flag"].append(filtered_casual_dict[key][subkey][2])
            causal_df_data["job_name"].append(filtered_casual_dict[key][subkey][5])

    df = DataFrame(causal_df_data)
    print(tabulate(causal_df_data,headers=causal_df_data.keys(),tablefmt="psql"))
    df.to_sql(name="predicted_causal_metrics",con=mysql_engine,if_exists="append",index=False,method="multi")

def write_correlated_to_mysql(correlated_dict,mysql_engine,execution_id):
    
    correlated_df_data = {"execution_id":[],"service_id":[],"correlation_metric_id":[],"outcome_metric_id":[],"value":[],"probability_value":[],"rule_name":[],"stickiness_flag":[]}
    for key in correlated_dict.keys():
        for subkey in correlated_dict[key].keys():
            core_metric_key = key.rsplit('_',1)
            corres_metric = subkey.rsplit('_',1)
            print (core_metric_key)
            print (corres_metric)
            if core_metric_key[0].lower() == "sage" :
                core_metric_key[0] = "sagemaker"
            if corres_metric[0].lower() == "sage":
                corres_metric[0] = "sagemaker"
                # print (corres_metric)
            print ("select service_id from services where service_name='" + core_metric_key[0].lower() + "'")
            mysql_cursor.execute("select service_id from services where service_name='" + core_metric_key[0].lower() + "'")
            service_id = mysql_cursor.fetchone()[0]

            print ("select metric_id from metrics where metric_name='" + core_metric_key[1] + "' and service_id = "+str(service_id))
            mysql_cursor.execute("select metric_id from metrics where metric_name='" + core_metric_key[1] + "' and service_id = "+str(service_id))
            cor_met = mysql_cursor.fetchone()[0]

            print ("select service_id from services where service_name='" + corres_metric[0].lower() + "'")
            mysql_cursor.execute("select service_id from services where service_name='" + corres_metric[0].lower() + "'")
            corres_service_id = mysql_cursor.fetchone()[0]

            print ("select metric_id from metrics where metric_name='" + corres_metric[1] + "' and service_id = "+str(corres_service_id))
            mysql_cursor.execute("select metric_id from metrics where metric_name='" + corres_metric[1] + "' and service_id = "+str(corres_service_id))
            outcome_met = mysql_cursor.fetchone()[0]
            
            correlated_df_data["execution_id"].append(execution_id)
            correlated_df_data["service_id"].append(service_id)
            # correlated_df_data["inventory_id"].append(inventory_id)
            correlated_df_data["correlation_metric_id"].append(cor_met)
            correlated_df_data["outcome_metric_id"].append(outcome_met)
            correlated_df_data["value"].append(correlated_dict[key][subkey][0])
            correlated_df_data["probability_value"].append(correlated_dict[key][subkey][2])
            correlated_df_data["rule_name"].append(correlated_dict[key][subkey][3])
            correlated_df_data["stickiness_flag"].append(correlated_dict[key][subkey][1])

    print(tabulate(correlated_df_data,headers=correlated_df_data.keys(),tablefmt="psql"))

    df = DataFrame(correlated_df_data)
    df.to_sql(name="predicted_correlated_metrics",con=mysql_engine,if_exists="append",index=False,method="multi")

if __name__ == "__main__":
    config=read_yaml()
    vault_url = config['platformops']['vault_url']
    vault_key = config['platformops']['vault_key']
    key_url = config['platformops']['key_url']

    db_details = get_db_connection(vault_url,vault_key)

    jdbc_url = db_details['data']['data']['jdbc-url']
    db_username = db_details['data']['data']['username']
    db_passowrd = db_details['data']['data']['password']
    db_host = jdbc_url.split("/")[-2].split(":")[0]
    db_name = jdbc_url.split("/")[-1]

   
   
    mysql_cnx, mysql_engine = connect_to_mysql(db_username,db_passowrd, db_host, db_name, 3306)

    mysql_cursor = mysql_cnx.cursor()

    cur_date = datetime.today()
    # mysql_cursor.execute("insert into metrics_processor_output_time (execution_timestamp) values ('" + cur_date.strftime("%Y-%m-%d %H:%M:%S") + "')")
    mysql_cursor.execute("select MAX(execution_id) from metrics_processor_output_time")
    execution_id = mysql_cursor.fetchone()[0]
    
    predicted_casual, predicted_correlated = predicited_correlation_csvs()
    write_correlated_to_mysql(predicted_correlated,mysql_engine,execution_id)
    
    filtered_casual_dict = filter_casual_dict(predicted_casual)
    
    write_casual_to_mysql(filtered_casual_dict,mysql_engine,execution_id)

