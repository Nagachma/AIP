import entry
import yaml
import sys
import os
import shutil

if not (os.path.exists('prediction/Config/')):
    os.makedirs('prediction/Config/')
shutil.copy2('/config/config.yml', 'prediction/Config/new.yml')
entry.main('yaml_reset')
#entry.main('batch Glue')
#entry.main('predict_xgb Glue')

entry.main('read_db')
config = entry.read_yaml('prediction/Config/new.yml')
# #
print(config['live_services'])
#entry.main('yaml_reset')
if len(config['live_services'])==0:
    print("No jobs running currently")
    sys.exit(0)
entry.main('yaml_reset')
for i in config['live_services']:
    if ' ' in i:
        i=i.replace(' ','_')
        print(i)
    entry.main('batch {service}'.format(service=str(i)))
    entry.main('predict_xgb {service}'.format(service=str(i)))
    #entry.main('batch {service}'.format(service=str(i)))
    #entry.main('predict_xgb {service}'.format(service=str(i)))
#     entry.main('batch {service}'.format(service=str(i)))
#     entry.main('predict_xgb {service}'.format(service=str(i)))
entry.main('kendall')
os.system('python prediction/update_predicited_table.py')
#os.system('python .\\prediction\\update_predicted_table.py')

